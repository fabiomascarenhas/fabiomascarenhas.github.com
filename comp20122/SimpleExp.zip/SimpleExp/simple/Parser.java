package simple;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;

public class Parser {
	Scanner scan;
	Token lookAhead;
	
	public Parser(InputStream in) throws IOException {
		scan = new Scanner(in);
		lookAhead = scan.nextToken();
	}
	
	public Exp parseProg() throws IOException {
		Exp e = parseExp();
		if(lookAhead.type != Token.EOF)
			throw new 
			 	RuntimeException("lixo depois da expressão: " + lookAhead.type);
		return e;
	}
	
	// EXP := TERM { (+|-) TERM }
	public Exp parseExp() throws IOException {
		Exp e = parseTerm();
		while(lookAhead.type == Token.PLUS ||
				lookAhead.type == Token.MINUS) {
			if(lookAhead.type == Token.PLUS){
				lookAhead = scan.nextToken();
				e = new ExpPlus(e, parseTerm());
			} else {
				lookAhead = scan.nextToken();
				e = new ExpMinus(e, parseTerm());
			}
		}
		if(lookAhead.type != Token.EOF &&
				lookAhead.type != Token.RPAR)
			throw new RuntimeException("token após final da expressão: " + lookAhead.type);
		return e;
	}

	public Exp parseTerm() throws IOException {
		Exp e = parseAtom();
		while(lookAhead.type == Token.TIMES ||
				lookAhead.type == Token.DIV) {
			if(lookAhead.type == Token.TIMES){
				lookAhead = scan.nextToken();
				e = new ExpTimes(e, parseTerm());
			} else {
				lookAhead = scan.nextToken();
				e = new ExpDiv(e, parseTerm());
			}
		}
		return e;
	}

	public Exp parseAtom() throws IOException {
		switch(lookAhead.type) {
		case Token.LPAR:
			lookAhead = scan.nextToken();
			Exp exp = parseExp();
			if(lookAhead.type != Token.RPAR)
				throw new RuntimeException("esperava fecha parêntese, encontrei: " + lookAhead.type);
			lookAhead = scan.nextToken();
			return exp;
		case Token.NUM:
			BigDecimal val = lookAhead.val;
			lookAhead = scan.nextToken();
			return new ExpNum(val);
		default:
			throw new RuntimeException("expressão atômica inválida: " + lookAhead.type);
		}
	}
}
