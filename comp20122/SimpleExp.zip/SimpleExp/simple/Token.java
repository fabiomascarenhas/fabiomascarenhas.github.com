package simple;

import java.math.BigDecimal;

public class Token {
	public static final int LPAR = 1;
	public static final int RPAR = 2;
	public static final int PLUS = 3;
	public static final int MINUS = 4;
	public static final int TIMES = 5;
	public static final int DIV = 6;
	public static final int EOF = 7;
	public static final int NUM = 8;
	
	int type;
	BigDecimal val;
	
	public Token(int type) {
		this.type = type;
	}
	
	public Token(int type, BigDecimal val) {
		this.type = type;
		this.val = val;
	}
}
