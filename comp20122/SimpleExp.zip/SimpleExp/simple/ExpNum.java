package simple;

import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;

public class ExpNum implements Exp {
	public BigDecimal val;
	
	public ExpNum(BigDecimal val) {
		this.val = val;
	}

	@Override
	public BigDecimal value() {
		return val;
	}
	
	@Override
	public void compile(Writer out) throws IOException {
		// pilha = ....
		out.append("ldc " + val + "\n");
		// pilha = .... val
	}
}
