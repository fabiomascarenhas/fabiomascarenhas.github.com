package simple;

import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;

public interface Exp {
	public BigDecimal value();
	public void compile(Writer out) throws IOException;
}
