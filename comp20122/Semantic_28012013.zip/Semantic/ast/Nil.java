package ast;

public class Nil extends Exp {

	public Nil(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return null;
	}

	@Override
	public String label() {
		return "nil";
	}

}
