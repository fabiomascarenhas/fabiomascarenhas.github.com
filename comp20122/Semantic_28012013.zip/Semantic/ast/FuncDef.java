package ast;

import java.util.List;

public class FuncDef extends Stat {
	public Id name;
	public List<Id> params;
	public Bloco body;
	
	public FuncDef(Id name, List<Id> params, Bloco body,
			int line, int col) {
		super(line, col);
		this.name = name;
		this.params = params;
		this.body = body;
	}

	@Override
	public void eval(Environment<Object> env) {
		env.update(name.name, new FuncVal(params, body, env));
	}

	@Override
	public String label() {
		// TODO Auto-generated method stub
		return null;
	}

}
