package ast;

public class Neq extends Exp {
	public Exp l;
	public Exp r;
	
	public Neq(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return !l.eval(env).equals(r.eval(env));
	}

	@Override
	public String label() {
		return "~=";
	}

}
