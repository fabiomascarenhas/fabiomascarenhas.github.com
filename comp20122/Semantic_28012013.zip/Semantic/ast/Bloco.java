package ast;

import java.util.List;

public class Bloco extends Stat {
	public List<Stat> stats;
	
	public Bloco(List<Stat> stats, int line, int col) {
		super(line, col);
		this.stats = stats;
	}

	@Override
	public void eval(Environment<Object> env) {
		Environment<Object> benv = env.extend();
		for(Stat s: stats)
			s.eval(benv);
	}

	@Override
	public String label() {
		return "bloco";
	}
}
