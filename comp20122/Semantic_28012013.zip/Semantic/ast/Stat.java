package ast;

public abstract class Stat extends Node {
	public Stat(int line, int col) {
		super(line, col);
	}
	
	public abstract void eval(Environment<Object> env);
}
