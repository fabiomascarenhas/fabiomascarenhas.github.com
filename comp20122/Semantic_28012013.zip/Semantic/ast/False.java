package ast;

public class False extends Exp {

	public False(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return false;
	}

	@Override
	public String label() {
		return "false";
	}

}
