package ast;

public class Index extends Exp {
	public Exp prefix;
	public Id field;
	
	public Index(Exp prefix, Id field, int line, int col) {
		super(line, col);
		this.prefix = prefix;
		this.field = field;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return null;
	}

	@Override
	public String label() {
		return ".";
	}
	
}
