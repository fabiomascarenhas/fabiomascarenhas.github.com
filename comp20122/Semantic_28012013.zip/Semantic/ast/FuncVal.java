package ast;

import java.util.List;

public class FuncVal implements Func {
	public List<Id> params;
	public Bloco corpo;
	public Environment<Object> env;
	
	public FuncVal(List<Id> params, Bloco corpo, Environment<Object> env) {
		this.params = params;
		this.corpo = corpo;
		this.env = env;
	}

	@Override
	public Object apply(Object... args) {
		if(args.length != params.size())
			throw new RuntimeException("# de argumentos não bate com # de parâmetros");
		Environment<Object> fenv = env.extend();
		for(int i = 0; i < args.length; i++) {
			fenv.bind(params.get(i).name, args[i]);
		}
		try {
			corpo.eval(fenv);
			return null;
		} catch(ReturnVal rv) {
			return rv.val;
		}
	}
	
}
