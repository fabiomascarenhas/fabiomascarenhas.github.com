package ast;

public class Id extends Exp {
	public String name;
	
	public Id(String name, int line, int col) {
		super(line, col);
		this.name = name;
	}
	
	public String label() {
		return name;
	}
	
	public Object eval(Environment<Object> env) {
		return env.lookup(name);
	}
}
