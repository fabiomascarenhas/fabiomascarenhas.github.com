package ast;

public class Div extends Exp {
	public Exp l;
	public Exp r;
	
	public Div(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}
	
	public Object eval(Environment<Object> env) {
		return (Double)l.eval(env) / (Double)r.eval(env);
	}
	
	public String label() {
		return "/";
	}
}
