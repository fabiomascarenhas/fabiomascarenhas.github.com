package ast;

public class Menor extends Exp {
	public Exp l;
	public Exp r;
	
	public Menor(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		Comparable<Object> c = (Comparable<Object>)l.eval(env);
		return c.compareTo(r.eval(env)) < 0;
	}

	@Override
	public String label() {
		return "<";
	}

}
