package ast;

public abstract class Exp extends Node {
	public Exp(int line, int col) {
		super(line, col);
	}
	
	public abstract Object eval(Environment<Object> env);
}
