package ast;

public class Atrib extends Stat{
	public Id lval;
	public Exp rval;
	
	public Atrib(Id lval, Exp rval, int line, int col) {
		super(line, col);
		this.lval = lval;
		this.rval = rval;
	}
	
	public String label() {
		return "=";
	}
	
	public void eval(Environment<Object> env) {
		env.update(lval.name, rval.eval(env));
	}
}
