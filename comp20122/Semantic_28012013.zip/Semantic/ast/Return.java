package ast;

public class Return extends Stat {
	public Exp exp;
	
	public Return(Exp exp, int line, int col) {
		super(line, col);
		this.exp = exp;
	}

	@Override
	public void eval(Environment<Object> env) {
		throw new ReturnVal(exp.eval(env));
	}

	@Override
	public String label() {
		return "return";
	}

}
