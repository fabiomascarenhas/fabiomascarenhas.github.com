package ast;

public class Local extends Stat{
	public Id id;
	public Exp rval;
	
	public Local(Id id, Exp rval, int line, int col) {
		super(line, col);
		this.id = id;
		this.rval = rval;
	}
	
	public String label() {
		return "=";
	}
	
	public void eval(Environment<Object> env) {
		if(rval != null)
			env.bind(id.name, rval.eval(env));
		else
			env.bind(id.name, null);
	}
}
