package ast;

public class CallStat extends Stat {
	public Call call;
	
	public CallStat(Call call) {
		super(call.line, call.col);
		this.call = call;
	}

	@Override
	public void eval(Environment<Object> env) {
		call.eval(env);
	}

	@Override
	public String label() {
		return "call";
	}

}
