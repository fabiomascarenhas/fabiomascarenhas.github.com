package ast;

public class While extends Stat {
	public Exp cond;
	public Bloco corpo;
	
	public While(Exp cond, Bloco corpo, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.corpo = corpo;
	}

	@Override
	public void eval(Environment<Object> env) {
		while((Boolean)cond.eval(env)) {
			corpo.eval(env);
		}
	}

	@Override
	public String label() {
		return "while";
	}

}
