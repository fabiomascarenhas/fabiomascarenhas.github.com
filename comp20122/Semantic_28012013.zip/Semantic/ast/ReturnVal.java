package ast;

public class ReturnVal extends RuntimeException {
	public Object val;
	
	public ReturnVal(Object val) {
		this.val = val;
	}
}
