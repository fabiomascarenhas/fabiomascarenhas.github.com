package types;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import ast.Environment;
import ast.Node;

public class GenFunc extends Type {
	public Func func;
	public Set<Var> genVars;
	
	public GenFunc(Func func, Environment<Type> tenv) {
		this.func = func;
		genVars = func.openVars();
		Set<Type> envTypes = tenv.values();
		for(Type t: envTypes) {
			if(t != func) {
				genVars.removeAll(t.openVars());
			}
		}
	}

	@Override
	public Type instantiate() {
		Map<Var,Var> rmap = new HashMap<Var,Var>();
		char olast = Var.last;
		Var.last = 'A';
		for(Var v: genVars) {
			Var nv = new Var();
			rmap.put(v, nv);	
		}
		Var.last = olast;
		return func.replace(rmap);
	}
		
	@Override
	public void unify(Var v, Node n) {
		throw new RuntimeException("linha " + n.line + ", coluna " + n.col + ": tipo polimórfico não pode ser unificado!");
	}

	@Override
	public void unify(Type t, Node n) {
		throw new RuntimeException("linha " + n.line + ", coluna " + n.col + ": tipo polimórfico não pode ser unificado!");
	}
	
	@Override
	public String toString() {
		return instantiate().toString();
	}

}
