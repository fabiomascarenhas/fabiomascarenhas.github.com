package ast;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.List;

import types.Type;
import types.Var;

public abstract class Node {
	public int line;
	public int col;
	
	public Node(int line, int col) {
		this.line = line;
		this.col = col;
	}

	public abstract String label();

	public void typeError(Type t1, Type t2) {
		HashMap<Var, Var> nvars = new HashMap<Var, Var>();
		t1 = t1.replace(nvars);
		t2 = t2.replace(nvars);
		throw new RuntimeException("tipos incompatíveis, linha " + line + ", coluna " + col + ": " + t1 + ", " + t2);
	}
	
	public void constraintError(String tag, Type t) {
		HashMap<Var, Var> nvars = new HashMap<Var, Var>();
		t = t.replace(nvars);
		throw new RuntimeException("linha " + line + ", coluna " + col + ": tipo " + t + " não é " + tag);
	}
	
	public void printDot(String filename) {
		BufferedWriter buf;
		try {
			buf = new BufferedWriter(new FileWriter(filename));
			try {
				buf.write("digraph tree {\n");
				StringBuffer sb = new StringBuffer();
				dot(sb);
				buf.write(sb.toString());
				buf.write("}\n");
			} finally {
				buf.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void dot(StringBuffer buf) {
		Class<? extends Node> c = this.getClass();
		buf.append("\"" + this.toString() + "\"");
		buf.append(" [label=\"");
		buf.append(label());
		buf.append("\"];\n");
		for(Field f: c.getDeclaredFields()) {
			if(Node.class.isAssignableFrom(f.getType())) {
				try {
					Node child = (Node)f.get(this);
					if(child != null) {
						child.dot(buf);
						buf.append("\"" + this.toString() + "\"");
						buf.append(" -> ");
						buf.append("\"" + child.toString() + "\"");
						buf.append(";\n");
					}
				} catch (IllegalAccessException e) {
					throw new RuntimeException(e);
				}
			} else if(List.class.isAssignableFrom(f.getType())) {
				try {
					List l = (List)f.get(this);
					for(Object o: l) {
						Node child = (Node)o;
						child.dot(buf);
						buf.append("\"" + this.toString() + "\"");
						buf.append(" -> ");
						buf.append("\"" + child.toString() + "\"");
						buf.append(";\n");
					}
				} catch (IllegalAccessException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
}


