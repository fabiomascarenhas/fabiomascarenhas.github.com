package ast;

import types.Type;

public class False extends Node implements Exp {

	public False(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return false;
	}

	@Override
	public String label() {
		return "false";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Bool.type;
	}

}
