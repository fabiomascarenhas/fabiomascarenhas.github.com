package ast;

import types.Type;

public class If extends Node implements Stat {
	public Exp cond;
	public Bloco bthen;
	public Bloco belse;

	public If(Exp cond, Bloco bthen, Bloco belse, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.bthen = bthen;
		this.belse = belse;
	}

	@Override
	public void run(Environment<Object> env) {
		if((Boolean)cond.eval(env)) {
			bthen.run(env);
		} else {
			if(belse != null)
				belse.run(env);
		}
	}

	@Override
	public String label() {
		return "if";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type tcond = cond.tcExp(tenv);
		tcond.unify(types.Bool.type, (Node)cond);
		boolean retThen = false;
		try {
			bthen.tcStat(tenv);
		} catch(ReturnVal rv) {
			retThen = true;
		}
		if(belse != null) {
			try {
				belse.tcStat(tenv);
			} catch(ReturnVal rv) {
				if(retThen)
					throw rv;
			}
		}
	}

}
