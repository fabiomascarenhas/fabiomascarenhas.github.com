package ast;

import types.Type;

public interface Stat {
	void run(Environment<Object> env);
	void tcStat(Environment<Type> tenv);
}
