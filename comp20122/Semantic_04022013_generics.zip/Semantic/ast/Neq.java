package ast;

import types.Type;

public class Neq extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Neq(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return !l.eval(env).equals(r.eval(env));
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type tl = l.tcExp(tenv);
		Type tr = r.tcExp(tenv);
		tl.unify(tr, (Node)r);
		return types.Bool.type;
	}

	@Override
	public String label() {
		return "~=";
	}

}
