package ast;

import types.Type;

public class Id extends Node implements Exp {
	public String name;
	
	public Id(String name, int line, int col) {
		super(line, col);
		this.name = name;
	}
	
	public String label() {
		return name;
	}
	
	public Object eval(Environment<Object> env) {
		return env.lookup(name);
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type tinst = tenv.lookup(name).instantiate();
		System.out.println(name + ": " + tinst.prune());
		return tinst;
	}
}
