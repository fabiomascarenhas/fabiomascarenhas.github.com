package ast;

import types.Type;

public class Concat extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Concat(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	public Object eval(Environment<Object> env) {
		return (String)l.eval(env) + (String)r.eval(env);
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type tl = l.tcExp(tenv);
		tl.unify(types.Str.type, (Node)l);
		Type tr = r.tcExp(tenv);
		tr.unify(types.Str.type, (Node)r);
		return types.Str.type;
	}

	public String label() {
		return "..";
	}
}
