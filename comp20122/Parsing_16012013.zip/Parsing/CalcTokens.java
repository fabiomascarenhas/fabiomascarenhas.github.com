// Output created by jacc on Wed Jan 16 17:06:50 BRST 2013

interface CalcTokens {
    int ENDINPUT = 0;
    int INTEGER = 1;
    int error = 2;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // '-' (code=45)
    // '/' (code=47)
}
