package parse;

import ast.*;
import java.io.IOException;

public class ScriptParser {
	public Scanner input;
	public Token la;
	
	public ScriptParser(Scanner input) {
		this.input = input;
	}
	
	public Token match(int token) {
		if(la.type == token) {
			Token tok = la;
			try {
				la = input.nextToken();
			} catch(IOException e) {
				throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
			}
			return tok;
		} else
			throw new RuntimeException("erro de sintaxe em " +
					la.line + ":" + la.col + ", esperado: "
					+ token + ", achado: " +
					la.type + "(" + la.val + ")");
	}
	
	public Exp parse() {
		try {
			la = input.nextToken();
			match(Token.LPE);
			return exp();
		} catch(IOException e) {
			throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
		}
	}
	
	public Exp parseExp(Token la) {
		this.la = la;
		return exp();
	}
	
	public Exp exp() {
		return aexp();
	}
	
	// AEXP   -> AEXP + MEXP
	// AEXP   -> AEXP - MEXP
	// AEXP   -> MEXP
	public Exp aexp() {
		Exp res = mexp();
		while(la.type == '+' || la.type == '-') {
			if(la.type == '+') {
				Token tok = match('+');
				res = new Soma(res, mexp(), tok.line, tok.col);
			} else {
				Token tok = match('-');
				res = new Sub(res, mexp(), tok.line, tok.col);
			}
		}
		return res;
	}

	// MEXP   -> MEXP * SEXP
	// MEXP   -> MEXP / SEXP
	// MEXP   -> SEXP
	public Exp mexp() {
		Exp res = sexp();
		while(la.type == '*' || la.type == '/') {
			if(la.type == '*') {
				Token tok = match('*');
				res = new Mul(res, sexp(), tok.line, tok.col);
			} else {
				Token tok = match('/');
				res = new Div(res, sexp(), tok.line, tok.col);
			}
		}
		return res;
	}
	
	// SEXP -> num
	// SEXP -> PEXP
	public Exp sexp() {
		switch(la.type) {
		case Token.NUM:
			Token tok = match(Token.NUM);
			return new Num(tok.val, tok.line, tok.col);
		default:
			return pexp();
		}
	}

	// PEXP   -> ( EXP )
	public Exp pexp() {
		switch(la.type) {
		case '(':
			match('(');
			Exp res = exp();
			match(')');
			return res;
		}
		System.out.println(la);
		return null;
	}

}