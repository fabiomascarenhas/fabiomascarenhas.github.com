package ast;

public class Mul extends Exp {
	public Exp l;
	public Exp r;
	
	public Mul(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	public double eval() {
		return l.eval() * r.eval();
	}

	public String label() {
		return "*";
	}
}
