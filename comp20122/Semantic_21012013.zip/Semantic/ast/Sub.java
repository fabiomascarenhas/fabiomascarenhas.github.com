package ast;

public class Sub extends Exp {
	public Exp l;
	public Exp r;
	
	public Sub(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	public double eval() {
		return l.eval() - r.eval();
	}

	public String label() {
		return "-";
	}
}
