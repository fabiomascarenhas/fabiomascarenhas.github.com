package ast;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;

public abstract class Node {
	public int line;
	public int col;
	
	public Node(int line, int col) {
		this.line = line;
		this.col = col;
	}

	public abstract String label();

	public void printDot(String filename) {
		BufferedWriter buf;
		try {
			buf = new BufferedWriter(new FileWriter(filename));
			try {
				buf.write("digraph tree {\n");
				StringBuffer sb = new StringBuffer();
				dot(sb);
				buf.write(sb.toString());
				buf.write("}\n");
			} finally {
				buf.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void dot(StringBuffer buf) {
		Class<? extends Node> c = this.getClass();
		buf.append("\"" + this.toString() + "\"");
		buf.append(" [label=\"");
		buf.append(label());
		buf.append("\"];\n");
		for(Field f: c.getDeclaredFields()) {
			if(Node.class.isAssignableFrom(f.getType())) {
				try {
					Node child = (Node)f.get(this);
					if(child != null) {
						child.dot(buf);
						buf.append("\"" + this.toString() + "\"");
						buf.append(" -> ");
						buf.append("\"" + child.toString() + "\"");
						buf.append(";\n");
					}
				} catch (IllegalAccessException e) {
					throw new RuntimeException(e);
				}
			}
		}
	}
}


