package ast;

public class Div extends Exp {
	public Exp l;
	public Exp r;
	
	public Div(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}
	
	public double eval() {
		return l.eval() / r.eval();
	}
	
	public String label() {
		return "/";
	}
}
