package ast;

import java.lang.reflect.Field;

public abstract class Exp extends Node {
	public Exp(int line, int col) {
		super(line, col);
	}
	
	public abstract double eval();
}
