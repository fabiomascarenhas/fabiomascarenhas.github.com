package ast;

import java.util.HashMap;

public class SymbolTable<T> {
	public HashMap<String, T> map;
	public SymbolTable<T> parent;
	
	public SymbolTable(SymbolTable<T> parent) {
		map = new HashMap<String, T>();
		this.parent = parent;
	}
	
	public SymbolTable() {
		this(null);
	}
	
	public T find(String name) {
		if(map.containsKey(name))
			return map.get(name);
		else
			return parent != null ? parent.find(name) : null;
	}
	
	public void add(String name, T value) {
		map.put(name, value);
	}
	
	public boolean check(String name) {
		return map.containsKey(name);
	}
}
