package ast;

public class Num extends Exp {
	public double val;
	
	public Num(String tok, int line, int col) {
		super(line, col);
		val = Double.parseDouble(tok);
	}

	public double eval() {
		return val;
	}

	public String label() {
		return "" + val;
	}
}
