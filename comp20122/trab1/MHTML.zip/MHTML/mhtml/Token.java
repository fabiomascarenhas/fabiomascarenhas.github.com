package mhtml;

public class Token {
	public int type;
	public String val;
	public int line;
	public int col;

	public final static int EOF = 0;
	public final static int LS = 1;
	public final static int LP = 2;
	public final static int SG = 3;
	public final static int PG = 4;
	public final static int WORD = 5;
	public final static int STRING = 6;
	public final static int ID = 7;
	public final static int NUM = 8;
	public final static int FUNCTION = 9;
	public final static int END = 10;
	public final static int WHILE = 11;
	public final static int LOCAL = 12;
	public final static int TRUE = 13;
	public final static int FALSE = 14;
	public final static int AND = 15;
	public final static int ELSE = 16;
	public final static int IF = 17;
	public final static int ELSEIF = 18;
	public final static int NOT = 19;
	public final static int NIL = 20;
	public final static int OR = 21;
	public final static int RETURN = 22;
	public final static int THEN = 23;
	public final static int EQ = 24;
	public final static int NEQ = 25;
	public final static int CONCAT = 26;
	public final static int LPE = 27;
	
	public final static String[] names = new String[] {
		"EOF", "</", "<%", "/>", "%>", "WORD", "STRING", "ID",
		"NUM", "FUNCTION", "END", "WHILE", "LOCAL", "TRUE",
		"FALSE", "AND", "ELSE", "IF", "ELSEIF", "NOT",
		"NIL", "OR", "RETURN", "THEN", "EQ", "NEQ", "CONCAT",
		"<%="
	};
	
	public Token(int type, String val, int line, int col) {
		this.type = type;
		this.val = val;
		this.line = line + 1;
		this.col = col + 1;
	}
	
	@Override
	public boolean equals(Object other) {
		Token tok = (Token)other;
		return type == tok.type &&
				val.equals(tok.val) &&
				line == tok.line &&
				col == tok.col;
	}
	
	@Override
	public int hashCode() {
		return val.hashCode();
	}

	@Override
	public String toString() {
		String tok = "," + line + "," + col + ")";
		if(type < 32)
			return "(" + names[type] + "," + val + tok;
		else
			return "(" + (char)type + tok;
	}
}
