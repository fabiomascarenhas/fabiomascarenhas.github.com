package lex;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class ScannerDFA implements Scanner {
	public Reader input;
	public int lookAhead;
	
	public State[] states;
	public State init;
	
	public class State {
		public boolean accept;
		public int type;
		public int num;
		public Map<String, State> rules = 
				new HashMap<String, State>();
		
		public State(int num) {
			this.num = num;
			this.accept = false;
		}
		
		public void type(int type) {
			this.accept = true;
			this.type = type;
		}
		
		public void rule(String regex, State to) {
			rules.put(regex,  to);
		}
		
		public State next(int c) {
			if(c != -1) {
				for(Map.Entry<String, State> entry: rules.entrySet()) {
					if(Pattern.matches(entry.getKey(), 
							String.valueOf((char)c))) {
						return entry.getValue();
					}
				}
			} else {
				if(rules.containsKey("<<EOF>>"))
					return rules.get("<<EOF>>");
			}
			if(accept) {
				return null;
			} else {
				throw new RuntimeException("estado: " + num + ", caractere inválido: " + (char)c);
			}
		}
	}
	
	public ScannerDFA(int nStates) {
		states = new State[nStates];
		for(int i = 0; i < nStates; i++)
			states[i] = new State(i);
		init = states[0];
	}
	
	public void rule(int state, String regex, int to) {
		states[state].rule(regex, states[to]);
	}
	
	public void type(int state, int type) {
		states[state].type(type);
	}
	
	@Override
	public void setInput(String input) {
		this.input = new StringReader(input);
		try {
			lookAhead = this.input.read();
		} catch(IOException ioe) {
			throw new RuntimeException(ioe);
		}
	}

	@Override
	public Token nextToken() {
		StringBuffer token = new StringBuffer();
		State current = init;
		int type = current.type;
		do {
			current = current.next(lookAhead);
			if(current != null) {
				type = current.type;
				token.append((char)lookAhead);
				try {
					lookAhead = input.read();
				} catch(IOException ioe) {
					throw new RuntimeException(ioe);
				}
			}
		} while(current != null);
		return new Token(type, token.toString());
	}

	@Override
	public List<Token> allTokens() {
		List<Token> tokens = new ArrayList<Token>();
		Token tok = nextToken();
		while(tok.type != Token.EOF) {
			tokens.add(tok);
			tok = nextToken();
		}
		return tokens;
	}

}
