package runtime;


public class ToStringFunc implements Func {

	@Override
	public Object apply(Object... args) {
		return args[0].toString();
	}

}
