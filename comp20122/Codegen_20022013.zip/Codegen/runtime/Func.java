package runtime;

public interface Func {
	Object apply(Object ... args);
}
