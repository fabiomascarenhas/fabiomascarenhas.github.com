package inc;

import runtime.Func;
import runtime.Upvalue;

public class main implements Func {
Object print;

public main(Object print) {
this.print = print;
}

@Override
public Object apply(Object ... args) {
Upvalue $loc1 = new Upvalue(null);
$loc1.val = 0.0;
Object $loc2;
$loc2 = new inc($loc1, this.print);
Object $loc3;
$loc3 = new soma();
((Func)this.print).apply(((Func)$loc3).apply(2.0, 3.0));
((Func)this.print).apply(((Func)$loc2).apply(1.0));
Object $loc4;
$loc4 = 5.0;
((Func)this.print).apply($loc4);
((Func)this.print).apply(((Func)$loc2).apply(3.0));
Object $loc5;
$loc5 = new contador($loc1);
Object $loc6;
$loc6 = ((Func)$loc5).apply(1.0);
Object $loc7;
$loc7 = ((Func)$loc5).apply(1.0);
((Func)this.print).apply(((Func)$loc6).apply(2.0));
((Func)this.print).apply(((Func)$loc6).apply(3.0));
((Func)this.print).apply(((Func)$loc7).apply(1.0));
((Func)this.print).apply($loc1.val);
return null;}}
