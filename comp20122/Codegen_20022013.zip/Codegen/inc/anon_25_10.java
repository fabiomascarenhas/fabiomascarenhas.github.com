package inc;

import runtime.Func;
import runtime.Upvalue;

public class anon_25_10 implements Func {
Upvalue n;
Upvalue y;

public anon_25_10(Upvalue n, Upvalue y) {
this.n = n;
this.y = y;
}

@Override
public Object apply(Object ... args) {
this.n.val = ((Double)this.n.val) + ((Double)args[0]);
this.y.val = ((Double)this.y.val) + ((Double)1.0);
return this.n.val;
}}
