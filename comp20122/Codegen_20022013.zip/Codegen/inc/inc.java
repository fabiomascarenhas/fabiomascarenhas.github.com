package inc;

import runtime.Func;
import runtime.Upvalue;

public class inc implements Func {
Upvalue y;
Object print;

public inc(Upvalue y, Object print) {
this.y = y;
this.print = print;
}

@Override
public Object apply(Object ... args) {
((Func)this.print).apply(args[0]);
this.y.val = ((Double)this.y.val) + ((Double)args[0]);
return this.y.val;
}}
