package inc;

import runtime.Func;
import runtime.Upvalue;

public class soma implements Func {

public soma() { }

@Override
public Object apply(Object ... args) {
return ((Double)args[0]) + ((Double)args[1]);
}}
