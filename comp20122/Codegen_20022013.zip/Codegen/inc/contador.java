package inc;

import runtime.Func;
import runtime.Upvalue;

public class contador implements Func {
Upvalue y;

public contador(Upvalue y) {
this.y = y;
}

@Override
public Object apply(Object ... args) {
Upvalue $arg0 = new Upvalue(args[0]);
return new anon_25_10($arg0, this.y);
}}
