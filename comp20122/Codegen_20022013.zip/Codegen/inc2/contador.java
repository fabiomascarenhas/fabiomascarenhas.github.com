package inc2;

import runtime.Func;
import runtime.Upvalue;

public class contador implements Func {
	public Upvalue y;
	
	public contador(Upvalue y) {
		this.y = y;
	}

	@Override
	public Object apply(Object... args) {
		if(args.length != 1)
			throw new RuntimeException("erro de aridade");
		Upvalue n = new Upvalue(args[0]);
		return new anon_25_10(n, this.y);
	}
}
