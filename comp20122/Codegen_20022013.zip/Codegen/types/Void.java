package types;

import ast.Node;

public class Void extends Type {
	public static Type type = new Void();
	
	private Void() { }
	
	@Override
	public void checkEq(Void v, Node n) { }
	
	@Override
	public void checkEq(Type t, Node n) {
		t.checkEq(this, n);
	}

	@Override
	public String toString() {
		return "void";
	}

}
