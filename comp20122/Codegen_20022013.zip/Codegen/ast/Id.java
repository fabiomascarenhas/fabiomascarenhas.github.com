package ast;

import java.util.List;

import runtime.Upvalue;
import types.Type;

public class Id extends Node implements Exp {
	public String name;
	public Type type;
	public boolean shared; // é usado por funções internas
	public boolean updated; // é usado no l. e. de atribuição
	
	public Id(String name, int line, int col) {
		super(line, col);
		this.name = name;
	}
	
	public String label() {
		return name;
	}
	
	public Object eval(Environment<Object> env) {
		Object obj = env.lookup(name);
		if(obj instanceof Upvalue)
			return ((Upvalue)obj).val;
		else
			return obj;
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return tenv.lookup(name);
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur,
			List<PrimFunc> funcs) {
		LocId loc = env.lookup(name);
		if(loc.owner != cur) {
			loc.id.shared = true;
			while(cur != null && cur != loc.owner){
				cur.env.add(loc.id);
				cur = cur.parent;
			}
		}
		return this;
	}

	@Override
	public String cgExp(Environment<Location> env) {
		Location loc = env.lookup(name);
		return loc.get();
	}
	
}
