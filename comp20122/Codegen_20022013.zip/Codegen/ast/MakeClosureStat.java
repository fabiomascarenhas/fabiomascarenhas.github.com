package ast;

import java.util.ArrayList;
import java.util.List;

import types.Type;

public class MakeClosureStat extends Node implements Stat {
	public Id name;
	public PrimFunc func;
	
	public MakeClosureStat(Id name, PrimFunc pf, int line, int col) {
		super(line, col);
		this.name = name;
		this.func = pf;
	}

	@Override
	public void run(Environment<Object> env) {
		Environment<Object> fenv = new SymbolTable<Object>();
		env.bind(name.name, null);
		for(Id name: func.env) {
			fenv.bind(name.name, env.lookup(name.name));
		}
		env.update(name.name, new FuncVal(func.params, func.body, fenv));
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public String label() {
		return "closurestat";
	}

	@Override
	public String cgStat(Environment<Location> env, PrimFunc func) {
		StringBuffer buf = new StringBuffer();
		Location loc; 
		if(name.shared && name.updated) {
			loc = new LocationLocal(func.getLoc(), true);
		} else {
			loc = new LocationLocal(func.getLoc(), false);
		}
		env.bind(name.name, loc);
		buf.append(loc.declare());
		if(this.func.env.isEmpty()) {
			buf.append(loc.set("new " + this.func.name + "()"));
			return buf.toString();
		}
		StringBuffer make = new StringBuffer();
		make.append("new " + this.func.name + "(");
		List<String> cenv = new ArrayList<String>();
		for(Id name: this.func.env) {
			cenv.add(env.lookup(name.name).getBox());
		}
		make.append(cenv.get(0));
		for(int i = 1; i < cenv.size(); i++)
			make.append(", " + cenv.get(i));
		make.append(")");
		buf.append(loc.set(make.toString()));
		return buf.toString();
	}

}
