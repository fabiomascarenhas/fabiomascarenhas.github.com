package ast;

import java.util.List;

import types.Type;

public class False extends Node implements Exp {

	public False(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return false;
	}

	@Override
	public String label() {
		return "false";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Bool.type;
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return this;
	}

	@Override
	public String cgExp(Environment<Location> env) {
		return "false";
	}

}
