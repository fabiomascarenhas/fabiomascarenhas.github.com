package ast;

import java.util.List;

import types.Type;

public class Nil extends Node implements Exp {

	public Nil(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return null;
	}

	@Override
	public String label() {
		return "nil";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Any.type;
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return this;
	}

	@Override
	public String cgExp(Environment<Location> env) {
		return "null";
	}

}
