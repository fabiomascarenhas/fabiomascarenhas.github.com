package ast;

public class LocationLocal extends Location {
	public int idx;

	public LocationLocal(int idx, boolean upvalue) {
		super(upvalue);
		this.idx = idx;
	}
	
	@Override
	public String get() {
		if(upvalue)
			return "$loc" + idx + ".val";
		else
			return "$loc" + idx;
	}

	@Override
	public String set(String rval) {
		if(upvalue)
			return "$loc" + idx + ".val = " + rval + ";\n";
		else
			return "$loc" + idx + " = " + rval + ";\n";
	}

	@Override
	public String getBox() {
		return "$loc" + idx;
	}

	@Override
	public String declare() {
		if(upvalue) {
			return "Upvalue $loc" + idx + " = new Upvalue(null);\n";
		} else {
			return "Object $loc" + idx + ";\n";
		}
	}

}
