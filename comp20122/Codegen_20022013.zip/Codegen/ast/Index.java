package ast;

import java.util.List;

import types.Type;

public class Index extends Node implements Exp {
	public Exp prefix;
	public Id field;
	
	public Index(Exp prefix, Id field, int line, int col) {
		super(line, col);
		this.prefix = prefix;
		this.field = field;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return null;
	}

	@Override
	public String label() {
		return ".";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return null;
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return null;
	}

	@Override
	public String cgExp(Environment<Location> env) {
		// TODO Auto-generated method stub
		return null;
	}

}
