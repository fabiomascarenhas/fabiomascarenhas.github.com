package ast;

public class LocationEnv extends Location {
	public String name;
	
	public LocationEnv(String name, boolean upvalue) {
		super(upvalue);
		this.name = name;
	}
	
	@Override
	public String get() {
		if(upvalue)
			return "this." + name + ".val";
		else
			return "this." + name;
	}

	@Override
	public String set(String rval) {
		if(upvalue)
			return "this." + name + ".val = " + rval + ";\n";
		else
			return "this." + name + " = " + rval + ";\n";
	}

	@Override
	public String getBox() {
		return "this." + name;
	}

	@Override
	public String declare() {
		if(upvalue) {
			return "Upvalue " + name + ";\n";
		} else {
			return "Object " + name + ";\n";
		}
	}
	
}
