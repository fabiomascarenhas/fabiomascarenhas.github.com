package ast;

import java.util.ArrayList;
import java.util.List;

import runtime.PrintFunc;
import types.Type;

public class Bloco extends Node implements Stat {
	public List<Stat> stats;
	
	public Bloco(List<Stat> stats, int line, int col) {
		super(line, col);
		this.stats = stats;
	}

	@Override
	public void run(Environment<Object> env) {
		Environment<Object> benv = env.extend();
		for(Stat s: stats)
			s.run(benv);
	}

	@Override
	public String label() {
		return "bloco";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		tenv = tenv.extend();
		for(Stat s: stats)
			s.tcStat(tenv);
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		env = env.extend();
		List<Stat> cstats = new ArrayList<Stat>();
		for(Stat s: stats) {
			try {
				cstats.add(s.ccStat(env, func, funcs));
			} catch(ReturnVal rv) {
				cstats.add((Stat)rv.val);
				throw new ReturnVal(new Bloco(cstats, line, col));
			}
		}
		return new Bloco(cstats, line, col);
	}
	
	public List<PrimFunc> cc(Id ... globals) {
		Environment<LocId> env = new SymbolTable<LocId>();
		env.bind("print", new LocId(globals[0], new PrintFunc()));
		PrimFunc top = new PrimFunc("main", new ArrayList<Id>(), null);
//		for(Id global : globals)
//			env.bind(global.name, new LocId(global, top)); 
		List<PrimFunc> funcs = new ArrayList<PrimFunc>();
		funcs.add(top);
		try {
			top.body = (Bloco)ccStat(env, top, funcs);
		} catch(ReturnVal rv) {
			top.body = (Bloco)rv.val;
		}
		top.main = true;
		return funcs;
	}

	@Override
	public String cgStat(Environment<Location> env, PrimFunc func) {
		Environment<Location> benv = env.extend();
		StringBuffer buf = new StringBuffer();
		for(Stat s: stats) {
			try {
				buf.append(s.cgStat(benv, func));
			} catch(ReturnVal rv) {
				buf.append(rv.val.toString());
				throw new ReturnVal(buf.toString());
			}
		}
		return buf.toString();
	}
}
