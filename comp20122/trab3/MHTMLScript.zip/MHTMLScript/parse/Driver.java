package parse;

public class Driver {
	public static void main(String[] args) throws java.io.IOException {
		String filename = args[0];
		java.io.FileReader f = new java.io.FileReader(filename);
		parse.Scanner scan = new parse.Scanner(f);
		parse.ScriptParser parser = new parse.ScriptParser(scan);
		ast.Bloco bloco = parser.parseBloco();
		bloco.printDot(filename + ".gv");
		bloco.topRun();
	}
}
