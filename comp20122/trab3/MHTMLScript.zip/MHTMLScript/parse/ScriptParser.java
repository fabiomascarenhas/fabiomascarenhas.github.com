package parse;

import ast.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ScriptParser {
	public Scanner input;
	public Token la;
	
	public ScriptParser(Scanner input) {
		this.input = input;
	}
	
	public Token match(int token) {
		if(la.type == token) {
			Token tok = la;
			try {
				la = input.nextToken();
			} catch(IOException e) {
				throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
			}
			return tok;
		} else
			throw new RuntimeException("erro de sintaxe em " +
					la.line + ":" + la.col + ", esperado: "
					+ token + ", achado: " +
					la.type + "(" + la.val + ")");
	}
		
	public Bloco parseBloco() {
		try {
			la = input.nextToken();
			match(Token.LPE);
			return bloco();
		} catch(IOException e) {
			throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
		}
	}

	public Exp parseExp() {
		try {
			la = input.nextToken();
			match(Token.LPE);
			return exp();
		} catch(IOException e) {
			throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
		}
	}

	public Bloco parseBloco(Token la) {
		this.la = la;
		return bloco();
	}
	
	public Exp parseExp(Token la) {
		this.la = la;
		return exp();
	}

	
	// BLOCO -> {STAT} [RET]
	public Bloco bloco() {
		ArrayList<Stat> stats = new ArrayList<Stat>();
		int line = la.line; int col = la.col;
		// Conjunto FIRST(STAT)
		while(la.type == Token.DO || la.type == Token.IF ||
				la.type == Token.WHILE || la.type == '(' ||
				la.type == Token.ID || la.type == Token.LOCAL ||
				la.type == Token.FUNCTION) {
			stats.add(stat());
		}
		if(la.type == Token.RETURN) {
			stats.add(ret());
		}
		return new Bloco(stats, line, col);
	}
	
	public Stat ret() {
		Token tok = match(Token.RETURN);
		return new Return(exp(), tok.line, tok.col);
	}

	public Id id() {
		Token tok_id = match(Token.ID);
		return new Id(tok_id.val, tok_id.line, tok_id.col);
	}
	
	// STAT -> do BLOCO end
	// STAT -> while EXP do BLOCO end
	// STAT -> if exp then BLOCO {elseif EXP then BLOCO} [else BLOCO] end
	// STAT -> local id [= EXP]
	// STAT -> function id ( [IDS] ) BLOCO end
	// STAT -> LVAL = EXP
	// STAT -> PEXP ( [EXPS] )
	public Stat stat() {
		switch(la.type) {
		case Token.DO: // STAT -> id = exp
			match(Token.DO);
			Bloco bloco = bloco();
			match(Token.END);
			return bloco;
		case Token.WHILE: { // STAT -> while EXP do BLOCO end
			Token tok = match(Token.WHILE);
			Exp cond = exp();
			match(Token.DO);
			Bloco b = bloco();
			match(Token.END);
			return new While(cond, b, tok.line, tok.col);
		}
		// STAT -> if exp then BLOCO {elseif EXP then BLOCO} [else BLOCO] end
		case Token.IF: {
			Token tok = match(Token.IF);
			Exp cond = exp();
			match(Token.THEN);
			Bloco bthen = bloco();
			If res = new If(cond, bthen, null, tok.line, tok.col);
			If cur = res;
			while(la.type == Token.ELSEIF) {
				tok = match(Token.ELSEIF);
				cond = exp();
				match(Token.THEN);
				bthen = bloco();
				cur = new If(cond, bthen, null, tok.line, tok.col);
			}
			if(la.type == Token.ELSE) {
				match(Token.ELSE);
				cur.belse = bloco();
			}
			match(Token.END);
			return res;
		}
		case Token.LOCAL: { // STAT -> local id [= exp]
			Token tok = match(Token.LOCAL);
			Id id = id();
			Exp init = null;
			if(la.type == '=') {
				match('=');
				init = exp();
			}
			return new Local(id, init, tok.line, tok.col);
		}
		// STAT -> function id ( [IDS] ) BLOCO end
		case Token.FUNCTION: {
			Token tok = match(Token.FUNCTION);
			Id id = id();
			match('(');
			List<Id> params;
			if(la.type != ')')
				params = ids();
			else
				params = new ArrayList<Id>();
			match(')');
			Bloco b = bloco();
			match(Token.END);
			return new FuncStat(id, params, b, tok.line, tok.col);
		}
		// STAT -> LVAL = EXP
		// STAT -> PEXP ( [EXPS] )
		case Token.ID:
		case '(': {
			Node pexp = (Node)pexp();
			if(pexp instanceof Call) {
				return (Call)pexp;
			}
			if(pexp instanceof Id || pexp instanceof Index) {
				Lval lval = (Lval)pexp;
				Token tok = match('=');
				Exp rval = exp();
				return new Atrib(lval, rval, tok.line, tok.col);
			}
			throw new RuntimeException("lvalue inválido em " + pexp.line + ", " + pexp.col);
		}
		default:
			throw new RuntimeException("comando inválido em " + la.line + ":" + la.col +
					", começando com: " + la.type + "(" + la.val + ")");	
		}
	}

	// EXP -> EXP or LEXP
	// EXP -> LEXP
	public Exp exp() {
		Exp res = lexp();
		while(la.type == Token.OR) {
			Token tok = match(Token.OR);
			res = new Or(res, lexp(), tok.line, tok.col);
		}
		return res;
	}
	
	// LEXP -> LEXP and REXP
	// LEXP -> REXP
	public Exp lexp() {
		Exp res = rexp();
		while(la.type == Token.AND) {
			Token tok = match(Token.AND);
			res = new And(res, rexp(), tok.line, tok.col);
		}
		return res;
	}
	
	// REXP   -> REXP < CEXP
	// REXP   -> REXP == CEXP
	// REXP   -> REXP ~= CEXP
	// REXP   -> CEXP
	public Exp rexp() {
		Exp res = cexp();
		while(la.type == Token.NEQ || la.type == Token.EQ
				|| la.type == '<') {
			if(la.type == Token.NEQ){ 
				Token tok = match(Token.NEQ);
				res = new Neq(res, cexp(), tok.line, tok.col);
			} else if(la.type == Token.EQ) {
				Token tok = match(Token.EQ);
				res = new Eq(res, cexp(), tok.line, tok.col);
			} else {
				Token tok = match('<');
				res = new Menor(res, cexp(), tok.line, tok.col);
			}
		}
		return res;
	}
	
	// CEXP -> AEXP .. CEXP
	// CEXP -> AEXP
	public Exp cexp() {
		Exp res = aexp();
		if(la.type == Token.CONCAT) {
			Token tok = match(Token.CONCAT);
			res = new Concat(res, cexp(), tok.line, tok.col);
		}
		return res;
	}
	
	// AEXP   -> AEXP + MEXP
	// AEXP   -> AEXP - MEXP
	// AEXP   -> MEXP
	public Exp aexp() {
		Exp res = mexp();
		while(la.type == '+' || la.type == '-') {
			if(la.type == '+') {
				Token tok = match('+');
				res = new Soma(res, mexp(), tok.line, tok.col);
			} else {
				Token tok = match('-');
				res = new Sub(res, mexp(), tok.line, tok.col);
			}
		}
		return res;
	}

	// MEXP   -> MEXP * SEXP
	// MEXP   -> MEXP / SEXP
	// MEXP   -> SEXP
	public Exp mexp() {
		Exp res = sexp();
		while(la.type == '*' || la.type == '/') {
			if(la.type == '*') {
				Token tok = match('*');
				res = new Mul(res, sexp(), tok.line, tok.col);
			} else {
				Token tok = match('/');
				res = new Div(res, sexp(), tok.line, tok.col);
			}
		}
		return res;
	}
	
	// SEXP -> - SEXP
	// SEXP -> not SEXP
	// SEXP -> num
	// SEXP -> string
	// SEXP -> nil
	// SEXP -> true
	// SEXP -> false
	// SEXP -> { }
	// SEXP -> function ( [IDS] ) BLOCO end
	// SEXP -> PEXP
	public Exp sexp() {
		switch(la.type) {
		case '-': {
			Token tok = match('-');
			return new Negate(sexp(), tok.line, tok.col);
		} 
		case Token.NOT: {
			Token tok = match(Token.NOT);
			return new Not(sexp(), tok.line, tok.col);
		} 
		case Token.NUM: {
			Token tok = match(Token.NUM);
			return new Num(tok.val, tok.line, tok.col);
		}
		case Token.STRING: {
			Token tok = match(Token.STRING);
			return new Str(tok.val, tok.line, tok.col);
		}
		case Token.NIL: {
			Token tok = match(Token.NIL);
			return new Nil(tok.line, tok.col);
		}
		case Token.TRUE: {
			Token tok = match(Token.TRUE);
			return new True(tok.line, tok.col);
		}
		case Token.FALSE: {
			Token tok = match(Token.FALSE);
			return new False(tok.line, tok.col);
		}
		case '{': {
			Token tok = match('{');
			match('}');
			return new NewTable(tok.line, tok.col);
		}
		case Token.FUNCTION: {
			Token tok = match(Token.FUNCTION);
			match('(');
			List<Id> params;
			if(la.type != ')')
				params = ids();
			else
				params = new ArrayList<Id>();
			match(')');
			Bloco b = bloco();
			match(Token.END);
			return new FuncDef(params, b, tok.line, tok.col);
		}
		default:
			return pexp();
		}
	}

	// PEXP   -> PEXP ( [EXPS] )
	// PEXP   -> PEXP . id
	// PEXP   -> id
	// PEXP   -> ( EXP )
	public Exp pexp() {
		Exp res;
		switch(la.type) {
		case Token.ID:
			res = id();
			break;
		case '(':
			match('(');
			res = exp();
			match(')');
			break;
		default:
			throw new RuntimeException("expressão inválida em " + la.line + ":" + la.col +
					", começando com: " + la.type + "(" + la.val + ")");	
		}
		while(la.type == '(' || la.type == '.') {
			if(la.type == '(') {
				Token tok = match('(');
				if(la.type != ')')
					res = new Call(res, exps(), tok.line, tok.col);
				else
					res = new Call(res, new ArrayList<Exp>(), tok.line, tok.col);
				match(')');
			} else {
				Token tok = match('.');
				Id id = id();
				res = new Index(res, id, tok.line, tok.col);
			}
		}
		return res;
	}

	public List<Exp> exps() {
		ArrayList<Exp> res = new ArrayList<Exp>();
		res.add(exp());
		while(la.type == ',') {
			match(',');
			res.add(exp());
		}
		return res;
	}

	public List<Id> ids() {
		ArrayList<Id> res = new ArrayList<Id>();
		res.add(id());
		while(la.type == ',') {
			match(',');
			res.add(id());
		}
		return res;
	}

}