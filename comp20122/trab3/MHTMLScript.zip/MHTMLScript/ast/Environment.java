package ast;

import java.util.Set;

public interface Environment<T> {
	T lookup(String name);
	void bind(String name, T value);
	void update(String name, T value);
	Environment<T> extend();
	Set<T> values();
}
