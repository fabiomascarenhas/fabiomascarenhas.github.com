package ast;

public class ReturnVal extends RuntimeException {
	private static final long serialVersionUID = -3628940142077348384L;

	public Object val;
	
	public ReturnVal() {
		super();
	}
	
	public ReturnVal(Object val) {
		super();
		this.val = val;
	}
}
