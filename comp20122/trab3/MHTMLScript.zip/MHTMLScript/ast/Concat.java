package ast;

public class Concat extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Concat(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	public Object eval(Environment<Object> env) {
		return (String)l.eval(env) + (String)r.eval(env);
	}

	public String label() {
		return "..";
	}
}
