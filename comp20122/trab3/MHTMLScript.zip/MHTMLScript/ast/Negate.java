package ast;

public class Negate extends Node implements Exp {
	public Exp exp;
	
	public Negate(Exp exp, int line, int col) {
		super(line, col);
		this.exp = exp;
	}

	@Override
	public Object eval(Environment<Object> env) {
		// TODO especificação da negação
		return null;
	}

	@Override
	public String label() {
		return "-";
	}

}
