package ast;

public class PrintFunc implements Func {

	@Override
	public Object apply(Object... args) {
		for(Object arg: args) {
			System.out.print(arg);
			System.out.print("\t");
		}
		System.out.println();
		return null;
	}

}
