package ast;

public class While extends Node implements Stat {
	public Exp cond;
	public Bloco corpo;
	
	public While(Exp cond, Bloco corpo, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.corpo = corpo;
	}

	@Override
	public void run(Environment<Object> env) {
		while((Boolean)cond.eval(env)) {
			corpo.run(env);
		}
	}

	@Override
	public String label() {
		return "while";
	}

}
