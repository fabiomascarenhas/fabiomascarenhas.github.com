package ast;

import java.util.List;

public class Bloco extends Node implements Stat {
	public List<Stat> stats;
	
	public Bloco(List<Stat> stats, int line, int col) {
		super(line, col);
		this.stats = stats;
	}

	@Override
	public void run(Environment<Object> env) {
		Environment<Object> benv = env.extend();
		for(Stat s: stats)
			s.run(benv);
	}
	
	public Environment<Object> topRun() {
		Environment<Object> env = new SymbolTable<Object>();
		env.bind("print", new ast.PrintFunc());
		env.bind("tostring", new ast.ToStringFunc());
		Environment<Object> benv = env.extend();
		for(Stat s: stats)
			s.run(benv);
		return benv;
	}

	@Override
	public String label() {
		return "bloco";
	}

}
