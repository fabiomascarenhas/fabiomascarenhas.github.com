package ast;

public class Eq extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Eq(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		Object ol = l.eval(env);
		Object or = r.eval(env);
		if(ol == null)
			return ol == or;
		else
			return ol.equals(or);
	}

	@Override
	public String label() {
		return "==";
	}

}
