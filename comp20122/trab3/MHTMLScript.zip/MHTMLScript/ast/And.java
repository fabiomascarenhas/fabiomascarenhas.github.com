package ast;

public class And extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public And(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		// TODO especificar comportamento do and
		return null;
	}

	@Override
	public String label() {
		return "and";
	}

}
