package lp

object Lista1 extends App {
  for {
    i <- Range(0, 7)
  } yield print(pascal(i, 7) + " ")
  println()
  println()
  println(balanceado("so (um (teste) (da funcao) ) ".toList))
  println(balanceado("so (um (teste (da funcao) ) ".toList))
  println(balanceado("so (um (teste)) (da funcao) ) ".toList))
  println()
  println(particao(List(1,4,3,9,6,8,5,7), 6))
  println(quicksort(List(1,4,3,9,6,8,5,7)))
  println()
  val sem1 = List((9.5,3),(7.3,4),(5.0,3),(4.0,4))
  val sem2 = List((6.5,3),(8.3,4),(5.0,3))
  val sem3 = List((8.5,3),(2.0,4),(5.0,4),(3.5,5))
  println(crSemestre(sem1))
  println(crSemestre(sem2))
  println(crSemestre(sem3))
  println(crsAcumulados(List(sem1, sem2, sem3)))
}
