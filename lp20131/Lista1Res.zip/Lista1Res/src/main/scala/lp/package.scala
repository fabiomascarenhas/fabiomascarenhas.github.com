package object lp {
  def pascal(col: Int, lin: Int): Int = 
    if (col <= 0 || col >= lin) 1
    else pascal(col-1, lin-1) + pascal(col, lin-1)
    
  def balanceado(l: List[Char]): Boolean = {
    def loop(l: List[Char], nivel: Int): Boolean = l match {
      case List() => if (nivel == 0) true else false
      case h :: t => if (h == '(') loop(t, nivel + 1)
                     else if(h == ')') loop(t, nivel - 1)
                     else loop(t, nivel)
    }
    loop(l, 0)
  }
  
  def particao(l: List[Int], pivo: Int): (List[Int], List[Int]) = {
    def loop(l: List[Int], lr1: List[Int], lr2: List[Int]): (List[Int], List[Int]) = l match {
      case List() => (lr1, lr2)
      case h :: t => if (h <= pivo) loop(t, h :: lr1, lr2)
                     else loop(t, lr1, h :: lr2)
    }
    loop(l, List(), List())
  }
  
  def quicksort(l: List[Int]): List[Int] = l match {
    case List() => l
    case h :: t => {
      val (l1, l2) = particao(t, h)
      quicksort(l1) ++ List(h) ++ quicksort(l2)
    }
  }
  
  def crSemestre(notas: List[(Double, Int)]): (Double, Int) = {
    def loop(notas: List[(Double, Int)], media: Double, creditos: Int): (Double, Int) = notas match {
      case List() => (media, creditos)
      case (nota, cred) :: t => loop(t, 
                                     (media * creditos + nota * cred) / (creditos + cred),
                                     creditos + cred)
    }
    loop(notas, 0, 0)
  }

  def crsAcumulados(semestres: List[List[(Double, Int)]]): (List[Double], Int) = {
    def loop(semestres: List[List[(Double, Int)]], acum: List[Double], creditos: Int): (List[Double], Int) = semestres match {
      case List() => (acum.reverse.tail, creditos)
      case sem :: t => {
        val (cr, cred) = crSemestre(sem)
        val cracum = (acum.head * creditos + cr * cred) / (creditos + cred)
        loop(t, cracum :: acum, creditos + cred)
      }
    }
    loop(semestres, List(0.0), 0)
  }
}