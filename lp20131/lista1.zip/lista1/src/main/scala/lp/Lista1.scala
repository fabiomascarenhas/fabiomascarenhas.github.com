package lp

object Lista1 extends App {
  // escreva testes de suas fun��es aqui
  println("Ol�, Mundo!")
}
