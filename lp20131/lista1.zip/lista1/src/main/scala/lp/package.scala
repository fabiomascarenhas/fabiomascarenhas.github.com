package object lp {
  // defina as fun��es da sua resposta aqui
}