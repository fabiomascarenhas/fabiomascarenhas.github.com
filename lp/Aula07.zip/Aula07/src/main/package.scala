import scala.annotation.tailrec
import parser._

package object main {
  trait Exp
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp

  def ExpFun: Parser[Exp] =
    chainl(TermoFun, for {
      _ <- op("+")
    } yield (e1, e2) => Soma(e1, e2), TermoFun)
    
  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)
    
  def FatorFun: Parser[Exp] =
    choice(for {
      (v, pos) <- num
    } yield Num(v), for {
      _ <- op("(")
      e <- ExpFun
      _ <- op(")")
    } yield e)
    
  def parser: Parser[Exp] = for {
    e <- ExpFun
    _ <- space
    _ <- not(pred(c => true), Unit)
  } yield e
  
  def eval(e: Exp): Double = e match {
    case Num(v) => v
    case Soma(e1, e2) => eval(e1) + eval(e2)
    case Mult(e1, e2) => eval(e1) * eval(e2)
  }
  
  def run(s: String): Double = eval(parser.parse(s))
}


    
