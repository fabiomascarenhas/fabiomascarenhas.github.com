import scala.annotation.tailrec

package object lp {
  type Conjunto[T] = T => Boolean

  def contem[T](conj: Conjunto[T], elem: T) = conj(elem)
  def unitario[T](elem: T): Conjunto[T] = e => e == elem
  def uniao[T](c1: Conjunto[T], c2: Conjunto[T]): Conjunto[T] =
    e => contem(c1, e) || contem(c2, e)
  def intersecao[T](c1: Conjunto[T], c2: Conjunto[T]): Conjunto[T] =
    e => contem(c1, e) && contem(c2, e)
  def diferenca[T](c1: Conjunto[T], c2: Conjunto[T]): Conjunto[T] =
    e => contem(c1, e) && !contem(c2, e)
  def filtro[T](c: Conjunto[T], f: T => Boolean): Conjunto[T] =
    intersecao(f, c)
  def map[T, U](c: Conjunto[T], f: U => T): Conjunto[U] =
    (e: U) => contem(c, f(e))
  
  trait ConjInt {
    def contem(x: Int): Boolean = this match {
      case ConjVazio() => false
      case ConjCons(elem, _, _) if x == elem => true
      case ConjCons(elem, esq, _) if x < elem => esq.contem(x)
      case ConjCons(elem, _, dir) if x > elem => dir.contem(x)
    }
    def insere(x: Int): ConjInt = this match {
      case ConjVazio() => ConjCons(x, ConjVazio(), ConjVazio())
      case ConjCons(elem, _, _) if x == elem => this
      case ConjCons(elem, esq, dir) if x < elem =>
        ConjCons(elem, esq.insere(x), dir)
      case ConjCons(elem, esq, dir) if x > elem =>
        ConjCons(elem, esq, dir.insere(x))
    }

    def uniao(outro: ConjInt): ConjInt = outro match {
      case ConjVazio() => this
      case ConjCons(elem, esq, dir) =>
        this.insere(elem).uniao(dir).uniao(esq)
    }

    def ++(outro: ConjInt): ConjInt = this.uniao(outro)

    def filter(p: Int => Boolean): ConjInt = this match {
      case ConjVazio() => this
      case ConjCons(elem, esq, dir) if p(elem) =>
        ConjCons(elem, esq.filter(p), dir.filter(p))
      case ConjCons(elem, esq, dir) if !p(elem) => esq.filter(p).uniao(dir.filter(p))
    }

    def filterLoop(p: Int => Boolean): ConjInt = {
      def loop(c: ConjInt, acum: ConjInt): ConjInt = c match {
        case ConjVazio() => acum
        case ConjCons(elem, esq, dir) if p(elem) =>
          loop(dir, loop(esq, acum.insere(elem)))
        case ConjCons(elem, esq, dir) if !p(elem) =>
          loop(esq, loop(dir, acum))
      }
      loop(this, ConjVazio())
    }

    def map(f: Int => Int): ConjInt = this match {
      case ConjVazio() => this
      case ConjCons(elem, esq, dir) => esq.map(f).uniao(dir.map(f)).insere(f(elem))
    }

    def flatMap(f: Int => ConjInt): ConjInt = this match {
      case ConjVazio() => this
      case ConjCons(elem, esq, dir) => esq.flatMap(f) ++ dir.flatMap(f) ++ f(elem)
    }

  }
  case class ConjVazio() extends ConjInt
  case class ConjCons(elem: Int, esq: ConjInt, dir: ConjInt) extends ConjInt
    
  def intersecaoCI(c1: ConjInt, c2: ConjInt): ConjInt = for {
    x <- c1
    y <- c2 if x == y
  } yield x

  def intersecaoCI2(c1: ConjInt, c2: ConjInt): ConjInt =
    c1.flatMap(x => c2.filter(y => x == y).map(y => x))

  def intersecaoCI3(c1: ConjInt, c2: ConjInt): ConjInt =
    c1.filter(x => c2.contem(x))


  type Ordem[T] = (T, T) => Int

  implicit val ordInt: Ordem[Int] = (x, y) => x - y
  implicit val ordDouble: Ordem[Double] = (x, y) => if(x == y) 0 else if(x < y) -1 else 1

  abstract class Conj[T: Ordem] {
    val ord = implicitly[Ordem[T]]

    def contem(x: T): Boolean = this match {
      case ConjV() => false
      case ConjC(elem, _, _) if ord(x, elem) == 0 => true
      case ConjC(elem, esq, _) if ord(x, elem) < 0 => esq.contem(x)
      case ConjC(elem, _, dir) if ord(x, elem) > 0 => dir.contem(x)
    }

    def insere(x: T): Conj[T] = this match {
      case ConjV() => ConjC(x, ConjV(), ConjV())
      case ConjC(elem, _, _) if ord(x, elem) == 0 => this
      case ConjC(elem, esq, dir) if ord(x, elem) < 0 =>
        ConjC(elem, esq.insere(x), dir)
      case ConjC(elem, esq, dir) if ord(x, elem) > 0 =>
        ConjC(elem, esq, dir.insere(x))
    }

    def uniao(outro: Conj[T]): Conj[T] = outro match {
      case ConjV() => this
      case ConjC(elem, esq, dir) =>
        this.insere(elem).uniao(dir).uniao(esq)
    }

    def ++(outro: Conj[T]): Conj[T] = this.uniao(outro)

    def filter(p: T => Boolean): Conj[T] = this match {
      case ConjV() => this
      case ConjC(elem, esq, dir) if p(elem) =>
        ConjC(elem, esq.filter(p), dir.filter(p))
      case ConjC(elem, esq, dir) if !p(elem) => esq.filter(p).uniao(dir.filter(p))
    }

    def map[U: Ordem](f: T => U): Conj[U] = this match {
      case ConjV() => ConjV()
      case ConjC(elem, esq, dir) => (esq.map(f) ++ dir.map(f)).insere(f(elem))
    }

    def flatMap[U: Ordem](f: T => Conj[U]): Conj[U] = this match {
      case ConjV() => ConjV()
      case ConjC(elem, esq, dir) => esq.flatMap(f) ++ dir.flatMap(f) ++ f(elem)
    }
  }

  case class ConjV[T: Ordem]() extends Conj[T]
  case class ConjC[T: Ordem](elem: T, esq: Conj[T], dir: Conj[T]) extends Conj[T]

  def intersecaoCT[T: Ordem](c1: Conj[T], c2: Conj[T]): Conj[T] = for {
    x <- c1
    y <- c2 if x == y
  } yield x

}
