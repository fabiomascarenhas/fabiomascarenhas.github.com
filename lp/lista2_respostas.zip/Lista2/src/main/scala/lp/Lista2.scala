package lp

object Lista2 extends App {
  // escreva testes de suas funções aqui
  println("Olá, Mundo!")
}
