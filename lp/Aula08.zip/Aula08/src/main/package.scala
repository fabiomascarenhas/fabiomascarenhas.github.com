import scala.annotation.tailrec
import parser._

package object main {
  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  // Usado apenas na avaliação verificada (stepc)
  case class Erro() extends Exp

  trait Valor
  case class NumV(v: Double) extends Valor
  case class TrueV() extends Valor
  case class FalseV() extends Valor
  // Usado apenas na avaliação verificada (evalc)
  case class ErroV() extends Valor
  
  def ExpFun: Parser[Exp] =
    chainl(AexpFun,
           for { _ <- op("<") } yield (e1, e2) => Menor(e1, e2),
           AexpFun)
  
  def AexpFun: Parser[Exp] =
    chainl(TermoFun, 
        (for { _ <- op("+") } yield (e1, e2) => Soma(e1, e2)) +:
        (for { _ <- op("-") } yield (e1: Exp, e2: Exp) => 
          Soma(e1, Mult(Num(-1), e2))),
        TermoFun)
    
  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)
    
  def FatorFun: Parser[Exp] =
    (for { (v, pos) <- num } yield Num(v)) +:
    (for {
      _ <- op("(")
      e <- ExpFun
      _ <- op(")")
    } yield e) +:
    (for {
      _ <- op("-")
      (v, pos) <- num
    } yield Mult(Num(-1), Num(v))) +:
    (for {
      _ <- kw("if")
      econd <- ExpFun
      _ <- kw("then")
      ethen <- ExpFun
      _ <- kw("else")
      eelse <- ExpFun
      _ <- kw("end")
    } yield If(econd, ethen, eelse)) +:
    (for { _ <- kw("true") } yield True()) +:
    (for { _ <- kw("false") } yield False())
    
  def fun: Parser[Exp] = for {
    e <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield e
  
  def eval(e: Exp): Valor = e match {
    case Num(v) => NumV(v)
    case Soma(e1, e2) => {
      val (NumV(v1), NumV(v2)) = (eval(e1), eval(e2))
      NumV(v1 + v2)
    }
    case Mult(e1, e2) => {
      val (NumV(v1), NumV(v2)) = (eval(e1), eval(e2))
      NumV(v1 * v2)
    }
    case Menor(e1, e2) => {
      val (NumV(v1), NumV(v2)) = (eval(e1), eval(e2))
      if(v1 < v2) TrueV() else FalseV()
    }
    case If(econd, ethen, eelse) => eval(econd) match {
      case TrueV() => eval(ethen)
      case FalseV() => eval(eelse)
    }
    case True() => TrueV()
    case False() => FalseV()
  }
  
  def evalc(e: Exp): Valor = e match {
    case Num(v) => NumV(v)
    case Soma(e1, e2) => (evalc(e1), evalc(e2)) match {
      case (NumV(v1), NumV(v2)) => NumV(v1 + v2)
      case _ => ErroV()
    }
    case Mult(e1, e2) => (evalc(e1), evalc(e2)) match {
      case (NumV(v1), NumV(v2)) => NumV(v1 * v2)
      case _ => ErroV()
    }
    case Menor(e1, e2) => (evalc(e1), evalc(e2)) match {
      case (NumV(v1), NumV(v2)) => if(v1 < v2) TrueV() else FalseV()
      case _ => ErroV()
    }
    case If(econd, ethen, eelse) => evalc(econd) match {
      case TrueV() => evalc(ethen)
      case FalseV() => evalc(eelse)
      case _ => ErroV()
    }
    case True() => TrueV()
    case False() => FalseV()
  }
  
  def run(s: String): Valor = eval(fun.parse(s))
  
  def step(e: Exp): Exp = e match {
    case Num(v) => Num(v)
    case Soma(Num(v1), Num(v2)) => Num(v1 + v2)
    case Soma(Num(v), e) => Soma(Num(v), step(e))
    case Soma(e1, e2) => Soma(step(e1), e2)
    case Mult(Num(v1), Num(v2)) => Num(v1 * v2)
    case Mult(Num(v), e) => Mult(Num(v), step(e))
    case Mult(e1, e2) => Mult(step(e1), e2)
    case True() => True()
    case False() => False()
    case Menor(Num(v1), Num(v2)) => if(v1 < v2) True() else False()
    case Menor(Num(v), e) => Menor(Num(v), step(e))
    case Menor(e1, e2) => Menor(step(e1), e2)
    case If(True(), ethen, eelse) => ethen
    case If(False(), ethen, eelse) => eelse
    case If(econd, ethen, eelse) => If(step(econd), ethen, eelse)
  }
  
  def evals(e: Exp): Valor = e match {
    case Num(v) => NumV(v)
    case True() => TrueV()
    case False() => FalseV()
    case e1 => {
      val e2 = step(e1)
      if(e1 == e2) error("travou " + e1) else evals(e2)
    }
  }

  def stepc(e: Exp): Exp = e match {
    case Num(v) => Num(v)
    case Soma(_, True()) => Erro()
    case Soma(_, False()) => Erro()
    case Soma(True(), _) => Erro()
    case Soma(False(), _) => Erro()
    case Soma(Num(v1), Num(v2)) => Num(v1 + v2)
    case Soma(Num(v), e) => Soma(Num(v), stepc(e))
    case Soma(e1, e2) => Soma(stepc(e1), e2)
    case Mult(_, True()) => Erro()
    case Mult(_, False()) => Erro()
    case Mult(True(), _) => Erro()
    case Mult(False(), _) => Erro()
    case Mult(Num(v1), Num(v2)) => Num(v1 * v2)
    case Mult(Num(v), e) => Mult(Num(v), stepc(e))
    case Mult(e1, e2) => Mult(stepc(e1), e2)
    case True() => True()
    case False() => False()
    case Menor(_, True()) => Erro()
    case Menor(_, False()) => Erro()
    case Menor(True(), _) => Erro()
    case Menor(False(), _) => Erro()
    case Menor(Num(v1), Num(v2)) => if(v1 < v2) True() else False()
    case Menor(Num(v), e) => Menor(Num(v), stepc(e))
    case Menor(e1, e2) => Menor(stepc(e1), e2)
    case If(Num(_), _, _) => Erro()
    case If(True(), ethen, eelse) => ethen
    case If(False(), ethen, eelse) => eelse
    case If(econd, ethen, eelse) => If(stepc(econd), ethen, eelse)
  }

  def evalsc(e: Exp): Valor = e match {
    case Num(v) => NumV(v)
    case True() => TrueV()
    case False() => FalseV()
    case Erro() => ErroV()
    case _ => evalsc(stepc(e))
  }

  def runs(s: String): Valor = evals(fun.parse(s))
}
