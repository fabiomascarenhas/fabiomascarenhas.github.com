import parser._
import util.Random

package object fun {
  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(funs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  // Let
  case class Let(nome: String, exp: Exp, corpo: Exp) extends Exp
  // Funções de primeira classe
  case class Fun(params: List[String], corpo: Exp) extends Exp
  case class Ap(f: Exp, args: List[Exp]) extends Exp
  // Recursão de primeira classe
  case class Rec(nome: String, exp: Exp) extends Exp
  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(e: Exp) extends Exp
  case class Caixa(r: End) extends Exp
  // Exceções
  case class Throw(msg: String) extends Exp
  case class TryCatch(etry: Exp, ecatch: Exp) extends Exp
  case class TryFinally(etry: Exp, efin: Exp) extends Exp

  trait Valor
  case class NumV(v: Double) extends Valor
  case class TrueV() extends Valor
  case class FalseV() extends Valor
  case class FunV(env: Env, params: List[String], corpo: Exp) extends Valor
  case class CaixaV(r: End) extends Valor
  case class ThunkV(env: Env, exp: Exp) extends Valor
  case class RecV(env: Env, nome: String, exp: Exp) extends Valor

  type End = Int
  type Mem = Map[End, Valor]
  type Env = Map[String, Valor]

  // Erros
  trait Talvez[T]
  case class Ok[T](v: T) extends Talvez[T]
  case class Erro[T](msg: String) extends Talvez[T]

  // Ações
  type Acao[T] = Mem => (Talvez[T], Mem)

  implicit class RichAcao[A](val p: Acao[A]) extends AnyVal {
    def flatMap[B](f: A => Acao[B]): Acao[B] = bind(p, f)
    def map[B](f: A => B): Acao[B] = bind(p, (v: A) => emptya(f(v)))
    def filter(f: A => Boolean): Acao[A] = bind(p, (v: A) => if(f(v)) emptya(v)
    else sys.error("filter falhou"))
  }

  def emptya[T](v: T): Acao[T] = m => (Ok(v), m)
  def le(r: Int): Acao[Valor] = m => (Ok(m(r)), m)
  def escreve(r: Int, v: Valor): Acao[Valor] = m => (Ok(CaixaV(r)), m + (r -> v))
  def bind[T, U](a: Acao[T], f: T => Acao[U]): Acao[U] = m => {
    val (v, nm) = a(m)
    v match {
      case Ok(vok) => f(vok)(nm)
      case Erro(msg) => (Erro(msg), nm)
    }
  }
  def erro[T](msg: String): Acao[T] = m => (Erro(msg), m)
  def trycatch[T](atry: Acao[T], acatch: Acao[T]): Acao[T] = m => {
    val (v, nm) = atry(m)
    v match {
      case Ok(_) => (v, nm)
      case Erro(msg) => acatch(nm)
    }
  }
  def tryfinally[T,U](atry: Acao[T], afin: Acao[U]): Acao[T] = m => {
    val (vtry, m1) = atry(m)
    val (vfin, m2) = afin(m1)
    vfin match {
      case Ok(_) => (vtry, m2)
      case Erro(msg) => (Erro(msg), m2)
    }
  }

  def lift[T](l: List[Acao[T]]): Acao[List[T]] = l match {
    case Nil => emptya(Nil)
    case h :: t => for {
      vh <- h    // h é uma Acao[T]
      vt <- lift(t) // lift(t) é uma Acao[List[T]]
    } yield vh :: vt
  }

  def ProgFun: Parser[Prog] = for {
    funs <- many(DefFun)
    corpo <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield Prog(funs.toSet, corpo)

  def DefFun: Parser[Fun1] = for {
    _ <- kw("fun")
    (nome, _) <- id
    _ <- op("(")
    params <- (for {
      (p, _) <- id
      ps <- many(for {
        _ <- op(",")
        (p, _) <- id
      } yield p)
    } yield p :: ps) +: empty(List())
    _ <- op(")")
    corpo <- ExpFun
    _ <- kw("end")
  } yield Fun1(nome, params, corpo)

  def ExpFun: Parser[Exp] =
    chainl(AtexpFun,
      for { _ <- op(";") } yield (e1, e2) => Seq(e1, e2),
      AtexpFun)

  def AtexpFun: Parser[Exp] =
    chainl(RexpFun,
      for { _ <- op(":=") } yield (e1, e2) => Atrib(e1, e2),
      RexpFun)

  def RexpFun: Parser[Exp] =
    chainl(AexpFun,
      for { _ <- op("<") } yield (e1, e2) => Menor(e1, e2),
      AexpFun)

  def AexpFun: Parser[Exp] =
    chainl(TermoFun,
      (for { _ <- op("+") } yield (e1, e2) => Soma(e1, e2)) +:
        (for { _ <- op("-") } yield (e1: Exp, e2: Exp) =>
          Soma(e1, Mult(Num(-1), e2))),
      TermoFun)

  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)

  def ArgsFun : Parser[List[Exp]] = (for {
    a <- ExpFun
    as <- many(for {
      _ <- op(",")
      a <- ExpFun
    } yield a)
  } yield a :: as) +: empty(List())

  def FatorFun: Parser[Exp] =
    (for {
      _ <- kw("fun")
      _ <- op("(")
      params <- (for {
        (p, _) <- id
        ps <- many(for {
          _ <- op(",")
          (p, _) <- id
        } yield p)
      } yield p :: ps) +: empty(List())
      _ <- op(")")
      corpo <- ExpFun
      _ <- kw("end")
    } yield Fun(params, corpo)) +:
      (for { (v, pos) <- num } yield Num(v)) +:
      (for {
        _ <- op("(")
        e <- ExpFun
        _ <- op(")")
        _ <- op("(")
        args <- ArgsFun
        _ <- op(")")
        resto <- many(for{
          _ <- op("(")
          args <- ArgsFun
          _ <- op(")")
        } yield args)
      } yield (args :: resto).foldLeft(e)((f, args) => Ap(f, args))) +:
      (for {
        _ <- op("(")
        e <- ExpFun
        _ <- op(")")
      } yield e) +:
      (for {
        _ <- op("-")
        e <- FatorFun
      } yield Mult(Num(-1), e)) +:
      (for {
        _ <- kw("ref")
        e <- FatorFun
      } yield Ref(e)) +:
      (for {
        _ <- kw("throw")
        (msg, _) <- str
      } yield Throw(msg)) +:
      (for {
        _ <- op("!")
        e <- FatorFun
      } yield Deref(e)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("else")
        eelse <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, eelse)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("end")
      } yield TryCatch(etry, ecatch)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(etry, efin)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(TryCatch(etry, ecatch), efin)) +:
      (for {
        _ <- kw("letrec")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
        _ <- kw("in")
        corpo <- ExpFun
        _ <- kw("end")
      } yield Let(nome, Rec(nome, exp), corpo)) +:
      (for {
        _ <- kw("let")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
        resto <- many(for {
          _ <- op(",")
          (nome, _) <- id
          _ <- op("=")
          exp <- ExpFun
        } yield (nome, exp))
        _ <- kw("in")
        corpo <- ExpFun
        _ <- kw("end")
      } yield ((nome, exp) :: resto).foldRight(corpo){
        case ((nome, exp), corpo) => Let(nome, exp, corpo) // Ap(Fun(List(nome), corpo), List(exp))
      }) +:
      (for { _ <- kw("true") } yield True()) +:
      (for { _ <- kw("false") } yield False()) +:
      (for {
        (nome, _) <- id
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Ap1(nome, args)) +:
      (for { (nome, _) <- id } yield Var(nome))


  def eval(p: Prog): (Talvez[Valor], Mem) = p match {
    case Prog(funs, corpo) => eval(funs)(Map(), corpo)(Map(0 -> NumV(1)))
  }

  def checaNum(a: Acao[Valor], nome: String): Acao[Double] = for {
    va <- a
    n <- va match {
      case NumV(na) => emptya(na)
      case _ => erro[Double](nome + " não é um número")
    }
  } yield n

  def eval(funs: Set[Fun1]) = {
    def eval(env: Env, e: Exp): Acao[Valor] = e match {
      case Num(v) => emptya(NumV(v))
      case Soma(e1, e2) => for {
        n1 <- checaNum(eval(env, e1), "lado esquerdo da soma")
        n2 <- checaNum(eval(env, e2), "lado direito da soma")
      } yield NumV(n1 + n2)
      case Mult(e1, e2) => for {
        NumV(n1) <- eval(env, e1)
        NumV(n2) <- eval(env, e2)
      } yield NumV(n1 * n2)
      case Menor(e1, e2) => for {
        NumV(n1) <- eval(env, e1)
        NumV(n2) <- eval(env, e2)
      } yield if(n1 < n2) TrueV() else FalseV()
      case If(econd, ethen, eelse) => for {
        vcond <- eval(env, econd)
        vif <- vcond match {
          case TrueV() => eval(env, ethen)
          case FalseV() => eval(env, eelse)
        }
      } yield vif
      case True() => emptya(TrueV())
      case False() => emptya(FalseV())
      case Ap1(nome, args) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val pas: List[(String, Acao[Valor])] = params.zip(args).map({
          // parâmetro começado com _ é CBN
          case (p, a) => if(p.startsWith("_")) (p, emptya[Valor](ThunkV(env, a)))
          else (p, eval(env, a))
        })
        for {
          vas <- lift(pas.map({ case (_, a) => a }))  // vas é uma List[Valor]
          vap <- eval(params.zip(vas).toMap, corpo)
        } yield vap
      case Let(nome, exp, corpo) =>
        if(nome.startsWith("_")) eval(env + (nome -> ThunkV(env, exp)), corpo)
        else for {
          vexp <- eval(env, exp)
          vlet <- eval(env + (nome -> vexp), corpo)
        } yield vlet
      case Fun(params, corpo) => emptya(FunV(env, params, corpo))
      case Ap(f, args) => for {
        FunV(fenv, params, corpo) <- eval(env, f)
        pas <- emptya(params.zip(args).map{
          // parâmetro começado com _ é CBN
          case (p, a) => if(p.startsWith("_")) (p, emptya[Valor](ThunkV(env, a)))
          else (p, eval(env, a))
        })
        vas <- lift(pas.map({ case (_, a) => a }))  // vas é uma List[Exp]
        vap <- eval(fenv ++ params.zip(vas).toMap, corpo)
      } yield vap
      case Rec(nome, exp) =>
        eval(env + (nome -> RecV(env, nome, exp)), exp)
      case Ref(e) => for {
        v <- eval(env, e)
        NumV(r) <- le(0)
        c <- escreve(r.toInt, v)
        _ <- escreve(0, NumV(r+1))
      } yield c
      case Deref(e) => for {
        CaixaV(r) <- eval(env, e)
        vr <- le(r)
      } yield vr
      case Atrib(lv, rv) => for {
        CaixaV(r) <- eval(env, lv)
        vrv <- eval(env, rv)
        c <- escreve(r, vrv)
      } yield c
      case Seq(e1, e2) => for {
        _ <- eval(env, e1)
        ve2 <- eval(env, e2)
      } yield ve2
      case Caixa(r) => emptya(CaixaV(r))
      case Throw(msg) => erro(msg)
      case TryCatch(etry, ecatch) => trycatch(eval(env, etry), eval(env, ecatch))
      case TryFinally(etry, efin) => tryfinally(eval(env, etry), eval(env, efin))
      case Var(nome) => env(nome) match {
        // Forçando o thunk recursivo
        case RecV(renv, nome, rexp) => eval(renv + (nome -> RecV(renv, nome, rexp)), rexp)
        // Forçando o thunk normal
        case ThunkV(tenv, texp) => eval(tenv, texp)
        // Outros valores
        case v => emptya(v)
      }
    }
    eval _  // retorna a função eval interna (com funs fixado)
  }

  def cps(e: Exp): Fun = e match {
    case Num(n) => Fun(List("k"), Ap(Var("k"), List(Num(n))))
    case Soma(e1, e2) => Fun(List("k"),
      Ap(cps(e1), List(
        Fun(List("v1"), Ap(cps(e2),
          List(Fun(List("v2"),
            Ap(Var("k"),
              List(Soma(Var("v1"), Var("v2")))))))))))
    case If(econd, ethen, eelse) => Fun(List("k"),
      Ap(cps(econd), List(Fun(List("vc"), If(Var("vc"), Ap(cps(ethen), List(Var("k"))),
        Ap(cps(eelse), List(Var("k"))))))))
  }

}
