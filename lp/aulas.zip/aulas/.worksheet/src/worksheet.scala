object worksheet {
  type Conjunto[T] = T => Boolean;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(107); 
  
  val pares: Conjunto[Int] = (x: Int) => x % 2 == 0;System.out.println("""pares  : Int => Boolean = """ + $show(pares ));$skip(58); 

  def contem[T](conj: Conjunto[T], elem: T) = conj(elem);System.out.println("""contem: [T](conj: T => Boolean, elem: T)Boolean""");$skip(19); val res$0 = 
  contem(pares, 2);System.out.println("""res0: Boolean = """ + $show(res$0));$skip(19); val res$1 = 
  contem(pares, 7);System.out.println("""res1: Boolean = """ + $show(res$1));$skip(65); 
  
  val stam1: Conjunto[String] = (s: String) => s.length == 1;System.out.println("""stam1  : String => Boolean = """ + $show(stam1 ));$skip(22); val res$2 = 

  contem(stam1, "a");System.out.println("""res2: Boolean = """ + $show(res$2));$skip(23); val res$3 = 
  contem(stam1, "foo");System.out.println("""res3: Boolean = """ + $show(res$3));$skip(77); 
  
  def comp[A, B, C](f: A => B, g: B => C): A => C =
    (x: A) => g(f(x));System.out.println("""comp: [A, B, C](f: A => B, g: B => C)A => C""");$skip(48); 

  def dobra[T](f: T => T): T => T = comp(f, f);System.out.println("""dobra: [T](f: T => T)T => T""");$skip(31); val res$4 = 

  dobra((x: Int) => x * x)(3);System.out.println("""res4: Int = """ + $show(res$4))}
}
