package threads

import acao._

object interp {  
  // Valores
  trait Valor {
    /*def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Valor = this match {
      case FunV(envc, params, corpo) =>     
        if (params.size != args.size) 
          sys.error("erro de aridade em função anônima, esperado: " +
              params.size + ", passado: " + args.size)
        else
          corpo.eval(funs)(envc ++ envargs(funs, params, args, env))
      case _ => sys.error("não é uma função: " + this)
    }*/
  
    def force(funs: Map[String, Fun1]): Acao = this match {
      case Thunk(envc, corpo) =>
        corpo.eval(funs)(envc)
      case RecV(envc, nome, corpo) =>
        corpo.eval(funs)(envc + (nome -> RecV(envc, nome, corpo)))
      case v => id(v)
    }    
  }
  case class NumV(v: Double) extends Valor
  case class Bool(v: Boolean) extends Valor
  case class FunV(env: Map[String, Valor], ps: List[String], c: Exp) extends Valor
  case class Thunk(env: Map[String, Valor], c: Exp) extends Valor
  case class RecV(env: Map[String, Valor], nome: String, c: Exp) extends Valor
  case class Caixa(l: Int) extends Valor
  case class ContV(k: Cont) extends Valor
  
  // Ambientes
  type Env[T] = Map[String, T]

  // Memória
  type Mem = Map[Int, Valor]
  
  trait Exp {
    def eval(funs: Env[Fun1])(env: Env[Valor]): Acao = this match {
      case Num(v) => id(NumV(v))
      case True() => id(Bool(true))
      case False() => id(Bool(false))
      case Soma(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield (v1, v2) match {
        case (NumV(n1), NumV(n2)) => NumV(n1 + n2)
        case _ => sys.error("soma precisa de dois números")
      }
      case Mult(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield (v1, v2) match {
        case (NumV(n1), NumV(n2)) => NumV(n1 * n2)
        case _ => sys.error("mult precisa de dois números")
      }
      case Div(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield (v1, v2) match {
        case (NumV(n1), NumV(n2)) => NumV(n1 / n2)
        case _ => sys.error("div precisa de dois números")
      }
      case Menor(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield (v1, v2) match {
        case (NumV(n1), NumV(n2)) => Bool(n1 < n2)
        case _ => sys.error("menor precisa de dois números")
      }
      case Eq(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield Bool(v1 == v2) 
      case If(c, et, ee) => for {
        vc <- c.eval(funs)(env)
        vr <- vc match { 
          case Bool(true) => et.eval(funs)(env)
          case Bool(false) => ee.eval(funs)(env)
          case _ => sys.error("condição do if deve ser booleano: " + c)
        }
      } yield vr
      /*case Ap1(func, args) => 
        funs.get(func) match {
          case Some(f) => f.apply(funs, args, env)
          case None => sys.error("função " + func + " não existe ")
        }*/
/*      case Let(nome, exp, corpo) =>
          if (nome.charAt(0) == '_')
            corpo.eval(funs)(env + (nome -> Thunk(env, exp)))
          else for {
            ve <- exp.eval(funs)(env)
            vc <- corpo.eval(funs)(env + (nome -> ve))
          } yield vc*/
      case Let(nome, exp, corpo) =>
          if (nome.charAt(0) == '_')
            corpo.eval(funs)(env + (nome -> Thunk(env, exp)))
          else bindcc(cc => for {
            ve <- exp.eval(funs)(env)
            vc <- corpo.eval(funs)(env + (nome -> ve) + ("$" -> cc))
          } yield vc)
      case Abort(e) => for {
        ve <- e.eval(funs)(env)
        vr <- env.get("$") match {
          case Some(ContV(k)) => abort(k, ve)
          case _ => sys.error("abort sem continuação")
        }
      } yield vr
      case Spawn(e) => spawn(for {
        v <- e.eval(funs)(env)
        _ <- quit
      } yield NumV(0))
      case Print(e) => for {
        v <- e.eval(funs)(env)
        _ <- id({ println(v); v })
      } yield v
      case Var(nome) => env.get(nome) match {
        case Some(v) => v.force(funs)
        case None => sys.error("variável livre: " + nome)
      }
      case Fun(params, corpo) => id(FunV(env, params, corpo))
      /*case Ap(func, args) => func.eval(funs)(env).apply(funs, args, env)*/
      case Rec(n, e) => e.eval(funs)(env + (n -> RecV(env, n, Rec(n, e))))
      case Ref(e) => for {
        ve <- e.eval(funs)(env) 
        vr <- aloca(ve)
      } yield vr
      case Deref(e) => for {
        vc <- e.eval(funs)(env)
        vr <- vc match {
          case Caixa(l) => le(l)
          case _ => sys.error("valor não é referência")
        }
      } yield vr
      case Seq(e1, e2) => for {
        _ <- e1.eval(funs)(env)
        v <- e2.eval(funs)(env)
      } yield v
      case Atrib(l, r) => for {
        lv <- l.eval(funs)(env)
        v <- lv match {
          case Caixa(l) => for {
            rv <- r.eval(funs)(env)
            _ <- escreve(l, rv)
          } yield rv
          case _ => sys.error("lado esquerdo da atrib não é ref")
        }
      } yield v
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case True() => True()
      case False() => False()
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, False())
      case Ou(e1, e2) => If(e1.desugar, True(), e2.desugar)
      case Nao(e) => If(e.desugar, False(), True())
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Ap(f, as) => Ap(f.desugar, as.map(e => e.desugar))
      case Fun(ps, c) => Fun(ps, c.desugar)
      case Rec(n, e) => Rec(n, e.desugar)
      case Atrib(l, r) => Atrib(l.desugar, r.desugar)
      case Seq(e1, e2) => Seq(e1.desugar, e2.desugar)
      case Ref(e) => Ref(e.desugar)
      case Deref(e) => Deref(e.desugar)
      case Eq(e1, e2) => Eq(e1.desugar, e2.desugar)
      case Abort(e) => Abort(e.desugar)
      case Spawn(e) => Spawn(e.desugar)
      case Print(e) => Print(e.desugar)
    }
  }
  
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem e variáveis
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
    /*def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Valor =
      if (params.size != args.size) 
        sys.error("erro de aridade em " + nome + ", esperado: " +
            params.size + ", passado: " + args.size)
      else
        corpo.eval(funs)(envargs(funs, params, args, env))*/
  }
  case class Prog(defs: Map[String, Fun1], corpo: Exp) {
    def eval: (Valor, Threads, Int, Mem) = (for {
      v <- corpo.eval(defs)(Map())
      _ <- join
    } yield v)(Threads(List()), TICKS, Map(0 -> NumV(0)), (v, ts, ticks, mem) => (v, ts, ticks, mem))
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Funções de primeira classe
  case class Ap(fun: Exp, args: List[Exp]) extends Exp
  case class Fun(params: List[String], corpo: Exp) extends Exp
  
  // Recursão local
  case class Rec(nome: String, exp: Exp) extends Exp
  
  // Listas
  case class Nil() extends Exp

  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(l: Exp) extends Exp
  
  // Igualdade
  case class Eq(e1: Exp, e2: Exp) extends Exp
  
  // Escape
  case class Abort(e: Exp) extends Exp
  case class Spawn(e: Exp) extends Exp
  case class Print(e: Exp) extends Exp
  
  // Gera mapa de substituições para let e parâmetros
  /*def envargs(funs: Map[String, Fun1], oq: List[String], peloq: List[Exp], env: Map[String, Valor]):
      Map[String, Valor] =
    for {
      (nome, exp) <- oq.zip(peloq).toMap
    } yield if (nome.charAt(0) == '_') (nome, Thunk(env, exp))
            else (nome, exp.eval(funs)(env))*/
}

