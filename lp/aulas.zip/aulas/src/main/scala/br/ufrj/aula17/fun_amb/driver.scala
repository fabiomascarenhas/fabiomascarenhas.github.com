package br.ufrj.aula17.fun_amb

object driver extends App {
  println(parser.parseFile(args(0)).eval.take(10).toList)
}