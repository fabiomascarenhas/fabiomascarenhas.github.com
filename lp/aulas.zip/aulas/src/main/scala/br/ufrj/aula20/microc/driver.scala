package br.ufrj.aula20.microc

object driver extends App {
  val kid: acao.Cont = v => (hs, sp, mem) => (v, hs, sp, mem)
  println((parser.parseFile(args(0)).eval)
           (kid)
           (acao.Handlers(List((0, kid))), 0, Map()))
}
