package br.ufrj.aula23.classe

object driver extends App {
  val kid: acao.Cont[interp.Valor] = v => (sp, free, mem) => (v, sp, free, mem)
  val classes: Map[String, interp.Classe] = Map()
  println((parser.parseFile(classes, args(0)).eval)
           (kid)
           (0, 1000, Map()))
}
