package br.ufrj

object Aulas extends App {
  println("Hello, aulas")
}
