package br.ufrj

import scala.annotation.tailrec
package object aula6 {
  def mult(l: List[Double], fator: Double): List[Double] = l match {
    case Nil => Nil
    case h :: t => (h * fator) :: mult(t, fator)
  }
  
  def map[T,U](l: List[T], f: T => U): List[U] = l match {
    case Nil => Nil
    case h :: t => f(h) :: map(t, f)
  }
  
  def filtraMaiores(l: List[Double], pivo: Double): List[Double] = l match {
    case Nil => Nil
    case h :: t => if (h > pivo) h :: filtraMaiores(t, pivo)
                   else filtraMaiores(t, pivo)
  }
  
  def filter[T](l: List[T], pred: T => Boolean): List[T] = l match {
  	case Nil => Nil
  	case h :: t => if (pred(h)) h :: filter(t, pred)
  				   else filter(t, pred)
  }
  
  def pertence[T](l: List[T], n: T): Boolean = l match {
    case Nil => false
    case h :: t => if (n == h) true else pertence(t, n)
  }

  //List(1,1,3,3,2,2,2,2,8,2) = List(1,3,2,8,2)
  def pack[T](l: List[T]): List[T] = {
    def loop(s: List[T], l: List[T]): List[T] = (s,l) match {
      case (s, Nil) => s
      case (Nil, h :: t) => loop(h :: Nil, t)
      case (hs :: ts, hl :: tl) =>
        if (hl == hs) loop(s, tl)
        else loop(hl :: s, tl)
    }
    inverte(loop(Nil, l))
  }
  
  def packF[T](l: List[T]): List[T] = l match {
    case Nil => Nil
    case h :: t => h :: packF(filter[T](t, x => x != h))
  }
  
  // flatten(List(List(1,2,3),List(4,5,6),List(7,8))=
  //    List(1,2,3,4,5,6,7,8)
  def flattenRec[T](l: List[List[T]]): List[T] = l match {
    case Nil => error("lista vazia")
    case h :: Nil => h
    case h :: t => h ++ flattenRec(t)
  }
 
  def reduceRight[T](l: List[T], op: (T, T) => T): T = l match {
    case Nil => error("lista vazia")
    case h :: Nil => h
    case h :: t => op(h, reduceRight(t, op))
  }
  
  def reduceLeft[T](l: List[T], op: (T, T) => T): T = {
    @tailrec
    def loop(l: List[T], acum: T): T = l match {
      case Nil => acum
      case h :: t => loop(t, op(acum, h))
    }
    l match {
      case Nil => error("lista vazia")
      case h :: t => loop(t, h)
    }
  }
  
  def flatten[T](l: List[List[T]]) =
    reduceLeft[List[T]](l, (x, y) => x ++ y)
    
  def foldRight[T,U](l: List[T], z: U, op: (T, U) => U): U = l match {
    case Nil => z
    case h :: t => op(h, foldRight(t, z, op))
  } 

  @tailrec
  def foldLeft[T,U](l: List[T], z : U, op: (U, T) => U): U = l match {
    case Nil => z
    case h :: t => foldLeft(t, op(z, h), op)
  }
  
  def somatorio(l: List[Double]) =
    foldLeft[Double,Double](l, 0, (x, y) => x + y)
    
  def produto(l: List[Double]) =
    foldLeft[Double,Double](l, 1, (x, y) => x * y)
    
  def concat[T](l1: List[T], l2: List[T]) =
    foldRight[T,List[T]](l1, l2, (h, t) => h :: t)
    
  def inverte[T](l: List[T]) = 
    foldLeft[T, List[T]](l, Nil, (t, h) => h :: t)
    
  def pertenceF[T](l: List[T], n: T) =
    foldLeft[T,Boolean](l, false, (b, x) => (x == n) || b)
    
  def prodCart[T,U](l1: List[T], l2: List[U]): List[(T,U)] =
    l1.flatMap(x => l2.map(y => (x, y)))
}
