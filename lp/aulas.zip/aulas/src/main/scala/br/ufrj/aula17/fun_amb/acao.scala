package br.ufrj.aula17.fun_amb

import interp.Caixa
import interp.Valor
import interp.NumV
import interp.Msg

object acao {
  type Acao[T] = Stream[T]

  def id[T](v: T): Acao[T] = Stream[T](v)

  def amb[T](as: Stream[Acao[T]]): Acao[T] = as.flatten
  
  def erro(s: String): Acao[Valor] = sys.error(s)
  def erro(v: Valor): Acao[Valor] = sys.error(v.toString)
 
}


