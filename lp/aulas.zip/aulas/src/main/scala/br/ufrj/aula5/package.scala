package br.ufrj

import scala.annotation.tailrec

package object aula5 {
	def id(x: Int) = x
	def quadrado(x: Int) = x * x
	def fat(x: Int) = {
	    @tailrec
	    def loop(acum: Int, n: Int): Int = {
	      if(n < 2) acum
	      else loop(acum * n, n - 1)
	    }
	    loop(1, x)
	}

	def soma(f: Int => Int, a: Int, b: Int): Int =
	  if (a > b) 0 
	  else f(a) + soma(f, a + 1, b)
	
	def produto(f: Int => Int, a: Int, b: Int): Int =
	  if (a > b) 1
	  else f(a) * produto(f, a + 1, b)
	
	def intervalo[T](f: Int => Int, base: T, op: (Int, T) => T,
	    a: Int, b: Int): T =
	  if (a > b) base
	  else op(f(a), intervalo(f, base, op, a + 1, b))
	  
	def fatorialProd(n: Int) = produto(x => x, 1, n)
	  
	def somaInt = (a: Int, b: Int) => soma(id, a, b)
	def somaQuadrado(a: Int, b: Int) = soma(quadrado, a, b)
	def somaFat(a: Int, b: Int) = soma(fat, a, b)
	
	def somaCurry(f: Int => Int)(a: Int, b: Int): Int =
		if (a > b) 0 else f(a) + somaCurry(f)(a + 1, b)
		
	def somaIntCurry: (Int, Int) => Int = somaCurry(id)

	def abs(x: Double) = if (x < 0) -x else x

	def pontoFixo(f: Double => Double)(est: Double): Double = {
		val erro = 0.00000001
		def suficiente(est1: Double, est2: Double) =
			abs(est2 - est1) < erro * est1
		@tailrec
		def loop(est: Double): Double = {
			val prox = f(est)
			if (suficiente(est, prox)) prox
			else loop(prox)
		}
		loop(est)
	}
	
	def deriv(f: Double => Double): Double => Double = {
	  val dx = 0.00000001
	  x => (f(x + dx) - f(x)) / dx
	}
	
	def zeroNewton(g: Double => Double): Double => Double =
	  pontoFixo(x => x - g(x)/deriv(g)(x))
	
	def raiz(x: Double): Double = zeroNewton(y => y * y - x)(1.0)
	
}

/*
 * f(y) = 2 / y
 * f(1) = 2 / 1 = 2
 * f(2) = 2 / 2 = 1
 * f(1) = 2 / 1 = 2
 * f(2) = 2 / 2 = 1
 * f(a) = 2 / a
 * f(2/a) = 2 / (2 / a) = a
 * f(a) = 2 / a
 */
