package br.ufrj.aula10

object scanner {
  trait Token
  case class OP(c: Char) extends Token {
    override def toString() : String = "'" + c + "'";
  }
  case class EOF() extends Token;
  case class FUN() extends Token;
  case class IF() extends Token;
  case class THEN() extends Token;
  case class ELSE() extends Token;
  case class END() extends Token;
  case class LET() extends Token;
  case class IN() extends Token;
  case class DEFINE() extends Token;
  case class TRUE() extends Token;
  case class FALSE() extends Token;
  case class NIL() extends Token;
  case class LETREC() extends Token;
  case class REC() extends Token;
  case class NUM(n: Double) extends Token;
  case class ID(s: String) extends Token;
  
  def collect(lexeme: String, input: Seq[Char], pred: Char => Boolean): (String, Seq[Char]) =
        input.headOption match {
    case Some(c) if pred(c) => collect(lexeme + c, input.tail, pred)
    case _ => (lexeme, input)
  }
  
  def identifier(input: Seq[Char], line: Int) : (Token, Seq[Char], Int) = {
    val (lexeme, ninput) = 
      collect("" + input.head, input.tail, 
          c => Character.isJavaIdentifierPart(c))
    (lexeme match {
      case "if" => IF()
      case "then" => THEN()
      case "else" => ELSE()
      case "end" => END()
      case "fun" => FUN()
      case "let" => LET()
      case "in" => IN()
      case "define" => DEFINE()
      case "true" => TRUE()
      case "false" => FALSE()
      case "nil" => NIL()
      case "letrec" => LETREC()
      case "rec" => REC()
      case _ => ID(lexeme)
    }, ninput, line)
  }
  
  def number(input: Seq[Char], line: Int) : (Token, Seq[Char], Int) = {
    val (lexeme1, ninput1) = collect("", input, c => c.isDigit)
    ninput1.headOption match {
      case Some('.') => {
        val (lexeme2, ninput2) = collect(lexeme1 + ".", ninput1.tail,
            c => c.isDigit)
        (NUM(lexeme2.toDouble), ninput2, line)
      }
      case _ => (NUM(lexeme1.toDouble), ninput1, line)
    }
  }
  
  def skip(input: Seq[Char], pred: Char => Boolean, 
              line: Int): (Seq[Char], Int) = input.headOption match {
    case Some(c) if pred(c) => skip(input.tail, pred, 
        if (c == '\n') line + 1 else line)
    case _ => (input, line)
  }
  
  def comment(input: Seq[Char], line: Int): (Token, Seq[Char], Int) = {
    val (ninput, nline) = skip(input, c => c != '\n', line) 
    token(ninput, nline)
  }
  
  def token(input: Seq[Char], line: Int):
      (Token, Seq[Char], Int) = {
    val (ninput, nline) = skip(input, c => c.isWhitespace, line)
    ninput.headOption match {
      case None => (EOF(), ninput, nline)
      case Some('-') => ninput.tail.headOption match {
        case Some('-') => comment(ninput, nline)
        case _ => (OP('-'), ninput.tail, nline)
      }
      case Some(c) if Character.isJavaIdentifierStart(c) =>
        identifier(ninput, nline)
      case Some(c) if c.isDigit =>
        number(ninput, nline)
      case Some(c) => (OP(c), ninput.tail, nline)
    }
  }
  
  def scan(input: Seq[Char]): Stream[(Token, Int)] = {
    def loop(input: Seq[Char], line: Int): Stream[(Token, Int)] = 
      token(input, line) match {
        case (EOF(), tail, line) => (EOF(), line) #:: Stream.empty
        case (token, tail, line) => (token, line) #:: loop(tail, line)
      }
    loop(input, 1)
  }
  
  def scanFile(filename: String): Stream[(Token, Int)] = {
    scan(scala.io.Source.fromFile(filename).toSeq)
  }
  
  def scan(input: String): Stream[(Token, Int)] = {
    scan(input.toSeq)
  }
  
}
