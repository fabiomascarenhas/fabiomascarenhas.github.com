package br.ufrj.aula20.microc

import interp.Mem
import interp.Valor
import interp.End

object acao {
  type Comp = (Handlers, End, Mem) => (Valor, Handlers, End, Mem)
  type Cont = Valor => Comp
  type Acao = Cont => Comp
  
  case class Handlers(l: List[(End, Cont)]) {
    def pushHandler(sp: End, k: Cont): Handlers = Handlers((sp, k) :: l)
    def popHandler: (End, Cont, Handlers) = l match {
      case (sp, k) :: t => (sp, k, Handlers(t))
    }
    def pop: Handlers = l match {
      case _ :: t => Handlers(t)
    }
  }
    
  def id(v: Valor): Acao = k => k(v)

  def le(l: End): Acao = k => (hs, sp, mem) => mem.get(l) match {
    case Some(v) => k(v)(hs, sp, mem)
    case None => erro(1)(k)(hs, sp, mem)
  }

  def erro(v: Valor): Acao = k1 => (hs, sp1, mem) => {
    val (sp2, k2, nhs) = hs.popHandler
    k2(v)(nhs, sp2, mem.filter({ case (l, _) => l < sp2 }))
  }
  
  def escreve(l: Int, v: Int): Acao = 
    k => (hs, sp, mem) => k(v)(hs, sp, mem + (l -> v))  

  val SP: Acao = k => (hs, sp, mem) => k(sp)(hs, sp, mem)
  
  def setSP(l: End): Acao = k => (hs, sp, mem) => k(sp)(hs, l, mem)
  
  def free(l: End): Acao = k => (hs, sp, mem) => k(sp)(hs, sp, mem - l)
  
  def bind(a1: Acao, f: Valor => Acao): Acao =
    k => a1(v => f(v)(k))
      
  def trycatch(at: Acao, f: Valor => Acao): Acao = 
    k => (hs, sp, mem) =>
      at(v => (hs, sp, mem) => k(v)(hs.pop, sp, mem))(hs.pushHandler(sp, err => f(err)(k)), sp, mem)
  
  def tryfinally(at: Acao, af: Acao): Acao =
    k => (hs, sp, mem) => {
      val handler: Cont =
        err => af(_ => erro(err)(k))
      at(v => (hs, sp, mem) => af(_ => k(v))(hs.pop, sp, mem))(hs.pushHandler(sp, handler), sp, mem)
    }
    
  implicit class AcaoImp(val a: Acao) extends AnyVal {
    def flatMap(f: Valor => Acao): Acao = bind(a, f)
    def map(f: Valor => Valor): Acao = bind(a, (x: Valor) => id(f(x)))
    def withFilter(p: Valor => Boolean): Acao = bind(a,
        (x: Valor) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def push(v: Int): Acao = for {
    sp <- SP
    _ <- setSP(sp+1)
    _ <- escreve(sp, v)
  } yield sp
  
  def pop: Acao = for {
    sp <- SP
    _ <- setSP(sp-1)
    v <- le(sp-1)
    _ <- free(sp-1)
  } yield v
}


