package br.ufrj.aula19.microc

object driver extends App {
  println((parser.parseFile(args(0)).eval)
           (v => (sp, mem) => (v, sp, mem))
           (0, Map()))
}
