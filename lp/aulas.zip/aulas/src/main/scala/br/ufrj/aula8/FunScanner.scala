package br.ufrj.aula8

class FunScanner(in: Seq[Char]) extends Iterator[FunTokens.YYToken] {
  // These features are added to the Scanner class
  var (lookahead, input, line) = token(in, 1)
    
  override def hasNext() : Boolean = { 
    lookahead match {
      case FunTokens.YYEOF() => false
      case _ => true
    }
  }
  
  def identifier(input: Seq[Char], line: Int) : (FunTokens.YYToken, Seq[Char], Int) = {
    def loop(lexeme: String, input: Seq[Char]): (String, Seq[Char]) = {
      if(!input.isEmpty && input.head.isUnicodeIdentifierPart)
        loop(lexeme + input.head, input.tail)
      else
        (lexeme, input)
    }
    val (lexeme, ninput) = loop("", input)
    (lexeme match {
      case "if" => FunTokens.IF()
      case "then" => FunTokens.THEN()
      case "else" => FunTokens.ELSE()
      case "end" => FunTokens.END()
      case "fun" => FunTokens.FUN()
      case "let" => FunTokens.LET()
      case "in" => FunTokens.IN()
      case "define" => FunTokens.DEFINE()
      case "true" => FunTokens.TRUE()
      case "false" => FunTokens.FALSE()
      case "nil" => FunTokens.NIL()
      case _ => FunTokens.ID(lexeme)
    }, ninput, line)
  }
  
  def number(input: Seq[Char], line: Int) : (FunTokens.YYToken, Seq[Char], Int) = {
    def loop(lexeme: String, input: Seq[Char]): (String, Seq[Char]) = {
      if(!input.isEmpty && input.head.isDigit)
        loop(lexeme + input.head, input.tail)
      else
        (lexeme, input)
    }
    val (lexeme1, ninput1) = loop("", input)
    if(!ninput1.isEmpty && ninput1.head == '.') {
      val (lexeme2, ninput2) = loop(lexeme1 + ".", ninput1.tail)
      (FunTokens.NUM(lexeme2.toDouble), ninput2, line)
    } else 
      (FunTokens.NUM(lexeme1.toDouble), ninput1, line)
  }
  
  def comment(input: Seq[Char], line: Int): (FunTokens.YYToken, Seq[Char], Int) = {
    def skip(input: Seq[Char]): Seq[Char] = {
        if (!input.isEmpty && input.head != '\n')
          skip(input.tail)
        else
          input
    }
    token(skip(input), line)
  }
  
  def token(input: Seq[Char], line: Int):
      (FunTokens.YYToken, Seq[Char], Int) = {
    def skip(input: Seq[Char], line: Int): (Seq[Char], Int) = {
      if(!input.isEmpty && input.head.isWhitespace) {
        if (input.head == '\n') skip(input.tail, line + 1)
        else skip(input.tail, line)
      } else
        (input, line)
    }
    val (ninput, nline) = skip(input, line)
    if (ninput.isEmpty) 
      (FunTokens.YYEOF(), ninput, nline)
    else if (ninput.head.isUnicodeIdentifierStart)
      identifier(ninput, nline)
    else if (ninput.head.isDigit)
      number(ninput, nline)
    else if (ninput.head == '-') {
      if(!ninput.tail.isEmpty && ninput.tail.head == '-')
        comment(ninput, nline)
      else (FunTokens.YYCHAR('-'), ninput.tail, nline)
    } else
      (FunTokens.YYCHAR(ninput.head), ninput.tail, nline)
  }

  override def next() : FunTokens.YYToken = {
    val result = lookahead
    val (tok, ninput, nline) = token(input, line)
    lookahead = tok
    input = ninput
    line = nline
    result
  }
  
}