package br.ufrj.aula13

object interp {  
  // Valores
  trait Valor {
    def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Valor = this match {
      case FunV(envc, params, corpo) =>     
        if (params.size != args.size) 
          sys.error("erro de aridade em função anônima, esperado: " +
              params.size + ", passado: " + args.size)
        else
          corpo.eval(funs)(envc ++ envargs(funs, params, args, env))
      case _ => sys.error("não é uma função: " + this)
    }
  
    def force(funs: Map[String, Fun1])(mem: Mem): (Valor, Mem) = this match {
      case Thunk(envc, corpo) =>
        corpo.eval(funs)(envc)(mem)
      case RecV(envc, nome, corpo) =>
        corpo.eval(funs)(envc + (nome -> RecV(envc, nome, corpo)))(mem)
      case v => (v, mem)
    }    
  }
  case class NumV(v: Double) extends Valor
  case class Bool(v: Boolean) extends Valor
  case class FunV(env: Map[String, Valor], ps: List[String], c: Exp) extends Valor
  case class Thunk(env: Map[String, Valor], c: Exp) extends Valor
  case class RecV(env: Map[String, Valor], nome: String, c: Exp) extends Valor
  case class Caixa(l: Int) extends Valor
  
  // Ambientes
  type Env[T] = Map[String, T]

  // Memória
  type Mem = Map[Int, Valor]
  
  trait Exp {
    def eval(funs: Env[Fun1])(env: Env[Valor])(mem: Mem): (Valor, Mem) = this match {
      case Num(v) => (NumV(v), mem)
      case True() => (Bool(true), mem)
      case False() => (Bool(false), mem)
      case Soma(e1, e2) => {
        val (v1, mem1) = e1.eval(funs)(env)(mem)
        val (v2, mem2) = e2.eval(funs)(env)(mem1)
        (v1, v2) match {
          case (NumV(n1), NumV(n2)) => (NumV(n1+n2), mem2)
          case _ => sys.error("soma precisa de dois números")
        }
      } 
      case Mult(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 * v2)
        case _ => sys.error("mult precisa de dois números")
      }
      case Div(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 / v2)
        case _ => sys.error("div precisa de dois números")
      }
      case Menor(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => Bool(v1 < v2)
        case _ => sys.error("menor precisa de dois números")
      }
      case Eq(e1, e2) => Bool(e1.eval(funs)(env) == e2.eval(funs)(env))
      case If(c, et, ee) => {
        val (vc, mem1) = c.eval(funs)(env)(mem)
        vc match {
          case Bool(true) => et.eval(funs)(env)(mem1)
          case Bool(false) => ee.eval(funs)(env)(mem1)
          case _ => sys.error("condição do if deve ser booleano: " + c)
        }
      }
      case Ap1(func, args) => 
        funs.get(func) match {
          case Some(f) => f.apply(funs, args, env)
          case None => sys.error("função " + func + " não existe ")
        }
      case Let(nome, exp, corpo) =>
          if (nome.charAt(0) == '_')
            corpo.eval(funs)(env + (nome -> Thunk(env, exp)))
          else 
            corpo.eval(funs)(env + (nome -> exp.eval(funs)(env)))
      case Var(nome) => env.get(nome) match {
        case Some(v) => v.force(funs)(mem)
        case None => sys.error("variável livre: " + nome)
      }
      case Fun(params, corpo) => (FunV(env, params, corpo), mem)
      case Ap(func, args) => func.eval(funs)(env).apply(funs, args, env)
      case Rec(n, e) => e.eval(funs)(env + (n -> RecV(env, n, Rec(n, e))))
      case Ref(e) => Caixa(e.eval(funs)(env))
      case Deref(e) => e.eval(funs)(env) match {
        case Caixa(v) => v
        case _ => sys.error("valor não é referência")
      }
      case Seq(e1, e2) => {
        val (_, nmem) = e1.eval(funs)(env)(mem)
        e2.eval(funs)(env)(nmem)
      }
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case True() => True()
      case False() => False()
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, False())
      case Ou(e1, e2) => If(e1.desugar, True(), e2.desugar)
      case Nao(e) => If(e.desugar, False(), True())
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Ap(f, as) => Ap(f.desugar, as.map(e => e.desugar))
      case Fun(ps, c) => Fun(ps, c.desugar)
      case Rec(n, e) => Rec(n, e.desugar)
      case Atrib(l, r) => Atrib(l.desugar, r.desugar)
      case Seq(e1, e2) => Seq(e1.desugar, e2.desugar)
      case Ref(e) => Ref(e.desugar)
      case Deref(e) => Deref(e.desugar)
      case Eq(e1, e2) => Eq(e1.desugar, e2.desugar)
    }
  }
  
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem e variáveis
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
    def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Valor =
      if (params.size != args.size) 
        sys.error("erro de aridade em " + nome + ", esperado: " +
            params.size + ", passado: " + args.size)
      else
        corpo.eval(funs)(envargs(funs, params, args, env))
  }
  case class Prog(defs: Map[String, Fun1], corpo: Exp) {
    def eval: Valor = corpo.eval(defs)(Map())
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Funções de primeira classe
  case class Ap(fun: Exp, args: List[Exp]) extends Exp
  case class Fun(params: List[String], corpo: Exp) extends Exp
  
  // Recursão local
  case class Rec(nome: String, exp: Exp) extends Exp
  
  // Listas
  case class Nil() extends Exp

  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(l: Exp) extends Exp
  
  // Igualdade
  case class Eq(e1: Exp, e2: Exp) extends Exp
  
  // Gera mapa de substituições para let e parâmetros
  def envargs(funs: Map[String, Fun1], oq: List[String], peloq: List[Exp], env: Map[String, Valor]):
      Map[String, Valor] =
    for {
      (nome, exp) <- oq.zip(peloq).toMap
    } yield if (nome.charAt(0) == '_') (nome, Thunk(env, exp))
            else (nome, exp.eval(funs)(env))
}

