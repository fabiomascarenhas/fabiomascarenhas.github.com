package br.ufrj.aula18.microc

import interp.Mem
import interp.Valor
import interp.End

object acao {
  trait Talvez
  case class Ok(v: Valor) extends Talvez
  case class Erro(v: Valor) extends Talvez
  
  type Acao = (End, Mem) => (Talvez, End, Mem)

  def id(v: Valor): Acao = (sp, mem) => (Ok(v), sp, mem)

  def le(l: Int): Acao = (sp, mem) => mem.get(l) match {
    case Some(v) => (Ok(v), sp, mem)
    case None => erro(0)(sp, mem)
  }

  def erro(v: Valor): Acao = (sp, mem) => (Erro(v), sp, mem)
  
  def escreve(l: Int, v: Int): Acao = (sp, mem) => (Ok(v), sp, mem + (l -> v))  

  val SP: Acao = (sp, mem) => (Ok(sp), sp, mem)
  
  def setSP(l: End): Acao = (sp, mem) => (Ok(sp), l, mem)
  
  def free(l: End): Acao = (sp, mem) => (Ok(sp), sp, mem - l)
  
  def bind(a1: Acao, f: Valor => Acao): Acao = (sp, mem) => {
    val (v, nsp, nmem) = a1(sp, mem)
    v match {
      case Ok(v) => {
        val a2 = f(v)
        a2(nsp, nmem)
      }
      case Erro(v) => (Erro(v), nsp, nmem)
    }
  }

  def trycatch(at: Acao, f: Valor => Acao): Acao = (sp, mem) => {
    val (v, nsp, nmem) = at(sp, mem)
    v match {
      case Erro(v) => {
        val ac = f(v)
        ac(sp, nmem.filter({ case (l, _) => l < sp }))
      }
      case Ok(v) => (Ok(v), nsp, nmem)
    }
    
  }
  
  implicit class AcaoImp(val a: Acao) extends AnyVal {
    def flatMap(f: Valor => Acao): Acao = bind(a, f)
    def map(f: Valor => Valor): Acao = bind(a, (x: Valor) => id(f(x)))
    def withFilter(p: Valor => Boolean): Acao = bind(a,
        (x: Valor) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def push(v: Int): Acao = for {
    sp <- SP
    _ <- setSP(sp+1)
    _ <- escreve(sp, v)
  } yield sp
  
  def pop: Acao = for {
    sp <- SP
    _ <- setSP(sp-1)
    v <- le(sp-1)
    _ <- free(sp-1)
  } yield v
}


