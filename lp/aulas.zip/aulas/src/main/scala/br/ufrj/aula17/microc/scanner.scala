package br.ufrj.aula17.microc

object scanner {
  trait Token
  case class OP(c: Char) extends Token {
    override def toString() : String = "'" + c + "'";
  }
  case class EOF() extends Token;
  case class FUN() extends Token;
  case class IF() extends Token;
  case class THEN() extends Token;
  case class ELSE() extends Token;
  case class WHILE() extends Token;
  case class DO() extends Token;
  case class END() extends Token;
  case class LET() extends Token;
  case class IN() extends Token;
  case class EQ() extends Token;
  case class AND() extends Token;
  case class OR() extends Token;
  case class TRY() extends Token;
  case class CATCH() extends Token;
  case class THROW() extends Token;
  case class NUM(n: Double) extends Token;
  case class ID(s: String) extends Token;
  
  def collect(lexeme: String, input: Seq[Char], pred: Char => Boolean): (String, Seq[Char]) =
        input.headOption match {
    case Some(c) if pred(c) => collect(lexeme + c, input.tail, pred)
    case _ => (lexeme, input)
  }
  
  def identifier(input: Seq[Char], line: Int) : (Token, Seq[Char], Int) = {
    val (lexeme, ninput) = 
      collect("" + input.head, input.tail, 
          c => Character.isJavaIdentifierPart(c))
    (lexeme match {
      case "if" => IF()
      case "then" => THEN()
      case "else" => ELSE()
      case "end" => END()
      case "fun" => FUN()
      case "let" => LET()
      case "in" => IN()
      case "while" => WHILE()
      case "do" => DO()
      case "try" => TRY()
      case "catch" => CATCH()
      case "throw" => THROW()
       case _ => ID(lexeme)
    }, ninput, line)
  }
  
  def number(input: Seq[Char], line: Int) : (Token, Seq[Char], Int) = {
    val (lexeme1, ninput1) = collect("", input, c => c.isDigit)
    ninput1.headOption match {
      case Some('.') => {
        val (lexeme2, ninput2) = collect(lexeme1 + ".", ninput1.tail,
            c => c.isDigit)
        (NUM(lexeme2.toDouble), ninput2, line)
      }
      case _ => (NUM(lexeme1.toDouble), ninput1, line)
    }
  }
  
  def skip(input: Seq[Char], pred: Char => Boolean, 
              line: Int): (Seq[Char], Int) = input.headOption match {
    case Some(c) if pred(c) => skip(input.tail, pred, 
        if (c == '\n') line + 1 else line)
    case _ => (input, line)
  }
  
  def comment(input: Seq[Char], line: Int): (Token, Seq[Char], Int) = {
    val (ninput, nline) = skip(input, c => c != '\n', line) 
    token(ninput, nline)
  }
  
  def token(input: Seq[Char], line: Int):
      (Token, Seq[Char], Int) = {
    val (ninput, nline) = skip(input, c => c.isWhitespace, line)
    ninput.headOption match {
      case None => (EOF(), ninput, nline)
      case Some('-') => ninput.tail.headOption match {
        case Some('-') => comment(ninput, nline)
        case _ => (OP('-'), ninput.tail, nline)
      }
      case Some('=') => ninput.tail.headOption match {
        case Some('=') => (EQ(), ninput.tail.tail, nline)
        case _ => (OP('='), ninput.tail, nline)
      }
      case Some('&') => ninput.tail.headOption match {
        case Some('&') => (AND(), ninput.tail.tail, nline)
        case _ => (OP('&'), ninput.tail, nline)
      }
      case Some('|') => ninput.tail.headOption match {
        case Some('|') => (OR(), ninput.tail.tail, nline)
        case _ => (OP('|'), ninput.tail, nline)
      }
      case Some(c) if Character.isJavaIdentifierStart(c) =>
        identifier(ninput, nline)
      case Some(c) if c.isDigit =>
        number(ninput, nline)
      case Some(c) => (OP(c), ninput.tail, nline)
    }
  }
  
  def scan(input: Seq[Char]): Stream[(Token, Int)] = {
    def loop(input: Seq[Char], line: Int): Stream[(Token, Int)] = 
      token(input, line) match {
        case (EOF(), tail, line) => (EOF(), line) #:: Stream.empty
        case (token, tail, line) => (token, line) #:: loop(tail, line)
      }
    loop(input, 1)
  }
  
  def scanFile(filename: String): Stream[(Token, Int)] = {
    scan(scala.io.Source.fromFile(filename).toSeq)
  }
  
  def scan(input: String): Stream[(Token, Int)] = {
    scan(input.toSeq)
  }
  
}
