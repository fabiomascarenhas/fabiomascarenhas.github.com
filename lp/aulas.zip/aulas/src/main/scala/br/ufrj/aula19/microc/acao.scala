package br.ufrj.aula19.microc

import interp.Mem
import interp.Valor
import interp.End

object acao {
  type Comp = (End, Mem) => (Valor, End, Mem)
  type Cont = Valor => Comp
  type Acao = Cont => Comp
  
  def id(v: Valor): Acao = k => k(v)

  def le(l: End): Acao = k => (sp, mem) => mem.get(l) match {
    case Some(v) => k(v)(sp, mem)
    case None => erro(1)(k)(sp, mem)
  }

  def erro(v: Valor): Acao = k => (sp, mem) => (v, sp, mem)
  
  def escreve(l: Int, v: Int): Acao = 
    k => (sp, mem) => k(v)(sp, mem + (l -> v))  

  val SP: Acao = k => (sp, mem) => k(sp)(sp, mem)
  
  def setSP(l: End): Acao = k => (sp, mem) => k(sp)(l, mem)
  
  def free(l: End): Acao = k => (sp, mem) => k(sp)(sp, mem - l)
  
  def bind(a1: Acao, f: Valor => Acao): Acao =
    k => a1(v => f(v)(k))
      
  /*def trycatch(at: Acao, f: Valor => Acao): Acao = (sp, mem) => {
    val (v, nsp, nmem) = at(sp, mem)
    v match {
      case Erro(v) => {
        val ac = f(v)
        ac(sp, nmem.filter({ case (l, _) => l < sp }))
      }
      case Ok(v) => (Ok(v), nsp, nmem)
    }
    
  }*/
  
  implicit class AcaoImp(val a: Acao) extends AnyVal {
    def flatMap(f: Valor => Acao): Acao = bind(a, f)
    def map(f: Valor => Valor): Acao = bind(a, (x: Valor) => id(f(x)))
    def withFilter(p: Valor => Boolean): Acao = bind(a,
        (x: Valor) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def push(v: Int): Acao = for {
    sp <- SP
    _ <- setSP(sp+1)
    _ <- escreve(sp, v)
  } yield sp
  
  def pop: Acao = for {
    sp <- SP
    _ <- setSP(sp-1)
    v <- le(sp-1)
    _ <- free(sp-1)
  } yield v
}


