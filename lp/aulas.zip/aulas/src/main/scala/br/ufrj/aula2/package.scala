package br.ufrj

import scala.annotation.tailrec

package object aula2 {
	def raio = 5
	def pi = 3.14159
	val circ = 2 * pi * raio
	def quadrado(x: Double) = x * x
	def somaDeQuadrados(x: Double, y: Double) = 
		quadrado(x) + quadrado(y)
	def loop: Int = loop
	def primeiro(x: Int, y: => Int) = x
	
	def abs(x: Double) = if (x < 0) -x else x
	
	 /*
	  raizIter(1, 2) =
	  if (abs(quadrado(1) - 2) < 0.000001) 1
	    else raizIter(melhora(1, 2), 2) =
	   if (false) 1 else raizIter(melhora(1, 2), 2) =
	   raizIter(melhora(1, 2), 2) =
	   raizIter(1.5, 2) =
	   if (abs(qquadrado(1.5) - 2) < 0.000001) 1.5
	     else raizIter(melhora(1.5, 2), 2) =
	    if (false) 1.5 else raizIter(melhora(1.5, 2), 2) =
	    raizIter(melhora(1.5, 2), 2) =
	    raizIter(1.4166666666666665, 2) = ... =
	    raizIter(1.4142135623746899, 2) =
	    if (abs(quadrado(1.4142135623746899) - 2) < 0.000001)
	         1.4142135623746899
	       else raizIter(melhora(1.4142135623746899, 2), 2) =
	     if (true) 1.4142135623746899 else
	        raizIter(melhora(1.4142135623746899, 2), 2) =
	     1.4142135623746899 
	  */
	 	 		
	def raiz(x: Double) = {
			def melhora(est: Double, x: Double) =
					(est + x / est) / 2
			@tailrec
			def raizIter(est: Double, x: Double): Double =
				if (abs(quadrado(est) - x) < 0.000001)
					est
				else
					raizIter(melhora(est, x), x)
			raizIter(1, x)	
	 }
	
	@tailrec
	def mdc(a: Int, b: Int) : Int =
	  if (b == 0)
		  a 
	  else 
		  mdc(b, a % b)
}

/*
fat(4) =
if (4 < 2) 1 else 4 * fat(4 - 1) =
4 * fat(4 - 1) =
4 * fat(3) =
4 * (if (3 < 2) 1 else 3 * fat(3 - 1)) =
4 * (3 * fat(3 - 1)) =
4 * (3 * fat(2)) =
4 * (3 * (if (2 < 2) 1 else 2 * fat(2 - 1))) =
4 * (3 * (2 * fat(2-1))) =
4 * (3 * (2 * fat(1))) =
4 * (3 * (2 * (if (1 < 2) 1 else 1 * fat(1 - 1)))) =
4 * (3 * (2 * (1))) =
4 * (3 * 2) =
4 * 6 =
24

 
 */
 

