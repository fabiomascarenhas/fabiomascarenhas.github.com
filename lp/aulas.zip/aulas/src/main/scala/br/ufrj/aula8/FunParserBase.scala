package br.ufrj.aula8;

import scala.io.Source

abstract class FunParserBase {
  var res: Option[interp.Prog] = None;
  
  def yyreset(input : Iterator[FunTokens.YYToken]);
  def yyparse(): Boolean;
  def parse_exp(): interp.Exp;
  
  def parseProg(input : Iterator[FunTokens.YYToken]): interp.Prog = {
    yyreset(input)
    yyparse()
    res match {
      case None => sys.error("parser não retornou nada!")
      case Some(x) => x
    }
  }
      
  def parseProg(filename: String): interp.Prog = {
    val input : Iterator[Char] = Source.fromFile(filename)
    parseProg(new FunScanner(input.toSeq))
  }

  def parseExp(input : Iterator[FunTokens.YYToken]): interp.Exp = {
    parseProg(input) match {
      case interp.Prog(_, e) => e
    }
  }
  
  def parseExp(filename: String): interp.Exp = {
    val input : Iterator[Char] = Source.fromFile(filename)
    parseExp(new FunScanner(input.toSeq))
  }
  
  def parse(source: String): interp.Exp = {
    parseProg(new FunScanner(source.toSeq)) match {
      case interp.Prog(_, e) => e
    }
  }

}
