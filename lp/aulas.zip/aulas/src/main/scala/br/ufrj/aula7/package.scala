import scala.annotation.tailrec

package br.ufrj.aula7 {

    trait Lista[T] {
      def map[U](f: T => U): Lista[U] = this match {
        case Vazia() => Vazia[U]
        case Cons(hd, tl) => Cons(f(hd), tl.map(f))
      }
    }
    case class Vazia[T]() extends Lista[T]
    case class Cons[T](hd: T, tl: Lista[T]) extends Lista[T]

    trait Talvez[T] {
      def map[U](f: T => U): Talvez[U] = this match {
        case Nada() => Nada[U]
        case Apenas(x) => Apenas(f(x))
      }
    }
    case class Nada[T]() extends Talvez[T]
    case class Apenas[T](x: T) extends Talvez[T]
    
    trait ArvoreBin[T] {
      def altura: Int = this match {
        case Folha(x) => 1
        case Ramo(_,esq,dir) => 1 + math.max(esq.altura, dir.altura)
      }
      
      def preOrdem: List[T] = this match {
        case Folha(r) => List(r)
        case Ramo(r, e, d) => List(r) ++ e.preOrdem ++ d.preOrdem
      }
      
      def preFoldR[U](z: U, f: (T, U) => U) = 
        this.preOrdem.foldRight(z)(f)
        
      def cata[U](f: T => U)(g: (T, U, U) => U): U = this match {
        case Folha(r) => f(r)
        case Ramo(r, e, d) => g(r, e.cata(f)(g), d.cata(f)(g))
      }
      
      def emOrdem: List[T] = 
        this.cata(r => List(r))((r, le, ld) => le ++ List(r) ++ ld)
        
      def map[U](f: T => U): ArvoreBin[U] =
        this.cata[ArvoreBin[U]](r => Folha(f(r)))((r, me, md) => Ramo(f(r), me, md))
    }
    
    case class Folha[T](rot: T) extends ArvoreBin[T]
    case class Ramo[T](rot: T, 
                       esq: ArvoreBin[T], 
                       dir: ArvoreBin[T]) extends ArvoreBin[T]

    
    object funcoes {
      // o tipo da funcao anonima e T => List[T]
      def filtro[T](l: List[T], pred: T => Boolean): List[T] =
        l.flatMap((x: T) => if (pred(x)) List(x) else List())

      @tailrec
      def mdc(a: Int, b: Int) : Int =
          if (b == 0) a else mdc(b, a % b)
      
      def tamanho[T](l: Lista[T]): Int = l match {
          case Vazia() => 0
          case Cons(hd, tl) => 1 + tamanho(tl)
      }
 
      def primeiro[T](l: List[T]): Option[T] = l match {
          case Nil => None
          case h :: t => Some(h)
      }
      
      def multPrimeiro2(l1: List[Int], l2: List[Int]): Option[Int] =
        primeiro(l1).flatMap(x =>
          primeiro(l2).map(y => x * y))
          
     def somaArvore(a: ArvoreBin[Int]): Int =
       a.cata(r => r)((r, se, sd) => r + se + sd)
    }
}
