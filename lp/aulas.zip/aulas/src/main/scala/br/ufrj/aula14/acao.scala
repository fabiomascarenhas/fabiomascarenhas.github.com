package br.ufrj.aula14

import interp.Valor
import interp.Mem
import interp.NumV
import interp.Caixa

object acao {
  type Acao[T] = (Int, Mem) => (T, Int, Mem)

  def id[T](v: T): Acao[T] = (free, mem) => (v, free, mem)

  def le(l: Int): Acao[Valor] = (free, mem) => mem.get(l) match {
    case Some(v) => (v, free, mem)
    case None => sys.error("endereço inválido: " + l)
  }
  
  def escreve(l: Int, v: Valor): Acao[Valor] = (free, mem) => (v, free, mem + (l -> v))  

  val next: Acao[Int] = (free, mem) => (free, free+1, mem)
  
  def bind[T, U](a1: Acao[T], f: T => Acao[U]): Acao[U] = (free, mem) => {
    val (v, nfree, nmem) = a1(free, mem)
    val a2 = f(v)
    a2(nfree, nmem)
  }

  implicit class AcaoImp[T](val a: Acao[T]) extends AnyVal {
    def flatMap[U](f: T => Acao[U]): Acao[U] = bind(a, f)
    def map[U](f: T => U): Acao[U] = bind(a, (x: T) => id(f(x)))
    def withFilter(p: T => Boolean): Acao[T] = bind(a,
        (x: T) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def aloca(v: Valor): Acao[Valor] = for {
    nl <- next
    _ <- escreve(nl, v)
  } yield Caixa(nl)
  
  
}


/*

def aloca(v: Valor): Acao[Valor] = for {
  NumV(l) <- le(0)
  nl <- id(l.toInt+1)
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl)

=>

le(0).flatMap({ case NumV(l) => for {
  nl <- id(l.toInt+1)
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => for {
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl)) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) => for {
  _ <- escreve(nl, v)
} yield Caixa(nl))) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) =>
      escreve(nl, v).map((_) => Caixa(nl)))) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) =>
      escreve(nl, v).flatMap((_) => id(Caixa(nl))))) })

=>

le(0).bind({ case NumV(l) => 
  id(l.toInt+1).bind((nl) => 
    escreve(0, NumV(nl)).bind((_) =>
      escreve(nl, v).bind((_) => id(Caixa(nl))))) })

=>

bind(le(0), { case NumV(l) => 
  bind(id(l.toInt+1), (nl: Int) => 
    bind(escreve(0, NumV(nl)), (_: Valor) =>
      bind(escreve(nl, v), (_: Valor) => id(Caixa(nl))))) })

=>

bind(le(0), (lv: Valor) => {
  val NumV(l) = lv 
  bind(id(l.toInt+1), (nl: Int) => 
    bind(escreve(0, NumV(nl)), (_: Valor) =>
      bind(escreve(nl, v), (_: Valor) => id(Caixa(nl))))) })


 */
