class FooMeta
  def s
  end
end

class Foo
  def m
    5
  end
end

c = Foo

Foo.s
f = c.new
# classe de f é Foo
# classe de Foo é FooMeta
# classe de FooMeta é Metaclass
