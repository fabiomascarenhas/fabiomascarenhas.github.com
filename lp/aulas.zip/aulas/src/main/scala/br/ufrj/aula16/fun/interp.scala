package br.ufrj.aula16.fun

import acao._

object interp {  
  // Valores
  trait Valor {
    def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Acao[Valor] = this match {
      case FunV(envc, params, corpo) =>     
        if (params.size != args.size) 
          erro("erro de aridade em função anônima, esperado: " +
              params.size + ", passado: " + args.size)
        else for {
          vargs <- AcaoImp(evalArgs(funs, params.zip(args), env))
          vr <- corpo.eval(funs)(envc ++ params.zip(vargs))
        } yield vr
      case _ => erro("não é uma função: " + this)
    }
  
    def force(funs: Map[String, Fun1]): Acao[Valor] = this match {
      case Thunk(envc, corpo) =>
        corpo.eval(funs)(envc)
      case RecV(envc, nome, corpo) =>
        corpo.eval(funs)(envc + (nome -> RecV(envc, nome, corpo)))
      case v => id(v)
    }    
  }
  case class NumV(v: Double) extends Valor
  case class Bool(v: Boolean) extends Valor
  case class FunV(env: Map[String, Valor], ps: List[String], c: Exp) extends Valor
  case class Thunk(env: Map[String, Valor], c: Exp) extends Valor
  case class RecV(env: Map[String, Valor], nome: String, c: Exp) extends Valor
  case class Caixa(l: Int) extends Valor
  case class Msg(s: String) extends Valor
  
  // Ambientes
  type Env[T] = Map[String, T]

  trait Exp {
    def eval(funs: Env[Fun1])(env: Env[Valor]): Acao[Valor] = this match {
      case Num(v) => id(NumV(v))
      case True() => id(Bool(true))
      case False() => id(Bool(false))
      case Soma(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
        vs <- (v1, v2) match {
                 case (NumV(n1), NumV(n2)) => id[Valor](NumV(n1 + n2))
                 case _ => erro("soma precisa de dois números")
              }
      } yield vs
      case Mult(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
        vs <- (v1, v2) match {
                 case (NumV(n1), NumV(n2)) => id[Valor](NumV(n1 * n2))
                 case _ => erro("mult precisa de dois números")
              }
      } yield vs
      case Div(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
        vs <- (v1, v2) match {
                 case (NumV(n1), NumV(n2)) => id[Valor](NumV(n1 / n2))
                 case _ => erro("div precisa de dois números")
              }
      } yield vs
      case Menor(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
        vs <- (v1, v2) match {
                 case (NumV(n1), NumV(n2)) => id[Valor](Bool(n1 < n2))
                 case _ => erro("menor precisa de dois números")
              }
      } yield vs
      case Eq(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield Bool(v1 == v2) 
      case If(c, et, ee) => for {
        vc <- c.eval(funs)(env)
        vi <- vc match { 
          case Bool(true) => et.eval(funs)(env)
          case Bool(false) => ee.eval(funs)(env)
          case _ => erro("condição do if deve ser booleano: " + c)
        }
      } yield vi
      case Ap1(func, args) => 
        funs.get(func) match {
          case Some(f) => f.apply(funs, args, env)
          case None => erro("função " + func + " não existe ")
        }
      case Let(nome, exp, corpo) =>
          if (nome.charAt(0) == '_')
            corpo.eval(funs)(env + (nome -> Thunk(env, exp)))
          else for {
            ve <- exp.eval(funs)(env)
            vc <- corpo.eval(funs)(env + (nome -> ve))
          } yield vc
      case Var(nome) => env.get(nome) match {
        case Some(v) => v.force(funs)
        case None => erro("variável livre: " + nome)
      }
      case Fun(params, corpo) => id(FunV(env, params, corpo))
      case Ap(func, args) => for {
        vf <- func.eval(funs)(env)
        vr <- vf.apply(funs, args, env)
      }  yield vr
      case Rec(n, e) => e.eval(funs)(env + (n -> RecV(env, n, Rec(n, e))))
      case Seq(e1, e2) => for {
        _ <- e1.eval(funs)(env)
        v <- e2.eval(funs)(env)
      } yield v
      case Throw(e) => for {
        v <- e.eval(funs)(env)
        ve <- erro(v)
      } yield ve
      /*case TryCatch(e1, n, e2) =>
        trycatch(e1.eval(funs)(env), err => for {
          v <- e2.eval(funs)(env + (n -> err))
        } yield v)*/
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case True() => True()
      case False() => False()
      case Nil() => Nil()
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, False())
      case Ou(e1, e2) => If(e1.desugar, True(), e2.desugar)
      case Nao(e) => If(e.desugar, False(), True())
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Ap(f, as) => Ap(f.desugar, as.map(e => e.desugar))
      case Fun(ps, c) => Fun(ps, c.desugar)
      case Rec(n, e) => Rec(n, e.desugar)
      case Seq(e1, e2) => Seq(e1.desugar, e2.desugar)
      case Eq(e1, e2) => Eq(e1.desugar, e2.desugar)
      case Cons(e1, e2) => Cons(e1.desugar, e2.desugar)
      case Throw(e) => Throw(e.desugar)
      case TryCatch(e1, n, e2) => TryCatch(e1.desugar, n, e2.desugar)
    }
  }
  
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem e variáveis
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
    def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Acao[Valor] =
      if (params.size != args.size) 
        erro("erro de aridade em " + nome + ", esperado: " +
            params.size + ", passado: " + args.size)
      else for {
        vargs <- AcaoImp(evalArgs(funs, params.zip(args), env))
        vf <- corpo.eval(funs)(params.zip(vargs).toMap)
      } yield vf
  }
  case class Prog(defs: Map[String, Fun1], corpo: Exp) {
    def eval: Valor = corpo.eval(defs)(Map())
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Funções de primeira classe
  case class Ap(fun: Exp, args: List[Exp]) extends Exp
  case class Fun(params: List[String], corpo: Exp) extends Exp
  
  // Recursão local
  case class Rec(nome: String, exp: Exp) extends Exp
  
  // Listas
  case class Cons(h: Exp, t: Exp) extends Exp
  case class Nil() extends Exp

  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  
  // Igualdade
  case class Eq(e1: Exp, e2: Exp) extends Exp
  
  // Exceções
  case class Throw(e: Exp) extends Exp
  case class TryCatch(e1: Exp, n: String, e2: Exp) extends Exp
  
  // Não-determinismo
  case class Amb(es: List[Exp]) extends Exp
  
  // Avalia argumentos de uma chamada de função

  def evalArgs(funs: Env[Fun1], paramargs: List[(String,Exp)], env: Env[Valor]):
      Acao[List[Valor]] = paramargs match {
    case (nome, exp) :: t => for {
      varg <- if (nome.charAt(0) == '_') id[Valor](Thunk(env, exp))
              else exp.eval(funs)(env)
      vargs <- AcaoImp(evalArgs(funs, t, env))
    } yield varg :: vargs
    case List() => id[List[Valor]](List[Valor]())
  }
}

