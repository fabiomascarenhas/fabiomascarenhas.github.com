package br.ufrj

import scala.annotation.tailrec

package object aula4 {
	def tamanho[T](l: List[T]): Int = l match {
	  case Nil => 0
	  case _ :: t => 1 + tamanho(t)
	}

	def inverte[T](l: List[T]) = {
	  @tailrec
	  def loop(acum: List[T], l: List[T]): List[T] = l match {
	    case Nil => acum
	    case h :: t => loop(h :: acum, t)
	  }
	  loop(Nil, l)
	}

	// divisao inteira, retorna quociente e resto
	def div(a: Int, b: Int): (Int, Int) = (a / b, a % b)
	
	def zipper[T](l: List[T]): (List[T], T, List[T]) = l match {
	  case Nil => sys.error("lista vazia")
	  case h :: t => (Nil, h, t)
	}
	
	def paraFrente[T](z: (List[T], T, List[T])) = z match {
	  case (e, f, Nil) => sys.error("final do zipper")
	  case (e, f, h :: t) => (f :: e, h, t)
	}
	
	def paraTras[T](z: (List[T], T, List[T])) = z match {
	  case (Nil, f, d) => sys.error("inicio do zipper")
	  case (h :: t, f, d) => (t, h, f :: d)
	}
	
	def divide(l: List[Int], pos: Int): (List[Int], List[Int]) = {
	  def loop(z: (List[Int], Int, List[Int]), n: Int) :
	      (List[Int], Int, List[Int]) = {
	    if (n == 0) z
	    else loop(paraFrente(z), n - 1)
	  }
	  val (e, f, d) = loop(zipper(l), pos)
	  (e, f :: d)
	}
	
	def merge(l1: List[Int], l2: List[Int]): List[Int] = (l1, l2) match {
	  case (Nil, l) => l
	  case (l, Nil) => l
	  case (x :: xs, y :: ys) =>
	    if (x <= y) x :: merge(xs, l2)
	    else y :: merge(l1, ys)
	}
	
	def mergeSort(l: List[Int]): List[Int] = l match {
	  case Nil => l
	  case _ :: Nil => l
	  case _ => {
	    val (e, d) = divide(l, tamanho(l) / 2)
	    merge(mergeSort(e), mergeSort(d))
	  }
	}
}

/*
tamanho(1 :: 2 :: 3 :: Nil) =
1 :: 2 :: 3 :: Nil match { case Nil => 0 case _ :: t => ... } =
1 + tamanho(2 :: 3 :: Nil) =
1 + (2 :: 3 :: Nil match { case Nil => 0 case _ :: t => ... }) =
1 + (1 + tamanho(3 :: Nil)) =
1 + (1 + (3 :: Nil match { case Nil => 0 case _ :: t => ... })) =
1 + (1 + (1 + tamanho(Nil))) =
1 + (1 + (1 + (Nil match { case Nil => 0 case _ :: t => ... }))) =
1 + (1 + (1 + (0))) =
1 + (1 + 1) =
1 + 2 =
3
*/
