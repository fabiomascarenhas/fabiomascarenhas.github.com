package br.ufrj.aula8

package interp {  
  // Valores
  trait Valor
  case class NumV(v: Double) extends Valor
  case class Bool(v: Boolean) extends Valor
  
  trait Exp {
    def eval: Valor = this match {
      case Num(v) => NumV(v)
      case Soma(e1, e2) => (e1.eval, e2.eval) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 + v2)
        case _ => error("soma precisa de dois números")
      }
      case Mult(e1, e2) => (e1.eval, e2.eval) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 * v2)
        case _ => error("mult precisa de dois números")
      }
      case Menor(e1, e2) => (e1.eval, e2.eval) match {
        case (NumV(v1), NumV(v2)) => Bool(v1 < v2)
        case _ => error("menor precisa de dois números")
      }
      case If(c, et, ee) => c.eval match {
        case Bool(true) => et.eval
        case Bool(false) => ee.eval
        case _ => error("condição do if deve ser booleano")
      }
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, False())
      case Ou(e1, e2) => If(e1.desugar, True(), e2.desugar)
      case Nao(e) => If(e.desugar, False(), True())
    }
    
    def dseval: Valor = this.desugar.eval
  }
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp

  // Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(defs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e1: Exp, e2: Exp) extends Exp

  // Funções de primeira classe
  case class Ap(fun: Exp, args: List[Exp]) extends Exp
  case class Fun(params: List[String], corpo: Exp) extends Exp
  
  // Listas
  case class Nil() extends Exp

  // Funções de utilidade
  object util {
    def liftNumV(v1: Valor, v2: Valor, op: (Double, Double) => Double) = 
      (v1, v2) match {
        case (NumV(v1), NumV(v2)) => NumV(op(v1, v2))
        case _ => error("operação precisa de dois números")
      }
  }
}


object parser {
  def parseProg(filename: String): interp.Prog = {
    new FunParser().parseProg(filename)
  }

  def parseExp(filename: String): interp.Exp = {
    new FunParser().parseExp(filename)
  }
  
  def parse(source: String): interp.Exp = {
    new FunParser().parse(source)
  }
}

object scanner {
  def scanFile(filename: String): Seq[FunTokens.YYToken] = {
    val input : Iterator[Char] = scala.io.Source.fromFile(filename)
    val scan = new FunScanner(input.toSeq)
    scan.toSeq
  }
  
  def scanStr(source: String): Seq[FunTokens.YYToken] = {
    new FunScanner(source.toSeq).toSeq
  }
}

object driver extends App {
  println(parser.parseExp(args(0)).dseval)
}

