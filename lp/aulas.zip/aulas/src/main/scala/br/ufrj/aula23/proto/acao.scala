package br.ufrj.aula23.proto

import interp.Mem
import interp.Valor
import interp.NumV
import interp.End
import interp.Env
import interp.Metodo
import interp.ObjV

object acao {
  // (stack, heap, memória)
  type Comp = (End, End, Mem) => (Valor, End, End, Mem)
  type Cont[T] = T => Comp
  type Acao[T] = Cont[T] => Comp
  
  def id[T](v: T): Acao[T] = k => k(v)

  def le(l: End): Acao[Valor] = k => (sp, free, mem) => mem.get(l) match {
    case Some(v) => k(v)(sp, free, mem)
    case None => k(NumV(0))(sp, free, mem)
  }

  def escreve(l: End, v: Valor): Acao[Valor] = 
    k => (sp, free, mem) => k(v)(sp, free, mem + (l -> v))  

  val SP: Acao[End] = k => (sp, free, mem) => k(sp)(sp, free, mem)
  
  def setSP(l: End): Acao[End] = k => (sp, free, mem) => k(sp)(l, free, mem)
  
  def free(l: End): Acao[End] = k => (sp, free, mem) => k(sp)(sp, free, mem - l)
  
  val HP: Acao[End] = k => (sp, free, mem) => k(free)(sp, free, mem)
  
  def setHP(l: End): Acao[End] = k => (sp, free, mem) => k(free)(sp, l, mem)
  
  def bump(n: Int): Acao[End] = k => (sp, free, mem) => k(free)(sp, free+n, mem)
  
  def bind[T, U](a1: Acao[T], f: T => Acao[U]): Acao[U] =
    k => a1(v => f(v)(k))

  implicit class AcaoImp[T](val a: Acao[T]) extends AnyVal {
    def flatMap[U](f: T => Acao[U]): Acao[U] = bind(a, f)
    def map[U](f: T => U): Acao[U] = bind(a, (x: T) => id(f(x)))
    def withFilter(p: T => Boolean): Acao[T] = bind(a,
        (x: T) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
    
  def copy(from: End, to: End, count: Int): Acao[Unit] = 
    if (count > 0) for {
      v <- le(from)
      _ <- escreve(to, v)
      _ <- copy(from + 1, to + 1, count - 1)
    } yield () 
    else id(())
    
  def clonar(self: ObjV): Acao[ObjV] = {
    val ncampos = self.campos.size
    for {
        c1 <- bump(ncampos)
        _ <- copy(self.campos(0), c1, ncampos)
    } yield ObjV((c1 until c1 + ncampos).toVector, self.metodos, self.proto)
  }
  
  def push(v: Valor): Acao[End] = for {
    sp <- SP
    _ <- setSP(sp+1)
    _ <- escreve(sp, v)
  } yield sp
  
  def pop: Acao[Valor] = for {
    sp <- SP
    _ <- setSP(sp-1)
    v <- le(sp-1)
    _ <- free(sp-1)
  } yield v
}


