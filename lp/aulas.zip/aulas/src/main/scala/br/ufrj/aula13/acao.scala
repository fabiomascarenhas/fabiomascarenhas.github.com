package br.ufrj.aula13

import interp.Valor
import interp.Mem
import interp.NumV
import interp.Caixa

object acao {
  type Acao[T] = Mem => (T, Mem)

  def id[T](v: T): Acao[T] = m => (v, m)

  def bind[T, U](a: Acao[T], f: T => Acao[U]): Acao[U] = m => {
    val (v, nm) = a(m)
    f(v)(nm)
  }

  def le(l: Int): Acao[Valor] = m => m.get(l) match {
    case Some(v) => (v, m)
    case None => sys.error("endereço inválido: " + l)
  }
  
  def escreve(l: Int, v: Valor): Acao[Valor] = m => (v, m + (l -> v))
  
  implicit class AcaoFuncs[T](val a: Acao[T]) extends AnyVal {
    def flatMap[U](f: T => Acao[U]): Acao[U] = bind(a, f)
    def map[U](f: T => U): Acao[U] = bind(a, (v: T) => id(f(v)))
    def filter(p: T => Boolean): Acao[T] = 
      bind(a, (v: T) => if (p(v)) id(v) 
                        else sys.error("predicado do filtro falhou"))
  }
   
 
  def aloca(v: Valor): Acao[Valor] = for {
    NumV(l) <- le(0)
    nl <- id(l.toInt+1)
    _ <- escreve(0, NumV(nl))
    _ <- escreve(nl, v)
  } yield Caixa(nl)
  
  def foldA[T, U](l: List[T], z: U, op: (U, T) => Acao[U]): Acao[U] = l match {
    case h :: t => for {
                     nz <- op(z, h)
                     res <- foldA(t, nz, op)
                   } yield res
    case Nil => id(z)
  }
  
  def mapA[T, U](l: List[T], f: T => Acao[U]): Acao[List[U]] = l match {
    case h :: t => for {
                     vh <- f(h)
                     lt <- mapA(t, f)
                   } yield vh :: lt
    case List() => id(List[U]())
  }

}

