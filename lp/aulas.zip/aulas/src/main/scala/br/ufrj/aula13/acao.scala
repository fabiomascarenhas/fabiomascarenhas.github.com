package br.ufrj.aula13

import interp.Valor
import interp.Mem
import interp.NumV
import interp.Caixa


trait Acao[T] {

  def exec(m: Mem): (T, Mem) = this match {
    case AcaoFlatMap(a, f) => {
      val (v, nm) = a.exec(m)
      f(v).exec(nm)
    }
    case AcaoMap(a, f) => {
      val (v, nm) = a.exec(m)
      (f(v), nm)
    }
    case AcaoFilter(a, p) => {
      val (v, nm) = a.exec(m)
      if (p(v)) (v, nm) else sys.error("predicado falhou")
    }
    case Unit(v) => (v, m)
    case AcaoFold(l, z, op) => l match {
      case h :: t => (for {
        nz <- op(z, h)
        res <- AcaoFold(t, nz, op)
      } yield res).exec(m)
      case Nil => (z, m)
    }
  }
  
  def flatMap[U](f: T => Acao[U]): Acao[U] = AcaoFlatMap(this, f)
  def map[U](f: T => U): Acao[U] = AcaoMap(this, f)
  def withFilter(p: T => Boolean): Acao[T] = AcaoFilter(this, p)
}

case class AcaoFlatMap[T, U](a: Acao[T], f: T => Acao[U]) extends Acao[U]
case class AcaoMap[T, U](a: Acao[T], f: T => U) extends Acao[U]
case class AcaoFilter[T](a: Acao[T], p: T => Boolean) extends Acao[T]
case class AcaoFold[T, U](l: List[T], z: U, op: (U, T) => Acao[U]) extends Acao[U]
case class Unit[T](v: T) extends Acao[T]

case class Le(l: Int) extends Acao[Valor] {
  override def exec(m: Mem): (Valor, Mem) = m.get(l) match {
      case Some(v) => (v, m)
      case None => sys.error("endereço inválido: " + l)
  }
}

case class Escreve(l: Int, v: Valor) extends Acao[Valor] {
  override def exec(m: Mem): (Valor, Mem) = (v, m + (l -> v))
}

case class Aloca(v: Valor) extends Acao[Valor] {
  override def exec(m: Mem): (Valor, Mem) =
    (for {
       NumV(l) <- Le(0)
       nl <- Unit(l.toInt+1)
       _ <- Escreve(0, NumV(nl))
       _ <- Escreve(nl, v)
     } yield Caixa(nl)).exec(m)
}

case class MapA[T, U](l: List[T], f: T => Acao[U]) extends Acao[List[U]] {
  override def exec(m: Mem): (List[U], Mem) = l match {
    case h :: t => (for {
                      vh <- f(h)
                      lt <- MapA(t, f)
                    } yield vh :: lt).exec(m)
    case List() => (List[U](), m)
  }
}

