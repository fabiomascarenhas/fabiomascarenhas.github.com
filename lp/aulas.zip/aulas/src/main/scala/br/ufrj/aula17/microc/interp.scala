package br.ufrj.aula17.microc

import acao._

object interp {  
  // Ambientes
  type Env[T] = Map[String, T]

  // Memória
  type Mem = Map[Int, Int]
  
  trait Exp {
    def eval(funs: Env[Fun1])(env: Env[Int]): Acao[Int] = this match {
      case _ => sys.error("não implementado")
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, Num(0))
      case Ou(e1, e2) => If(e1.desugar, Num(1), e2.desugar)
      case Nao(e) => If(e.desugar, Num(0), Num(1))
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Atrib(l, r) => Atrib(l.desugar, r.desugar)
      case Seq(e1, e2) => Seq(e1.desugar, e2.desugar)
      case Ender(e) => Ender(e)
      case Deref(e) => Deref(e.desugar)
      case Eq(e1, e2) => Eq(e1.desugar, e2.desugar)
      case While(e, c) => While(e.desugar, c.desugar)
    }
  }
  
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Expressões ariméticas - Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais e controle
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class While(cond: Exp, corpo: Exp) extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem e variáveis
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
  }
  case class Prog(defs: Map[String, Fun1], corpo: Exp) {
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Atribuições e ponteiros
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ender(v: String) extends Exp
  case class Deref(e: Exp) extends Exp
  
  // Igualdade
  case class Eq(e1: Exp, e2: Exp) extends Exp
  
}

