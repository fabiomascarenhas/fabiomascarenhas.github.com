package br.ufrj.aula23.proto

import scanner._    

object parser {
  // Trait para poder especificar parsers usando for
  trait Parser[T] {
    def parse(input: Stream[(Token, Int)]): (T, Stream[(Token, Int)]);
    
    def flatMap[U](f: T => Parser[U]): Parser[U] = {
      val p = this
      new Parser[U] {
        override def parse(input: Stream[(Token, Int)]): (U, Stream[(Token, Int)]) = {
          val (res, tail) = p.parse(input)
          f(res).parse(tail)
        }
      }
    }
  
    def map[U](f: T => U): Parser[U] = {
      val p = this
      new Parser[U] {
        override def parse(input: Stream[(Token, Int)]): (U, Stream[(Token, Int)]) = {
          val (res, tail) = p.parse(input)
          (f(res), tail)
        }
      }
    }
    
    def withFilter(f: T => Boolean): Parser[T] = {
      val p = this
      new Parser[T] {
        override def parse(input: Stream[(Token, Int)]): (T, Stream[(Token, Int)]) = {
          val (res, tail) = p.parse(input)
          if (f(res)) (res, tail) else sys.error("predicado falhou")
        }
      }
    }
  }

  // Precedência de operadores binários
  val prec: Map[Token, (Int, Int)] = Map(
    OR()    -> (3, 3),
    AND()   -> (4, 4),
    OP('<') -> (5, 5),
    EQ()    -> (5, 5),
    OP('+') -> (6, 6),
    OP('-') -> (6, 6),
    OP('*') -> (7, 7),
    OP('/') -> (7, 7),
    OP('=') -> (8, 2),
    OP(';') -> (2, 1)
  )
  
  // Construtores dos operadores binários
  val binExp: Map[Token, (interp.Exp, interp.Exp) => interp.Exp] = Map(
    OR()    -> interp.Ou,
    AND()   -> interp.E,
    OP('<') -> interp.Menor,
    OP('+') -> interp.Soma,
    OP('-') -> interp.Sub,
    OP('*') -> interp.Mult,
    OP('/') -> interp.Div,
    OP('=') -> interp.Atrib,
    OP(';') -> interp.Seq,
    EQ()    -> interp.Eq
  )
  
  // Próximo token tem que ser tok ou é erro
  def token(tok: Token) = new Parser[Token] {
    override def parse(input: Stream[(Token, Int)]): (Token, Stream[(Token, Int)]) =
      input.head match {
        case (token, line) if token == tok => (token, input.tail)
        case (token, line) => sys.error("erro de sintaxe na linha " + line +
            ", encontrado: " + token + ", esperado: " + tok)
      }
  }
  
  // Retorna próximo token sem avançar
  object peek extends Parser[Token] {
    override def parse(input: Stream[(Token, Int)]): (Token, Stream[(Token, Int)]) = {
      val (token, _) = input.head
      (token, input)
    }
  }

  // Erro de parsing
  def parseError[T](esperado: String) = new Parser[T] {
    override def parse(input: Stream[(Token, Int)]): (T, Stream[(Token, Int)]) = {
      val (token, line) = input.head
      sys.error("erro de sintaxe na linha: " + line + ", encontrado: " +
          token + ", esperado: " + esperado)
    }
  }

  // Introduz um valor no parser
  def unit[T](x: T) = new Parser[T] {
    override def parse(input: Stream[(Token, Int)]): (T, Stream[(Token, Int)]) =
      (x, input)
  }

  // Salta próximo token e introduz um valor
  def skip[T](x: T) = new Parser[T] {
    override def parse(input: Stream[(Token, Int)]): (T, Stream[(Token, Int)]) =
      (x, input.tail)
  }
  
  // Uma lista de ps separados por vírgula
  def listOf[T](p: Parser[T]): Parser[List[T]] = for {
    first <- p
    tok <- peek
    rest <- if (tok == OP(',')) (for {
                                   _ <- token(OP(','))
                                   rest <- listOf(p) 
                                 } yield rest)
            else unit(List[T]())
  } yield first :: rest

  // Identificadores
  object id extends Parser[String] {
    override def parse(input: Stream[(Token, Int)]): (String, Stream[(Token, Int)]) =
      input.head match {
        case (ID(s), line) => (s, input.tail)
        case (token, line) => sys.error("erro de sintaxe na linha " + line +
            ", encontrado: " + token + ", esperado identificador")
      }
  }  

  // Identificadores
  object num extends Parser[Int] {
    override def parse(input: Stream[(Token, Int)]): (Int, Stream[(Token, Int)]) =
      input.head match {
        case (NUM(n), line) => (n, input.tail)
        case (token, line) => sys.error("erro de sintaxe na linha " + line +
            ", encontrado: " + token + ", esperado número")
      }
  }  
 
  // Métodos
  val metodo: Parser[interp.Metodo] = for {
    _ <- token(DEF())
    nome <- id
    _ <- token(OP('('))
    tok <- peek
    params <- if (tok == OP(')')) unit(List[String]()) 
              else listOf(id)
    _ <- token(OP(')'))
    corpo <- exp
    _ <- token(END())
  } yield interp.Metodo(nome, params, corpo.desugar)
  
  // Expressões atômicas
  val simple: Parser[interp.Exp] = for {
    tok <- peek
    e <- tok match {
      case NUM(n) => skip(interp.Num(n))
      case ID(s) => for {
        v <- skip(interp.Var(s))
      } yield v
      case OBJECT() => anonobj
      case NEW() => skip(interp.New())
      case SELF() => skip(interp.Self())
      case SUPER() => skip(interp.Super())
      case IF() => parseIf
      case LET() => let
      case WHILE() => for {
        _ <- token(WHILE())
        cond <- exp
        _ <- token(DO())
        corpo <- exp
        _ <- token(END())
      } yield interp.While(cond, corpo)
      case OP('!') => for {
        _ <- token(OP('!'))
        e <- simple
      } yield interp.Nao(e)
      case OP('-') => for {
        _ <- token(OP('-'))
        e <- simple
      } yield interp.Menos(e)
      case OP('@') => for {
        _ <- token(OP('@'))
        n <- num
      } yield interp.Campo(n)
      case OP('(') => for {
        _ <- token(OP('('))
        e <- exp
        _ <- token(OP(')'))
      } yield e
      case READ() => for {
        _ <- token(READ())
      } yield interp.Read()
      case PRINT() => for {
        _ <- token(PRINT())
        es <- args
      } yield es match {
        case Some(l) => interp.Print(l)
        case None => interp.Print(List())
      }
      case _ => parseError("expressão")
    }
    tok <- peek
    call <- if (tok == OP('.')) for {
                                  _ <- token(OP('.'))
                                  m <- id
                                  Some(as) <- args
                                } yield Some((m, as))
            else unit(None) 
  } yield call match {
    case Some((m, as)) => interp.Send(e, m, as)
    case None => e
  }
  
  // Lista de argumentos (entre parênteses) de uma chamada
  val args: Parser[Option[List[interp.Exp]]] = for {
    _ <- token(OP('('))
    tok <- peek
    list <- if (tok == OP(')')) unit(List())
            else listOf(exp)
    _ <- token(OP(')'))
  } yield Some(list)

  // Expressões
  val exp: Parser[interp.Exp] = for {
    e1 <- simple
    e <- expPrec(e1, 0)
  } yield e

  // Expressões binárias
  def expPrec(first: interp.Exp, limit: Int): Parser[interp.Exp] = for {
    left <- unit(first)
    op <- peek
    res <- prec.get(op) match {
      case Some((pleft, pright)) => if (pleft > limit) for {
                                             _ <- token(op)
                                             next <- simple
                                             right <- expPrec(next, pright)
                                             e <- expPrec(binExp(op)(left, right), limit)
                                           } yield e
                     else unit(left)
      case None => unit(left)
    }
  } yield res

  // Expressão if
  val parseIf: Parser[interp.If] = for {
    _ <- token(IF())
    cond <- exp
    _ <- token(THEN())
    ethen <- exp
    _ <- token(ELSE())
    eelse <- exp
    _ <- token(END())
  } yield interp.If(cond, ethen, eelse)
  
  // Let e let múltiplo
  val let: Parser[interp.Exp] = for {
    _ <- token(LET())
    bindings <- listOf(binding)
    _ <- token(IN())
    corpo <- exp
    _ <- token(END())
  } yield bindings match {
    case (nome, e) :: Nil => interp.Let(nome, e, corpo)
    case _ => interp.LetM(bindings, corpo)
  }
  
  // Atribuição do let
  val binding: Parser[(String, interp.Exp)] = for {
    nome <- id
    _ <- token(OP('='))
    e <- exp
  } yield (nome, e)
  
  val metodos: Parser[Map[String, interp.Metodo]] = for {
    tok <- peek
    ms <- if (tok == DEF()) for {
                              m <- metodo
                              ms <- metodos
                            } yield ms + (m.nome -> m)
          else unit(Map[String, interp.Metodo]())
  } yield ms
  
  val obj: Parser[(String, interp.Obj)] = for {
    _ <- token(OBJECT())
    nome <- id
    _ <- token(OP('('))
    ncampos <- num
    _ <- token(OP(')'))
    tok <- peek
    proto <- tok match {
      case EXTENDS() => for {
        _ <- token(EXTENDS())
        n <- exp
      } yield Some(n)
      case _ => unit(None)
    }
    ms <- metodos
    _ <- token(END())
  } yield (nome, interp.Obj(ncampos, ms, proto))

  val anonobj: Parser[interp.Obj] = for {
    _ <- token(OBJECT())
    _ <- token(OP('('))
    ncampos <- num
    _ <- token(OP(')'))
    tok <- peek
    proto <- tok match {
      case EXTENDS() => for {
        _ <- token(EXTENDS())
        n <- exp
      } yield Some(n)
      case _ => unit(None)
    }
    ms <- metodos
    _ <- token(END())
  } yield interp.Obj(ncampos, ms, proto)

  // Objetos do top-level
  val objs: Parser[interp.Exp] = for {
    tok <- peek
    os <- if (tok == OBJECT()) for {
                              (n, o) <- obj
                              os <- objs
                            } yield interp.Let(n, o.desugar, os.desugar)
          else exp
  } yield os
  
  // Programa
  val prog: Parser[interp.Prog] = for {
    os <- objs
    _ <- token(EOF())
  } yield interp.Prog(os)
  
  def parseProg(input: Seq[Char]): interp.Prog = {
    val tokens = scanner.scan(input)
    val (p, _) = prog.parse(tokens)
    p
  }
  
  def parseExp(input: Seq[Char]): interp.Exp = {
    val tokens = scanner.scan(input)
    val (interp.Prog(e), _) = prog.parse(tokens)
    e
  }

  def parseProg(input: String): interp.Prog = parseProg(input.toSeq)

  def parseExp(input: String): interp.Exp = parseExp(input.toSeq)
  
  def parseFile(filename: String): interp.Prog =
    parseProg(scala.io.Source.fromFile(filename).toSeq)
}

