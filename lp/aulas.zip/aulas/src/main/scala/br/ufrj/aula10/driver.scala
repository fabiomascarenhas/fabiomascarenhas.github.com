package br.ufrj.aula10

object driver extends App {
  val prog = parser.parseFile(args(0))
  println(prog)
  println(prog.eval)
}
