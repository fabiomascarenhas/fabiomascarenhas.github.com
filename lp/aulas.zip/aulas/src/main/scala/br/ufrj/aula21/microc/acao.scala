package br.ufrj.aula21.microc

import interp.Mem
import interp.Valor
import interp.End

object acao {
  type Comp = (Int, Threads, End, Mem) => (Valor, Int, Threads, End, Mem)
  type Cont = Valor => Comp
  type Acao = Cont => Comp
  
  type Thread = (Valor, End, Cont)
  
  val TICKS = 5
  
  case class Threads(l: List[Thread]) {
    def insert(t: Thread): Threads = Threads(l ++ List(t))
    def remove: (Thread, Threads) = l match {
      case t :: ts => (t, Threads(ts))
    }
    def change(t: Thread): (Thread, Threads) = 
      this.insert(t).remove
  }
  
  def check(a: Acao): Acao = k => (tick, ts, sp, mem) =>
    if(tick > 0) a(k)(tick, ts, sp, mem)
    else change(_ => a(k))(tick, ts, sp, mem)
  
  def id(v: Valor): Acao = check(k => k(v))

  def atomic(a: Acao): Acao = 
    k => (tick, ts, sp, mem) =>
        a(v => (_, ts, sp, mem) =>
            k(v)(tick, ts, sp, mem))(Integer.MAX_VALUE, ts, sp, mem)
      
  def le(l: End): Acao = check(k => (tick, hs, sp, mem) => mem.get(l) match {
    case Some(v) => k(v)(tick-1, hs, sp, mem)
    case None => erro(1)(k)(tick-1, hs, sp, mem)
  })

  def erro(v: Valor): Acao = k1 => (tick, ts, sp1, mem) => (tick, v, ts, sp1, mem)
  
  val fim: Cont = v => (tick, ts, sp, mem) => (tick, v, ts, sp, mem)
  
  def spawn(t: Acao, spt: End): Acao = k => (tick, ts, sp, mem) => {
    val thatual = (spt, sp, k)
    t(fim)(TICKS, ts.insert(thatual), spt, mem)
  }
  
  def join(v: Valor): Acao = k => (tick, ts, sp, mem) => {
    val Threads(l) = ts
    if(l.size == 0) (tick, v, ts, sp, mem)
    else {
      val ((v, nsp, nk), nts) = ts.remove
      nk(v)(TICKS, nts, nsp, mem)
    }
  } 
  
  val change: Acao = k => (tick, ts, sp, mem) => {
    val thatual = (0, sp, k)
    val ((v, nsp, nk), nts) = ts.change(thatual)
    nk(v)(TICKS, nts, nsp, mem)
  }
  
  def escreve(l: Int, v: Int): Acao = 
    check(k => (tick, hs, sp, mem) => k(v)(tick-1, hs, sp, mem + (l -> v)))  

  val SP: Acao = check(k => (tick, hs, sp, mem) => k(sp)(tick-1, hs, sp, mem))
  
  def setSP(l: End): Acao = check(k => (tick, hs, sp, mem) => k(sp)(tick-1, hs, l, mem))
  
  def free(l: End): Acao = check(k => (tick, hs, sp, mem) => k(sp)(tick-1, hs, sp, mem - l))
  
  def bind(a1: Acao, f: Valor => Acao): Acao =
    k => a1(v => f(v)(k))
      

  implicit class AcaoImp(val a: Acao) extends AnyVal {
    def flatMap(f: Valor => Acao): Acao = bind(a, f)
    def map(f: Valor => Valor): Acao = bind(a, (x: Valor) => id(f(x)))
    def withFilter(p: Valor => Boolean): Acao = bind(a,
        (x: Valor) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def push(v: Int): Acao = for {
    sp <- SP
    _ <- setSP(sp+1)
    _ <- escreve(sp, v)
  } yield sp
  
  def pop: Acao = for {
    sp <- SP
    _ <- setSP(sp-1)
    v <- le(sp-1)
    _ <- free(sp-1)
  } yield v
}


