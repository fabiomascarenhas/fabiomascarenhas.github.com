package br.ufrj.aula16.fun_err

import interp.Mem
import interp.Caixa
import interp.Valor
import interp.NumV
import interp.Msg

object acao {
  trait Talvez[T]
  case class Ok[T](v: T) extends Talvez[T]
  case class Erro[T](exc: Valor) extends Talvez[T]
  
  type Acao[T] = Mem => (Talvez[T], Mem)

  def id[T](v: T): Acao[T] = mem => (Ok(v), mem)
  
  def erro(s: String): Acao[Valor] = mem => (Erro(Msg(s)), mem)
  def erro(v: Valor): Acao[Valor] = mem => (Erro(v), mem)
  
  def le(l: Int): Acao[Valor] = mem => mem.get(l) match {
    case Some(v) => (Ok(v), mem)
    case None => erro("endereço inválido: " + l)(mem)
  }
  
  def escreve(l: Int, v: Valor): Acao[Valor] = mem => (Ok(v), mem + (l -> v))  

  val next: Acao[Int] = for {
    NumV(free) <- le(0)
    _ <- escreve(0, NumV(free+1))
  } yield free.toInt
  
  def bind[T, U](a1: Acao[T], f: T => Acao[U]): Acao[U] = mem => {
    val (v, nmem) = a1(mem)
    v match {
      case Ok(v) => {
        val a2 = f(v)
        a2(nmem)  // => (v2: U, nmem2)
      }
      case Erro(v) => (Erro(v), nmem)
    }
  }
  
  def trycatch[T](atry: Acao[T], f: Valor => Acao[T]): Acao[T] = mem => {
    val (ve, nmem) = atry(mem)
    ve match {
      case Ok(v) => (Ok(v), nmem)
      case Erro(v) => {
        val acatch = f(v)
        acatch(nmem)
      }
    }
  }

  implicit class AcaoImp[T](val a: Acao[T]) extends AnyVal {
    def flatMap[U](f: T => Acao[U]): Acao[U] = bind(a, f)
    def map[U](f: T => U): Acao[U] = bind(a, (x: T) => id(f(x)))
    def withFilter(p: T => Boolean): Acao[T] = bind(a,
        (x: T) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def aloca(v: Valor): Acao[Valor] = for {
    nl <- next
    _ <- escreve(nl, v)
  } yield Caixa(nl)
  
  
}


