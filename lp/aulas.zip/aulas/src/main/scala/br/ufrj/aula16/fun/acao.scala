package br.ufrj.aula16.fun

import interp.Caixa
import interp.Valor
import interp.NumV
import interp.Msg

object acao {
  type Acao[T] = T

  def id[T](v: T): Acao[T] = v
  def unpack[T](a: Acao[T]): T = a
  
  def erro(s: String): Acao[Valor] = sys.error(s)
  def erro(v: Valor): Acao[Valor] = sys.error(v.toString)
  
  def bind[T, U](a1: Acao[T], f: T => Acao[U]): Acao[U] = f(unpack(a1))
  
  implicit class AcaoImp[T](val a: Acao[T]) extends AnyVal {
    def flatMap[U](f: T => Acao[U]): Acao[U] = bind(a, f)
    def map[U](f: T => U): Acao[U] = bind(a, (x: T) => id[U](f(x)))
    def withFilter(p: T => Boolean): Acao[T] = bind(a,
        (x: T) => if (p(x)) id[T](x) else sys.error("predicado falhou"))
  }
  
}


