package br.ufrj.aula17.microc

object driver extends App {
  println((parser.parseFile(args(0)).eval)(0, Map()))
}
