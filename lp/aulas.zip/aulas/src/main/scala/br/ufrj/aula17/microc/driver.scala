package br.ufrj.aula17.microc

object driver extends App {
  var sc = new java.util.Scanner(System.in)
  def input: Stream[Int] = {
    sc.nextInt #:: input
  }
  println((parser.parseFile(args(0)).eval)(0, Map()))
}
