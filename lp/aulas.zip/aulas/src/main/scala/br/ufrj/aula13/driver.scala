package br.ufrj.aula13

object driver extends App {
  println(parser.parseFile(args(0)).eval)
}
