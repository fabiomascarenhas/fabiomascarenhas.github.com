package br.ufrj.aula10

object interp {  
  // Valores
  trait Valor {
    def toExp: Exp = this match {
      case NumV(v) => Num(v)
      case Bool(b) => if (b) True() else False()
      case FunV(ps, c) => Fun(ps, c)
    }
    
    def apply(funs: Set[Fun1], args: List[Exp]): Valor = this match {
      case FunV(params, corpo) =>     
        if (params.size != args.size) 
          sys.error("erro de aridade em função anônima, esperado: " +
              params.size + ", passado: " + args.size)
        else
          corpo.subst(mapaSubst(funs, params, args)).eval(funs)
      case _ => sys.error("não é uma função: " + this)
    }
  
  }
  case class NumV(v: Double) extends Valor
  case class Bool(v: Boolean) extends Valor
  case class FunV(ps: List[String], c: Exp) extends Valor
  
  trait Exp {
    def eval(funs: Set[Fun1]): Valor = this match {
      case Num(v) => NumV(v)
      case True() => Bool(true)
      case False() => Bool(false)
      case Soma(e1, e2) => (e1.eval(funs), e2.eval(funs)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 + v2)
        case _ => sys.error("soma precisa de dois números")
      }
      case Mult(e1, e2) => (e1.eval(funs), e2.eval(funs)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 * v2)
        case _ => sys.error("mult precisa de dois números")
      }
      case Div(e1, e2) => (e1.eval(funs), e2.eval(funs)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 / v2)
        case _ => sys.error("div precisa de dois números")
      }
      case Menor(e1, e2) => (e1.eval(funs), e2.eval(funs)) match {
        case (NumV(v1), NumV(v2)) => Bool(v1 < v2)
        case _ => sys.error("menor precisa de dois números")
      }
      case If(c, et, ee) => c.eval(funs) match {
        case Bool(true) => et.eval(funs)
        case Bool(false) => ee.eval(funs)
        case _ => sys.error("condição do if deve ser booleano: " + c)
      }
      case Ap1(func, args) => 
        funs.filter({ 
          case Fun1(nome, _, _) => nome == func
        }).headOption match {
          case Some(f) => f.apply(funs, args)
          case None => sys.error("função " + func + " não existe ")
        }
      case Let(nome, exp, corpo) =>
        corpo.subst(mapaSubst(funs, List(nome), List(exp))).eval(funs)
      case Var(nome) => sys.error("variável livre: " + nome)
      case Fun(params, corpo) => FunV(params, corpo)
      case Ap(func, args) => func.eval(funs).apply(funs, args)
      case Rec(n, e) => e.subst(Map(n -> Rec(n, e))).eval(funs)
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case True() => True()
      case False() => False()
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, False())
      case Ou(e1, e2) => If(e1.desugar, True(), e2.desugar)
      case Nao(e) => If(e.desugar, False(), True())
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Ap(f, as) => Ap(f.desugar, as.map(e => e.desugar))
      case Fun(ps, c) => Fun(ps, c.desugar)
      case Rec(n, e) => Rec(n, e.desugar)
    }
    
    def subst(m: Map[String, Exp]): Exp = this match {
      case Num(v) => Num(v)
      case True() => True()
      case False() => False()
      case Soma(e1, e2) => Soma(e1.subst(m), e2.subst(m))
      case Mult(e1, e2) => Mult(e1.subst(m), e2.subst(m))
      case Div(e1, e2) => Div(e1.subst(m), e2.subst(m))
      case Menor(e1, e2) => Menor(e1.subst(m), e2.subst(m))
      case If(c, et, ee) => If(c.subst(m), et.subst(m), ee.subst(m))
      case Ap1(n, as) => Ap1(n, as.map(e => e.subst(m)))
      case Var(n) => m.get(n) match {
        case Some(e) => if (!e.fvs.isEmpty) sys.error("expressão com variáveis livres: " + e + ", fvs: " + e.fvs)
                        else e
        case None => Var(n)
      }
      case Let(n, e, c) => {
        val mlet = m.filterNot({ case (nome, _) => n == nome })
        Let(n, e.subst(m), c.subst(mlet))
      }
      case Ap(f, as) => Ap(f.subst(m), as.map(e => e.subst(m)))
      case Fun(ps, c) => {
        var mfun = m.filterNot({ case (nome, _) => ps.contains(nome) })
        Fun(ps, c.subst(mfun))
      }
      case Rec(n, e) => {
        val mrec = m.filterNot({ case (nome, _) => n == nome })
        Rec(n, e.subst(mrec))
      }
    }
    
    def fvs: Set[String] = this match {
      case Num(_) => Set()
      case True() => Set()
      case False() => Set()
      case Var(x) => Set(x)
      case Soma(e1, e2) => e1.fvs ++ e2.fvs
      case Mult(e1, e2) => e1.fvs ++ e2.fvs
      case Div(e1, e2) => e1.fvs ++ e2.fvs
      case Menor(e1, e2) => e1.fvs ++ e2.fvs
      case If(c, et, ee) => c.fvs ++ et.fvs ++ ee.fvs
      case Let(x, e, c) => e.fvs ++ (c.fvs - x)
      case Ap1(n, es) => es.foldRight[Set[String]](Set())(
        (e, s) => e.fvs ++ s)
      case Ap(f, es) => f.fvs ++ es.foldRight[Set[String]](Set())(
        (e, s) => e.fvs ++ s)
      case Fun(ps, c) => c.fvs -- ps
      case Rec(n, e) => e.fvs - n
    }

  }
  
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
    def apply(funs: Set[Fun1], args: List[Exp]): Valor =
      if (params.size != args.size) 
        sys.error("erro de aridade em " + nome + ", esperado: " +
            params.size + ", passado: " + args.size)
      else
        corpo.subst(mapaSubst(funs, params, args)).eval(funs)
  
    def fvs: Set[String] = corpo.fvs -- params.toSet    
  }
  case class Prog(defs: Set[Fun1], corpo: Exp) {
    def eval: Valor = corpo.eval(defs)
    def fvs : Set[String] = defs.foldRight[Set[String]](Set())(
        (e, s) => e.fvs ++ s) ++ corpo.fvs
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Funções de primeira classe
  case class Ap(fun: Exp, args: List[Exp]) extends Exp
  case class Fun(params: List[String], corpo: Exp) extends Exp
  
  // Recursão local
  case class Rec(nome: String, exp: Exp) extends Exp
  
  // Listas
  case class Nil() extends Exp

  // Funções de utilidade
  def liftNumV(v1: Valor, v2: Valor, op: (Double, Double) => Double) = 
    (v1, v2) match {
      case (NumV(v1), NumV(v2)) => NumV(op(v1, v2))
      case _ => sys.error("operação precisa de dois números")
    }
  
  // Gera mapa de substituições para let e parâmetros
  def mapaSubst(funs: Set[Fun1], oq: List[String], peloq: List[Exp]):
      Map[String, Exp] =
    for {
      (nome, exp) <- oq.zip(peloq).toMap
    } yield if (nome.charAt(0) == '_') (nome, exp)
            else (nome, exp.eval(funs).toExp)
}

