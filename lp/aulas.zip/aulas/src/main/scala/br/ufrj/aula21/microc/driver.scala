package br.ufrj.aula21.microc

object driver extends App {
  val kid: acao.Cont = v => (tick, hs, sp, mem) => (tick, v, hs, sp, mem)
  println((parser.parseFile(args(0)).eval)
           (kid)
           (acao.TICKS, acao.Threads(List()), 0, Map()))
}
