package br.ufrj.aula18.microc

import acao._

object interp {  
  // Ambientes
  type Env[T] = Map[String, T]

  // Endereços
  type End = Int
  
  // Valores
  type Valor = Int
  
  // Memória
  type Mem = Map[End, Valor]
  
  trait Exp {
    def eval(funs: Env[Fun1])(env: Env[End]): Acao = this match {
      case Num(v) => id(v)
      case Soma(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield v1 + v2
      case Mult(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield v1 * v2
      case Div(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
        d <- if (v2 != 0) id(v1 / v2)
             else erro(100)
      } yield d
      case Menor(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield if (v1 < v2) 1 else 0
      case Eq(e1, e2) => for {
        v1 <- e1.eval(funs)(env)
        v2 <- e2.eval(funs)(env)
      } yield if (v1 == v2) 1 else 0
      case If(c, et, ee) => for {
        vc <- c.eval(funs)(env)
        vi <- if (vc != 0)
                et.eval(funs)(env)
              else
                ee.eval(funs)(env)
      } yield vi
      case While(c, e) => {
        val cond = c.eval(funs)(env)
        val corpo = e.eval(funs)(env)
        def loop: Acao = for {
          vc <- cond
          _ <- if (vc != 0) for {
                              _ <- corpo
                              _ <- loop
                            } yield 0
               else id(0)
        } yield 0
        loop
      }
      case Var(nome) => le(env(nome))
      case Atrib(lval, rval) => lval match {
        case Var(n) => for {
          rv <- rval.eval(funs)(env)
          _ <- escreve(env(n), rv)
        } yield rv
        case Deref(e) => for {
          l <- e.eval(funs)(env)
          rv <- rval.eval(funs)(env)
          _ <- escreve(l, rv)
        } yield rv
        case _ => sys.error("lado esquerdo inválido")
      }
      case Let(n, e, c) => for {
        ve <- e.eval(funs)(env)
        l <- push(ve)
        vc <- c.eval(funs)(env + (n -> l))
        _ <- pop   // recicla endereço da variável da let
      } yield vc
      case Seq(e1, e2) => for {
        _ <- e1.eval(funs)(env)
        v <- e2.eval(funs)(env)
      } yield v
      case Ap1(func, args) => for {
        larg1 <- pushArgs(funs, env, args)
        v <- funs(func).apply(funs, args.size, larg1)
        _ <- popArgs(args.size)
      }  yield v
      case Throw(e) => for {
        ve <- e.eval(funs)(env)
        v <- erro(ve)
      } yield v
      case TryCatch(et, n, ec) => trycatch(et.eval(funs)(env),
          ex => for {
            l <- push(ex)
            vc <- ec.eval(funs)(env + (n -> l))
            _ <- pop
          } yield vc)
      case Deref(e) => for {
        l <- e.eval(funs)(env)
        v <- le(l)
      } yield v
      case Read() => id(readInt())
      case Print(es: List[Exp]) => {
        def printArgs(l: List[Exp]): Acao = l match {
          case h :: t => for {
            v <- h.eval(funs)(env)
            _ <- { print(v); print("\t"); printArgs(t) }
          } yield 0
          case List() => { print("\n"); id(0) }
        }
        printArgs(es)
      }
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, Num(0))
      case Ou(e1, e2) => If(e1.desugar, Num(1), e2.desugar)
      case Nao(e) => If(e.desugar, Num(0), Num(1))
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Atrib(l, r) => Atrib(l.desugar, r.desugar)
      case Seq(e1, e2) => Seq(e1.desugar, e2.desugar)
      case Ender(e) => Ender(e)
      case Deref(e) => Deref(e.desugar)
      case Eq(e1, e2) => Eq(e1.desugar, e2.desugar)
      case While(e, c) => While(e.desugar, c.desugar)
      case Throw(e) => Throw(e.desugar)
      case TryCatch(e1, n, e2) => TryCatch(e1.desugar, n, e2.desugar)
      case Read() => Read()
      case Print(es) => Print(es.map(e => e.desugar))
    }
  }
  
  // Expressões aritméticas
  case class Num(v: Int) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Expressões ariméticas - Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais e controle
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class While(cond: Exp, corpo: Exp) extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem e variáveis
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
    def apply(funs: Env[Fun1], nargs: Int, larg1: Int): Acao = {
      if (nargs != params.size) sys.error("erro de aridade em " + nome)
      else corpo.eval(funs)(
          params.zip(larg1.to(larg1+params.size-1)).toMap)
    }
  }
  case class Prog(defs: Map[String, Fun1], corpo: Exp) {
    def eval: Acao = {
      corpo.eval(defs)(Map())
    }
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Atribuições e ponteiros
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ender(v: String) extends Exp
  case class Deref(e: Exp) extends Exp
  
  // Igualdade
  case class Eq(e1: Exp, e2: Exp) extends Exp

   // Exceções
  case class Throw(e: Exp) extends Exp
  case class TryCatch(e1: Exp, n: String, e2: Exp) extends Exp
 
  // Entrada e Saída
  case class Read() extends Exp
  case class Print(es: List[Exp]) extends Exp
  
  def pushArgs(funs: Env[Fun1], env: Env[End], args: List[Exp]): Acao = args match {
    case h :: t => for {
      v <- h.eval(funs)(env)
      larg1 <- push(v)
      _ <- pushArgs(funs, env, t)
    } yield larg1     
    case List() => SP
  }
  
  def popArgs(n: Int): Acao = if (n > 0) for {
                                           _ <- pop
                                           l <- popArgs(n-1)
                                         } yield l
                              else SP
  
}

