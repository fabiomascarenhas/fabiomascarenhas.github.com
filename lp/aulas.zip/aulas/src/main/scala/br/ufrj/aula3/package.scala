package br.ufrj

import scala.annotation.tailrec

package object aula3 {
	def quadrado(x: Double) = x * x
	def abs(x: Double) = if (x < 0) -x else x
	def raiz(x: Double) = {
		def melhora(est: Double) =
				(est + x / est) / 2
		@tailrec
		def loop(est: Double): Double =
			if (abs(quadrado(est) - x) < 0.000001)
				est
			else
				loop(melhora(est))
		loop(1)	
	}
	def fat(x: Int) = {
	    @tailrec
	    def loop(acum: Int, n: Int): Int = {
	      if(n < 2) acum
	      else loop(acum * n, n - 1)
	    }
	    loop(1, x)
	}
	
	def concat[T](l1: List[T], l2: List[T]): List[T] =
	  if (l1.isEmpty) l2
	  else l1.head :: concat(l1.tail, l2)
		  
	def tamanhoR[T](l: List[T]): Int =
	  if (l.isEmpty) 0
	  else 1 + tamanhoR(l.tail)
	  
	def tamanho[T](l: List[T]) = {
	    @tailrec
	    def loop(acum: Int, l: List[T]): Int =
	      if (l.isEmpty) acum
	      else loop(acum + 1, l.tail)
	    loop(0, l)
	}
	
	def inverte[T](l: List[T]) = {
	  @tailrec
	  def loop(acum: List[T], l: List[T]): List[T] =
	    if (l.isEmpty) acum
	    else loop(l.head :: acum, l.tail)
	  loop(Nil, l)
	}
	
	def concatI[T](l1: List[T], l2: List[T]) = {
	  @tailrec
	  def loop(l: List[T], acum: List[T]): List[T] =
	    if (l.isEmpty) acum
	    else loop(l.head :: acum, l.tail)
	  loop(inverte(l1), l2)
	}
}

/*
fat(4) =
loop(1, 4) = 
if (4 < 2) 1 else loop(1 * 4, 4 - 1) =
if false 1 else loop(1 * 4, 4 - 1) =
loop(1 * 4, 4 - 1) =
loop(4, 4 - 1) = 
loop(4, 3) =
if (3 < 2) 4 else loop(4 * 3, 3 - 1) =
loop(4 * 3, 3 - 1) =
loop(12, 2) =
if (2 < 2) 12 else loop(12 * 2, 2 - 1) =
loop(12 * 2, 2 - 1) = 
loop(24, 1) =
if (1 < 2) 24 else loop(24 * 1, 1 - 1) =
if true 24 else loop(24 * 1, 1 - 1) = 
24

fat(5) =
loop(1, 5) = 
if (5 < 2) 1 else loop(1 * 5, 5 - 1) =
if false 1 else loop(1 * 5, 5 - 1) =
loop(1 * 5, 5 - 1) =
loop(5, 5 - 1) = 
loop(5, 4) =
if (4 < 2) 5 else loop(5 * 4, 4 - 1) =
loop(5 * 4, 4 - 1) =
loop(20, 3) =
if (3 < 2) 20 else loop(20 * 3, 3 - 1) =
loop(20 * 3, 3 - 1) = 
loop(60, 2) =
if (2 < 2) 60 else loop(60 * 2, 2 - 1) =
loop(60 * 2, 2 - 1) =
loop(120, 1) =
if (1 < 2) 120 else loop(120 * 1, 1 - 1) =
if true 120 else loop(120 * 1, 1 - 1) = 
120

Tipos de Listas:

List[Int] -> listas de inteiros
  1 :: 2 :: 3 :: Nil
  1 :: (2 :: (3 :: Nil))
List[Double] -> listas de doubles
  1.0 :: 2.0 :: 3.0 :: Nil
List[Boolean] -> " de booleanos
  true :: false :: true :: false :: Nil
List[Char] -> " de caracteres
  'a' :: 'b' :: Nil
List[List[Int]] -> listas de listas de inteiros
  (1 :: 2 :: 3 :: Nil) :: (4 :: 5 :: Nil) :: Nil
List[List[List[Int]]] -> listas de listas de listas de inteiros
List[List[T]] -> listas de listas de um tipo T qualquer


*/

