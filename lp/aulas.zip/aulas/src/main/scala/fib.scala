object fib extends App {
  def fib(n: Int): Int = if (n < 3) 1 else fib(n-1) + fib(n-2)

  def memo(f: Int => Int): Int => Int = {
    var m = Map[Int, Int]();
    n => {
      m.get(n) match {
        case Some(v) => v
        case None => {
          m = m + (n -> f(n))
          m(n)
        }
      }
    }
  }
  
  val fib2: Int => Int = memo(fib)
  
  println(fib2(30))
  println(fib(30))
}