package cont

import interp.Valor
import interp.Mem
import interp.NumV
import interp.ContV
import interp.Caixa

object acao {
  type Cont = (Valor, Mem) => (Valor, Mem)
  type Acao = (Mem, Cont) => (Valor, Mem) 

  def id(v: Valor): Acao = (m, k) => k(v, m)

  def le(l: Int): Acao = (m, k) => k(m.get(l) match {
    case Some(v) => v
    case None => sys.error("endereço inválido: " + l)
  }, m)
    
  def escreve(l: Int, v: Valor): Acao = (m, k) => k(v, m + (l -> v))  

  def bindcc(f: Valor => Acao): Acao = (m, k) => f(ContV(k))(m, k)
  
  def abort(k: Cont, v: Valor): Acao = (m, _) => k(v, m)
  
  def bind(a1: Acao, f: Valor => Acao): Acao = (m, k) => 
    a1(m, (v, nm) => f(v)(nm, k))
      
  implicit class AcaoImp(val a: Acao) extends AnyVal {
    def flatMap(f: Valor => Acao): Acao = bind(a, f)
    def map(f: Valor => Valor): Acao = bind(a, (x: Valor) => id(f(x)))
    def withFilter(p: Valor => Boolean): Acao = bind(a,
        (x: Valor) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def aloca(v: Valor): Acao = for {
    NumV(l) <- le(0)
    _ <- escreve(0, NumV(l.toInt+1))
    _ <- escreve(l.toInt+1, v)
  } yield Caixa(l.toInt+1)
 
}


/*

def aloca(v: Valor): Acao[Valor] = for {
  NumV(l) <- le(0)
  nl <- id(l.toInt+1)
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl)

=>

le(0).flatMap({ case NumV(l) => for {
  nl <- id(l.toInt+1)
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => for {
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl)) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) => for {
  _ <- escreve(nl, v)
} yield Caixa(nl))) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) =>
      escreve(nl, v).map((_) => Caixa(nl)))) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) =>
      escreve(nl, v).flatMap((_) => id(Caixa(nl))))) })

=>

le(0).bind({ case NumV(l) => 
  id(l.toInt+1).bind((nl) => 
    escreve(0, NumV(nl)).bind((_) =>
      escreve(nl, v).bind((_) => id(Caixa(nl))))) })

=>

bind(le(0), { case NumV(l) => 
  bind(id(l.toInt+1), (nl: Int) => 
    bind(escreve(0, NumV(nl)), (_: Valor) =>
      bind(escreve(nl, v), (_: Valor) => id(Caixa(nl))))) })

=>

bind(le(0), (lv: Valor) => {
  val NumV(l) = lv 
  bind(id(l.toInt+1), (nl: Int) => 
    bind(escreve(0, NumV(nl)), (_: Valor) =>
      bind(escreve(nl, v), (_: Valor) => id(Caixa(nl))))) })


 */
