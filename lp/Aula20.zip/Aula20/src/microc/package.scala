import parser._
import util.Random

package object microc {

  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(funs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  // Let
  case class Let(nome: String, exp: Exp, corpo: Exp) extends Exp
  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(e: Exp) extends Exp
  // Exceções
  case class Throw(msg: String) extends Exp
  case class TryCatch(etry: Exp, ecatch: Exp) extends Exp
  case class TryFinally(etry: Exp, efin: Exp) extends Exp
  // Entrada/Saída
  case class Read() extends Exp
  case class Print(args: List[Exp]) extends Exp
  // While
  case class While(econd: Exp, corpo: Exp) extends Exp

  type Valor = Int
  type End = Int
  type Mem = Map[End, Valor]
  type Env = Map[String, End]

  // Erros
  trait Talvez[T]
  case class Ok[T](v: T) extends Talvez[T]
  case class Erro[T](msg: String) extends Talvez[T]

  // Ações
  type Acao[T] = (End, Mem) => (Talvez[T], End, Mem)

  implicit class RichAcao[A](val p: Acao[A]) extends AnyVal {
    def flatMap[B](f: A => Acao[B]): Acao[B] = bind(p, f)
    def map[B](f: A => B): Acao[B] = bind(p, (v: A) => emptya(f(v)))
  }

  def emptya[T](v: T): Acao[T] = (sp, m) => (Ok(v), sp, m)
  def le(r: Int): Acao[Valor] = (sp, m) => m.get(r) match {
    case Some(v) => (Ok(v), sp, m)
    case None => (Erro("endereço " + r + " não existe"), sp, m)
  }
  def escreve(r: Int, v: Valor): Acao[Valor] = (sp, m) => (Ok(r), sp, m + (r -> v))
  def bind[T, U](a: Acao[T], f: T => Acao[U]): Acao[U] = (sp, m) => {
    val (v, nsp, nm) = a(sp, m)
    v match {
      case Ok(vok) => f(vok)(nsp, nm)
      case Erro(msg) => (Erro(msg), nsp, nm)
    }
  }

  val leSP: Acao[End] = (sp, m) => (Ok(sp), sp, m)
  def escreveSP(sp: End): Acao[Unit] = (_, m) => (Ok(()), sp, m)

  def push(n: Valor): Acao[End] = for {
    sp <- leSP
    _ <- escreve(sp, n)
    _ <- escreveSP(sp + 1)
  } yield sp

  def pop(n: Int): Acao[Unit] = for {
    sp <- leSP
    _ <- escreveSP(sp - n)
  } yield ()

  def erro[T](msg: String): Acao[T] = (sp, m) => (Erro(msg), sp, m)
  def trycatch[T](atry: Acao[T], acatch: Acao[T]): Acao[T] = (sp, m) => {
    val (v, nsp, nm) = atry(sp, m)
    v match {
      case Ok(_) => (v, nsp, nm)
      case Erro(msg) => acatch(sp, nm) // restaurando sp do início do try
    }
  }
  def tryfinally[T,U](atry: Acao[T], afin: Acao[U]): Acao[T] = (sp, m) => {
    val (vtry, sp1, m1) = atry(sp, m)
    vtry match {
      case Ok(_) => {
        val (vfin, sp2, m2) = afin(sp1, m1)
        vfin match {
          case Ok(_) => (vtry, sp2, m2)
          case Erro(msg) => (Erro(msg), sp1, m2) // restaura sp do final do try
        }
      }
      case Erro(msg) => {
        val (vfin, sp2, m2) = afin(sp, m1) // restaura sp do início do try
        vfin match {
          case Ok(_) => (vtry, sp2, m2)
          case Erro(msg) => (Erro(msg), sp, m2) // restaura sp do início do try
        }
      }
    }
  }

  def lift[T](l: List[Acao[T]]): Acao[List[T]] = l match {
    case Nil => emptya(Nil)
    case h :: t => for {
      vh <- h // h é uma Acao[T]
      vt <- lift(t) // lift(t) é uma Acao[List[T]]
    } yield vh :: vt
  }

  def ProgFun: Parser[Prog] = for {
    funs <- many(DefFun)
    corpo <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield Prog(funs.toSet, corpo)

  def DefFun: Parser[Fun1] = for {
    _ <- kw("fun")
    (nome, _) <- id
    _ <- op("(")
    params <- (for {
      (p, _) <- id
      ps <- many(for {
        _ <- op(",")
        (p, _) <- id
      } yield p)
    } yield p :: ps) +: empty(List())
    _ <- op(")")
    corpo <- ExpFun
    _ <- kw("end")
  } yield Fun1(nome, params, corpo)

  def ExpFun: Parser[Exp] =
    chainl(AtexpFun,
      for {_ <- op(";")} yield (e1, e2) => Seq(e1, e2),
      AtexpFun)

  def AtexpFun: Parser[Exp] =
    chainl(RexpFun,
      for {_ <- op(":=")} yield (e1, e2) => Atrib(e1, e2),
      RexpFun)

  def RexpFun: Parser[Exp] =
    chainl(AexpFun,
      for {_ <- op("<")} yield (e1, e2) => Menor(e1, e2),
      AexpFun)

  def AexpFun: Parser[Exp] =
    chainl(TermoFun,
      (for {_ <- op("+")} yield (e1, e2) => Soma(e1, e2)) +:
        (for {_ <- op("-")} yield (e1: Exp, e2: Exp) =>
          Soma(e1, Mult(Num(-1), e2))),
      TermoFun)

  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)

  def ArgsFun: Parser[List[Exp]] = (for {
    a <- ExpFun
    as <- many(for {
      _ <- op(",")
      a <- ExpFun
    } yield a)
  } yield a :: as) +: empty(List())

  def FatorFun: Parser[Exp] =
    (for {(v, pos) <- num} yield Num(v)) +:
      (for {
        _ <- op("(")
        e <- ExpFun
        _ <- op(")")
      } yield e) +:
      (for {
        _ <- kw("read")
      } yield Read()) +:
      (for {
        _ <- op("-")
        e <- FatorFun
      } yield Mult(Num(-1), e)) +:
      (for {
        _ <- op("&")
        e <- FatorFun
      } yield Ref(e)) +:
      (for {
        _ <- kw("throw")
        (msg, _) <- str
      } yield Throw(msg)) +:
      (for {
        _ <- op("*")
        e <- FatorFun
      } yield Deref(e)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("else")
        eelse <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, eelse)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, Num(0))) +:
      (for {
        _ <- kw("while")
        econd <- ExpFun
        _ <- kw("do")
        ewhile <- ExpFun
        _ <- kw("end")
      } yield While(econd, ewhile)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("end")
      } yield TryCatch(etry, ecatch)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(etry, efin)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(TryCatch(etry, ecatch), efin)) +:
      (for {
        _ <- kw("let")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
        resto <- many(for {
          _ <- op(",")
          (nome, _) <- id
          _ <- op("=")
          exp <- ExpFun
        } yield (nome, exp))
        _ <- kw("in")
        corpo <- ExpFun
        _ <- kw("end")
      } yield ((nome, exp) :: resto).foldRight(corpo) {
        case ((nome, exp), corpo) => Let(nome, exp, corpo) // Ap(Fun(List(nome), corpo), List(exp))
      }) +:
      (for {
        (nome, _) <- id
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Ap1(nome, args)) +:
      (for {
        _ <- kw("print")
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Print(args)) +:
      (for {(nome, _) <- id} yield Var(nome))

  def eval(p: Prog): (Talvez[Valor], End, Mem) = p match {
    case Prog(funs, corpo) => eval(funs)(Map(), corpo)(0, Map())
  }

  def eval(funs: Set[Fun1]) = {
    def eval(env: Env, e: Exp): Acao[Valor] = e match {
      case Num(v) => emptya(v.toInt)
      case Soma(e1, e2) => for {
        n1 <- eval(env, e1)
        n2 <- eval(env, e2)
      } yield n1 + n2
      case Mult(e1, e2) => for {
        n1 <- eval(env, e1)
        n2 <- eval(env, e2)
      } yield n1 * n2
      case Menor(e1, e2) => for {
        n1 <- eval(env, e1)
        n2 <- eval(env, e2)
      } yield if(n1 < n2) 1 else 0
      case If(ec, et, ee) => for {
        vc <- eval(env, ec)
        vif <- if(vc != 0) eval(env, et) else eval(env, ee)
      } yield vif
      case Ap1(nome, args) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val pas: List[(String, Exp)] = params.zip(args)
        for {
          ves <- lift(pas.map({ case (p, a) => if(p.startsWith("_")) {
            for {
              l <- a match {
                case Var(nome) => emptya(env(nome))
                case Deref(la) => eval(env, la)
              }
            } yield l // por ref, o endereço é o endereço do arg
          } else for {
            v <- eval(env, a)
            l <- push(v) // por val, o endereço é alocado
          } yield l }))  // ves é uma List[End]
          vap <- eval(params.zip(ves).toMap, corpo)
          _ <- pop(params.filterNot(p => p.startsWith("_")).size)
        } yield vap
      case Seq(e1, e2) => for {
        _ <- eval(env, e1)
        ve2 <- eval(env, e2)
      } yield ve2
      case Atrib(Var(nome), rv) => for {
        vrv <- eval(env, rv)
        c <- escreve(env(nome), vrv)
      } yield c
      case Atrib(Deref(lv), rv) => for {
        l <- eval(env, lv)
        vrv <- eval(env, rv)
        c <- escreve(l, vrv)
      } yield c
      case Deref(e) => for {
        l <- eval(env, e)
        v <- le(l)
      } yield v
      case Ref(Var(nome)) => emptya(env(nome))
      case Ref(Deref(lv)) => for {
        l <- eval(env, lv)
      } yield l
      case Let(n, e, c) => for {
        ve <- eval(env, e)
        l <- push(ve)
        vc <- eval(env + (n -> l), c)
        _ <- pop(1)
      } yield vc
      case Throw(msg) => erro(msg)
      case TryCatch(etry, ecatch) => trycatch(eval(env, etry), eval(env, ecatch))
      case TryFinally(etry, efin) => tryfinally(eval(env, etry), eval(env, efin))
      case Var(nome) => le(env(nome))
    }
    eval _ // retorna a função eval interna (com funs fixado)
  }

}
