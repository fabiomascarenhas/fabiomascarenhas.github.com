package fun

import parser._

object DriverStep extends App {
  println(evals(ProgFun.parseFile(args(0))))
}