import parser._
import util.Random

package object microc {

  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(funs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  // Let
  case class Let(nome: String, exp: Exp, corpo: Exp) extends Exp
  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(e: Exp) extends Exp
  // Exceções
  case class Throw(msg: String) extends Exp
  case class TryCatch(etry: Exp, ecatch: Exp) extends Exp
  case class TryFinally(etry: Exp, efin: Exp) extends Exp
  // Entrada/Saída
  case class Read() extends Exp
  case class Print(args: List[Exp]) extends Exp
  // While
  case class While(econd: Exp, corpo: Exp) extends Exp

  type Valor = Int
  type End = Int
  type Mem = Map[End, Valor]

  // Erros
  trait Talvez[T]
  case class Ok[T](v: T) extends Talvez[T]
  case class Erro[T](msg: String) extends Talvez[T]

  // Ações
  // Resposta da questão 4 - parte 1
  type Acao[T] = (Stream[Valor], List[String], End, Mem) => (Talvez[T], Stream[Valor], List[String], End, Mem)

  implicit class RichAcao[A](val p: Acao[A]) extends AnyVal {
    def flatMap[B](f: A => Acao[B]): Acao[B] = bind(p, f)
    def map[B](f: A => B): Acao[B] = bind(p, (v: A) => emptya(f(v)))
  }

  def emptya[T](v: T): Acao[T] = (i, o, sp, m) => (Ok(v), i, o, sp, m)
  def le(r: End): Acao[Valor] = (i, o, sp, m) => m.get(r) match {
    case Some(v) => (Ok(v), i, o, sp, m)
    case None => (Erro("endereço " + r + " não existe"), i, o, sp, m)
  }
  def escreve(r: End, v: Valor): Acao[Valor] = (i, o, sp, m) => (Ok(v), i, o, sp, m + (r -> v))
  def bind[T, U](a: Acao[T], f: T => Acao[U]): Acao[U] = (i, o, sp, m) => {
    val (v, ni, no, nsp, nm) = a(i, o, sp, m)
    v match {
      case Ok(vok) => f(vok)(ni, no, nsp, nm)
      case Erro(msg) => (Erro(msg), ni, no, nsp, nm)
    }
  }

  val leSP: Acao[End] = (i, o, sp, m) => (Ok(sp), i, o, sp, m)
  def escreveSP(sp: End): Acao[Unit] = (i, o, _, m) => (Ok(()), i, o, sp, m)

  def push(n: Valor): Acao[End] = for {
    sp <- leSP
    _ <- escreve(sp, n)
    _ <- escreveSP(sp + 1)
  } yield sp

  def pop(n: Int): Acao[Unit] = for {
    sp <- leSP
    _ <- escreveSP(sp - n)
  } yield ()

  def erro[T](msg: String): Acao[T] = (i, o, sp, m) => (Erro(msg), i, o, sp, m)
  def trycatch[T](atry: Acao[T], acatch: Acao[T]): Acao[T] = (i, o, sp, m) => {
    val (v, ni, no, nsp, nm) = atry(i, o, sp, m)
    v match {
      case Ok(_) => (v, ni, no, nsp, nm)
      case Erro(msg) => acatch(ni, no, sp, nm) // restaurando sp do início do try
    }
  }
  def tryfinally[T,U](atry: Acao[T], afin: Acao[U]): Acao[T] = (i, o, sp, m) => {
    val (vtry, i1, o1, sp1, m1) = atry(i, o, sp, m)
    vtry match {
      case Ok(_) => {
        val (vfin, i2, o2, sp2, m2) = afin(i1, o1, sp1, m1)
        vfin match {
          case Ok(_) => (vtry, i2, o2, sp2, m2)
          case Erro(msg) => (Erro(msg), i2, o2, sp1, m2) // restaura sp do final do try
        }
      }
      case Erro(msg) => {
        val (vfin, i2, o2, sp2, m2) = afin(i1, o1, sp, m1) // restaura sp do início do try
        vfin match {
          case Ok(_) => (vtry, i2, o2, sp2, m2)
          case Erro(msg) => (Erro(msg), i2, o2, sp, m2) // restaura sp do início do try
        }
      }
    }
  }

  // Resposta da questão 4 - parte 2
  def levalor: Acao[Valor] = (i, o, sp, m) => (Ok(i.head), i.tail, o, sp, m)
  def imprime(s: String): Acao[Unit] = (i, o, sp, m) => (Ok(()), i, o ++ List(s), sp, m)

  def lift[T](l: List[Acao[T]]): Acao[List[T]] = l match {
    case Nil => emptya(Nil)
    case h :: t => for {
      vh <- h // h é uma Acao[T]
      vt <- lift(t) // lift(t) é uma Acao[List[T]]
    } yield vh :: vt
  }

  def ProgFun: Parser[Prog] = for {
    funs <- many(DefFun)
    corpo <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield Prog(funs.toSet, corpo)

  def DefFun: Parser[Fun1] = for {
    _ <- kw("fun")
    (nome, _) <- id
    _ <- op("(")
    params <- (for {
      (p, _) <- id
      ps <- many(for {
        _ <- op(",")
        (p, _) <- id
      } yield p)
    } yield p :: ps) +: empty(List())
    _ <- op(")")
    corpo <- ExpFun
    _ <- kw("end")
  } yield Fun1(nome, params, corpo)

  def ExpFun: Parser[Exp] =
    chainl(AtexpFun,
      for {_ <- op(";")} yield (e1, e2) => Seq(e1, e2),
      AtexpFun)

  def AtexpFun: Parser[Exp] =
    chainl(RexpFun,
      for {_ <- op(":=")} yield (e1, e2) => Atrib(e1, e2),
      RexpFun)

  def RexpFun: Parser[Exp] =
    chainl(AexpFun,
      for {_ <- op("<")} yield (e1, e2) => Menor(e1, e2),
      AexpFun)

  def AexpFun: Parser[Exp] =
    chainl(TermoFun,
      (for {_ <- op("+")} yield (e1, e2) => Soma(e1, e2)) +:
        (for {_ <- op("-")} yield (e1: Exp, e2: Exp) =>
          Soma(e1, Mult(Num(-1), e2))),
      TermoFun)

  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)

  def ArgsFun: Parser[List[Exp]] = (for {
    a <- ExpFun
    as <- many(for {
      _ <- op(",")
      a <- ExpFun
    } yield a)
  } yield a :: as) +: empty(List())

  def FatorFun: Parser[Exp] =
    (for {(v, pos) <- num} yield Num(v)) +:
      (for {
        _ <- op("(")
        e <- ExpFun
        _ <- op(")")
      } yield e) +:
      (for {
        _ <- kw("read")
      } yield Read()) +:
      (for {
        _ <- op("-")
        e <- FatorFun
      } yield Mult(Num(-1), e)) +:
      (for {
        _ <- op("&")
        e <- FatorFun
      } yield Ref(e)) +:
      (for {
        _ <- kw("throw")
        (msg, _) <- str
      } yield Throw(msg)) +:
      (for {
        _ <- op("*")
        e <- FatorFun
      } yield Deref(e)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("else")
        eelse <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, eelse)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, Num(0))) +:
      (for {
        _ <- kw("while")
        econd <- ExpFun
        _ <- kw("do")
        ewhile <- ExpFun
        _ <- kw("end")
      } yield While(econd, ewhile)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("end")
      } yield TryCatch(etry, ecatch)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(etry, efin)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(TryCatch(etry, ecatch), efin)) +:
      (for {
        _ <- kw("print")
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Print(args)) +:
      (for {
        _ <- kw("let")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
        resto <- many(for {
          _ <- op(",")
          (nome, _) <- id
          _ <- op("=")
          exp <- ExpFun
        } yield (nome, exp))
        _ <- kw("in")
        corpo <- ExpFun
        _ <- kw("end")
      } yield ((nome, exp) :: resto).foldRight(corpo) {
        case ((nome, exp), corpo) => Let(nome, exp, corpo) // Ap(Fun(List(nome), corpo), List(exp))
      }) +:
      (for {
        (nome, _) <- id
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Ap1(nome, args)) +:
      (for {(nome, _) <- id} yield Var(nome))

  val sc = new java.util.Scanner("44 22 33 55 11 100 88 77 1000")
  def input: Stream[Valor] = sc.nextInt #:: input

  def eval(p: Prog): (Talvez[Valor], Stream[Valor], List[String], End, Mem) = p match {
    case Prog(funs, corpo) => eval(funs)(corpo)(input, List(), 0, Map())
  }

  def eval(funs: Set[Fun1]) = {
    def eval(e: Exp): Acao[Valor] = e match {
      case Num(v) => emptya(v.toInt)
      case Soma(e1, e2) => for {
        n1 <- eval(e1)
        n2 <- eval(e2)
      } yield n1 + n2
      case Mult(e1, e2) => for {
        n1 <- eval(e1)
        n2 <- eval(e2)
      } yield n1 * n2
      case Menor(e1, e2) => for {
        n1 <- eval(e1)
        n2 <- eval(e2)
      } yield if(n1 < n2) 1 else 0
      case If(ec, et, ee) => for {
        vc <- eval(ec)
        vif <- if(vc != 0) eval(et) else eval(ee)
      } yield vif
      case Ap1(nome, args) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val pas: List[(String, Exp)] = params.zip(args)
        for {
          ves <- lift(pas.map({ case (p, a) => if(p.startsWith("_")) {
            val Deref(la) = a
            for {
              l <- eval(la)
            } yield l // por ref, o endereço é o endereço do arg
          } else for {
            v <- eval(a)
            l <- push(v) // por val, o endereço é alocado
          } yield l }))  // vas é uma List[Valor]
          vap <- eval(subst(params.zip(ves.map(n => Deref(Num(n)))).toMap)(corpo))
          _ <- pop(params.filterNot(p => p.startsWith("_")).size)
        } yield vap
      case Seq(e1, e2) => for {
        _ <- eval(e1)
        ve2 <- eval(e2)
      } yield ve2
      case Atrib(Deref(lv), rv) => for {
        l <- eval(lv)
        vrv <- eval(rv)
        c <- escreve(l, vrv)
      } yield c
      case Deref(e) => for {
        l <- eval(e)
        v <- le(l)
      } yield v
      case Ref(Deref(lv)) => for {
        l <- eval(lv)
      } yield l
      case Let(n, e, c) => for {
        ve <- eval(e)
        l <- push(ve)
        vc <- eval(subst(Map(n -> Deref(Num(l))))(c))
        _ <- pop(1)
      } yield vc
      case Throw(msg) => erro(msg)
      case TryCatch(etry, ecatch) => trycatch(eval(etry), eval(ecatch))
      case TryFinally(etry, efin) => tryfinally(eval(etry), eval(efin))
      // Resposta da questão 3 da lista 4 - parte 1
      case While(econd, ewhile) =>
        val awhile = eval(ewhile)
        val acond = eval(econd)
        def loop: Acao[Valor] = for {
          vc <- acond
          vw <- if(vc != 0) for {
            _ <- awhile
            _ <- loop
          } yield 0 else emptya(0)
        } yield 0
        loop
        // Outra resposta
        //case While(econd, ewhile) => for {
        //  vc <- eval(econd)
        //  vw <- if(vc != 0) eval(While(econd, ewhile))
        //        else emptya(0)
        //} yield vw
      // Resposta questão 4 da lista 4 - parte 3
      case Read() => levalor
      case Print(args) => for {
        vas <- lift(args.map(a => eval(a)))
        _ <- imprime(vas.mkString("\t"))
      } yield 0
    }
    eval _ // retorna a função eval interna (com funs fixado)
  }

  def fvs(e: Exp): Set[String] = e match {
    case Soma(e1, e2) => fvs(e1) ++ fvs(e2)
    case Mult(e1, e2) => fvs(e1) ++ fvs(e2)
    case Menor(e1, e2) => fvs(e1) ++ fvs(e2)
    case If(ec, et, ee) => fvs(ec) ++ fvs(et) ++ fvs(ee)
    case Var(x) => Set(x)
    case Ap1(nome, args) => args.map(arg => fvs(arg)).reduceOption((a, b) => a ++ b).getOrElse(Set())
    case Let(nome, exp, corpo) => fvs(exp) ++ (fvs(corpo) - nome)
    case Seq(e1, e2) => fvs(e1) ++ fvs(e2)
    case Atrib(lv, rv) => fvs(lv) ++ fvs(rv)
    case Ref(e) => fvs(e)
    case Deref(e) => fvs(e)
    case TryCatch(e1, e2) => fvs(e1) ++ fvs(e2)
    case TryFinally(e1, e2) => fvs(e1) ++ fvs(e2)
    // Resposta da questão 3 da lista 4 - parte 2
    case While(econd, ewhile) => fvs(econd) ++ fvs(ewhile)
    // Resposta questão 4 da lista 4 - parte 4
    case Read() => Set()
    case Print(args) => args.map(arg => fvs(arg)).reduceOption((a, b) => a ++ b).getOrElse(Set())
    case _ => Set()
  }

  def subst(n2v: Map[String, Exp]): (Exp => Exp) = {
    def sub(e: Exp): Exp = e match {
      case Soma(e1, e2) => Soma(sub(e1), sub(e2))
      case Mult(e1, e2) => Mult(sub(e1), sub(e2))
      case Menor(e1, e2) => Menor(sub(e1), sub(e2))
      case If(ec, et, ee) => If(sub(ec), sub(et), sub(ee))
      case Ap1(nome, args) => Ap1(nome, args.map(arg => sub(arg)))
      case Var(nome) => n2v.get(nome) match {
        case Some(e) => e
        case None => Var(nome)
      }
      case Let(nome, exp, corpo) =>
        val scorpo = n2v - nome
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(corpo).intersect(scorpo.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = scorpo.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        if(freevars.contains(nome)) { // ocorreu uma captura
        // Renomeia nome para evitar colisão com seu uso em u
        val novonome = Random.alphanumeric.take(10).mkString
          Let(novonome, sub(exp), subst(scorpo)(subst(Map(nome -> Var(novonome)))(corpo)))
        } else Let(nome, sub(exp), subst(scorpo)(corpo))
      case Seq(e1, e2) => Seq(sub(e1), sub(e2))
      case Atrib(lv, rv) => Atrib(sub(lv), sub(rv))
      case Ref(e) => Ref(sub(e))
      case Deref(e) => Deref(sub(e))
      case TryCatch(et, ec) => TryCatch(sub(et), sub(ec))
      case TryFinally(et, ef) => TryFinally(sub(et), sub(ef))
      // Reposta da questão 3 da lista 4 - parte 3
      case While(ec, ew) => While(sub(ec), sub(ew))
      // Resposta questão 4 da lista 4 - parte 4
      case Read() => Read()
      case Print(args) => Print(args.map(a => sub(a)))
      case _ => e
    }
    sub
  }

}
