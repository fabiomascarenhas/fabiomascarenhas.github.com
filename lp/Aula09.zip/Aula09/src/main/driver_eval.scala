package main

import parser._

object DriverEval extends App {
  println(eval(fun.parseFile(args(0))))
}