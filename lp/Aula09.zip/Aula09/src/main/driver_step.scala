package main

import parser._

object DriverStep extends App {
  println(evals(fun.parseFile(args(0))))
}