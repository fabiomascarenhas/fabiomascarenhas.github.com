import sbt._
import sbt.Keys._

object AulasBuild extends Build {

  lazy val aulas = Project(
    id = "aulas",
    base = file("."),
    settings = Project.defaultSettings ++ Seq(
      name := "aulas",
      organization := "br.ufrj",
      version := "0.1-SNAPSHOT",
      scalaVersion := "2.9.2"
      // add other settings here
    )
  )
}
