package threads

import interp.Valor
import interp.Mem
import interp.NumV
import interp.ContV
import interp.Caixa

object acao {
  type Cont = (Valor, Threads, Int, Mem) => (Valor, Threads, Int, Mem)
  type Acao = (Threads, Int, Mem, Cont) => (Valor, Threads, Int, Mem) 

  case class Threads(l: List[(Valor, Cont)])
  
  def id(v: Valor): Acao = (ths, tick, mem, k) => k(v, ths, tick-1, mem)

  def le(l: Int): Acao = (ths, tick, mem, k) => k(mem.get(l) match {
    case Some(v) => v
    case None => sys.error("endereço inválido: " + l)
  }, ths, tick-1, mem)
    
  def escreve(l: Int, v: Valor): Acao = (ths, tick, mem, k) => k(v, ths, tick-1, mem + (l -> v))  

  def bindcc(f: Valor => Acao): Acao = (ths, tick, mem, k) => f(ContV(k))(ths, tick, mem, k)
  
  def spawn(a: Acao): Acao = (ths, tick, mem, k) => {
    val Threads(l) = ths
    a(Threads(l ++ List((NumV(0),k))), tick-1, mem, k)
  }
  
  val quit: Acao = (ths, tick, mem, k) => {
    val Threads((vk, nk) :: t) = ths
    nk(vk, Threads(t), tick, mem)
  }
  
  val join: Acao = (ths, tick, mem, k) => {
    val Threads(l) = ths
    l.headOption match {
      case Some((vk, nk)) => nk(vk, Threads(l.tail ++ List[(Valor, Cont)]((NumV(0), (v, ths, tick, mem) => join(ths, tick, mem, k)))), tick, mem) 
      case None => k(NumV(0), ths, tick, mem)
    }
  } 
  
  def abort(k: Cont, v: Valor): Acao = (ths, tick, mem, _) => k(v, ths, tick-1, mem)
  
  val TICKS: Int = 100
  
  def bind(a1: Acao, f: Valor => Acao): Acao = (ths, tick, mem, k) =>
     a1(ths, tick, mem, (v, ths, tick, mem) =>
       if (tick > 0) f(v)(ths, tick, mem, k)
       else {
         val Threads(l) = ths
         l.headOption match {
           case Some((vk, nk)) => nk(vk, Threads(l.tail ++ List[(Valor, Cont)]((v, (v, ths, tick, mem) => f(v)(ths, tick, mem, k)))), TICKS, mem)
           case None => f(v)(ths, TICKS, mem, k)
         }
       })
    
  implicit class AcaoImp(val a: Acao) extends AnyVal {
    def flatMap(f: Valor => Acao): Acao = bind(a, f)
    def map(f: Valor => Valor): Acao = bind(a, (x: Valor) => id(f(x)))
    def withFilter(p: Valor => Boolean): Acao = bind(a,
        (x: Valor) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def aloca(v: Valor): Acao = for {
    NumV(l) <- le(0)
    _ <- escreve(0, NumV(l.toInt+1))
    _ <- escreve(l.toInt+1, v)
  } yield Caixa(l.toInt+1)
  
  
}


/*

def aloca(v: Valor): Acao[Valor] = for {
  NumV(l) <- le(0)
  nl <- id(l.toInt+1)
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl)

=>

le(0).flatMap({ case NumV(l) => for {
  nl <- id(l.toInt+1)
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => for {
  _ <- escreve(0, NumV(nl))
  _ <- escreve(nl, v)
} yield Caixa(nl)) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) => for {
  _ <- escreve(nl, v)
} yield Caixa(nl))) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) =>
      escreve(nl, v).map((_) => Caixa(nl)))) })

=>

le(0).flatMap({ case NumV(l) => 
  id(l.toInt+1).flatMap((nl) => 
    escreve(0, NumV(nl)).flatMap((_) =>
      escreve(nl, v).flatMap((_) => id(Caixa(nl))))) })

=>

le(0).bind({ case NumV(l) => 
  id(l.toInt+1).bind((nl) => 
    escreve(0, NumV(nl)).bind((_) =>
      escreve(nl, v).bind((_) => id(Caixa(nl))))) })

=>

bind(le(0), { case NumV(l) => 
  bind(id(l.toInt+1), (nl: Int) => 
    bind(escreve(0, NumV(nl)), (_: Valor) =>
      bind(escreve(nl, v), (_: Valor) => id(Caixa(nl))))) })

=>

bind(le(0), (lv: Valor) => {
  val NumV(l) = lv 
  bind(id(l.toInt+1), (nl: Int) => 
    bind(escreve(0, NumV(nl)), (_: Valor) =>
      bind(escreve(nl, v), (_: Valor) => id(Caixa(nl))))) })


 */
