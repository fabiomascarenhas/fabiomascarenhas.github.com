package br.ufrj.aula15

import br.ufrj.aula15.fun.parser

import br.ufrj.aula15.parser

object driver extends App {
  println(parser.parseFile(args(0)).eval)
}
