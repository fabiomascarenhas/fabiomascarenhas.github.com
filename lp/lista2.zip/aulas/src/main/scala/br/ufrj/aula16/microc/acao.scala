package br.ufrj.aula16.microc

import interp.Mem

object acao {
  type Acao[T] = (Int, Mem) => (T, Int, Mem)

  def id[T](v: T): Acao[T] = (free, mem) => (v, free, mem)

  def le(l: Int): Acao[Int] = (free, mem) => mem.get(l) match {
    case Some(v) => (v, free, mem)
    case None => sys.error("endereço inválido: " + l)
  }
  
  def escreve(l: Int, v: Int): Acao[Int] = (free, mem) => (v, free, mem + (l -> v))  

  val next: Acao[Int] = (free, mem) => (free, free+1, mem)
  
  def bind[T, U](a1: Acao[T], f: T => Acao[U]): Acao[U] = (free, mem) => {
    val (v, nfree, nmem) = a1(free, mem)
    val a2 = f(v)
    a2(nfree, nmem)
  }

  implicit class AcaoImp[T](val a: Acao[T]) extends AnyVal {
    def flatMap[U](f: T => Acao[U]): Acao[U] = bind(a, f)
    def map[U](f: T => U): Acao[U] = bind(a, (x: T) => id(f(x)))
    def withFilter(p: T => Boolean): Acao[T] = bind(a,
        (x: T) => if (p(x)) id(x) else sys.error("predicado falhou"))
  }
  
  def aloca(v: Int): Acao[Int] = for {
    nl <- next
    _ <- escreve(nl, v)
  } yield nl
  
  
}


