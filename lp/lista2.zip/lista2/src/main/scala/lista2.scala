object lista2 {
  type Conjunto[T] = T => Boolean
  // escreva suas respostas aqui  
}