package object lp {
  // defina as funções da sua resposta aqui
}