import parser._
import util.Random

package object proto {

  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(funs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  // Let
  case class Let(nome: String, exp: Exp, corpo: Exp) extends Exp
  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(e: Exp) extends Exp
  // Exceções
  case class Throw(msg: String) extends Exp
  case class TryCatch(etry: Exp, ecatch: Exp) extends Exp
  case class TryFinally(etry: Exp, efin: Exp) extends Exp
  // Entrada/Saída
  case class Read() extends Exp
  case class Print(args: List[Exp]) extends Exp
  // While
  case class While(econd: Exp, corpo: Exp) extends Exp
  // Corotinas
  case class Coro(nome: String) extends Exp
  case class Resume(coro: Exp) extends Exp
  case class Yield(e: Exp) extends Exp
  // Objetos
  case class Objeto(campos: List[Exp], metodos: List[(String, List[String], Exp)]) extends Exp
  case class Campo(n: Int) extends Exp
  case class Metodo(obj: Exp, nome: String, args: List[Exp]) extends Exp

  case class Coroutine(link: Valor, sp: End, resumer: Cont[Valor], yielder: Cont[Valor])

  type Valor = Int
  type End = Int
  type Mem = Map[End, Valor]
  type Env = Map[String, End]
  type Coros = Map[Valor, Coroutine]
  type Objs = Map[Valor, List[(String, List[String], Exp)]]

  type Resp = (End, Mem, Coros, Objs) => (Valor, End, Mem, Coros, Objs)
  type Cont[T] = T => Resp

  // Erros
  trait Talvez[T]
  case class Ok[T](v: T) extends Talvez[T]
  case class Erro[T](msg: String) extends Talvez[T]

  // Ações
  type Acao[T] = Cont[T] => Resp

  implicit class RichAcao[A](val p: Acao[A]) extends AnyVal {
    def flatMap[B](f: A => Acao[B]): Acao[B] = bind(p, f)
    def map[B](f: A => B): Acao[B] = bind(p, (v: A) => emptya(f(v)))
    def filter(f: A => Boolean): Acao[A] = bind(p, (v: A) => if(f(v)) emptya(v)
                                                    else sys.error("filter falhou"))
  }

  def emptya[T](v: T): Acao[T] = k => k(v)
  def le(r: End): Acao[Valor] = k => (sp, m, cs, os) => k(m(r))(sp, m, cs, os)
  def escreve(r: End, v: Valor): Acao[Valor] = k => (sp, m, cs, os) => k(v)(sp, m + (r -> v), cs, os)
  def bind[T, U](a: Acao[T], f: T => Acao[U]): Acao[U] = k => a(va => f(va)(k))

  val leSP: Acao[End] = k => (sp, m, cs, os) => k(sp)(sp, m, cs, os)
  def escreveSP(sp: End): Acao[Unit] = k => (_, m, cs, os) => k(())(sp, m, cs, os)

  def pushCampos(cs: List[Valor], base: End, m: Mem): Mem = cs match {
    case List() => m
    case c :: cs => pushCampos(cs, base + 1, m + (base -> c))
  }

  def newObj(campos: List[Valor], ms: List[(String, List[String], Exp)]): Acao[End] =
    k => (sp, m, cs, os) => k(m(PROX_OBJ))(sp,
      pushCampos(campos, m(PROX_OBJ), m) + (PROX_OBJ -> (m(PROX_OBJ) + campos.size + 1)), cs,
      os + (m(PROX_OBJ) -> ms))

  def metodo(obj: Valor, nome: String): Acao[(String, List[String], Exp)] =
    k => (sp, m, cs, os) => k(os(obj).find({ case (n, ps, c) => n == nome }).get)(sp, m, cs, os)

  val CORO_ATUAL: End = 0
  val PROX_OBJ: End = 1

  def newCoro(corpo: Acao[Valor]): Acao[Valor] = k => (sp, m, cs, os) => {
    val handle = if(cs.isEmpty) 1 else cs.keys.max + 1
    val c = Coroutine(-1, handle * 10000, _ => (sp, m, cs, os) => corpo(_ => sys.error("gerador terminou"))(sp, m, cs, os),
                         _ => sys.error("gerador não começou"))
    k(handle)(sp, m, cs + (handle -> c), os)
  }

  def leCoro(handle: Valor): Acao[Coroutine] = k => (sp, m, cs, os) => k(cs(handle))(sp, m, cs, os)

  def resumeCoro(handle: Valor): Acao[Valor] = k => (sp, m, cs, os) => {
    val Coroutine(_, spc, resumer, _) = cs(handle)
    resumer(0)(spc, m + (CORO_ATUAL -> handle),
      cs + (handle -> Coroutine(m(CORO_ATUAL), sp, _ => sys.error("corotinas em execução"), k)), os)
  }

  def yieldCoro(v: Valor): Acao[Valor] = k => (spc, m, cs, os) => {
    val Coroutine(link, sp, _, yielder) = cs(m(CORO_ATUAL))
    yielder(v)(sp, m + (CORO_ATUAL -> link), cs + (m(CORO_ATUAL) -> Coroutine(-1, spc, k, _ => sys.error("gerador não começou"))), os)
  }

  def push(n: Valor): Acao[End] = for {
    sp <- leSP
    _ <- escreve(sp, n)
    _ <- escreveSP(sp + 1)
  } yield sp

  def pop(n: Int): Acao[Unit] = for {
    sp <- leSP
    _ <- escreveSP(sp - n)
  } yield ()

  //def erro[T](msg: String): Acao[T] = (sp, m) => (Erro(msg), sp, m)
  /*def trycatch[T](atry: Acao[T], acatch: Acao[T]): Acao[T] = (sp, m) => {
    val (v, nsp, nm) = atry(sp, m)
    v match {
      case Ok(_) => (v, nsp, nm)
      case Erro(msg) => acatch(sp, nm) // restaurando sp do início do try
    }
  }
  def tryfinally[T,U](atry: Acao[T], afin: Acao[U]): Acao[T] = (sp, m) => {
    val (vtry, sp1, m1) = atry(sp, m)
    vtry match {
      case Ok(_) => {
        val (vfin, sp2, m2) = afin(sp1, m1)
        vfin match {
          case Ok(_) => (vtry, sp2, m2)
          case Erro(msg) => (Erro(msg), sp1, m2) // restaura sp do final do try
        }
      }
      case Erro(msg) => {
        val (vfin, sp2, m2) = afin(sp, m1) // restaura sp do início do try
        vfin match {
          case Ok(_) => (vtry, sp2, m2)
          case Erro(msg) => (Erro(msg), sp, m2) // restaura sp do início do try
        }
      }
    }
  }*/

  def lift[T](l: List[Acao[T]]): Acao[List[T]] = l match {
    case Nil => emptya(Nil)
    case h :: t => for {
      vh <- h // h é uma Acao[T]
      vt <- lift(t) // lift(t) é uma Acao[List[T]]
    } yield vh :: vt
  }

  def ProgFun: Parser[Prog] = for {
    funs <- many(DefFun)
    corpo <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield Prog(funs.toSet, corpo)

  def DefFun: Parser[Fun1] = for {
    _ <- kw("fun")
    (nome, _) <- id
    _ <- op("(")
    params <- (for {
      (p, _) <- id
      ps <- many(for {
        _ <- op(",")
        (p, _) <- id
      } yield p)
    } yield p :: ps) +: empty(List())
    _ <- op(")")
    corpo <- ExpFun
    _ <- kw("end")
  } yield Fun1(nome, params, corpo)

  def ExpFun: Parser[Exp] =
    chainl(AtexpFun,
      for {_ <- op(";")} yield (e1, e2) => Seq(e1, e2),
      AtexpFun)

  def AtexpFun: Parser[Exp] =
    chainl(RexpFun,
      for {_ <- op(":=")} yield (e1, e2) => Atrib(e1, e2),
      RexpFun)

  def RexpFun: Parser[Exp] =
    chainl(AexpFun,
      for {_ <- op("<")} yield (e1, e2) => Menor(e1, e2),
      AexpFun)

  def AexpFun: Parser[Exp] =
    chainl(TermoFun,
      (for {_ <- op("+")} yield (e1, e2) => Soma(e1, e2)) +:
        (for {_ <- op("-")} yield (e1: Exp, e2: Exp) =>
          Soma(e1, Mult(Num(-1), e2))),
      TermoFun)

  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)

  def ArgsFun: Parser[List[Exp]] = (for {
    a <- ExpFun
    as <- many(for {
      _ <- op(",")
      a <- ExpFun
    } yield a)
  } yield a :: as) +: empty(List())

  def FatorFun: Parser[Exp] =
    (for {(v, pos) <- num} yield Num(v)) +:
      (for {
        _ <- op("(")
        e <- ExpFun
        _ <- op(")")
      } yield e) +:
      (for {
        _ <- kw("read")
      } yield Read()) +:
      (for {
        _ <- kw("coro")
        (nome, _) <- id
      } yield Coro(nome)) +:
      (for {
        _ <- kw("resume")
        coro <- FatorFun
      } yield Resume(coro)) +:
      (for {
        _ <- kw("yield")
        e <- FatorFun
      } yield Yield(e)) +:
      (for {
        _ <- kw("print")
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Print(args)) +:
      (for {
        _ <- op("-")
        e <- FatorFun
      } yield Mult(Num(-1), e)) +:
      (for {
        _ <- op("&")
        e <- FatorFun
      } yield Ref(e)) +:
      (for {
        _ <- op("@")
        (n, _) <- num
      } yield Campo(n.toInt)) +:
      (for {
        _ <- kw("throw")
        (msg, _) <- str
      } yield Throw(msg)) +:
      (for {
        _ <- op("*")
        e <- FatorFun
      } yield Deref(e)) +:
      (for {
        _ <- kw("object")
        _ <- op("(")
        args <- (for {
          e <- ExpFun
          es <- many(for {
            _ <- op(",")
            e <- ExpFun
          } yield e)
        } yield e :: es) +: empty(List())
        _ <- op(")")
        ms <- many(for {
          _ <- kw("def")
          (nome, _) <- id
          _ <- op("(")
          params <- (for {
            (p, _) <- id
            ps <- many(for {
              _ <- op(",")
              (p, _) <- id
            } yield p)
          } yield p :: ps) +: empty(List())
          _ <- op(")")
          corpo <- ExpFun
          _ <- kw("end")
        } yield (nome, params, corpo))
        _ <- kw("end")
      } yield Objeto(args, ms)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("else")
        eelse <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, eelse)) +:
      (for {
        _ <- kw("if")
        econd <- ExpFun
        _ <- kw("then")
        ethen <- ExpFun
        _ <- kw("end")
      } yield If(econd, ethen, Num(0))) +:
      (for {
        _ <- kw("while")
        econd <- ExpFun
        _ <- kw("do")
        ewhile <- ExpFun
        _ <- kw("end")
      } yield While(econd, ewhile)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("end")
      } yield TryCatch(etry, ecatch)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(etry, efin)) +:
      (for {
        _ <- kw("try")
        etry <- ExpFun
        _ <- kw("catch")
        ecatch <- ExpFun
        _ <- kw("finally")
        efin <- ExpFun
        _ <- kw("end")
      } yield TryFinally(TryCatch(etry, ecatch), efin)) +:
      (for {
        _ <- kw("let")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
        resto <- many(for {
          _ <- op(",")
          (nome, _) <- id
          _ <- op("=")
          exp <- ExpFun
        } yield (nome, exp))
        _ <- kw("in")
        corpo <- ExpFun
        _ <- kw("end")
      } yield ((nome, exp) :: resto).foldRight(corpo) {
        case ((nome, exp), corpo) => Let(nome, exp, corpo) // Ap(Fun(List(nome), corpo), List(exp))
      }) +:
      (for {
        (obj, _) <- id
        _ <- op(".")
        (nome, _) <- id
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Metodo(Var(obj), nome, args)) +:
      (for {
        (nome, _) <- id
        _ <- op("(")
        args <- (for {
          a <- ExpFun
          as <- many(for {
            _ <- op(",")
            a <- ExpFun
          } yield a)
        } yield a :: as) +: empty(List())
        _ <- op(")")
      } yield Ap1(nome, args)) +:
      (for {(nome, _) <- id} yield Var(nome))

  def eval(p: Prog): (Valor, End, Mem, Coros, Objs) = p match {
    case Prog(funs, corpo) => eval(funs)(Map(), corpo)(vp => (sp, m, cs, os) => (vp, sp, m, cs, os))(2, Map(CORO_ATUAL -> -1, PROX_OBJ -> 10000), Map(), Map())
  }

  def eval(funs: Set[Fun1]) = {
    def eval(env: Env, e: Exp): Acao[Valor] = e match {
      case Num(v) => emptya(v.toInt)
      case Soma(e1, e2) => for {
        n1 <- eval(env, e1)
        n2 <- eval(env, e2)
      } yield n1 + n2
      case Mult(e1, e2) => for {
        n1 <- eval(env, e1)
        n2 <- eval(env, e2)
      } yield n1 * n2
      case Menor(e1, e2) => for {
        n1 <- eval(env, e1)
        n2 <- eval(env, e2)
      } yield if(n1 < n2) 1 else 0
      case If(ec, et, ee) => for {
        vc <- eval(env, ec)
        vif <- if(vc != 0) eval(env, et) else eval(env, ee)
      } yield vif
      case Ap1(nome, args) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val pas: List[(String, Exp)] = params.zip(args)
        for {
          ves <- lift(pas.map({ case (p, a) => if(p.startsWith("_")) {
            for {
              l <- a match {
                case Var(nome) => emptya(env(nome))
                case Deref(la) => eval(env, la)
              }
            } yield l // por ref, o endereço é o endereço do arg
          } else for {
            v <- eval(env, a)
            l <- push(v) // por val, o endereço é alocado
          } yield l }))  // ves é uma List[End]
          vap <- eval(params.zip(ves).toMap, corpo)
          _ <- pop(params.filterNot(p => p.startsWith("_")).size)
        } yield vap
      case Seq(e1, e2) => for {
        _ <- eval(env, e1)
        ve2 <- eval(env, e2)
      } yield ve2
      case Atrib(Var(nome), rv) => for {
        vrv <- eval(env, rv)
        c <- escreve(env(nome), vrv)
      } yield c
      case Atrib(Deref(lv), rv) => for {
        l <- eval(env, lv)
        vrv <- eval(env, rv)
        c <- escreve(l, vrv)
      } yield c
      case Deref(e) => for {
        l <- eval(env, e)
        v <- le(l)
      } yield v
      case Ref(Var(nome)) => emptya(env(nome))
      case Ref(Deref(lv)) => for {
        l <- eval(env, lv)
      } yield l
      case Let(n, e, c) => for {
        ve <- eval(env, e)
        l <- push(ve)
        vc <- eval(env + (n -> l), c)
        _ <- pop(1)
      } yield vc
      //case Throw(msg) => erro(msg)
      //case TryCatch(etry, ecatch) => trycatch(eval(env, etry), eval(env, ecatch))
      //case TryFinally(etry, efin) => tryfinally(eval(env, etry), eval(env, efin))
      case Var(nome) => le(env(nome))
      case Coro(nome) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        newCoro(eval(Map(), corpo))
      case Resume(coro) => for {
        handle <- eval(env, coro)
        vr <- resumeCoro(handle)
      } yield vr
      case Yield(e) => for {
        vy <- eval(env, e)
        _ <- yieldCoro(vy)
      } yield 0
      case Print(args) => for {
        as <- lift(args.map(a => eval(env, a)))
        _ <- emptya(as.map(a => println(a)))
      } yield 0
      case Campo(n: Int) => for {
        v <- le(env("self") + n)
      } yield v
      case Atrib(Campo(n), rv) => for {
        vrv <- eval(env, rv)
        _ <- escreve(env("self") + n, vrv)
      } yield vrv
      case Objeto(args, ms) => for {
        as <- lift(args.map(a => eval(env, a)))
        obj <- newObj(as, ms)
      } yield obj
      case Metodo(obj, nome, args) => for {
        vobj <- eval(env, obj)
        (_, params, corpo) <- metodo(vobj, nome)
        ves <- lift(params.zip(args).map({ case (p, a) => if(p.startsWith("_")) {
          for {
            l <- a match {
              case Var(nome) => emptya(env(nome))
              case Deref(la) => eval(env, la)
            }
          } yield l // por ref, o endereço é o endereço do arg
        } else for {
          v <- eval(env, a)
          l <- push(v) // por val, o endereço é alocado
        } yield l }))  // ves é uma List[End]
        vap <- eval(params.zip(ves).toMap + ("self" -> vobj), corpo)
        _ <- pop(params.filterNot(p => p.startsWith("_")).size)
      } yield vap
      case While(econd, ewhile) =>
        val awhile = eval(env, ewhile)
        val acond = eval(env, econd)
        def loop: Acao[Valor] = for {
          vc <- acond
          vw <- if(vc != 0) for {
            _ <- awhile
            _ <- loop
          } yield 0 else emptya(0)
        } yield 0
        loop
    }
    eval _ // retorna a função eval interna (com funs fixado)
  }

}
