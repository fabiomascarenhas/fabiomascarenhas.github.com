import parser._
import util.Random

package object fun {
  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  // Usado apenas na avaliação verificada (stepc)
  case class Erro() extends Exp
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(funs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  // Let
  case class Let(nome: String, exp: Exp, corpo: Exp) extends Exp
  // Funções de primeira classe
  case class Fun(params: List[String], corpo: Exp) extends Exp
  case class Ap(f: Exp, args: List[Exp]) extends Exp
  // Recursão de primeira classe
  case class Rec(nome: String, exp: Exp) extends Exp
  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(e: Exp) extends Exp
  case class Caixa(r: End) extends Exp

  trait Valor
  case class NumV(v: Double) extends Valor
  case class TrueV() extends Valor
  case class FalseV() extends Valor
  case class FunV(params: List[String], corpo: Exp) extends Valor
  case class CaixaV(r: End) extends Valor

  type End = Int
  type Mem = Map[End, Valor]

  class ScalaRef[T](var v: T) {}

  def val2exp(v: Valor): Exp = v match {
    case NumV(n) => Num(n)
    case TrueV() => True()
    case FalseV() => False()
    case FunV(params, corpo) => Fun(params, corpo)
    case CaixaV(v) => Caixa(v)
  }
  
  def ProgFun: Parser[Prog] = for {
    funs <- many(DefFun)
    corpo <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield Prog(funs.toSet, corpo)
    
  def DefFun: Parser[Fun1] = for {
    _ <- kw("fun")
    (nome, _) <- id
    _ <- op("(")
    params <- (for {
      (p, _) <- id
      ps <- many(for {
        _ <- op(",")
        (p, _) <- id
      } yield p)
    } yield p :: ps) +: empty(List())
    _ <- op(")")
    corpo <- ExpFun
    _ <- kw("end")
  } yield Fun1(nome, params, corpo) 
  
  def ExpFun: Parser[Exp] =
    chainl(AtexpFun,
           for { _ <- op(";") } yield (e1, e2) => Seq(e1, e2),
           AtexpFun)

  def AtexpFun: Parser[Exp] =
    chainl(RexpFun,
      for { _ <- op(":=") } yield (e1, e2) => Atrib(e1, e2),
      RexpFun)

  def RexpFun: Parser[Exp] =
    chainl(AexpFun,
      for { _ <- op("<") } yield (e1, e2) => Menor(e1, e2),
      AexpFun)

  def AexpFun: Parser[Exp] =
    chainl(TermoFun, 
        (for { _ <- op("+") } yield (e1, e2) => Soma(e1, e2)) +:
        (for { _ <- op("-") } yield (e1: Exp, e2: Exp) => 
          Soma(e1, Mult(Num(-1), e2))),
        TermoFun)
    
  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)

  def ArgsFun : Parser[List[Exp]] = (for {
    a <- ExpFun
    as <- many(for {
      _ <- op(",")
      a <- ExpFun
    } yield a)
  } yield a :: as) +: empty(List())

  def FatorFun: Parser[Exp] =
    (for {
      _ <- kw("fun")
      _ <- op("(")
      params <- (for {
        (p, _) <- id
        ps <- many(for {
          _ <- op(",")
          (p, _) <- id
        } yield p)
      } yield p :: ps) +: empty(List())
      _ <- op(")")
      corpo <- ExpFun
      _ <- kw("end")
    } yield Fun(params, corpo)) +:
    (for { (v, pos) <- num } yield Num(v)) +:
    (for {
      _ <- op("(")
      e <- ExpFun
      _ <- op(")")
      _ <- op("(")
      args <- ArgsFun
      _ <- op(")")
      resto <- many(for{
        _ <- op("(")
        args <- ArgsFun
        _ <- op(")")
      } yield args)
    } yield (args :: resto).foldLeft(e)((f, args) => Ap(f, args))) +:
    (for {
      _ <- op("(")
      e <- ExpFun
      _ <- op(")")
    } yield e) +:
    (for {
      _ <- op("-")
      e <- FatorFun
    } yield Mult(Num(-1), e)) +:
    (for {
      _ <- kw("ref")
      e <- FatorFun
    } yield Ref(e)) +:
    (for {
      _ <- op("!")
      e <- FatorFun
    } yield Deref(e)) +:
    (for {
      _ <- kw("if")
      econd <- ExpFun
      _ <- kw("then")
      ethen <- ExpFun
      _ <- kw("else")
      eelse <- ExpFun
      _ <- kw("end")
    } yield If(econd, ethen, eelse)) +:
    (for {
      _ <- kw("letrec")
      (nome, _) <- id
      _ <- op("=")
      exp <- ExpFun
      _ <- kw("in")
      corpo <- ExpFun
      _ <- kw("end")
    } yield Let(nome, Rec(nome, exp), corpo)) +:
    (for {
      _ <- kw("let")
      (nome, _) <- id
      _ <- op("=")
      exp <- ExpFun
      resto <- many(for {
        _ <- op(",")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
      } yield (nome, exp))
      _ <- kw("in")
      corpo <- ExpFun
      _ <- kw("end")
    } yield ((nome, exp) :: resto).foldRight(corpo){
      case ((nome, exp), corpo) => Let(nome, exp, corpo) // Ap(Fun(List(nome), corpo), List(exp))
    }) +:
    (for { _ <- kw("true") } yield True()) +:
    (for { _ <- kw("false") } yield False()) +:
    (for {
      (nome, _) <- id
      _ <- op("(")
      args <- (for {
        a <- ExpFun
        as <- many(for {
          _ <- op(",")
          a <- ExpFun
        } yield a)
      } yield a :: as) +: empty(List())
      _ <- op(")")
    } yield Ap1(nome, args)) +:
    (for { (nome, _) <- id } yield Var(nome))


  def eval(p: Prog): (Valor, Mem) = p match {
    case Prog(funs, corpo) => eval(funs)(corpo, Map(0 -> NumV(1)))
  }
  
  def eval(funs: Set[Fun1]) = {
    def eval(e: Exp, m: Mem): (Valor, Mem) = e match {
      case Num(v) => (NumV(v), m)
      case Soma(e1, e2) =>
        val (NumV(v1), m1) = eval(e1, m)
        val (NumV(v2), m2) = eval(e2, m1)
        (NumV(v1 + v2), m2)
      case Mult(e1, e2) =>
        val (NumV(v1), m1) = eval(e1, m)
        val (NumV(v2), m2) = eval(e2, m1)
        (NumV(v1 * v2), m2)
      case Menor(e1, e2) =>
        val (NumV(v1), m1) = eval(e1, m)
        val (NumV(v2), m2) = eval(e2, m1)
        if(v1 < v2) (TrueV(), m2) else (FalseV(), m2)
      case If(econd, ethen, eelse) => eval(econd, m) match {
        case (TrueV(), nm) => eval(ethen, nm)
        case (FalseV(), nm) => eval(eelse, nm)
      }
      case True() => (TrueV(), m)
      case False() => (FalseV(), m)
      case Ap1(nome, args) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val (pas, nm) = params.zip(args).foldRight((List[(String,Exp)](), m))({
          // parâmetro começado com _ é CBN
          case ((p, a), (pas, m)) => if(p.startsWith("_")) ((p, a) :: pas, m)
                                     else {
                                       val (v, nm) = eval(a, m)
                                       ((p, val2exp(v)) :: pas, nm)
                                     }
          case x => error(x.toString)
        })
        eval(subst(pas.toMap)(corpo), nm)
      case Let(nome, exp, corpo) => 
        if(nome.startsWith("_")) eval(subst(Map(nome -> exp))(corpo), m)
        else {
          val (v, nm) = eval(exp, m)
          eval(subst(Map(nome -> val2exp(v)))(corpo), nm)
        }
      case Fun(params, corpo) =>
        (FunV(params, corpo), m)
      case Ap(f, args) =>
        val (FunV(params, corpo), m1) = eval(f, m)
        val (pas, m2) = params.zip(args).foldRight((List[(String,Exp)](), m1))({
          // parâmetro começado com _ é CBN
          case ((p, a), (pas, m)) => if(p.startsWith("_")) ((p, a) :: pas, m)
                                        else {
                                          val (v, nm) = eval(a, m)
                                          ((p, val2exp(v)) :: pas, nm)
                                        }
        })
        eval(subst(pas.toMap)(corpo), m2)
      case Rec(nome, exp) =>
        eval(subst(Map(nome -> Rec(nome, exp)))(exp), m)
      case Ref(e) =>
        val (v, nm) = eval(e, m)
        val NumV(r) = nm(0)
        (CaixaV(r.toInt), nm + (r.toInt -> v, 0 -> NumV(r+1)))
      case Deref(e) =>
        val (CaixaV(r), nm) = eval(e, m)
        (nm(r), nm)
      case Atrib(lv, rv) =>
        val (v, m1) = eval(rv, m)
        val (CaixaV(r), m2) = eval(lv, m1)
        (CaixaV(r), m2 + (r -> v))
      case Seq(e1, e2) =>
        val (_, nm) = eval(e1, m)
        eval(e2, nm) // produz um valor e uma terceira memória
      case Caixa(r) => (CaixaV(r), m)
      // case Var(nome) => ??? expressão indefinida (erro!)
    }
    eval _  // retorna a função eval interna (com funs fixado)
  }
  
  def fvs(e: Exp): Set[String] = e match {
    case Soma(e1, e2) => fvs(e1) ++ fvs(e2)
    case Mult(e1, e2) => fvs(e1) ++ fvs(e2)
    case Menor(e1, e2) => fvs(e1) ++ fvs(e2)
    case If(ec, et, ee) => fvs(ec) ++ fvs(et) ++ fvs(ee)
    case Var(x) => Set(x)
    case Ap1(nome, args) => args.map(arg => fvs(arg)).reduceOption((a, b) => a ++ b).getOrElse(Set())
    case Let(nome, exp, corpo) => fvs(exp) ++ (fvs(corpo) - nome)
    case Fun(params, corpo) => fvs(corpo) -- params
    case Ap(f, args) => fvs(f) ++ args.map(arg => fvs(arg)).reduceOption((a, b) => a ++ b).getOrElse(Set())
    case Rec(nome, exp) => fvs(exp) - nome
    case Seq(e1, e2) => fvs(e1) ++ fvs(e2)
    case Atrib(lv, rv) => fvs(lv) ++ fvs(rv)
    case Ref(e) => fvs(e)
    case Deref(e) => fvs(e)
    case _ => Set()
  }
  
  def subst(n2v: Map[String,Exp]): (Exp => Exp) = {
    def sub(e: Exp): Exp = e match {
      case Soma(e1, e2) => Soma(sub(e1), sub(e2))
      case Mult(e1, e2) => Mult(sub(e1), sub(e2))
      case Menor(e1, e2) => Menor(sub(e1), sub(e2))
      case If(ec, et, ee) => If(sub(ec), sub(et), sub(ee))
      case Ap1(nome, args) => Ap1(nome, args.map(arg => sub(arg)))
      case Var(nome) => n2v.get(nome) match {
        case Some(e) => e
        case None => Var(nome)
      }
      case Let(nome, exp, corpo) =>
        val scorpo = n2v - nome
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(corpo).intersect(scorpo.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = scorpo.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        if(freevars.contains(nome)) { // ocorreu uma captura
          // Renomeia nome para evitar colisão com seu uso em u
          val novonome = Random.alphanumeric.take(10).mkString
          Let(novonome, sub(exp), subst(scorpo)(subst(Map(nome -> Var(novonome)))(corpo)))
        } else Let(nome, sub(exp), subst(scorpo)(corpo))
      case Ap(f, args) => Ap(sub(f), args.map(arg => sub(arg)))
      case Fun(params, corpo) =>
        val scorpo = n2v -- params
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(corpo).intersect(scorpo.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = scorpo.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        val (nparams, ncorpo) = params.foldRight((List[String](),corpo))({ case (nome, (ps, c)) =>
          if(freevars.contains(nome)) { // ocorreu uma captura
            // Renomeia nome para evitar colisão com seu uso em u
            val novonome = Random.alphanumeric.take(10).mkString
            (novonome :: ps, subst(Map(nome -> Var(novonome)))(c))
          } else (nome :: ps, c) })
        Fun(nparams, subst(scorpo)(ncorpo))
      case Rec(nome, exp) =>
        val sexp = n2v - nome
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(exp).intersect(sexp.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = sexp.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        if(freevars.contains(nome)) { // ocorreu uma captura
          // Renomeia nome para evitar colisão com seu uso em u
          val novonome = Random.alphanumeric.take(10).mkString
          Rec(novonome, subst(sexp)(subst(Map(nome -> Var(novonome)))(exp)))
        } else Rec(nome, subst(sexp)(exp))
      case Seq(e1, e2) => Seq(sub(e1), sub(e2))
      case Atrib(lv, rv) => Atrib(sub(lv), sub(rv))
      case Ref(e) => Ref(sub(e))
      case Deref(e) => Deref(sub(e))
      case _ => e
    }
    sub
  }

  def run(s: String): (Valor, Mem) = eval(ProgFun.parse(s))
  
  def step(funs: Set[Fun1]) = {
    def step(e: Exp): Exp = e match {
      case Num(v)                    => Num(v)
      case Soma(Num(v1), Num(v2))    => Num(v1 + v2)
      case Soma(Num(v), e)           => Soma(Num(v), step(e))
      case Soma(e1, e2)              => Soma(step(e1), e2)
      case Mult(Num(v1), Num(v2))    => Num(v1 * v2)
      case Mult(Num(v), e)           => Mult(Num(v), step(e))
      case Mult(e1, e2)              => Mult(step(e1), e2)
      case True()                    => True()
      case False()                   => False()
      case Menor(Num(v1), Num(v2))   => if (v1 < v2) True() else False()
      case Menor(Num(v), e)          => Menor(Num(v), step(e))
      case Menor(e1, e2)             => Menor(step(e1), e2)
      case If(True(), ethen, eelse)  => ethen
      case If(False(), ethen, eelse) => eelse
      case If(econd, ethen, eelse)   => If(step(econd), ethen, eelse)
      case Ap1(nome, args)           =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val (pas, sub) = stepArgs(params.zip(args))
        if(sub) subst(pas.toMap)(corpo)
        else  Ap1(nome, pas.map{ case(_, a) => a })
      // Let CBN
      case Let(nome, exp, corpo) if(nome.startsWith("_")) =>
        subst(Map(nome -> exp))(corpo)
      // Let CBV
      case Let(nome, Num(v), corpo) => subst(Map(nome -> Num(v)))(corpo) 
      case Let(nome, True(), corpo) => subst(Map(nome -> True()))(corpo) 
      case Let(nome, False(), corpo) => subst(Map(nome -> False()))(corpo)
      case Let(nome, Fun(params, corpof), corpol) => subst(Map(nome -> Fun(params, corpof)))(corpol)
      case Let(nome, exp, corpo) => Let(nome, step(exp), corpo)
      case Fun(params, corpo) => Fun(params, corpo)
      case Ap(Fun(params, corpo), args) =>
        val (pas, sub) = stepArgs(params.zip(args))
        if(sub) subst(pas.toMap)(corpo)
        else Ap(Fun(params, corpo), pas.map{ case(_, a) => a })
      case Ap(f, args) => Ap(step(f), args)
      case Rec(nome, exp) => subst(Map(nome -> Rec(nome, exp)))(exp)
      // case Var(nome)              => ??? indefinido (erro)
    }
    
    // [(param, arg)] => [arg]
    def stepArgs(args: List[(String,Exp)]): (List[(String,Exp)], Boolean) = {
      def loop(args: List[(String,Exp)], res: List[(String,Exp)]):
               (List[(String,Exp)], Boolean) = args match {
        case Nil => (res.reverse, true)
        case (p, a) :: t if p.startsWith("_") => loop(t, (p, a) :: res)
        case (p, Num(v)) :: t => loop(t, (p, Num(v)) :: res)
        case (p, True()) :: t => loop(t, (p, True()) :: res)
        case (p, False()) :: t => loop(t, (p, False()) :: res)
        case (p, Fun(params, corpo)) :: t => loop(t, (p, Fun(params, corpo)) :: res)
        case (p, h) :: t => (res.reverse ++ ((p,step(h)) :: t), false)
      }
      
      loop(args, Nil)
    }
    
    step _
  }
    
  def evals(funs: Set[Fun1]) = {
    val s = step(funs)
    def evals(e: Exp): Valor = e match {
      case Num(v) => NumV(v)
      case True() => TrueV()
      case False() => FalseV()
      case Fun(params, corpo) => FunV(params, corpo)
      case e1 =>
        val e2 = s(e1)
        if(e1 == e2) sys.error("travou " + e1) else evals(e2)
    }
    evals _
  } 
  
  def evals(p: Prog): Valor = evals(p.funs)(p.corpo)
  
  def runs(s: String): Valor = evals(ProgFun.parse(s))
}
