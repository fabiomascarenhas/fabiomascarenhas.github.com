package lp

object Lista1 extends App {
  // escreva testes de suas funções aqui
  println("Olá, Mundo!")
}
