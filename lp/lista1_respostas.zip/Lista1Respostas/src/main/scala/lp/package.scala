import scala.annotation.tailrec
package object lp {
  def pascal1(col: Int, lin: Int): Int = 
    if (col == 0) 1 
    else if (col == lin) 1
    else pascal1(col-1, lin-1) + pascal1(col, lin-1)
  
  def pascal2(col: Int, lin: Int): Int = (col, lin) match {
      case (0, _) => 1
      case (x, y) if (x == y) => 1
      case (x, y) => pascal2(col-1, lin-1) + pascal2(col, lin-1)
  }

  @tailrec
  def balanceado1(l: List[Char], n : Int): Boolean = (l, n) match {
    case (Nil, 0) => true
    case (Nil, _) => false
    case ('(' :: t, n) => balanceado1(t, n+1)
    case (')' :: t, 0) => false
    case (')' :: t, n) => balanceado1(t, n-1)
    case (_ :: t, n) => balanceado1(t, n)
  }
  
  @tailrec
  def balanceado2(l: List[Char], n : Int): Boolean =
    if (l.isEmpty) (n == 0)
    else if (l.head == '(') balanceado2(l.tail, n+1)
    else if (l.head == ')')
      if (n == 0) false
      else balanceado2(l.tail, n-1)
    else balanceado2(l.tail, n)

  def particao(l: List[Int], pivo: Int): (List[Int], List[Int]) = {
      @tailrec
      def loop(l: List[Int], p1: List[Int], p2: List[Int]): 
          (List[Int], List[Int]) = l match {
        case Nil => (p1, p2)
        case h :: t if (h <= pivo) => loop(t, h :: p1, p2)
        case h :: t => loop(t, p1, h :: p2)
      }
      loop(l, Nil, Nil)
  }    
  
  def quicksort(l: List[Int]): List[Int] = l match {
    case Nil => Nil
    case h :: t => {
      val (p1, p2) = particao(t, h)
      quicksort(p1) ++ List(h) ++ quicksort(p2)
    }
  }
  
  def crSemestre(notas: List[(Double, Int)]): (Double, Int) = {
    @tailrec
    def loop(l: List[(Double, Int)], sn: Double, sc: Int):
        (Double, Int) = l match {
      case Nil => (sn/sc, sc)
      case (n, c) :: t => loop(t, sn + n * c, sc + c)
    }
    loop(notas, 0.0, 0)
  }
  
  def crSemestre1(notas: List[(Double, Int)]): (Double, Int) = notas match {
    case Nil => (0.0, 0)
    case (nh, ch) :: t => {
      val (nt, ct) = crSemestre1(t)
      ((nh * ch + nt * ct) / (ch + ct), ch + ct)
    }
  }
   
  def crsAcumulados(semestres: List[List[(Double, Int)]]):
      (List[Double], Int) = {
    @tailrec
    def loop(l: List[List[(Double, Int)]], crs: List[Double], sc: Int):
        (List[Double], Int) = l match {
      case Nil => (crs.reverse, sc)
      case notas :: t => {
        val (cr, cred) = crSemestre(notas)
        crs match {
          case Nil => loop(t, List(cr), cred)
          case acum :: _ => loop(t, 
              ((acum * sc) + (cr * cred)) / (sc + cred) :: crs,
              sc + cred)
        }
      }
    }
    loop(semestres, Nil, 0)
  }
}
