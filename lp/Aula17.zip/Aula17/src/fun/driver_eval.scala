package fun

import parser._

object DriverEval extends App {
  println(eval(ProgFun.parseFile(args(0))))
}