import parser._
import util.Random

package object fun {
  trait Exp
  // Aritmética
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(econd: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp)
  case class Prog(funs: Set[Fun1], corpo: Exp)
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  // Let
  case class Let(nome: String, exp: Exp, corpo: Exp) extends Exp
  // Funções de primeira classe
  case class Fun(params: List[String], corpo: Exp) extends Exp
  case class Ap(f: Exp, args: List[Exp]) extends Exp
  // Recursão de primeira classe
  case class Rec(nome: String, exp: Exp) extends Exp
  // Referências
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  case class Ref(e: Exp) extends Exp
  case class Deref(e: Exp) extends Exp
  case class Caixa(r: End) extends Exp
  // Exceções
  case class Throw(msg: String) extends Exp
  case class TryCatch(etry: Exp, ecatch: Exp) extends Exp
  case class TryFinally(etry: Exp, efin: Exp) extends Exp

  trait Valor
  case class NumV(v: Double) extends Valor
  case class TrueV() extends Valor
  case class FalseV() extends Valor
  case class FunV(params: List[String], corpo: Exp) extends Valor
  case class CaixaV(r: End) extends Valor

  type End = Int
  type Mem = Map[End, Valor]

  // Erros
  trait Talvez[T]
  case class Ok[T](v: T) extends Talvez[T]
  case class Erro[T](msg: String) extends Talvez[T]

  // Ações
  type Acao[T] = Mem => (Talvez[T], Mem)

  implicit class RichAcao[A](val p: Acao[A]) extends AnyVal {
    def flatMap[B](f: A => Acao[B]): Acao[B] = bind(p, f)
    def map[B](f: A => B): Acao[B] = bind(p, (v: A) => emptya(f(v)))
    def filter(f: A => Boolean): Acao[A] = bind(p, (v: A) => if(f(v)) emptya(v)
                                                             else erro[A]("filter falhou"))
  }

  def emptya[T](v: T): Acao[T] = m => (Ok(v), m)
  def le(r: Int): Acao[Valor] = m => (Ok(m(r)), m)
  def escreve(r: Int, v: Valor): Acao[Valor] = m => (Ok(CaixaV(r)), m + (r -> v))
  def bind[T, U](a: Acao[T], f: T => Acao[U]): Acao[U] = m => {
    val (v, nm) = a(m)
    v match {
      case Ok(vok) => f(vok)(nm)
      case Erro(msg) => (Erro(msg), nm)
    }
  }
  def erro[T](msg: String): Acao[T] = m => (Erro(msg), m)
  def trycatch[T](atry: Acao[T], acatch: Acao[T]): Acao[T] = m => {
    val (v, nm) = atry(m)
    v match {
      case Ok(_) => (v, nm)
      case Erro(msg) => acatch(nm)
    }
  }
  def tryfinally[T,U](atry: Acao[T], afin: Acao[U]): Acao[T] = m => {
    val (vtry, m1) = atry(m)
    val (vfin, m2) = afin(m1)
    vfin match {
      case Ok(_) => (vtry, m2)
      case Erro(msg) => (Erro(msg), m2)
    }
  }

  def lift[T](l: List[Acao[T]]): Acao[List[T]] = l match {
    case Nil => emptya(Nil)
    case h :: t => for {
      vh <- h    // h é uma Acao[T]
      vt <- lift(t) // lift(t) é uma Acao[List[T]]
    } yield vh :: vt
  }

  def val2exp(v: Valor): Exp = v match {
    case NumV(n) => Num(n)
    case TrueV() => True()
    case FalseV() => False()
    case FunV(params, corpo) => Fun(params, corpo)
    case CaixaV(v) => Caixa(v)
  }

  def expisval(e: Exp): Boolean = e match {
    case Num(_) => true
    case True() => true
    case False() => true
    case Fun(_, _) => true
    case Caixa(_) => true
    case Throw(_) => true
    case _ => false
  }
  
  def ProgFun: Parser[Prog] = for {
    funs <- many(DefFun)
    corpo <- ExpFun
    _ <- space
    _ <- not(pred(c => true), ())
  } yield Prog(funs.toSet, corpo)
    
  def DefFun: Parser[Fun1] = for {
    _ <- kw("fun")
    (nome, _) <- id
    _ <- op("(")
    params <- (for {
      (p, _) <- id
      ps <- many(for {
        _ <- op(",")
        (p, _) <- id
      } yield p)
    } yield p :: ps) +: empty(List())
    _ <- op(")")
    corpo <- ExpFun
    _ <- kw("end")
  } yield Fun1(nome, params, corpo) 
  
  def ExpFun: Parser[Exp] =
    chainl(AtexpFun,
           for { _ <- op(";") } yield (e1, e2) => Seq(e1, e2),
           AtexpFun)

  def AtexpFun: Parser[Exp] =
    chainl(RexpFun,
      for { _ <- op(":=") } yield (e1, e2) => Atrib(e1, e2),
      RexpFun)

  def RexpFun: Parser[Exp] =
    chainl(AexpFun,
      for { _ <- op("<") } yield (e1, e2) => Menor(e1, e2),
      AexpFun)

  def AexpFun: Parser[Exp] =
    chainl(TermoFun, 
        (for { _ <- op("+") } yield (e1, e2) => Soma(e1, e2)) +:
        (for { _ <- op("-") } yield (e1: Exp, e2: Exp) => 
          Soma(e1, Mult(Num(-1), e2))),
        TermoFun)
    
  def TermoFun: Parser[Exp] =
    chainl(FatorFun, for {
      _ <- op("*")
    } yield (e1, e2) => Mult(e1, e2), FatorFun)

  def ArgsFun : Parser[List[Exp]] = (for {
    a <- ExpFun
    as <- many(for {
      _ <- op(",")
      a <- ExpFun
    } yield a)
  } yield a :: as) +: empty(List())

  def FatorFun: Parser[Exp] =
    (for {
      _ <- kw("fun")
      _ <- op("(")
      params <- (for {
        (p, _) <- id
        ps <- many(for {
          _ <- op(",")
          (p, _) <- id
        } yield p)
      } yield p :: ps) +: empty(List())
      _ <- op(")")
      corpo <- ExpFun
      _ <- kw("end")
    } yield Fun(params, corpo)) +:
    (for { (v, pos) <- num } yield Num(v)) +:
    (for {
      _ <- op("(")
      e <- ExpFun
      _ <- op(")")
      _ <- op("(")
      args <- ArgsFun
      _ <- op(")")
      resto <- many(for{
        _ <- op("(")
        args <- ArgsFun
        _ <- op(")")
      } yield args)
    } yield (args :: resto).foldLeft(e)((f, args) => Ap(f, args))) +:
    (for {
      _ <- op("(")
      e <- ExpFun
      _ <- op(")")
    } yield e) +:
    (for {
      _ <- op("-")
      e <- FatorFun
    } yield Mult(Num(-1), e)) +:
    (for {
      _ <- kw("ref")
      e <- FatorFun
    } yield Ref(e)) +:
    (for {
      _ <- kw("throw")
      (msg, _) <- str
    } yield Throw(msg)) +:
    (for {
      _ <- op("!")
      e <- FatorFun
    } yield Deref(e)) +:
    (for {
      _ <- kw("if")
      econd <- ExpFun
      _ <- kw("then")
      ethen <- ExpFun
      _ <- kw("else")
      eelse <- ExpFun
      _ <- kw("end")
    } yield If(econd, ethen, eelse)) +:
    (for {
      _ <- kw("try")
      etry <- ExpFun
      _ <- kw("catch")
      ecatch <- ExpFun
      _ <- kw("end")
    } yield TryCatch(etry, ecatch)) +:
    (for {
      _ <- kw("try")
      etry <- ExpFun
      _ <- kw("finally")
      efin <- ExpFun
      _ <- kw("end")
    } yield TryFinally(etry, efin)) +:
    (for {
      _ <- kw("try")
      etry <- ExpFun
      _ <- kw("catch")
      ecatch <- ExpFun
      _ <- kw("finally")
      efin <- ExpFun
      _ <- kw("end")
    } yield TryFinally(TryCatch(etry, ecatch), efin)) +:
    (for {
      _ <- kw("letrec")
      (nome, _) <- id
      _ <- op("=")
      exp <- ExpFun
      _ <- kw("in")
      corpo <- ExpFun
      _ <- kw("end")
    } yield Let(nome, Rec(nome, exp), corpo)) +:
    (for {
      _ <- kw("let")
      (nome, _) <- id
      _ <- op("=")
      exp <- ExpFun
      resto <- many(for {
        _ <- op(",")
        (nome, _) <- id
        _ <- op("=")
        exp <- ExpFun
      } yield (nome, exp))
      _ <- kw("in")
      corpo <- ExpFun
      _ <- kw("end")
    } yield ((nome, exp) :: resto).foldRight(corpo){
      case ((nome, exp), corpo) => Let(nome, exp, corpo) // Ap(Fun(List(nome), corpo), List(exp))
    }) +:
    (for { _ <- kw("true") } yield True()) +:
    (for { _ <- kw("false") } yield False()) +:
    (for {
      (nome, _) <- id
      _ <- op("(")
      args <- (for {
        a <- ExpFun
        as <- many(for {
          _ <- op(",")
          a <- ExpFun
        } yield a)
      } yield a :: as) +: empty(List())
      _ <- op(")")
    } yield Ap1(nome, args)) +:
    (for { (nome, _) <- id } yield Var(nome))


  def eval(p: Prog): (Talvez[Valor], Mem) = p match {
    case Prog(funs, corpo) => eval(funs)(corpo)(Map(0 -> NumV(1)))
  }

  def checaNum(a: Acao[Valor], nome: String): Acao[Double] = for {
    va <- a
    n <- va match {
      case NumV(na) => emptya(na)
      case _ => erro[Double](nome + " não é um número")
    }
  } yield n

  def eval(funs: Set[Fun1]) = {
    def eval(e: Exp): Acao[Valor] = e match {
      case Num(v) => emptya(NumV(v))
      case Soma(e1, e2) => for {
        n1 <- checaNum(eval(e1), "lado esquerdo da soma")
        n2 <- checaNum(eval(e2), "lado direito da soma")
      } yield NumV(n1 + n2)
      case Mult(e1, e2) => for {
        NumV(n1) <- eval(e1)
        NumV(n2) <- eval(e2)
      } yield NumV(n1 * n2)
      case Menor(e1, e2) => for {
        NumV(n1) <- eval(e1)
        NumV(n2) <- eval(e2)
      } yield if(n1 < n2) TrueV() else FalseV()
      case If(econd, ethen, eelse) => for {
        vcond <- eval(econd)
        vif <- vcond match {
          case TrueV() => eval(ethen)
          case FalseV() => eval(eelse)
        }
      } yield vif
      case True() => emptya(TrueV())
      case False() => emptya(FalseV())
      case Ap1(nome, args) =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val pas: List[(String,Acao[Exp])] = params.zip(args).map{
          // parâmetro começado com _ é CBN
          case (p, a) => if(p.startsWith("_")) (p, emptya(a))
          else (p, for { va <- eval(a) } yield val2exp(va))
        }
        for {
          vas <- lift(pas.map({ case (_, a) => a }))  // vas é uma List[Exp]
          vap <- eval(subst(params.zip(vas).toMap)(corpo))
        } yield vap
      case Let(nome, exp, corpo) =>
        if(nome.startsWith("_")) eval(subst(Map(nome -> exp))(corpo))
        else for {
          vexp <- eval(exp)
          vlet <- eval(subst(Map(nome -> val2exp(vexp)))(corpo))
        } yield vlet
      case Fun(params, corpo) => emptya(FunV(params, corpo))
      case Ap(f, args) => for {
        FunV(params, corpo) <- eval(f)
        pas <- emptya(params.zip(args).map{
          // parâmetro começado com _ é CBN
          case (p, a) => if(p.startsWith("_")) (p, emptya(a))
          else (p, for { va <- eval(a) } yield val2exp(va))
        })
        vas <- lift(pas.map({ case (_, a) => a }))  // vas é uma List[Exp]
        vap <- eval(subst(params.zip(vas).toMap)(corpo))
      } yield vap
      case Rec(nome, exp) =>
        eval(subst(Map(nome -> Rec(nome, exp)))(exp))
      case Ref(e) => for {
        v <- eval(e)
        NumV(r) <- le(0)
        c <- escreve(r.toInt, v)
        _ <- escreve(0, NumV(r+1))
      } yield c
      case Deref(e) => for {
        CaixaV(r) <- eval(e)
        vr <- le(r)
      } yield vr
      case Atrib(lv, rv) => for {
        CaixaV(r) <- eval(lv)
        vrv <- eval(rv)
        c <- escreve(r, vrv)
      } yield c
      case Seq(e1, e2) => for {
        _ <- eval(e1)
        ve2 <- eval(e2)
      } yield ve2
      case Caixa(r) => emptya(CaixaV(r))
      case Throw(msg) => erro(msg)
      case TryCatch(etry, ecatch) => trycatch(eval(etry), eval(ecatch))
      case TryFinally(etry, efin) => tryfinally(eval(etry), eval(efin))
      // case Var(nome) => ??? expressão indefinida (erro!)
    }
    eval _  // retorna a função eval interna (com funs fixado)
  }
  
  def fvs(e: Exp): Set[String] = e match {
    case Soma(e1, e2) => fvs(e1) ++ fvs(e2)
    case Mult(e1, e2) => fvs(e1) ++ fvs(e2)
    case Menor(e1, e2) => fvs(e1) ++ fvs(e2)
    case If(ec, et, ee) => fvs(ec) ++ fvs(et) ++ fvs(ee)
    case Var(x) => Set(x)
    case Ap1(nome, args) => args.map(arg => fvs(arg)).reduceOption((a, b) => a ++ b).getOrElse(Set())
    case Let(nome, exp, corpo) => fvs(exp) ++ (fvs(corpo) - nome)
    case Fun(params, corpo) => fvs(corpo) -- params
    case Ap(f, args) => fvs(f) ++ args.map(arg => fvs(arg)).reduceOption((a, b) => a ++ b).getOrElse(Set())
    case Rec(nome, exp) => fvs(exp) - nome
    case Seq(e1, e2) => fvs(e1) ++ fvs(e2)
    case Atrib(lv, rv) => fvs(lv) ++ fvs(rv)
    case Ref(e) => fvs(e)
    case Deref(e) => fvs(e)
    case TryCatch(e1, e2) => fvs(e1) ++ fvs(e2)
    case TryFinally(e1, e2) => fvs(e1) ++ fvs(e2)
    case _ => Set()
  }
  
  def subst(n2v: Map[String,Exp]): (Exp => Exp) = {
    def sub(e: Exp): Exp = e match {
      case Soma(e1, e2) => Soma(sub(e1), sub(e2))
      case Mult(e1, e2) => Mult(sub(e1), sub(e2))
      case Menor(e1, e2) => Menor(sub(e1), sub(e2))
      case If(ec, et, ee) => If(sub(ec), sub(et), sub(ee))
      case Ap1(nome, args) => Ap1(nome, args.map(arg => sub(arg)))
      case Var(nome) => n2v.get(nome) match {
        case Some(e) => e
        case None => Var(nome)
      }
      case Let(nome, exp, corpo) =>
        val scorpo = n2v - nome
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(corpo).intersect(scorpo.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = scorpo.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        if(freevars.contains(nome)) { // ocorreu uma captura
          // Renomeia nome para evitar colisão com seu uso em u
          val novonome = Random.alphanumeric.take(10).mkString
          Let(novonome, sub(exp), subst(scorpo)(subst(Map(nome -> Var(novonome)))(corpo)))
        } else Let(nome, sub(exp), subst(scorpo)(corpo))
      case Ap(f, args) => Ap(sub(f), args.map(arg => sub(arg)))
      case Fun(params, corpo) =>
        val scorpo = n2v -- params
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(corpo).intersect(scorpo.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = scorpo.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        val (nparams, ncorpo) = params.foldRight((List[String](),corpo))({ case (nome, (ps, c)) =>
          if(freevars.contains(nome)) { // ocorreu uma captura
            // Renomeia nome para evitar colisão com seu uso em u
            val novonome = Random.alphanumeric.take(10).mkString
            (novonome :: ps, subst(Map(nome -> Var(novonome)))(c))
          } else (nome :: ps, c) })
        Fun(nparams, subst(scorpo)(ncorpo))
      case Rec(nome, exp) =>
        val sexp = n2v - nome
        // variáveis no mapa de substituição que são efetivamente usadas
        val conflito = fvs(exp).intersect(sexp.keySet)
        // variáveis livres nos valores do mapa de substituição
        val freevars = sexp.filterKeys(n => conflito.contains(n)).values.map(e => fvs(e)).reduceOption((a, b) => a ++ b).getOrElse(Set())
        if(freevars.contains(nome)) { // ocorreu uma captura
          // Renomeia nome para evitar colisão com seu uso em u
          val novonome = Random.alphanumeric.take(10).mkString
          Rec(novonome, subst(sexp)(subst(Map(nome -> Var(novonome)))(exp)))
        } else Rec(nome, subst(sexp)(exp))
      case Seq(e1, e2) => Seq(sub(e1), sub(e2))
      case Atrib(lv, rv) => Atrib(sub(lv), sub(rv))
      case Ref(e) => Ref(sub(e))
      case Deref(e) => Deref(sub(e))
      case TryCatch(et, ec) => TryCatch(sub(et), sub(ec))
      case TryFinally(et, ef) => TryFinally(sub(et), sub(ef))
      case _ => e
    }
    sub
  }

  def run(s: String): (Talvez[Valor], Mem) = eval(ProgFun.parse(s))
  
  def step(funs: Set[Fun1]) = {
    def step(e: Exp, m: Mem): (Exp, Mem) = e match {
      case Num(v)                    => (Num(v), m)
      case Soma(Num(v1), Num(v2))    => (Num(v1 + v2), m)
      case Soma(Num(_), Throw(msg))  => (Throw(msg), m)
      case Soma(Num(v), e)           => {
        val (ne, nm) = step(e, m)
        (Soma(Num(v), ne), nm)
      }
      case Soma(Throw(msg), _)       => (Throw(msg), m)
      case Soma(e1, e2)              => {
        val (ne1, nm) = step(e1, m)
        (Soma(ne1, e2), nm)
      }
      case Mult(Num(v1), Num(v2))    => (Num(v1 * v2), m)
      case Mult(Num(_), Throw(msg))  => (Throw(msg), m)
      case Mult(Num(v), e)           => {
        val (ne, nm) = step(e, m)
        (Mult(Num(v), ne), nm)
      }
      case Mult(Throw(msg), _)       => (Throw(msg), m)
      case Mult(e1, e2)              => {
        val (ne1, nm) = step(e1, m)
        (Mult(ne1, e2), nm)
      }
      case True()                    => (True(), m)
      case False()                   => (False(), m)
      case Menor(Num(v1), Num(v2))   => (if (v1 < v2) True() else False(), m)
      case Menor(Num(_), Throw(msg)) => (Throw(msg), m)
      case Menor(Num(v), e)          => {
        val (ne, nm) = step(e, m)
        (Menor(Num(v), ne), nm)
      }
      case Menor(Throw(msg), _)      => (Throw(msg), m)
      case Menor(e1, e2)             => {
        val (ne1, nm) = step(e1, m)
        (Menor(ne1, e2), nm)
      }
      case If(True(), ethen, eelse)  => (ethen, m)
      case If(False(), ethen, eelse) => (eelse, m)
      case If(Throw(msg), ethen, eelse) => (Throw(msg), m)
      case If(econd, ethen, eelse)   => {
        val (nc, nm) = step(econd, m)
        (If(nc, ethen, eelse), nm)
      }
      case Ap1(nome, args)           =>
        val Fun1(_, params, corpo) = funs.find(f => f.nome == nome).get
        val (pas, nm, sub) = stepArgs(params.zip(args), m)
        pas match {
          case Ok(pas) => if (sub) (subst(pas.toMap)(corpo), nm)
                          else (Ap1(nome, pas.map { case (_, a) => a }), nm)
          case Erro(msg) => (Throw(msg), nm)
        }
      // Let CBN
      case Let(nome, exp, corpo) if(nome.startsWith("_")) =>
        (subst(Map(nome -> exp))(corpo), m)
      // Let CBV
      case Let(nome, Throw(msg), corpo) => (Throw(msg), m)
      case Let(nome, exp, corpo) if(expisval(exp)) => (subst(Map(nome -> exp))(corpo), m)
      case Let(nome, exp, corpo) => {
        val (ne, nm) = step(exp, m)
        (Let(nome, ne, corpo), nm)
      }
      case Fun(params, corpo) => (Fun(params, corpo), m)
      case Ap(Fun(params, corpo), args) =>
        val (pas, nm, sub) = stepArgs(params.zip(args), m)
        pas match {
          case Ok(pas) => if(sub) (subst(pas.toMap)(corpo), nm)
                          else (Ap(Fun(params, corpo), pas.map{ case(_, a) => a }), nm)
          case Erro(msg) => (Throw(msg), nm)
        }
      case Ap(Throw(msg), _) => (Throw(msg), m)
      case Ap(f, args) => {
        val (nf, nm) = step(f, m)
        (Ap(nf, args), nm)
      }
      case Rec(nome, exp) => (subst(Map(nome -> Rec(nome, exp)))(exp), m)
      // case Var(nome)              => ??? indefinido (erro)
      case Caixa(r) => (Caixa(r), m)
      case Deref(Caixa(r)) => (val2exp(m(r)), m)
      case Deref(Throw(msg)) => (Throw(msg), m)
      case Deref(e) => {
        val (ne, nm) = step(e, m)
        (Deref(ne), nm)
      }
      case Atrib(Throw(msg), _) => (Throw(msg), m)
      case Atrib(Caixa(r), Throw(msg)) => (Throw(msg), m)
      case Atrib(Caixa(r), Num(n)) => (Caixa(r), m + (r -> NumV(n)))
      case Atrib(Caixa(r), True()) => (Caixa(r), m + (r -> TrueV()))
      case Atrib(Caixa(r), False()) => (Caixa(r), m + (r -> FalseV()))
      case Atrib(Caixa(r), Fun(params, corpo)) => (Caixa(r), m + (r -> FunV(params, corpo)))
      case Atrib(Caixa(r), Caixa(l)) => (Caixa(r), m + (r -> CaixaV(l)))
      case Atrib(Caixa(r), e) => {
        val (ne, nm) = step(e, m)
        (Atrib(Caixa(r), ne), nm)
      }
      case Atrib(e1, e2) => {
        val (ne1, nm) = step(e1, m)
        (Atrib(ne1, e2), nm)
      }
      case Seq(Throw(msg), _) => (Throw(msg), m)
      case Seq(e1, e2) if(expisval(e1)) => (e2, m)
      case Seq(e1, e2) => {
        val (ne1, nm) = step(e1, m)
        (Seq(ne1, e2), nm)
      }
      case Ref(Num(n)) => {
        val NumV(r) = m(0)
        (Caixa(r.toInt), m + (0 -> NumV(r+1), r.toInt -> NumV(n)))
      }
      case Ref(True()) => {
        val NumV(r) = m(0)
        (Caixa(r.toInt), m + (0 -> NumV(r+1), r.toInt -> TrueV()))
      }
      case Ref(False()) => {
        val NumV(r) = m(0)
        (Caixa(r.toInt), m + (0 -> NumV(r+1), r.toInt -> FalseV()))
      }
      case Ref(Fun(p, c)) => {
        val NumV(r) = m(0)
        (Caixa(r.toInt), m + (0 -> NumV(r+1), r.toInt -> FunV(p, c)))
      }
      case Ref(Caixa(l)) => {
        val NumV(r) = m(0)
        (Caixa(r.toInt), m + (0 -> NumV(r+1), r.toInt -> CaixaV(l)))
      }
      case Ref(Throw(msg)) => (Throw(msg), m)
      case Ref(e) => {
        val (ne, nm) = step(e, m)
        (Ref(ne), nm)
      }
      case TryCatch(Throw(msg), ec) => (ec, m)
      case TryCatch(et, ec) if(expisval(et)) => (et, m)
      case TryCatch(et, ec) => {
        val (net, nm) = step(et, m)
        (TryCatch(net, ec), nm)
      }
      case TryFinally(et, Throw(msg)) if(expisval(et)) => (Throw(msg), m)
      case TryFinally(et, ef) if(expisval(et) && expisval(ef)) => (et, m)
      case TryFinally(et, ef) if(expisval(et)) => {
        val (nef, nm) = step(ef, m)
        (TryFinally(et, nef), nm)
      }
      case TryFinally(et, ef) => {
        val (net, nm) = step(et, m)
        (TryFinally(net, ef), nm)
      }
    }
    
    // [(param, arg)] => [arg]
    def stepArgs(args: List[(String,Exp)], m: Mem): (Talvez[List[(String,Exp)]], Mem, Boolean) = {
      def loop(args: List[(String,Exp)], res: List[(String,Exp)]):
               (Talvez[List[(String,Exp)]], Mem, Boolean) = args match {
        case Nil => (Ok(res.reverse), m, true)
        case (p, a) :: t if p.startsWith("_") => loop(t, (p, a) :: res)
        case (p, Num(v)) :: t => loop(t, (p, Num(v)) :: res)
        case (p, True()) :: t => loop(t, (p, True()) :: res)
        case (p, False()) :: t => loop(t, (p, False()) :: res)
        case (p, Fun(params, corpo)) :: t => loop(t, (p, Fun(params, corpo)) :: res)
        case (p, Caixa(r)) :: t => loop(t, (p, Caixa(r)) :: res)
        case (p, Throw(msg)) :: t => (Erro(msg), m, false)
        case (p, h) :: t => {
          val (nh, nm) = step(h, m)
          (Ok(res.reverse ++ ((p,nh) :: t)), nm, false)
        }
      }
      
      loop(args, Nil)
    }
    
    step _
  }
    
  def evals(funs: Set[Fun1]) = {
    val s = step(funs)
    def evals(e: Exp, m: Mem): (Talvez[Valor], Mem) = e match {
      case Num(v) => (Ok(NumV(v)), m)
      case True() => (Ok(TrueV()), m)
      case False() => (Ok(FalseV()), m)
      case Fun(params, corpo) => (Ok(FunV(params, corpo)), m)
      case Caixa(r) => (Ok(CaixaV(r)), m)
      case Throw(msg) => (Erro(msg), m)
      case e1 =>
        val (e2, nm) = s(e1, m)
        if(e1 == e2) sys.error("travou " + e1) else evals(e2, nm)
    }
    evals _
  } 
  
  def evals(p: Prog): (Talvez[Valor], Mem) = evals(p.funs)(p.corpo, Map(0 -> NumV(1)))
  
  def runs(s: String): (Talvez[Valor], Mem) = evals(ProgFun.parse(s))
}
