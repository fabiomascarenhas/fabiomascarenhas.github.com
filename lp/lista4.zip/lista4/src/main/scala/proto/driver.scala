package proto

object driver extends App {
  val kid: acao.Cont[interp.Valor] = v => (sp, free, mem) => (v, sp, free, mem)
  println((parser.parseFile(args(0)).eval)
           (kid)
           (0, 1000, Map()))
}
