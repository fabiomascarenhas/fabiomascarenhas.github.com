package proto

import acao._

object interp {  
  // Ambientes
  type Env[T] = Map[String, T]

  // Endereços
  type End = Int
  
  // Valores
  trait Valor
  case class NumV(n: Int) extends Valor
  case class ObjV(campos: Vector[End], metodos: Env[Metodo], proto: Option[ObjV]) extends Valor
  
  // Memória
  type Mem = Map[End, Valor]
  
  trait Exp {
    def eval(env: Env[End])(self: ObjV, sup: Option[ObjV]): Acao[Valor] = this match {
      case Num(v) => id(NumV(v))
      case Soma(e1, e2) => for {
        NumV(v1) <- e1.eval(env)(self, sup)
        NumV(v2) <- e2.eval(env)(self, sup)
      } yield NumV(v1 + v2)
      case Mult(e1, e2) => for {
        NumV(v1) <- e1.eval(env)(self, sup)
        NumV(v2) <- e2.eval(env)(self, sup)
      } yield NumV(v1 * v2)
      case Div(e1, e2) => for {
        NumV(v1) <- e1.eval(env)(self, sup)
        NumV(v2) <- e2.eval(env)(self, sup)
      } yield NumV(v1 / v2)
      case Menor(e1, e2) => for {
        NumV(v1) <- e1.eval(env)(self, sup)
        NumV(v2) <- e2.eval(env)(self, sup)
      } yield if (v1 < v2) NumV(1) else NumV(0)
      case Eq(e1, e2) => for {
        v1 <- e1.eval(env)(self, sup)
        v2 <- e2.eval(env)(self, sup)
      } yield if (v1 == v2) NumV(1) else NumV(0)
      case If(c, et, ee) => for {
        NumV(vc) <- c.eval(env)(self, sup)
        vi <- if (vc != 0)
                et.eval(env)(self, sup)
              else
                ee.eval(env)(self, sup)
      } yield vi
      case While(c, e) => {
        val cond = c.eval(env)(self, sup)
        val corpo = e.eval(env)(self, sup)
        def loop: Acao[Valor] = for {
          NumV(vc) <- cond
          _ <- if (vc != 0) for {
                              _ <- corpo
                              _ <- loop
                            } yield NumV(0)
               else id(NumV(0))
        } yield NumV(0)
        loop
      }
      case Var(nome) => le(env(nome))
      case Campo(n) => le(self.campos(n))
      case Atrib(lval, rval) => lval match {
        case Var(n) => for {
          rv <- rval.eval(env)(self, sup)
          _ <- escreve(env(n), rv)
        } yield rv
        case Campo(n) => for {
          rv <- rval.eval(env)(self, sup)
          _ <- escreve(self.campos(n), rv)
        } yield rv
        case _ => sys.error("lado esquerdo inválido")
      }
      case Let(n, e, c) => for {
        ve <- e.eval(env)(self, sup)
        l <- push(ve)
        vc <- c.eval(env + (n -> l))(self, sup)
        _ <- pop   // recicla endereço da variável da let
      } yield vc
      case Seq(e1, e2) => for {
        _ <- e1.eval(env)(self, sup)
        v <- e2.eval(env)(self, sup)
      } yield v
      case Send(obj, m, args) => obj match {
        case Super() => for {
          larg1 <- pushArgs(self, sup, env, args)
          v <- lookup(sup.get, m).apply(self, sup.get.proto, args.size, larg1)
          _ <- popArgs(args.size)
        } yield v
        case _ => for {
          ObjV(cs, ms, proto) <- obj.eval(env)(self, sup)
          larg1 <- pushArgs(self, sup, env, args)
          v <- lookup(ObjV(cs, ms, proto), m).apply(ObjV(cs, ms, proto), proto, args.size, larg1)
          _ <- popArgs(args.size)
        } yield v
      }
      case Read() => id(NumV(readInt()))
      case Print(es: List[Exp]) => {
        def printArgs(l: List[Exp]): Acao[Valor] = l match {
          case h :: t => for {
            v <- h.eval(env)(self, sup)
            _ <- { print(v); print("\t"); printArgs(t) }
          } yield NumV(0)
          case List() => { print("\n"); id(NumV(0)) }
        }
        printArgs(es)
      }
      case Obj(nc, ms, proto) => proto match {
        case Some(pai) => for {
          vpai <- pai.eval(env)(self, sup)
          o <- vpai match {
            case opai: ObjV => alocObj(nc + opai.campos.size, ms, Some(opai))
            case _ => sys.error("pai não é objeto")
          }
        } yield o
        case None => alocObj(nc, ms, None)
      }
      case New() => clonar(self)
      case Self() => id(self)
      case Super() => sys.error("super só pode aparecer em chamada de método")
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, Num(0))
      case Ou(e1, e2) => If(e1.desugar, Num(1), e2.desugar)
      case Nao(e) => If(e.desugar, Num(0), Num(1))
      case Var(s) => Var(s)
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Atrib(l, r) => Atrib(l.desugar, r.desugar)
      case Seq(e1, e2) => Seq(e1.desugar, e2.desugar)
      case Eq(e1, e2) => Eq(e1.desugar, e2.desugar)
      case While(e, c) => While(e.desugar, c.desugar)
      case Read() => Read()
      case Print(es) => Print(es.map(e => e.desugar))
      case Campo(n) => Campo(n)
      case Send(o, m, as) => Send(o.desugar, m, as.map(e => e.desugar))
      case New() => New()
      case Self() => Self()
      case Super() => Super()
      case Obj(nc, ms, proto) => Obj(nc, ms, proto)
    }
  }
  
  // Expressões aritméticas
  case class Num(v: Int) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Expressões ariméticas - Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais e controle
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class While(cond: Exp, corpo: Exp) extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  case class Campo(n: Int) extends Exp
  case class New() extends Exp
  case class Self() extends Exp
  case class Super() extends Exp
  case class Obj(ncampos: Int, metodos: Env[Metodo], proto: Option[Exp]) extends Exp
  case class Var(nome: String) extends Exp
  case class Send(obj: Exp, metodo: String, args: List[Exp]) extends Exp
  
  // Métodos
  case class Metodo(nome: String, params: List[String], corpo: Exp) {
    def apply(self: ObjV, sup: Option[ObjV], nargs: Int, larg1: Int): Acao[Valor] = {
      if (nargs != params.size) sys.error("erro de aridade em " + nome)
      else corpo.eval(params.zip(larg1.to(larg1+params.size-1)).toMap)(self, sup)
    }
  }
    
  case class Prog(corpo: Exp) {
    def eval: Acao[Valor] = for {
      v <- corpo.eval(Map())(ObjV(Vector(), Map(), None), None)
    } yield v
  }
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Atribuições e ponteiros
  case class Seq(e1: Exp, e2: Exp) extends Exp
  case class Atrib(lval: Exp, rval: Exp) extends Exp
  
  // Igualdade
  case class Eq(e1: Exp, e2: Exp) extends Exp

  // Entrada e Saída
  case class Read() extends Exp
  case class Print(es: List[Exp]) extends Exp
  
  def alocObj(ncampos: Int, metodos: Env[Metodo], proto: Option[ObjV]): Acao[Valor] = for {
    c1 <- bump(ncampos)
  } yield ObjV((c1 until c1 + ncampos).toVector, metodos, proto)
  
  def pushArgs(self: ObjV, sup: Option[ObjV], env: Env[End], args: List[Exp]): Acao[End] = args match {
    case h :: t => for {
      v <- h.eval(env)(self, sup)
      larg1 <- push(v)
      _ <- pushArgs(self, sup, env, t)
    } yield larg1     
    case List() => SP
  }
  
  def lookup(obj: ObjV, nome: String): Metodo = obj.metodos.get(nome) match {
    case Some(m) => m
    case None => obj.proto match {
      case Some(o) => lookup(o, nome)
      case None => sys.error("método " + nome + " não encontrado ")
    }
  }
  
  def popArgs(n: Int): Acao[End] = if (n > 0) for {
                                           _ <- pop
                                           l <- popArgs(n-1)
                                         } yield l
                              else SP
  
}

