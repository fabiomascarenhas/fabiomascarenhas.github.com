package fun

object interp {  
  // Valores
  trait Valor {
    def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Valor = this match {
      case FunV(envc, params, corpo) =>     
        if (params.size != args.size) 
          sys.error("erro de aridade em função anônima, esperado: " +
              params.size + ", passado: " + args.size)
        else
          corpo.eval(funs)(envc ++ envFuncao(funs, params, args, env))
      case _ => sys.error("não é uma função: " + this)
    }
  
    def force(funs: Map[String, Fun1]): Valor = this match {
      case Thunk(envc, corpo) =>
        corpo.eval(funs)(envc)
      case RecV(envc, nome, corpo) =>
        corpo.eval(funs)(envc + (nome -> RecV(envc, nome, corpo)))
      case v => v
    }    
  }
  case class NumV(v: Double) extends Valor
  case class Bool(v: Boolean) extends Valor
  case class FunV(env: Map[String, Valor], ps: List[String], c: Exp) extends Valor
  case class Thunk(env: Map[String, Valor], c: Exp) extends Valor
  case class RecV(env: Map[String, Valor], nome: String, c: Exp) extends Valor
  
  trait Exp {
    def eval(funs: Map[String, Fun1])(env: Map[String, Valor]): Valor = this match {
      case Num(v) => NumV(v)
      case True() => Bool(true)
      case False() => Bool(false)
      case Soma(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 + v2)
        case _ => sys.error("soma precisa de dois números")
      }
      case Mult(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 * v2)
        case _ => sys.error("mult precisa de dois números")
      }
      case Div(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => NumV(v1 / v2)
        case _ => sys.error("div precisa de dois números")
      }
      case Menor(e1, e2) => (e1.eval(funs)(env), e2.eval(funs)(env)) match {
        case (NumV(v1), NumV(v2)) => Bool(v1 < v2)
        case _ => sys.error("menor precisa de dois números")
      }
      case If(c, et, ee) => c.eval(funs)(env) match {
        case Bool(true) => et.eval(funs)(env)
        case Bool(false) => ee.eval(funs)(env)
        case _ => sys.error("condição do if deve ser booleano: " + c)
      }
      case Ap1(func, args) => 
        funs.get(func) match {
          case Some(f) => f.apply(funs, args, env)
          case None => sys.error("função " + func + " não existe ")
        }
      case Let(nome, exp, corpo) =>
          if (nome.charAt(0) == '_')
            corpo.eval(funs)(env + (nome -> Thunk(env, exp)))
          else 
            corpo.eval(funs)(env + (nome -> exp.eval(funs)(env)))
      case Var(nome) => env.get(nome) match {
        case Some(v) => v.force(funs)
        case None => sys.error("variável livre: " + nome)
      }
      case Fun(params, corpo) => FunV(env, params, corpo)
      case Ap(func, args) => func.eval(funs)(env).apply(funs, args, env)
      case Rec(n, e) => e.eval(funs)(env + (n -> RecV(env, n, Rec(n, e))))
    }
    
    def desugar: Exp = this match {
      case Num(v) => Num(v)
      case True() => True()
      case False() => False()
      case Soma(e1, e2) => Soma(e1.desugar, e2.desugar)
      case Mult(e1, e2) => Mult(e1.desugar, e2.desugar)
      case Div(e1, e2) => Div(e1.desugar, e2.desugar)
      case Sub(e1, e2) => Soma(e1.desugar, Mult(Num(-1), e2.desugar))
      case Menos(e) => Mult(Num(-1), e.desugar)
      case Menor(e1, e2) => Menor(e1.desugar, e2.desugar)
      case If(c, et, ee) => If(c.desugar, et.desugar, ee.desugar)
      case E(e1, e2) => If(e1.desugar, e2.desugar, False())
      case Ou(e1, e2) => If(e1.desugar, True(), e2.desugar)
      case Nao(e) => If(e.desugar, False(), True())
      case Var(s) => Var(s)
      case Ap1(n, as) => Ap1(n, as.map(e => e.desugar))
      case Let(n, e, c) => Let(n, e.desugar, c.desugar)
      case LetM(es, c) => es.foldRight[Exp](c.desugar)(
          (par, exp) => par match {
            case (n, e) => Let(n, e.desugar, exp)
          })
      case Ap(f, as) => Ap(f.desugar, as.map(e => e.desugar))
      case Fun(ps, c) => Fun(ps, c.desugar)
      case Rec(n, e) => Rec(n, e.desugar)
    }
    
    def fvs: Set[String] = this match {
      case Num(_) => Set()
      case True() => Set()
      case False() => Set()
      case Var(x) => Set(x)
      case Soma(e1, e2) => e1.fvs ++ e2.fvs
      case Mult(e1, e2) => e1.fvs ++ e2.fvs
      case Div(e1, e2) => e1.fvs ++ e2.fvs
      case Menor(e1, e2) => e1.fvs ++ e2.fvs
      case If(c, et, ee) => c.fvs ++ et.fvs ++ ee.fvs
      case Let(x, e, c) => e.fvs ++ (c.fvs - x)
      case Ap1(n, es) => es.foldRight[Set[String]](Set())(
        (e, s) => e.fvs ++ s)
      case Ap(f, es) => f.fvs ++ es.foldRight[Set[String]](Set())(
        (e, s) => e.fvs ++ s)
      case Fun(ps, c) => c.fvs -- ps
      case Rec(n, e) => e.fvs - n
    }

  }
  
  // Expressões aritméticas
  case class Num(v: Double) extends Exp
  case class Soma(e1: Exp, e2: Exp) extends Exp
  case class Mult(e1: Exp, e2: Exp) extends Exp
  case class Div(e1: Exp, e2: Exp) extends Exp

  // Açúcar sintático
  case class Sub(e1: Exp, e2: Exp) extends Exp
  case class Menos(e: Exp) extends Exp

  // Condicionais
  case class Menor(e1: Exp, e2: Exp) extends Exp
  case class If(cond: Exp, ethen: Exp, eelse: Exp) extends Exp
  case class True() extends Exp
  case class False() extends Exp
  
  // Operações Lógicas (açúcar sintático)
  case class E(e1: Exp, e2: Exp) extends Exp
  case class Ou(e1: Exp, e2: Exp) extends Exp
  case class Nao(e: Exp) extends Exp
  
  // Funções de primeira ordem
  case class Fun1(nome: String, params: List[String], corpo: Exp) {
    def apply(funs: Map[String, Fun1], args: List[Exp], env: Map[String, Valor]): Valor =
      if (params.size != args.size) 
        sys.error("erro de aridade em " + nome + ", esperado: " +
            params.size + ", passado: " + args.size)
      else
        corpo.eval(funs)(envFuncao(funs, params, args, env))
    def fvs: Set[String] = corpo.fvs -- params.toSet    
  }
    
  case class Prog(defs: Map[String, Fun1], corpo: Exp) {
    def eval: Valor = corpo.eval(defs)(Map())
    def fvs : Set[String] = defs.foldRight[Set[String]](Set())(
        { case ((_, e), s) => e.fvs ++ s }) ++ corpo.fvs
  }
  case class Var(nome: String) extends Exp
  case class Ap1(fun: String, args: List[Exp]) extends Exp
  
  // Let
  case class Let(nome: String, e: Exp, corpo: Exp) extends Exp

  // Açúcar - let múltiplo
  case class LetM(exps: List[(String, Exp)], corpo: Exp) extends Exp
  
  // Funções de primeira classe
  case class Ap(fun: Exp, args: List[Exp]) extends Exp
  case class Fun(params: List[String], corpo: Exp) extends Exp
  
  // Recursão local
  case class Rec(nome: String, exp: Exp) extends Exp
  
  // Listas
  case class Nil() extends Exp

  // Funções de utilidade
  def liftNumV(v1: Valor, v2: Valor, op: (Double, Double) => Double) = 
    (v1, v2) match {
      case (NumV(v1), NumV(v2)) => NumV(op(v1, v2))
      case _ => sys.error("operação precisa de dois números")
    }
  
  // Gera mapa de substituições para let e parâmetros
  def envFuncao(funs: Map[String, Fun1], oq: List[String], peloq: List[Exp], env: Map[String, Valor]):
      Map[String, Valor] =
    (for {
      (nome, exp) <- oq.zip(peloq).toMap
    } yield if (nome.charAt(0) == '_') (nome, Thunk(env, exp))
            else (nome, exp.eval(funs)(env)))
}

