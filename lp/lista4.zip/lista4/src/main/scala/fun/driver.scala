package fun

object driver extends App {
  println(parser.parseFile(args(0)).eval)
}
