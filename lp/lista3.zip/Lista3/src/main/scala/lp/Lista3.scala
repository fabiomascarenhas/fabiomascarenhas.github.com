package lp

object Lista3 extends App {
  // escreva testes de suas funções aqui
  println("Olá, Mundo!")
}
