
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    // Posição em "coordenadas de tela"
    public int x;
    public int y;
    // Cor
    public Cor cor = new Cor("azul");
    
    // Velocidade inicial de *todos* os aliens
    public static int vx = 800/4;
    
    /*
     * Construtor
     */ 
    public Alien(int x, int y) {
        // this é o objeto Alien que acabou
        // de ser criado
        this.y = y;
        this.x = x;
    }
}
