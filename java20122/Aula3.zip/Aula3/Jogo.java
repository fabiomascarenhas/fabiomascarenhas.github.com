
/**
 * Tabuleiro de Jogo
 */
public class Jogo
{
    // Jogadores
    public Canhao jogador1;
    public Canhao jogador2;
    
    // Alienígenas
    public Alien[] aliens;

    // Tiros
    public java.util.ArrayList<Tiro> tiros;
}
