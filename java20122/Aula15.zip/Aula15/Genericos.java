public class Genericos {
    public static void main(String[] args) {
        Lista l = new ListaCons(1, new ListaCons("foo", new ListaVazia()));
        String s = (String)l.elem(1);
        System.out.println(s);
        Enumerador<String> e = new Enumerador<String>() {
            String s = "";
            public String proximo() {
                s += "a";
                return s;
            }
            
            public boolean fim() {
                return false;
            }
        };
        String s1 = e.proximo();
        System.out.println(s1);
        String s2 = e.proximo();
        System.out.println(s2);
        String s3 = e.proximo();
        System.out.println(s3);
        Enumerador<Integer> ei = new Enumerador<Integer>() {
            int i = 1;
            public Integer proximo() {
                i *= 3;
                return i;
            }
            
            public boolean fim() {
                return false;
            }
        };
        int i1 = ei.proximo();
        System.out.println(i1);
        int i2 = ei.proximo();
        System.out.println(i2);
        int i3 = ei.proximo();
        System.out.println(i3);
    }
}