public interface EnumeradorString {
  String proximo();  // próximo elemento
  boolean fim();  // acabaram os elementos?
}
