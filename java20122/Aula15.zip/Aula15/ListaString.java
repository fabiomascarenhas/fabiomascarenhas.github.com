public interface ListaString {
  int quantos();     // quantos elementos a lista tem
  String elem(int i);   // element na posição i
  EnumeradorString enumerador(); // um enumerador para essa lista
}