
public class ListaConsString implements ListaString
{
    private String primeiro;
    private ListaString resto;
    
    public ListaConsString(String primeiro, ListaString resto)
    {
        this.primeiro = primeiro;
        this.resto = resto;
    }

    public int quantos() {
        return 1 + resto.quantos();
    }
    
    public String elem(int i) {
        if(i == 0)
            return primeiro;
        else
            return resto.elem(i - 1);
    }
    
    //public int soma() {
    //    return primeiro + resto.soma();
    //}
    
    public EnumeradorString enumerador() {
        return new EnumeradorString() {
            EnumeradorString enumResto;
            
            public String proximo() {
                if(enumResto == null) {
                    enumResto = resto.enumerador();
                    return primeiro;
                } else
                    return enumResto.proximo();
            }
            
            public boolean fim() {
                if(enumResto == null)
                    return false;
                else
                    return enumResto.fim();
            }
        };
    }
    
    //public int foldr(OpBin op, int z) {
    //    return op.op(primeiro, resto.foldr(op, z));
    //}
}
