
public interface Enumerador<TIPOELEM> {
  TIPOELEM proximo();  // próximo elemento
  boolean fim();  // acabaram os elementos?
}
