public class ListaVaziaString implements ListaString, EnumeradorString
{
    public ListaVaziaString() { }

    public int quantos() {
        return 0;
    }
    
    public String elem(int i) {
        throw new RuntimeException("lista vazia");
    }
    
    public EnumeradorString enumerador() {
        return this;
    }
    
    public String proximo() throws EnumeradorVazio {
        throw new EnumeradorVazio("lista vazia");
    }
    
    public boolean fim() {
        return true;
    }
    
}
