
public interface Lista {
  int quantos();     // quantos elementos a lista tem
  Object elem(int i);   // elemento na posição i
  Enumerador enumerador(); // um enumerador para essa lista
//  int foldr(OpBin op, int z);
}
