public class ListaPG implements Lista {
    private int a0;
    private int q;
    private int n;
    
    public ListaPG(int a0, int q, int n) {
        this.a0 = a0;
        this.q = q;
        this.n = n;
    }
    
    public int quantos() {
        return n;
    }
    
    public Object elem(int i) { return 0; }
    
    public int soma() {
        int soma = 0;
        int ai = a0;
        for(int i = 0; i < n; i++) {
            soma += ai;
            ai *= q;
        }
        return soma;
    }
    
    public Enumerador enumerador() {
        return new Enumerador() {
            private int i = 0;
            private int ai = a0;
            
            public boolean fim() {
                return i == n;
            }
            
            public Object proximo() {
                if(i == n) {
                    throw new EnumeradorVazio("final da PG");
                }
                int res = ai;
                i++; ai *= q;
                return res;
            }
        };
    }
    
    public int foldr(OpBin op, int z) {
        /*int ai = a0 * (int)Math.pow(q, n-1);
        int fold = z;
        for(int i = n; i > 0; i--) {
            fold = op.op(ai, fold);
            ai /= q;
        }
        return fold;*/
        return foldEnum(enumerador(), op, z);
    }
    
    private int foldEnum(Enumerador e, OpBin op, int z) {
        if(e.fim())
            return z;
        else {
            int a;
            try {
                a = (Integer)e.proximo();
            } catch(EnumeradorVazio ex) {
                a = z;
            }
            int b = foldEnum(e, op, z);
            return op.op(a, b);
        }
    }
    
}