
public class ListaCons implements Lista
{
    private Object primeiro;
    private Lista resto;
    
    public ListaCons(Object primeiro, Lista resto)
    {
        this.primeiro = primeiro;
        this.resto = resto;
    }

    public int quantos() {
        return 1 + resto.quantos();
    }
    
    public Object elem(int i) {
        if(i == 0)
            return primeiro;
        else
            return resto.elem(i - 1);
    }
    
    //public int soma() {
    //    return primeiro + resto.soma();
    //}
    
    public Enumerador<Object> enumerador() {
        return new Enumerador<Object>() {
            Enumerador enumResto;
            
            public Object proximo() {
                if(enumResto == null) {
                    enumResto = resto.enumerador();
                    return primeiro;
                } else
                    return enumResto.proximo();
            }
            
            public boolean fim() {
                if(enumResto == null)
                    return false;
                else
                    return enumResto.fim();
            }
        };
    }
    
    //public int foldr(OpBin op, int z) {
    //    return op.op(primeiro, resto.foldr(op, z));
    //}
}
