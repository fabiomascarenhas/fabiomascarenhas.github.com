public class ListaConcat implements Lista {
    private Lista lista1;
    private Lista lista2;
    
    public ListaConcat(Lista lista1, Lista lista2) {
        this.lista1 = lista1;
        this.lista2 = lista2;
    }
    
    public int quantos() {
        return lista1.quantos() + lista2.quantos();
    }
    
    public Object elem(int i) {
        if(i < lista1.quantos())
            return lista1.elem(i);
        else
            return lista2.elem(i - lista1.quantos());
    }
    
    //public int soma() {
    //    return lista1.soma() + lista2.soma();
    //}
    
    public Enumerador enumerador() {
        return new Enumerador() {
            private Enumerador en1 = lista1.enumerador();
            private Enumerador en2 = lista2.enumerador();
            
            public Object proximo() {
                if(en1.fim())
                    return en2.proximo();
                else
                    return en1.proximo();
            }
            
            public boolean fim() {
                return en1.fim() && en2.fim();
            }
        };
    }
    
    //public int foldr(OpBin op, int z) {
    //    return lista1.foldr(op, lista2.foldr(op, z));
    //}
}