// Coisas do lado esquerdo de atribuições
public interface Lvalue extends Expressao
{
    void atribui(double valor);
}
