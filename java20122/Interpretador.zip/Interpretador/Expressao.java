
public interface Expressao
{
    double valor();
}
