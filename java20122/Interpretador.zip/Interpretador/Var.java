
public class Var implements Lvalue
{
    private String nome;
    private double val;

    public Var(String nome)
    {
        this.nome = nome;
    }

    public double valor() {
        return val;
    }
    
    public void atribui(double val) {
        this.val = val;
    }
}
