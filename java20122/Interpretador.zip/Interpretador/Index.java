public class Index implements Lvalue
{
    private double[] vetor;
    private int indice;

    public Index(double[] vetor, int indice)
    {
        this.vetor = vetor;
        this.indice = indice;
    }

    public double valor() {
        return vetor[indice];
    }
    
    public void atribui(double valor) {
        vetor[indice] = valor;
    }
}
