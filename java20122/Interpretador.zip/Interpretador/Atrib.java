public class Atrib
{
    private Lvalue lvalue;
    private Expressao rvalue;

    public Atrib(Lvalue lvalue, Expressao rvalue)
    {
        this.lvalue = lvalue;
        this.rvalue = rvalue;
    }

    public void executa() {
        lvalue.atribui(rvalue.valor());
    }
}
