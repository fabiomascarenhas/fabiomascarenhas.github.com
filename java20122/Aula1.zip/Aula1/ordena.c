#include  <stdio.h>

int main (void)
{
	int vetor[5], i; 
	int trocou = 0;
	int fim = 5;
	int temp;

	printf("Entre com um vetor de %d elementos\n", 5);
	for (i = 0; i < 5; i++)
	{
		printf("Elemento %d ", i);
		scanf("%d", &vetor[i]);
	}

	do {
		trocou = 0;
		for (i=0; i < fim-1; i++)
		{
			if (vetor[i] > vetor[i+1])
			{
				temp = vetor[i];
				vetor[i] = vetor[i+1];
				vetor[i+1] = temp;
				trocou = 1;
			}
		}
		fim--;
	} while (trocou);

	for (i=0; i < 5; i++) printf("%d\n", vetor[i]);

	return 0;
}

