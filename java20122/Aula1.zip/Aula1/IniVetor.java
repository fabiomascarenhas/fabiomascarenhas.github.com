import java.util.Scanner;

public class IniVetor {
	public static Scanner in = new Scanner(System.in);
	
	public static void geraConjunto(double[] vetor, 
			double inicial) {
	    for (int i = 0 ; i < vetor.length; i++) {
	        vetor[i] = inicial;
	        inicial *= 2;
	    }
	}
	
	// public static = fun��o
	public static void main(String[] argv) {
		double[] vetor, vetor2;
		double num;
		int i;

	    System.out.println("Este programa gera um vetor de numeros inteiros.\n");
	    System.out.println("Entre com o tamanho. ");
	    vetor = new double[in.nextInt()];
	    vetor2 = vetor;
	    System.out.println("Entre com o numero inicial do conjunto. ");
	    num = in.nextDouble();
	    
	    /* Geracao do conjunto */
	    geraConjunto(vetor2, num);
	    
	    /* Impressao do conjunto */
	    for (i = 0; i < vetor.length; i++)
	        System.out.println("Elemento " + i
	        		+ ": " + vetor[i]);
	    
	    System.out.println(vetor.length == 5);
	}
}
