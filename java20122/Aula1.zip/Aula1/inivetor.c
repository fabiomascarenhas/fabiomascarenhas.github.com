#include <stdio.h>

void geraConjunto(double vetor[], int tamanho, double inicial) {
    for (int i = 0 ; i < tamanho; i++) {
        vetor[i] = inicial;
        inicial *= 2;
    }
}

int main(int argc, char *argv[])
{
    double vetor[5], num;
    int i;

    puts("Este programa gera um vetor de numeros inteiros.\n");
    puts("Entre com o numero inicial do conjunto. ");
    scanf("%lf", &num);

    /* Geracao do conjunto */
    geraConjunto(vetor, 5, num);
    
    /* Impressao do conjunto */
    for (i = 0; i < 5; i++)
        printf("Elemento %d = %lf\n", i, vetor[i]);

    return 0;
}

