
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    // Posição em "coordenadas de tela"
    public int x;
    public int y;
    
    public Alien(int x, int y) {
        // this é o objeto Alien que acabou
        // de ser criado
        this.x = x;
        this.y = y;
    }
}
