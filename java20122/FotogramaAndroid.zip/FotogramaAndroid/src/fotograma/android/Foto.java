package fotograma.android;

import java.util.Date;

import android.util.Base64;

import com.parse.ParseException;
import com.parse.ParseObject;

public class Foto {
	// Linha da tabela
	private ParseObject dados;
	
	// Calculado a partir do campo conteudo
	private byte[] conteudo;
	
	public Foto(ParseObject foto) {
		this.dados = foto;
		this.conteudo = Base64.decode(foto.getString("conteudo"), Base64.DEFAULT); 
	}
	
	public Foto(String autor, String titulo, byte[] conteudo) throws ParseException {
		dados = new ParseObject("Foto");
		dados.put("autor", autor);
		dados.put("titulo", titulo);
		dados.put("conteudo", Base64.encodeToString(conteudo, Base64.DEFAULT));
		this.conteudo = conteudo;
		dados.save();
	}
	
	public String getId() {
		return dados.getObjectId();
	}
	
	public String getTitulo() {
		return dados.getString("titulo");
	}

	public String getAutor() {
		return dados.getString("autor");
	}
	
	public Date getData() {
		return dados.getCreatedAt();
	}
	
	public byte[] getConteudo() {
		return this.conteudo;
	}
						
	public String toString() {
		return getTitulo() + ": " + dados.getString("conteudo");
	}
}
