package fotograma.android;

import java.util.List;

public interface ObservadorPessoa {
	void novaLinhaTempo(List<Foto> linhaTempo);
	void novaFoto(Foto f);
	void novoNSeg(int nseg);
}