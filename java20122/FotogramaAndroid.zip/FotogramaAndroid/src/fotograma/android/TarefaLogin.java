package fotograma.android;

import com.parse.ParseException;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.Toast;

public class TarefaLogin extends AsyncTask<String, Void, Pessoa> {
	private FotogramaActivity app;
	private ProgressDialog aviso;
	private Exception erro;
	private String nome;
	private String senha;
	
	TarefaLogin(FotogramaActivity app) {
		this.app = app;
	}
	
	@Override
	protected void onPreExecute() {
	    aviso = ProgressDialog.show(app, "Login", "Aguarde...", true);
	}
	
	@Override
	protected Pessoa doInBackground(String... args) {
		nome = args[0];
		senha = args[1];
		try {
			return new Pessoa(nome, senha);
		} catch(Exception e) {
			e.printStackTrace();
			erro = e;
			return null;
		}
	}

	@Override
	protected void onPostExecute(Pessoa p) {
		aviso.dismiss();
		if(erro != null) {
			try {
				throw erro;
			} catch(SenhaErrada se) {
				Toast.makeText(app, "Senha errada", Toast.LENGTH_LONG).show();
			} catch(PessoaNaoEncontrada pne) {
				app.criaPessoa(nome, senha);
				return;
			} catch(ParseException pe) {
				Toast.makeText(app, "Erro de comunica��o: " + pe.getMessage(), Toast.LENGTH_LONG).show();
			} catch(Exception e) {
				Toast.makeText(app, "Erro de comunica��o: " + e.getMessage(), Toast.LENGTH_LONG).show();
			}
			app.showLogin();
		} else {
			app.init(p);
		}
	}
}