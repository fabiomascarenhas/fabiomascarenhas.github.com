package fotograma.android;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.parse.ParseException;

public class TarefaSeguir extends AsyncTask<String, Void, Void> {
	private Context ctx;
	private Pessoa pessoa;
	private LinhaTempoAdapter lta;
	private ProgressDialog aviso;
	private Exception erro;
	private String nome;

	public TarefaSeguir(Context ctx, Pessoa pessoa, LinhaTempoAdapter lta) {
		this.ctx = ctx;
		this.pessoa = pessoa;
		this.lta = lta;
	}

	@Override
	protected void onPreExecute() {
	    aviso = ProgressDialog.show(ctx, "Seguir", "Aguarde...", true);
	}

	@Override
	protected Void doInBackground(String... params) {
		nome = params[0];
		try {
			pessoa.seguir(nome);
		} catch(Exception e) {
			erro = e;
		}
		return null;
	}

	@Override
	protected void onPostExecute(Void v) {
		aviso.dismiss();
		if(erro != null) {
			if(erro instanceof PessoaNaoEncontrada) {
				Toast.makeText(ctx, "Usu�rio n�o encontrado", Toast.LENGTH_LONG).show();
			} else if(erro instanceof ParseException) {
				Toast.makeText(ctx, "Erro de comunica��o: " + erro.getMessage(), Toast.LENGTH_LONG).show();
			}
		} else {
			Toast.makeText(ctx, "Voc� est� seguindo " + nome, Toast.LENGTH_LONG).show();
			lta.notifyDataSetChanged();
		}
	}

}