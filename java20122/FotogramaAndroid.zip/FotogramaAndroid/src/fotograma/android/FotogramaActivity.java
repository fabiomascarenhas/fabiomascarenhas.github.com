package fotograma.android;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.parse.Parse;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class FotogramaActivity extends Activity {

	private Pessoa pessoa;
	private LinhaTempoAdapter lta;
	private Handler handler;
	private File foto;
	private String senha;
			
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Parse.initialize(this, DadosAcessoBD.APP_KEY, DadosAcessoBD.API_KEY);
		handler = new Handler();
		if(savedInstanceState != null &&
				savedInstanceState.containsKey("nome")) {
			login(savedInstanceState.getString("nome"),
					savedInstanceState.getString("senha"));
		} else {
			showLogin();
		}
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
		state.putString("nome", pessoa.getNome());
		state.putString("senha", senha);
	}
    
    public void showLogin() {
		final Dialog janela = new Dialog(this);
		janela.requestWindowFeature(Window.FEATURE_NO_TITLE);
		janela.setContentView(R.layout.login);
		Button entrar = (Button)janela.findViewById(R.id.botEntrar);
		entrar.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				String nome = ((EditText)janela.findViewById(R.id.txtNome)).getText().toString();
			    String senha = ((EditText)janela.findViewById(R.id.txtSenha)).getText().toString();
				janela.dismiss();
				login(nome, senha);
			}
		});
		janela.show();
    }
    
    private void login(String nome, String senha) {
    		this.senha = senha;
    		new TarefaLogin(this).execute(nome, senha);
    }

    private void showSeguir() {
		AlertDialog.Builder seguir = new AlertDialog.Builder(this);
		seguir.setTitle("Seguir pessoa");
		final String[] nomes = pessoa.getNaoSeguidos().toArray(new String[] {});
		seguir.setItems(nomes, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				String nome = nomes[which];
				seguir(nome);
			}
		});
		seguir.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
			}
		});
		seguir.create().show();
    }
    
    private void seguir(String nome) {
		new TarefaSeguir(this, pessoa, lta).execute(nome);
    }

    private File criaArquivo() throws IOException {
	    String timeStamp = 
	        new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	    String imageFileName = "Fotograma_" + timeStamp;
	    File imageDir = new File(
	    		Environment.getExternalStoragePublicDirectory(
	    				Environment.DIRECTORY_PICTURES
            ), "Fotograma");
	    imageDir.mkdirs();
	    File image = File.createTempFile(
	        imageFileName, 
	        ".jpg", 
	        imageDir
	    );
	    return image;		
	}

	private void tiraFoto() {
		try {
			this.foto = criaArquivo();
			Intent takePictureIntent = 
					new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, 
					Uri.fromFile(foto));
			this.startActivityForResult(takePictureIntent, 1);
		} catch (IOException e) {
			Toast.makeText(this, "Foto n�o criada: " + e.getMessage(), Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		System.out.println("resultado: " + resultCode);
		System.out.println("req: " + requestCode);
		if(requestCode == 1 && resultCode == -1)
			showEditaFoto("");
		if(requestCode == 2 && resultCode == -1)
			new TarefaPublicar(this, lta, pessoa, 
					data.getStringExtra("titulo"),
					data.getByteArrayExtra("conteudo")).execute();
	}

    public void showEditaFoto(String titulo) {
    		Intent req = new Intent(this, EditaFoto.class);
    		req.putExtra("foto", foto.getAbsolutePath());
    		req.putExtra("titulo", titulo);
    		this.startActivityForResult(req, 2);
    }

    public void init(Pessoa p) {
    		pessoa = p;
		lta = new LinhaTempoAdapter(pessoa.getLinhaTempo());
        this.pessoa.observar(lta);
        ListView lista = (ListView)this.findViewById(R.id.linhaTempo);
        lista.setAdapter(lta);
        Button publica = (Button)findViewById(R.id.botPublicar);
        publica.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				tiraFoto();
			}
        });
        Button seguir = (Button)findViewById(R.id.botSeguir);
        seguir.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				showSeguir();
			}
        });
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				new TarefaAtualiza(lta).execute(pessoa);
				long agora = SystemClock.uptimeMillis();
				handler.postAtTime(this, agora + 30000);
			}
		}, 30000);
    }

    void novoUsuario(String nome, String senha) {
		new TarefaNovo(this).execute(nome, senha);
    }
    
	public void criaPessoa(final String nome, final String senha) {
		AlertDialog.Builder pergunta = new AlertDialog.Builder(this);
		pergunta.setTitle("Novo usu�rio");
		pergunta.setMessage("Usu�rio " + nome + " n�o existe. Criar?");
		pergunta.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				novoUsuario(nome, senha);
			}
		});
		pergunta.setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				showLogin();
			}
		});
		pergunta.create().show();
	}
}