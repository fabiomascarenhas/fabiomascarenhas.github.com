package fotograma.android;

import java.io.FileReader;

import com.parse.ParseException;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.Toast;

public class TarefaPublicar extends AsyncTask<Void, Void, Void> {
	private FotogramaActivity app;
	private LinhaTempoAdapter lta;
	private Pessoa pessoa;
	private String titulo;
	private byte[] conteudo;
	private ProgressDialog aviso;
	private ParseException erro;

	public TarefaPublicar(FotogramaActivity app, LinhaTempoAdapter lta,
			Pessoa pessoa, String titulo, byte[] conteudo) {
		this.app = app;
		this.pessoa = pessoa;
		this.lta = lta;
		this.titulo = titulo;
		this.conteudo = conteudo;
	}

	@Override
	protected void onPreExecute() {
	    aviso = ProgressDialog.show(app, "Publicar", "Aguarde...", true);
	}

	@Override
	protected Void doInBackground(Void... args) {
		FileReader fr;
		try {
			pessoa.publicar(titulo, conteudo);
		} catch(ParseException pe) {
			erro = pe;
		}
		return null;
	}

	@Override
	protected void onPostExecute(Void v) {
		aviso.dismiss();
		if(erro != null) {
			Toast.makeText(app, "Erro de comunica��o: " + erro.getMessage(), Toast.LENGTH_LONG).show();
			app.showEditaFoto(titulo);
		} else
			lta.notifyDataSetChanged();
	}
	
}
