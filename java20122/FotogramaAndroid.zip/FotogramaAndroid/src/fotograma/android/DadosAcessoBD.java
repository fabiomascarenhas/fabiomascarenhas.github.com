package fotograma.android;

public class DadosAcessoBD {
	public static String SAL = "7e387tgeiugofkjbakbjg";
	public static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	public static String API_KEY = "j1NgkHcxTIoSlXmcOyWkp91BySLij3FzLtFWctoP";
}
