package fotograma.android;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.codec.digest.DigestUtils;

public class Pessoa {
	// Armazenados no banco de dados
	private ParseObject dados;
	
	// Calculados
	private List<Foto> linhaTempo;
	private Set<String> seguidos;
	private Set<String> naoSeguidos;
	
	private Set<ObservadorPessoa> observadores =
			new HashSet<ObservadorPessoa>();

	// Faz login e busca os dados da pessoa
	public Pessoa(String nome, String senha) throws ParseException {
		ParseQuery busca = new ParseQuery("Pessoa");
		busca.whereEqualTo("nome", nome);
		List<ParseObject> pessoa = busca.find();
		if(pessoa.isEmpty())
			throw new PessoaNaoEncontrada(nome);
		if(pessoa.get(0).getString("senha").equals(
				DigestUtils.shaHex(DadosAcessoBD.SAL + senha))) {
			this.dados = pessoa.get(0);
			this.buscaSeguidos();
			this.buscaNaoSeguidos();
			this.buscaLinhaTempo();
		} else	
			throw new SenhaErrada(nome);
	}
	
	public Pessoa(ParseObject dados) throws ParseException {
		this.dados = dados;
		this.buscaSeguidos();
		this.buscaNaoSeguidos();
		this.buscaLinhaTempo();
	}

	// Pessoa.cria("usuario", "senha") ao inv�s de new Pessoa("usuario", "senha")
	public static Pessoa cria(String nome, String senha) throws ParseException {
		ParseObject dados = new ParseObject("Pessoa");
		dados.put("nome", nome);
		dados.put("senha", DigestUtils.shaHex(DadosAcessoBD.SAL + senha));
		dados.put("nseg", 0);
		dados.save();
		ParseObject autoseguir = new ParseObject("Seguidor");
		autoseguir.put("seguidor", nome);
		autoseguir.put("seguido", nome);
		autoseguir.save();
		return new Pessoa(dados);
	}
	
	public void buscaNaoSeguidos() throws ParseException {
		ParseQuery qry = new ParseQuery("Pessoa");
		Set<String> nomes = new HashSet<String>();
		qry.addAscendingOrder("nome");
		qry.whereNotContainedIn("nome", seguidos);
		List<ParseObject> objs = qry.find();
		for(ParseObject obj: objs)
			nomes.add(obj.getString("nome"));
		naoSeguidos = nomes;
	}
	
	public void observar(ObservadorPessoa op) {
		this.observadores.add(op);
	}
	
	public void esquecer(ObservadorPessoa op) {
		this.observadores.remove(op);
	}
		
	public String getNome() {
		return dados.getString("nome");
	}
	
	public int getNSeg() {
		return dados.getInt("nseg");
	}
		
	public List<Foto> getLinhaTempo() {
		return this.linhaTempo;
	}
	
	public Set<String> getNaoSeguidos() {
		return this.naoSeguidos;
	}
	
	public Set<String> getSeguidos() {
		return this.seguidos;
	}
		
	private void buscaLinhaTempo() throws ParseException {
		ParseQuery qry = new ParseQuery("Foto");
		qry.whereContainedIn("autor", seguidos);
		qry.addDescendingOrder("createdAt");
		List<ParseObject> fotos = qry.find();
		linhaTempo = new ArrayList<Foto>();
		for(ParseObject foto : fotos) {
			linhaTempo.add(new Foto(foto));
		}
		for(ObservadorPessoa op : this.observadores) {
			op.novaLinhaTempo(linhaTempo);
		}
	}

	private void buscaSeguidos() throws ParseException {
		ParseQuery qry = new ParseQuery("Seguidor");
		qry.whereEqualTo("seguidor", getNome());
		List<ParseObject> poSeguidos = qry.find();
		seguidos = new HashSet<String>();
		for(ParseObject po : poSeguidos) {
			seguidos.add(po.getString("seguido"));
		}
	}
	
	public void seguir(String nome) throws ParseException {
		if(seguidos.contains(nome))
			return;
		// Atualiza nseg do seguido
		ParseQuery qrySeguido = new ParseQuery("Pessoa");
		qrySeguido.whereEqualTo("nome", nome);
		List<ParseObject> seguido = qrySeguido.find();
		if(seguido.isEmpty())
			throw new PessoaNaoEncontrada(nome);
		seguido.get(0).put("nseg", seguido.get(0).getInt("nseg") + 1);
		seguido.get(0).save();
		// Cria nova liga��o com seguidor
		ParseObject rel = new ParseObject("Seguidor");
		rel.put("seguidor", getNome());
		rel.put("seguido", nome);
		rel.save();
		// Atualiza linha do tempo
		this.seguidos.add(nome);
		this.naoSeguidos.remove(nome);
		this.buscaLinhaTempo();
	}
		
	public void atualiza() throws ParseException {
		if(!this.linhaTempo.isEmpty()) {
			Date recente = this.linhaTempo.get(0).getData();
			ParseQuery qry = new ParseQuery("Foto");
			qry.whereContainedIn("autor", seguidos);
			qry.whereGreaterThan("createdAt", recente);
			qry.addAscendingOrder("createdAt");
			List<ParseObject> fotos = qry.find();
			for(ParseObject foto : fotos) {
				Foto f = new Foto(foto);
				linhaTempo.add(0, f);
				for(ObservadorPessoa op : this.observadores)
					op.novaFoto(f);
			}
		} else {
			this.buscaLinhaTempo();
		}
		// Atualiza n�mero de seguidores
		ParseQuery qry = new ParseQuery("Pessoa");
		ParseObject po = qry.get(dados.getObjectId());
		if(getNSeg() != po.getInt("nseg")) {
			dados = po;
			for(ObservadorPessoa op : this.observadores) {
				op.novoNSeg(getNSeg());
			}
		}
	}
	
	public void publicar(String titulo, byte[] conteudo) throws ParseException {
		Foto f = new Foto(getNome(), titulo, conteudo);
		linhaTempo.add(0, f);
		for(ObservadorPessoa op : this.observadores)
			op.novaFoto(f);
	}
	
	public String toString() {
		String s = getNome() + " (" + getNSeg() + ")";
		for(Foto f : this.linhaTempo) {
			s += "\n" + f;
		}
		return s;
	}
}
