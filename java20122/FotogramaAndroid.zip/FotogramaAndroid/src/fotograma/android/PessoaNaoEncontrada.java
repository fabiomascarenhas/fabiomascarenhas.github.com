package fotograma.android;

public class PessoaNaoEncontrada extends RuntimeException {
	private static final long serialVersionUID = 3041660508593297389L;

	private String nome;
	
	public PessoaNaoEncontrada(String nome) {
		super("login " + nome + " n�o encontrado");
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
}