package fotograma.android;

import com.parse.ParseException;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.Toast;

public class TarefaNovo extends AsyncTask<String, Void, Pessoa> {
	private FotogramaActivity app;
	private ProgressDialog aviso;
	private ParseException erro;
	
	TarefaNovo(FotogramaActivity app) {
		this.app = app;
	}
	
	@Override
	protected void onPreExecute() {
	    aviso = ProgressDialog.show(app, "Login", "Aguarde...", true);
	}

	@Override
	protected Pessoa doInBackground(String... args) {
		String nome = args[0];
		String senha = args[1];
		try {
			return Pessoa.cria(nome, senha);
		} catch(ParseException e) {
			e.printStackTrace();
			erro = e;
			return null;
		}
	}
	
	@Override
	protected void onPostExecute(Pessoa p) {
		aviso.dismiss();
		if(erro != null) {
			Toast.makeText(app, "Erro de comunica��o: " + erro.getMessage(), Toast.LENGTH_LONG).show();
			app.showLogin();
		} else {
			app.init(p);
		}
	}
	
}
