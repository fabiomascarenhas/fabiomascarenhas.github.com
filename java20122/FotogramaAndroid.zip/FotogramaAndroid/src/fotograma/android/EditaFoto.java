package fotograma.android;

import java.io.ByteArrayOutputStream;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class EditaFoto extends Activity {
	private byte[] conteudo;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edita_foto);
		String foto = this.getIntent().getStringExtra("foto");
		ImageView labFoto = (ImageView)findViewById(R.id.labFoto);
	    final EditText titulo = (EditText)findViewById(R.id.txtTitulo);
		Bitmap bm;
		if(savedInstanceState != null &&
				savedInstanceState.containsKey("titulo")) {
			conteudo = savedInstanceState.getByteArray("conteudo");
			bm = BitmapFactory.decodeByteArray(conteudo, 0, conteudo.length);
			titulo.setText(savedInstanceState.getString("titulo"));
		} else {
			bm = BitmapFactory.decodeFile(foto);
			double factor = 300.0 / bm.getWidth();
			bm = Bitmap.createScaledBitmap(bm, (int)(bm.getWidth() * factor), 
					(int)(bm.getHeight() * factor), false);
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			bm.compress(CompressFormat.JPEG, 25, bytes);
			conteudo = bytes.toByteArray();
		}
	    labFoto.setImageBitmap(bm);
	    Button publicar = (Button)findViewById(R.id.botOkPublicar);
		publicar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent res = new Intent();
				res.putExtra("titulo",titulo.getText().toString());
				res.putExtra("conteudo", conteudo);
				setResult(-1, res);
				finish();
			}
		});
	    Button cancelar = (Button)findViewById(R.id.botCancelPublicar);
		cancelar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				setResult(0);
				finish();
			}
		});
	}
	
    @Override
    protected void onSaveInstanceState(Bundle state) {
	    EditText titulo = (EditText)findViewById(R.id.txtTitulo);
		state.putString("titulo", titulo.getText().toString());
    		state.putByteArray("conteudo", conteudo);
	}
	
}
