package fotograma.android;

class SenhaErrada extends RuntimeException {
	private static final long serialVersionUID = 3958640259502323381L;

	private String nome;
	
	public SenhaErrada(String nome) {
		super("senha inv�lida para login " + nome);
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
}