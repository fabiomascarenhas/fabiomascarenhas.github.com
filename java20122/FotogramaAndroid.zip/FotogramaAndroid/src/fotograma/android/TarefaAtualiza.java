package fotograma.android;

import android.os.AsyncTask;

import com.parse.ParseException;

public class TarefaAtualiza extends AsyncTask<Pessoa, Void, Void> {
	private LinhaTempoAdapter lta;
	
	public TarefaAtualiza(LinhaTempoAdapter lta) {
		this.lta = lta;
	}
	
	@Override
	protected Void doInBackground(Pessoa... params) {
		try {
			params[0].atualiza();
		} catch(ParseException pe) {
			// espera pr�ximo tique
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(Void v) {
		lta.notifyDataSetChanged();
	}
}
