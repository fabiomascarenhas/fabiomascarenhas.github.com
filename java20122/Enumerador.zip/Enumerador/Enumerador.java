public interface Enumerador {
      int proximo();
      boolean fim();
}