public class SeqRandom implements Enumerador
{
    private int limite;
    private int terminador;
    private boolean terminou;

    public SeqRandom(int limite, int terminador)
    {
        this.limite = limite;
        this.terminador = terminador;
        this.terminou = false;
    }

    public int proximo() {
        if(!terminou) {
            int prox = (int)(Math.random() * (limite + 1));
            if(prox == terminador)
                terminou = true;
            return prox;
        }
        return -1;
    }

    public boolean fim() {
        return terminou;
    }
}
