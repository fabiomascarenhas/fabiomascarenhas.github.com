import java.util.List;
import java.util.ArrayList;

public class EnumVetor implements Enumerador
{
    private int[] vetor;
    private int pos;
    
    public EnumVetor(int[] vetor) {
        this.vetor = vetor;
        this.pos = 0;
    }
    
    public int proximo() {
        int prox = vetor[pos];
        pos = pos + 1;
        return prox;
    }
    
    public boolean fim() {
        return pos == vetor.length;
    }
    
    public static List<Integer> listaDeEnum(Enumerador e) { 
        List<Integer> l = new ArrayList<Integer>();
        while(!e.fim()) {
            l.add(e.proximo());
        }
        return l;
    }

    public static void main(String[] args) {
        Enumerador e = new EnumVetor(new int[] { 1, 3, 5 });
        System.out.println(e.proximo()); // imprime 1
        System.out.println(e.fim()); // imprime false
        System.out.println(e.proximo()); // imprime 2
        System.out.println(e.proximo()); // imprime 3
        System.out.println(e.fim()); // imprime true    
        System.out.println(listaDeEnum(new SeqRandom(30,5)));
    }
}
