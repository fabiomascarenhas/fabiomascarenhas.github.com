import java.util.Set;

public interface Jogo {
    String getTitulo();
    int getAltura();
    int getLargura();
    void tecla(String tecla);
    void tique(Set<String> teclas, double dt);
    void desenhar(Tela tela);
}