import java.awt.Rectangle;

public class Retangulo extends FiguraCoord
{
    private int largura;
    private int altura;
    private Cor cor;
    
    public Retangulo(double x, double y, int largura,
        int altura, Cor cor) {
            super(x, y);
            this.largura = largura;
            this.altura = altura;
            this.cor = cor;
    }
  
    public void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
           
    public Rectangle getCaixa() {
        return new Rectangle(
            (int)Math.round(x), 
            (int)Math.round(y), 
            (int)Math.round(largura),
            (int)Math.round(altura));
    }
    
}
