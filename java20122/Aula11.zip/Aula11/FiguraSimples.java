import java.awt.Rectangle;

public abstract class FiguraSimples implements Figura
{
    public boolean cantoEsquerdo() {
        Rectangle c = this.getCaixa();
        return c.x <= 0;
    }
    
    public boolean cantoSuperior() {
        Rectangle c = this.getCaixa();
        return c.y <= 0;
    }
    
    public boolean cantoDireito(int largura) {
        Rectangle c = this.getCaixa();
        return c.x + c.width >= largura;
    }
    
    public boolean cantoInferior(int altura) {
        Rectangle c = this.getCaixa();
        return c.y + c.height >= altura;
    }
    
    public boolean colidiu(Figura f) {
        Rectangle c = f.getCaixa();
        return c.intersects(this.getCaixa());
    }
     
}
