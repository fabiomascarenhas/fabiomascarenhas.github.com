import java.awt.Rectangle;

// abstract impede que se criem instâncias de FiguraCoord
public abstract class FiguraCoord extends FiguraSimples
{
    protected double x;
    protected double y;

    public FiguraCoord(double x, double y)
    {
        this.x = x;
        this.y = y;
    }

    public void mover(double dx, double dy) {
        x += dx;
        y += dy;
    }
    
}
