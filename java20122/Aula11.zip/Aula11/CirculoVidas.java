
public class CirculoVidas extends Circulo
{
    private int vidas;
    
    public CirculoVidas(double cx, double cy, int raio, int vidas, 
        Cor cor)
    {
        super(cx, cy, raio, cor);
        this.vidas = vidas;
    }
    
    public boolean colidiu(Figura f) {
         if(super.colidiu(f)) {
             vidas--;
             cor.r = 255 - cor.r;
             cor.g = 255 - cor.g;
             cor.b = 255 - cor.b;
         }
         if(vidas == 0) return true; else return false;
    }
}
