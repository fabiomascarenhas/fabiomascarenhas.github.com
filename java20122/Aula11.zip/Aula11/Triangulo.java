import java.awt.Rectangle;

public class Triangulo extends FiguraSimples
{
    private double x1;
    private double y1;
    private double x2;
    private double y2;
    private double x3;
    private double y3;
    private Cor cor;

    public Triangulo(double x1, double y1, double x2,
            double y2, double x3, double y3, Cor cor)
    {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.x3 = x3;
        this.y3 = y3;
        this.cor = cor;
    }

    public void mover(double dx, double dy) {
        x1 += dx; x2 += dx; x3 += dx;
        y1 += dy; y2 += dy; y3 += dy;
    }
    
    public void desenhar(Tela t) {
        t.triangulo(x1, y1, x2, y2, x3, y3, cor);
    }
       
    public Rectangle getCaixa() {
        double minX = Math.min(Math.min(x1, x2), x3);
        double minY = Math.min(Math.min(y1, y2), y3);
        double maxX = Math.max(Math.max(x1, x2), x3);
        double maxY = Math.max(Math.max(y1, y2), y3);
        return new Rectangle(
            (int)Math.round(minX),
            (int)Math.round(minY),
            (int)Math.round(maxX - minX),
            (int)Math.round(maxY - minY)
        );
    }
}
