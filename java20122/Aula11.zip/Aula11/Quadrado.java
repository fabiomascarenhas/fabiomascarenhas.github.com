import java.awt.Rectangle;

public class Quadrado extends FiguraCoord
{
    private int lado;
    private Cor cor;
    
    public Quadrado(double x, double y, int lado, Cor cor) {
        super(x, y);
        this.lado = lado;
        this.cor = cor;
    }
    
    public void desenhar(Tela t) {
        t.quadrado(x, y, lado, cor);
    }
        
    public Rectangle getCaixa() {
        return new Rectangle(
            (int)Math.round(x), 
            (int)Math.round(y), 
            (int)Math.round(lado),
            (int)Math.round(lado));
    }
}
