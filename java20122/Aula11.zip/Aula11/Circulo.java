import java.awt.Rectangle;

public class Circulo extends FiguraCoord
{
    private int raio;
    protected Cor cor;
    
    public Circulo(double cx, double cy, int raio, Cor cor) {
        super(cx - raio, cy - raio);
        this.raio = raio;
        this.cor = cor;
    }
        
    public void desenhar(Tela t) {
        t.circulo(x + raio, y + raio, raio, cor);
    }
    
    public Rectangle getCaixa() {
        return new Rectangle(
            (int)Math.round(x), 
            (int)Math.round(y), 
            (int)Math.round(raio * 2),
            (int)Math.round(raio * 2));
    }
}
