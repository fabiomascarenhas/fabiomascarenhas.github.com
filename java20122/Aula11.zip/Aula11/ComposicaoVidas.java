
public class ComposicaoVidas extends Composicao
{
    private int vidas;
    
    public ComposicaoVidas(Figura ... partes) {
        // chama o construtor de Composicao
        // tem que ser a primeira linha do construtor
        super(partes);
        vidas = partes.length;
    }
    
    public boolean colidiu(Figura f1) {
        for(int i = 0; i < partes.length; i++) {
            if(partes[i].colidiu(f1)) {
                vidas--;
                partes[i] = new FiguraVazia();
                if(vidas == 0) return true; else return false;
            }
        }
        return false;
    }
}
