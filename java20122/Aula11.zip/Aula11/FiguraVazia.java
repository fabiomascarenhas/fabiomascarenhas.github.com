import java.awt.Rectangle;

public class FiguraVazia implements Figura
{
    public FiguraVazia()
    {
    }

    public void desenhar(Tela t) { }
    
    public void mover(double dx, double dy) { }
    
    public boolean cantoEsquerdo() { return false; }
    
    public boolean cantoSuperior() { return false; }
    
    public boolean cantoDireito(int largura) { return false; }
    
    public boolean cantoInferior(int altura) { return false; }
    
    public boolean colidiu(Figura f) { return false; }
    
    public Rectangle getCaixa() {
        return null;
    }
}
