
/**
 * Tiro do canhão
 */
public class Tiro
{
    // Coordenas de tela
    public double x;
    public double y;
    // De onde esse tiro saiu
    public Canhao origem;
    // Cor
    public Cor cor = new Cor("branco");
    
    // Velocidade de *todos* os tiros
    public static int vy = 600/3;
    
    public Tiro(Canhao origem) {
        this.x = origem.x;
        this.y = origem.y;
        this.origem = origem;
    }
}
