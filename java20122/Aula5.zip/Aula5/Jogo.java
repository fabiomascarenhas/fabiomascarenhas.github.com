// java.util é o *pacote*
// ArrayList é a classe
import java.util.ArrayList;
import java.util.HashSet;
import java.awt.event.KeyEvent;

/**
 * Tabuleiro de Jogo
 */
public class Jogo
{
    // Jogadores
    public Canhao jogador1;
    public Canhao jogador2;
    
    // Alienígenas
    public Alien[] aliens;

    // Tiros
    public ArrayList<Tiro> tiros;
    
    // Tamanho da tela
    public static int LARGURA = 800;
    public static int ALTURA = 600;
    public static String TITULO = "Space Invaders";
    
    public Jogo() {
        this.jogador1 = new Canhao(LARGURA/3, new Cor("vermelho"));
        this.jogador2 = new Canhao(2*LARGURA/3, new Cor("azul"));
        this.tiros = new ArrayList<Tiro>();
        this.aliens = new Alien[40];
        int x0 = 100; // Posição dos aliens da primeira coluna
        int y0 = 100; // Posição dos aliens da primeira linha
        int dx = 50;  // Distância entre colunas
        int dy = 50;  // Distância entre linhas
        for(int i = 0; i < 4; i++) {
            for(int j = 0; j < 10; j++) {
                aliens[i*10+j] = new Alien(
                    x0 + j * dx,
                    y0 + i * dy,
                    new Cor(
                        (int)(Math.random() * 255),
                        (int)(Math.random() * 255),
                        (int)(Math.random() * 255)
                   )
                );
            }
        }
    }

    public void desenhar(Tela tela) {
        jogador1.desenhar(tela);
        jogador2.desenhar(tela);
        for(Alien alien: aliens) {
            alien.desenhar(tela);
        }
    }
    
    boolean sync = true;
    
    public void tique(HashSet<Integer> teclas, double dt) {
        if(teclas.contains(KeyEvent.VK_A))
            jogador1.mover(-1, dt);
        if(teclas.contains(KeyEvent.VK_S))
            jogador1.mover(1, dt);
        if(teclas.contains(KeyEvent.VK_COMMA))
            jogador2.mover(-1, dt);
        if(teclas.contains(KeyEvent.VK_PERIOD))
            jogador2.mover(1, dt);
        boolean bateu = false;
        for(Alien alien: aliens) {
            // Cuidado com o curto circuito!!!
            bateu = alien.mover(dt) || bateu;
        }
        if(bateu) Alien.vx = -Alien.vx;
    }

    public static void main(String[] args) {
        Motor motor = new Motor(new Jogo());
    }
}

