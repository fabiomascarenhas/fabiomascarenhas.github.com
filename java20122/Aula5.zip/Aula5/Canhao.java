
/**
 * Canhão do jogo
 */
public class Canhao
{
    // Posição em coordenadas de tela
    public double x;
    public double y = 600;
    // Pontos desse jogador
    public int score;
    // Cor
    public Cor cor;

    // Velocidade
    public static double vx = 800/4;
    public static int tamanho = 40;

    public Canhao(double x, Cor cor) {
        this.x = x;
        this.cor = cor;
    }
    
    public Canhao(double x, double y, int score, Cor cor) {
        this.x = x;
        this.y = y;
        this.score = score;
        this.cor = cor;
    }
    
    /*
     * direcao: -1 (esquerda), 0 (parado), 1 (direita)
     */
    public void mover(int direcao, double dt) {
        this.x = this.x + direcao * vx * dt;
        if(this.x + tamanho > Jogo.LARGURA)
            this.x = Jogo.LARGURA - tamanho;
        if(this.x < 0)
            this.x = 0;
    }
    
    public void desenhar(Tela tela) {
        tela.triangulo(
            (int)Math.round(x), (int)Math.round(y),
            (int)Math.round(x + tamanho), (int)Math.round(y),
            (int)Math.round(x + tamanho/2), 
              (int)Math.round(y - tamanho),
            cor);
    }
}
