
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    // Posição em "coordenadas de tela"
    public double x;
    public double y;
    // Cor
    public Cor cor;
    
    // Velocidade inicial de *todos* os aliens
    public static double vx = 800/4;
    public static int tamanho = 30;
    
    /*
     * Construtor
     */ 
    public Alien(double x, double y, Cor cor) {
        // this é o objeto Alien que acabou
        // de ser criado
        this.y = y;
        this.x = x;
        this.cor = cor;
    }

    /*
     * Faz o movimento do alienígena em um intervalo de tempo dt
     * em segundos
     */
    public boolean mover(double dt) {
        // this é a instância na qual o método foi chamado
        this.x = this.x + vx * dt;
        if(vx > 0 && this.x + tamanho > Jogo.LARGURA) {
            return true;
        }
        if(vx < 0 && this.x < 0) {
            return true;
        }
        return false;
    }
    
    public void desenhar(Tela tela) {
        tela.quadrado((int)Math.round(x),
                      (int)Math.round(y),
                      tamanho,
                      cor);
    }
}



