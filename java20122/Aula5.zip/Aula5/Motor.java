import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferStrategy;
import java.lang.reflect.InvocationTargetException;
import java.util.HashSet;
import javax.swing.JFrame;
import javax.swing.JPanel;
/**
 * Motor do jogo, gerencia a parte gráfica e os eventos
 */
public class Motor extends java.awt.Canvas
{
    public Jogo jogo;
    public Thread loop;
    public BufferStrategy strategy;
    public HashSet<Integer> keySet = new HashSet<Integer>();
    
    public Motor(Jogo j) {
        final Jogo jogo = j;
        this.jogo = jogo;
        JFrame container = new JFrame(jogo.TITULO);
        JPanel panel = (JPanel) container.getContentPane();
        panel.setPreferredSize(new Dimension(
                jogo.LARGURA, jogo.ALTURA));
        panel.setLayout(null);
        setBounds(0,0,jogo.LARGURA,jogo.ALTURA);
        panel.add(this);        
        setIgnoreRepaint(true);
        container.pack();
        container.setResizable(false);
        container.setVisible(true);
        container.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        this.addKeyListener(new KeyListener() {
            @Override
            public void keyPressed(KeyEvent evt) {
                keySet.add(evt.getKeyCode());
            }
            @Override
            public void keyReleased(KeyEvent evt) {
                keySet.remove(evt.getKeyCode());
            }
            @Override
            public void keyTyped(KeyEvent evt) {
                //jogo.tecla(evt.getKeyChar());
            }
        });
        requestFocus();
        createBufferStrategy(3);
        strategy = getBufferStrategy();
        mainLoop();
    }
    
    public void mainLoop() {
        Runnable tique = new Runnable() {
                public long t0;
                public void run() {
                    long t1 = System.currentTimeMillis();
                    if(t0 == 0)
                        t0 = t1;
                    if(t1 > t0) {
                        double dt = (t1 - t0) / 1000.0;
                        t0 = t1;
                        jogo.tique(keySet, dt);
                        Graphics2D g = (Graphics2D)strategy.getDrawGraphics();
                        g.setColor(Color.black);
                        g.fillRect(0,0,jogo.LARGURA,
                                   jogo.ALTURA);
                        jogo.desenhar(new Tela(g));
                        strategy.show();
                    }
                }
            };
        /*try {
            Thread.sleep(5000);
        } catch (InterruptedException e) { }*/
        while(true) {
            try {
                EventQueue.invokeAndWait(tique);
            } catch (InterruptedException e) {
                break;
            } catch (InvocationTargetException e) {
                e.getCause().printStackTrace();
            }
        }
        loop.start();
    }
}
