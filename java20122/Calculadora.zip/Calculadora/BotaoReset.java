
public class BotaoReset extends BotaoCalc {

	public BotaoReset(ModeloCalc _calc) {
		super(_calc);
		bot.setText("C");
	}

	@Override
	protected void acao() {
		calc.reset();
	}

}
