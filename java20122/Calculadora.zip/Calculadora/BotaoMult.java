
public class BotaoMult extends BotaoCalc {

	public BotaoMult(ModeloCalc _calc) {
		super(_calc);
		bot.setText("*");
	}

	@Override
	protected void acao() {
		calc.mult();
	}

}
