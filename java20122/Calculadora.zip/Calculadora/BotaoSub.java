
public class BotaoSub extends BotaoCalc {

	public BotaoSub(ModeloCalc _calc) {
		super(_calc);
		bot.setText("-");
	}

	@Override
	protected void acao() {
		calc.sub();
	}

}
