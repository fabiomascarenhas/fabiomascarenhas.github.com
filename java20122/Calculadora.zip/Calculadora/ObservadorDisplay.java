import javax.swing.JLabel;


public class ObservadorDisplay implements Observador<ModeloCalc> {
	private JLabel label;
	
	public ObservadorDisplay(JLabel label) {
		this.label = label;
	}

	@Override
	public void evento(ModeloCalc fonte) {
		label.setText("" + fonte.getDisplay());
	}
}
