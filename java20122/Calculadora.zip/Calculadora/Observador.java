
public interface Observador<E> {
	void evento(E fonte);
}
