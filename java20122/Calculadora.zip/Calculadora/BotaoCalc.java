import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;


public abstract class BotaoCalc {
	protected ModeloCalc calc;
	protected JButton bot;
	
	public BotaoCalc(ModeloCalc _calc) {
		calc = _calc;
		bot = new JButton();
		bot.setFont(new Font(Font.MONOSPACED, 0, 24));
		bot.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				acao();
			}
		});
	}

	protected abstract void acao();
	
	public JButton getButton() {
		return bot;
	}
}
