import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;


public class JanelaCalc {

	private JFrame frame;
	
	private JLabel display;
	private ModeloCalc calc;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaCalc window = new JanelaCalc();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JanelaCalc() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 200, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Calculadora");
		
		Font fonte = new Font(Font.MONOSPACED, 0, 24);
		
		display = new JLabel();
		display.setHorizontalAlignment(SwingConstants.RIGHT);
		display.setText("0");
		display.setFont(fonte);
		display.setSize(300, 50);
		frame.getContentPane().add(display, BorderLayout.NORTH);
		
		calc = new ModeloCalc();
		calc.observador(new ObservadorDisplay(display));
		
		JPanel botoes = new JPanel();
		botoes.setLayout(new GridLayout(4, 4, 5, 5));
		BotaoDigito[] digitos = new BotaoDigito[10];
		for(int i = 0; i < digitos.length; i++)
			digitos[i] = new BotaoDigito(calc, i);
		
		botoes.add(digitos[7].getButton());
		botoes.add(digitos[8].getButton());
		botoes.add(digitos[9].getButton());
		botoes.add((new BotaoMult(calc)).getButton());

		botoes.add(digitos[4].getButton());
		botoes.add(digitos[5].getButton());
		botoes.add(digitos[6].getButton());
		botoes.add((new BotaoDiv(calc)).getButton());

		botoes.add(digitos[1].getButton());
		botoes.add(digitos[2].getButton());
		botoes.add(digitos[3].getButton());
		botoes.add((new BotaoSub(calc)).getButton());
		
		botoes.add((new BotaoReset(calc)).getButton());
		botoes.add(digitos[0].getButton());
		botoes.add((new BotaoIgual(calc)).getButton());
		botoes.add((new BotaoSoma(calc)).getButton());
		
		frame.getContentPane().add(botoes, BorderLayout.CENTER);
	}

}
