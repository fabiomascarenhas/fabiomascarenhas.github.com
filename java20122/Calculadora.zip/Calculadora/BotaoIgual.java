
public class BotaoIgual extends BotaoCalc {

	public BotaoIgual(ModeloCalc _calc) {
		super(_calc);
		bot.setText("=");
	}

	@Override
	protected void acao() {
		calc.igual();
	}

}
