import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;


public class BotaoDigito extends BotaoCalc {
	private int n;

	public BotaoDigito(ModeloCalc _calc, int _n) {
		super(_calc);
		n = _n;
		bot.setText("" + n);
	}

	@Override
	protected void acao() {
		calc.digito(n);
	}
	
}
