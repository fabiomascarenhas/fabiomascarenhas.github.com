
public class BotaoDiv extends BotaoCalc {

	public BotaoDiv(ModeloCalc _calc) {
		super(_calc);
		bot.setText("/");
	}

	@Override
	protected void acao() {
		calc.div();
	}

}
