
/**
 * Funções polinomiais
 */
public class Polinomial implements Funcao
{
    private int[] coefs;  // coefs.length é o grau + 1

    public Polinomial(int... coefs)
    {
        this.coefs = coefs;
    }

    public double valor(double x) {
        double val =  0;
        for(int i = 0; i < coefs.length; i++) {
            // val = val + c(x^i)
            val += coefs[i] * Math.pow(x, i);
        }
        return val;
    }
}
