
/*
 * Funções reais de 1 variável
 */
public interface Funcao
{
    double valor(double x);    
}
