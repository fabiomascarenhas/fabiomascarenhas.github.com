
/**
 * Função exponencial ( f(x) = n^x + c )
 */
public class Exponencial implements Funcao
{
    private double n;
    private double c;

    public Exponencial(double n, double c)
    {
        this.n = n;
        this.c = c;
    }
    
    public Exponencial(double n) {
        this.n = n;
        this.c = 0;
    }

    public double valor(double x) {
        return Math.pow(n, x) + c;
    }
}
