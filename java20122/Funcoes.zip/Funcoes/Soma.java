
/**
 * Soma de funções
 */
public class Soma implements Funcao
{
    private Funcao[] fs;

    public Soma(Funcao ... fs)
    {
        this.fs = fs;
    }
    
    public double valor(double x)
    {
        double soma = 0;
        for(Funcao f: fs) {
            soma += f.valor(x);
        }
        return soma;
    }
}
