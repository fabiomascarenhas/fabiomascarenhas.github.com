
/**
 * Operações com funções de uma variável
 */
public class Calculo
{
    // Integral definida de f no intervalo [a,b]
    public static double integral(Funcao f, double a, double b) {
        double dx = 0.0001;
        double soma = 0;
        if(a > b) {
            double tmp = a;
            a = b;
            b = tmp;
        }
        for(; a <= b; a += dx) {
            soma += f.valor(a) * dx;
        }
        return soma;
    }
    
    public static double val(Funcao f, double x) {
        return f.valor(x);
    }
    
}
