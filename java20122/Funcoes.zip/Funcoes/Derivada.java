
/**
 * Derivada de outra função f
 */
public class Derivada implements Funcao
{
    private Funcao f;

    public Derivada(Funcao f)
    {
        this.f = f;
    }

    public double valor(double x) {
        double dx = 0.0000001;
        return (f.valor(x + dx) - f.valor(x)) / dx;
    }
}
