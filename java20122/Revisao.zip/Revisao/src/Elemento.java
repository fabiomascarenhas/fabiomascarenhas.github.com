import java.io.Serializable;

public interface Elemento extends Serializable {
	String getChave();
}
