import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class BancoObjetos<TELEM extends Elemento> {
	private File dir;
	
	public BancoObjetos(String diretorio) {
		dir = new File(diretorio);
		dir.mkdirs();
		if(!dir.isDirectory())
			throw new RuntimeException(diretorio + " n�o � um diret�rio");
	}
	
	@SuppressWarnings("unchecked")
	public TELEM ler(String chave) {
		File arq = new File(dir, chave + ".objeto");
		try {
			ObjectInputStream entrada = new ObjectInputStream(
					new FileInputStream(arq));
			try {
				return (TELEM)entrada.readObject();
			} catch(ClassNotFoundException cnfe) {
				System.err.println(cnfe.getMessage());
				return null;
			} finally {
				entrada.close();
			}
		} catch(IOException ioe) {
			System.err.println(ioe.getMessage());
			return null;
		}
	}
	
	public boolean gravar(TELEM elem) {
		File arq = new File(dir, elem.getChave() + ".objeto");
		try {
			ObjectOutputStream saida = new ObjectOutputStream(
					new FileOutputStream(arq));
			try {
				saida.writeObject(elem);
				return true;
			} finally {
				saida.close();
			}
		} catch(IOException ioe) {
			System.err.println(ioe.getMessage());
			return false;
		}
	}
}
