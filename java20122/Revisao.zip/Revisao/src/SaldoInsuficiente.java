
public class SaldoInsuficiente extends Exception {
	private static final long serialVersionUID = -634633918278076507L;

	public SaldoInsuficiente(double valor, double saldo) {
		super("saldo " + saldo + " insuficiente para retirar " + valor);
	}
}
