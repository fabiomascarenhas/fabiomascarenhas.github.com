
public class Conjunto<TELEM> extends ListaFiltrada<TELEM> {
	@Override
	protected boolean filtro(TELEM obj) {
		return !contem(obj);
	}
}

