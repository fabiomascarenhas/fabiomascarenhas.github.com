
public class Lista<TELEM> {
	private TELEM primeiro;
	private Lista<TELEM> resto;
	
	public Lista(TELEM primeiro, Lista<TELEM> resto) {
		if(primeiro == null)
			throw new RuntimeException("elementos n�o podem ser null");
		this.primeiro = primeiro;
		this.resto = resto;
	}
		
	public Lista() {
		primeiro = null;
		resto = null;
	}
	
	public void adiciona(TELEM obj) {
		if(obj == null)
			throw new RuntimeException("elementos n�o podem ser null");
		if(primeiro == null)
			primeiro = obj;
		else
			resto = new Lista<TELEM>(obj, resto);
	}
	
	public boolean contem(TELEM obj) {
		return obj.equals(primeiro) || 
				(resto != null && resto.contem(obj));
	}
	
	public String toString() {
		if(resto != null) 
			return primeiro + ", " + resto.toString();
		else 
			return primeiro.toString();
	}
}
