import java.io.BufferedReader;
import java.io.IOException;


public class ContaCorrente implements Elemento {
	private static final long serialVersionUID = -4404036818111190987L;
	private int numero;
    private String correntista;
    private double saldo;

    public ContaCorrente(int numero, String correntista, double saldo) {
        this.numero = numero;
        this.correntista = correntista;
        this.saldo = saldo;
    }

    public void deposita(double valor) {
        this.saldo += valor;
    }

    public void retira(double valor) throws SaldoInsuficiente {
    		if(valor > saldo)
    			throw new SaldoInsuficiente(valor, saldo);
        this.saldo -= valor;
    }

    public void transfere(ContaCorrente destino, double valor)
    			throws SaldoInsuficiente {
        this.retira(valor);
        destino.deposita(valor);
    }
    
    public String getChave() {
    		return "" + numero;
    }
    
    public String toString() {
    		return numero + ", " + correntista + ", " + saldo;
    }
    
    public void processa(BufferedReader buf) throws IOException {
    		String linha = buf.readLine();
    		while(linha != null) {
    			try {
    				double valor = Double.parseDouble(linha);
    				if(valor < 0) {
    					this.retira(-valor);
    				} else {
    					this.deposita(valor);
    				}
    			} catch(NumberFormatException nfe) {
    				System.err.println(nfe.getMessage());
    			} catch(SaldoInsuficiente si) {
    				System.out.println(si.getMessage());
    			}
    			linha = buf.readLine();
    		}
    }
    
}
