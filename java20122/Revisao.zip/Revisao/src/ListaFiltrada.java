
public abstract class ListaFiltrada<TELEM> 
			extends Lista<TELEM> {
		
	@Override
	public void adiciona(TELEM obj) {
		if(!filtro(obj))
			throw new RuntimeException("elemento " + obj + " n�o pode ser inserido");
		super.adiciona(obj);
	}
	
	// posso adicionar obj?
	protected abstract boolean filtro(TELEM obj);
}
