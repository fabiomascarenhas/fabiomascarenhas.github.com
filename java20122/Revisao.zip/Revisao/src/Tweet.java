import java.util.Date;

public class Tweet implements Elemento {
	private String usuario;
	private String texto;
	private Date data;
	
	public Tweet(String usuario, String texto, Date data) {
		this.usuario = usuario;
		this.texto = texto;
		this.data = data;
	}

	public String getChave() {
		return data.toGMTString();
	}
	
	public String getUsuario() {
		return usuario;
	}

	public String getTexto() {
		return texto;
	}

}
