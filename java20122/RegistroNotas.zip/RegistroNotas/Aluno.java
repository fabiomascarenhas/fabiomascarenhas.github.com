public class Aluno
{
    public String DRE;
    public String nome;
    
    public Aluno(String DRE, String nome) {
        this.DRE = DRE;
        this.nome = nome;
    }
}
