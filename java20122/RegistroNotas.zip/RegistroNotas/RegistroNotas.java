public class RegistroNotas
{
    public Aluno aluno;
    public Disciplina disciplina;
    public String semestre;
    public double p1;
    public double p2;
    public double p3;
    
    public RegistroNotas(Aluno aluno, Disciplina disciplina,
        String semestre, double p1, double p2, double p3) {
        this.aluno = aluno;
        this.disciplina = disciplina;
        this.semestre = semestre;
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }
}
