public class Disciplina
{
    public String nome;
    public String codigo;
    
    public Disciplina(String codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }    
}
