
public interface Enumerador {
  int proximo() throws EnumeradorVazio;  // próximo elemento
  boolean fim();  // acabaram os elementos?
}
