public class EnumeradorVazio extends Exception {
    public EnumeradorVazio() {
        super();
    }
    
    public EnumeradorVazio(String msg) {
        super(msg);
    }
}
