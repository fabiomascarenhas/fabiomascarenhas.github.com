
public interface Lista {
  int quantos();     // quantos elementos a lista tem
  int soma();        // soma dos elementos da lista
  Enumerador enumerador(); // um enumerador para essa lista
  int foldr(OpBin op, int z);
}
