public class TratamentoExcecao {
    public static Lista l;
    public static Enumerador e;
    public static java.io.FileWriter out;

    public static void exec1() throws java.io.IOException { exec2(); }

    public static void exec2() throws java.io.IOException { exec3(); }
    
    public static void exec3() throws java.io.IOException {
        try {
            exec4();
        } catch(EnumeradorVazio ex) {
            System.out.println("(1) Acabou! " + ex.toString());
//            throw ex;
        } catch(NullPointerException ex) {
            System.out.println("(2) Acabou! " + ex.toString());
            System.out.println("NULL POINTER EXCEPTION");
            throw ex;
        }
        System.out.println("Código Morto");
     }
     
     public static void exec4() throws EnumeradorVazio, java.io.IOException {
            for(int i = 0; i < 1000000; i++) {
                //System.out.println(e.proximo());
                out.write(e.proximo() + "\n");
            }
     }

    public static void main(String[] args) throws java.io.IOException {
      //Lista l = new ListaCons(1, new ListaCons(2, new ListaVazia()));
       l = new ListaCons(1, new ListaCons(2, null));
        e = l.enumerador();
        out = new java.io.FileWriter(
            new java.io.File("out.txt"));
        try {
            exec1();
//        } catch(RuntimeException ex) {
//            System.out.println("(3) Acabou! " + ex.toString());
//            throw ex;
        } finally {
            System.out.println("Fechando...");
            out.close();
        }
    }
}