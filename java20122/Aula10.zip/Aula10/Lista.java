public interface Lista
{
    public Figura ler(int i);
    public void escrever(int i, Figura f);
    public int tamanho();
}
