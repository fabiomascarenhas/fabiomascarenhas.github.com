import java.awt.Rectangle;
import java.io.Serializable;

public class Composicao implements Figura, Lista
{
    private Figura[] partes;
    
    public Composicao(Figura ... partes)
    {
        this.partes = partes;
    }

    public void desenhar(Tela t) {
        for(Figura f: partes)
            f.desenhar(t);
    }
    
    public void mover(double dx, double dy) {
        for(Figura f: partes)
            f.mover(dx, dy);
    }
    
    public boolean cantoEsquerdo() {
        boolean encostou = false;
        for(Figura f: partes) {
            encostou = f.cantoEsquerdo() || encostou;
        }
        return encostou;
    }
    
    public boolean cantoDireito(int largura) {
        boolean encostou = false;
        for(Figura f: partes) {
            encostou = encostou || f.cantoDireito(largura);
        }
        return encostou;
    }
    
    public boolean cantoSuperior() {
        for(Figura f: partes)
            if(f.cantoSuperior())
                return true;
        return false;
    }

    public boolean cantoInferior(int altura) {
        for(Figura f: partes)
            if(f.cantoInferior(altura))
                return true;
        return false;
    }
    
    public boolean colidiu(Figura f1) {
        for(Figura f2: partes)
            if(f2.colidiu(f1))
                return true;
        return false;
    }
    
    public Rectangle getCaixa() {
        double minX = Double.MAX_VALUE;
        double minY = Double.MAX_VALUE;
        double maxX = 0;
        double maxY = 0;
        for(Figura f: partes) {
            Rectangle r = f.getCaixa();
            if(r.x < minX) minX = r.x;
            if(r.y < minY) minY = r.y;
            if(r.x + r.width > maxX) maxX = r.x + r.width;
            if(r.y + r.height > maxY) maxY = r.y + r.height;
        }
        return new Rectangle((int)Math.round(minX),
            (int)Math.round(minY), 
            (int)Math.round(maxX - minX),
            (int)Math.round(maxY - minY));
    }
    
    public int tamanho() {
        return partes.length;
    }
    
    public Figura ler(int i) {
        return partes[i];
    }
    
    public void escrever(int i, Figura f) {
        partes[i] = f;
    }
}
