import java.awt.Rectangle;

/**
 * Canhão do jogo
 */
public class Canhao
{
    private Figura figura;
    // Pontos desse jogador
    private int score;
    private int scoreX;
    private int scoreY;

    // Velocidade
    private static double vx = SpaceInvaders.LARGURA/4;
    public static int TAMANHO = 40;

    public Canhao(double x, int scoreX, int scoreY, Cor cor) {
        this.figura = new Triangulo(x, SpaceInvaders.ALTURA,
          x + TAMANHO, SpaceInvaders.ALTURA, x + TAMANHO/2, SpaceInvaders.ALTURA - TAMANHO,
          cor);
        this.scoreX = scoreX;
        this.scoreY = scoreY;
    }
        
    /*
     * direcao: -1 (esquerda), 0 (parado), 1 (direita)
     */
    public void mover(int direcao, double dt) {
        if((direcao > 0 && !figura.cantoDireito(SpaceInvaders.LARGURA)) ||
           (direcao < 0 && !figura.cantoEsquerdo()))
           figura.mover(vx * direcao * dt, 0);
    }
    
    public void desenhar(Tela tela) {
        figura.desenhar(tela);
    }
    
    public Tiro atirar() {
        Motor.tocar("shoot.wav");
        Rectangle ret = figura.getCaixa();
        return new Tiro(this, ret.x + ret.width/2, ret.y);
    }
    
    public void pontue() {
        this.score += 50;
    }
}
