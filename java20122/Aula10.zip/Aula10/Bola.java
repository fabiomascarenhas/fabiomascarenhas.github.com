import java.util.Set;

public class Bola implements Jogo {
	public double x = 400;
	public double y = 300;
	public double vx = 300;
	public double vy = 0;
	public double G = 500; // pixels/s^2;
	public Cor cor = new Cor("branco");
	
	@Override
	public String getTitulo() {
		return "Bola";
	}

	@Override
	public int getLargura() {
		return 800;
	}

	@Override
	public int getAltura() {
		return 600;
	}

	@Override
	public void tique(Set<String> keys, double dt) {
		x = x + vx * dt;
		if(x > 740) {
			vx = -vx;
			x = 740;
		}
		if(x < 0) {
			vx = -vx;
			x = 0;
		}
		vy = vy + G * dt;
		y = y + vy * dt;
		if(y > 540) {
			vy = -vy;
			y = 540;
		}
		if(y < 0) {
			vy = -vy;
			y = 0;
		}
	}

	@Override
	public void desenhar(Tela c) {
		c.circulo((int)(x + 30), (int)(y + 30), 30, cor);
	}

	@Override
	public void tecla(String c) {
		if(c.equals("left"))
			vx = vx > 0 ? -vx : vx;
		if(c.equals("right"))
			vx = vx < 0 ? -vx : vx;
		if(c.equals("up")) 
			G = G > 0 ? -G : G;
		if(c.equals("down"))
			G = G < 0 ? -G : G;
	}

	public static void main(String[] args) {
		new Motor(new Bola());
	}
}
