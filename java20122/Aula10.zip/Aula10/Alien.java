
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    private Figura figura;
    // Vivo ou morto
    private boolean vivo = true;
    
    // Velocidade inicial de *todos* os aliens
    private static double vx = SpaceInvaders.LARGURA/4;
    private static double vy = SpaceInvaders.ALTURA/60;
    
    private static int TAMANHO = 30;
    
    /*
     * Construtor
     */ 
    public Alien(double x, double y, Cor cor) {
        Figura f1 = new Circulo(x + TAMANHO/2, y + TAMANHO/2,
            7, cor);
        Figura f2 = new Retangulo(x + 5, y + TAMANHO/2 - 3,
            20, 6, cor);
        Figura f3 = new Triangulo(x, y + TAMANHO/2,
            x + 5, y + TAMANHO/2 - 3,
            x + 5, y + TAMANHO/2 + 3, cor);
        Figura f4 = new Triangulo(x + TAMANHO, y + TAMANHO/2,
            x + 25, y + TAMANHO/2 - 3,
            x + 25, y + TAMANHO/2 + 3, cor);
        this.figura = new Composicao(new Composicao(f1, f2),
        new Composicao(f3, f4));
    }

    /*
     * Faz o movimento do alienígena em um intervalo de tempo dt
     * em segundos
     */
    public boolean mover(double dt) {
        if(this.vivo) {
            // this é a instância na qual o método foi chamado
            figura.mover(vx * dt, vy * dt);
            return (vx > 0 && figura.cantoDireito(SpaceInvaders.LARGURA)) ||
                (vx < 0 && figura.cantoEsquerdo());
        }
        return false;
    }
    
    public static void inverter() {
        vx = -vx;
    }
    
    public void desenhar(Tela tela) {
        if(this.vivo) {
            figura.desenhar(tela);
        }
    }
    
    public void morrer() {
        this.vivo = false;
    }
    
    public boolean colidiu(Tiro t) {
        return vivo && figura.colidiu(t.figura);
    }

    public boolean pousou() {
        return figura.cantoInferior(SpaceInvaders.ALTURA);
    }
}



