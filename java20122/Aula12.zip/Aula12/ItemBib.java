public interface ItemBib {
    public boolean entregaAntes(ItemBibSuper outro);    
    public int diasAtraso(int hoje);
    public double multa(int hoje);
}