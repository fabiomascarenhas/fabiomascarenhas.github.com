import java.util.List;
import java.util.ArrayList;

public class Biblioteca {
    private List<ItemBib> items = new ArrayList<ItemBib>();

    public Biblioteca() {
        items.add(new Livro(100, "Java Básico", "João Silva", 12500));
        items.add(new Revista(100, "Java Magazine", 10, 5, 12505));
        items.add(new CD(100, "Músicas da Ilha de Java",
            "Orquestra Javanesa", 12502));
    }
    
    public ItemBib[] items() {
        ItemBib[] items = new ItemBib[this.items.size()];
        for(int i = 0; i < this.items.size(); i++) {
            items[i] = this.items.get(i);
        }
        return items;
    }
    
    public void atrasos(int hoje) {
        for(ItemBib item: items) {
            System.out.println(item.diasAtraso(hoje));
        }
    }

    public void multas(int hoje) {
        for(ItemBib item: items) {
            System.out.println(item.multa(hoje));
        }
    }
}