public class Livro extends ItemBibSuper implements ItemBib {
    private String autor;
    
    public Livro(int categoria, String titulo, String autor,
            int dataEntrega) {
        // tem que ser na primeira linha!
        super(categoria, titulo, dataEntrega);
        this.autor = autor;
    }
    
    public void imprime() {
        System.out.println("" + categoria + " - " + 
            titulo + " - " + autor);
    }
}