public interface OpBin<TA,TB> {
    TB op(TA a, TB b);  // faz a operação binária
}