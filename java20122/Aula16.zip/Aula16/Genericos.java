import java.util.ArrayList;

public class Genericos {
    public static void main(String[] args) {
        Lista<String> ls = new ListaCons<String>("foo", new ListaCons<String>("bar", new ListaVazia<String>()));
        Foldr<String,Lista<String>> fs = new Foldr<String,Lista<String>>();
        Lista<String> lus = fs.foldr(ls, new OpBin<String,Lista<String>>() {
            public Lista<String> op(String a, Lista<String> b) { 
                return new ListaCons<String>(a.toUpperCase(),b);
            } 
        }, ls);
        Enumerador<String> elus = lus.enumerador();
        while(!elus.fim())
            System.out.println(elus.proximo());
        Foldr<String,ArrayList<String>> fsa = new Foldr<String,ArrayList<String>>();
        ArrayList<String> as = fsa.foldr(ls, new OpBin<String,ArrayList<String>>() {
            public ArrayList<String> op(String a, ArrayList<String> b) {
                b.add(a.toUpperCase());
                return b;
            } 
        }, new ArrayList<String>());
        System.out.println("ARRAYLIST:");
        for(String s: as) System.out.println(s);
        Lista<String> lsno = new ListaCons<String>("f", 
            new ListaCons<String>("b", 
            new ListaCons<String>("a", 
            new ListaCons<String>("c", 
            new ListaCons<String>("e", 
            new ListaCons<String>("d", 
                new ListaVazia<String>()))))));
        Lista<String> lso = lsno.ordena();
        for(int i = 0; i < lso.quantos(); i++)
            System.out.println(lso.elem(i));
        Lista<Racional> lsnor = new ListaCons<Racional>(new Racional(1,2), 
            new ListaCons<Racional>(new Racional(2,3), 
            new ListaCons<Racional>(new Racional(1,4), 
            new ListaCons<Racional>(new Racional(4,5), 
            new ListaCons<Racional>(new Racional(3,7),
            new ListaCons<Racional>(new Racional(1,8), 
                new ListaVazia<Racional>()))))));
        Lista<Racional> lsor = lsnor.ordena();
        for(int i = 0; i < lsor.quantos(); i++)
            System.out.println(lsor.elem(i));
    }
}