public class ListaVazia<TELEM extends Comparable<TELEM>> implements Lista<TELEM>, Enumerador<TELEM>
{
    public ListaVazia() { }

    public int quantos() {
        return 0;
    }
        
    public TELEM elem(int i) {
        throw new RuntimeException("lista vazia");
    }
    
    public Enumerador<TELEM> enumerador() {
        return this;
    }
    
    public TELEM proximo() {
        throw new EnumeradorVazio("lista vazia");
    }
    
    public boolean fim() {
        return true;
    }
    
    public Lista<TELEM> ordena() {
        return this;
    }
}
