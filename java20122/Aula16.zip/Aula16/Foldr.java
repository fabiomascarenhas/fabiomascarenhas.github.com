public class Foldr<TA extends Comparable<TA>,TB>
{
    public Foldr() { }
    
    public TB foldr(Lista<TA> l, OpBin<TA,TB> op, TB z) {
        for(int i = l.quantos() - 1; i >= 0; i--)
            z = op.op(l.elem(i), z);
        return z;
    }
}
