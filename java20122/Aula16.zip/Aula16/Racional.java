public class Racional implements Comparable<Racional> {
    private int num; // numerador
    private int den; // denominador

    public Racional(int num, int den) {
        this.num = num;
        this.den = den;
    }

    public String toString() {
        return num + "/" + den;
    }
    
    public int compareTo(Racional outro) {
        double d1 = (double)num/(double)den;
        double d2 = (double)outro.num/(double)outro.den;
        return d1 < d2 ? -1 : (d1 > d2 ? 1 : 0);
    }
}