public class EnumeradorVazio extends RuntimeException {
    public EnumeradorVazio() {
        super();
    }
    
    public EnumeradorVazio(String msg) {
        super(msg);
    }
}
