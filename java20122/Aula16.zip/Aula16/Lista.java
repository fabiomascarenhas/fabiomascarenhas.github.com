
public interface Lista<TELEM extends Comparable<TELEM>> {
  int quantos();     // quantos elementos a lista tem
  TELEM elem(int i);   // elemento na posição i
  Enumerador<TELEM> enumerador(); // um enumerador para essa lista
  Lista<TELEM> ordena();
}
