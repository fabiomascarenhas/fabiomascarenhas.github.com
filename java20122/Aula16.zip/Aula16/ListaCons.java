public class ListaCons<TELEM extends Comparable<TELEM>> implements Lista<TELEM>
{
    private TELEM primeiro;
    private Lista<TELEM> resto;
    
    public ListaCons(TELEM primeiro, Lista<TELEM> resto)
    {
        this.primeiro = primeiro;
        this.resto = resto;
    }
    
    public int quantos() {
        return 1 + resto.quantos();
    }
    
    public TELEM elem(int i) {
        if(i == 0)
            return primeiro;
        else
            return resto.elem(i - 1);
    }
        
    public Enumerador<TELEM> enumerador() {
        return new Enumerador<TELEM>() {
            Enumerador<TELEM> enumResto;
            
            public TELEM proximo() {
                if(enumResto == null) {
                    enumResto = resto.enumerador();
                    return primeiro;
                } else
                    return enumResto.proximo();
            }
            
            public boolean fim() {
                if(enumResto == null)
                    return false;
                else
                    return enumResto.fim();
            }
        };
    }
    
    public Lista<TELEM> ordena() {
        java.util.ArrayList<TELEM> al = new java.util.ArrayList<TELEM>();
        Enumerador<TELEM> e = enumerador();
        while(!e.fim()) {
            TELEM prox = e.proximo();
            int i = 0;
            for(; i < al.size() && prox.compareTo(al.get(i)) > 0; i++);
            al.add(i, prox);
        }
        Lista<TELEM> l = new ListaVazia<TELEM>();
        for(int i = al.size() - 1; i >= 0; i--) {
            l = new ListaCons<TELEM>(al.get(i), l);
        }
        return l;
    }
}
