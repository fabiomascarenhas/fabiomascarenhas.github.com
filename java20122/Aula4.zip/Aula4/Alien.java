
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    // Posição em "coordenadas de tela"
    public int x;
    public int y;
    // Cor
    public Cor cor;
    
    // Velocidade inicial de *todos* os aliens
    public static int vx = 800/4;
    
    /*
     * Construtor
     */ 
    public Alien(int x, int y, Cor cor) {
        // this é o objeto Alien que acabou
        // de ser criado
        this.y = y;
        this.x = x;
        this.cor = cor;
    }

    /*
     * Faz o movimento do alienígena em um intervalo de tempo dt
     */
    public void mover(double dt) {
        // this é a instância na qual o método foi chamado
        this.x = this.x + (int)(vx * dt);
    }
}



