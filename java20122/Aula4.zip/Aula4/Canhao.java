
/**
 * Canhão do jogo
 */
public class Canhao
{
    // Posição em coordenadas de tela
    public int x;
    public int y = 600;
    // Velocidade
    public int vx = 0;
    // Pontos desse jogador
    public int score;
    // Cor
    public Cor cor;
    
    public Canhao(int x, Cor cor) {
        this.x = x;
        this.cor = cor;
    }
    
    public Canhao(int x, int y, int vx, int score, Cor cor) {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.score = score;
        this.cor = cor;
    }
}
