package compii.calc;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class EstadoNormal implements EstadoCalc {
	protected ModeloCalc calc;
	
	public EstadoNormal() { }
	
	public EstadoNormal(ModeloCalc calc) {
		this.calc = calc;
	}
	
	@Override
	public void digito(int n) {
		calc.setDisplay(n);
		calc.setEstado(new EstadoNormalAumenta(calc));
	}

	@Override
	public void soma() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoSoma(calc));
	}

	@Override
	public void sub() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoSub(calc));
	}

	@Override
	public void mult() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoMult(calc));
	}

	@Override
	public void div() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoDiv(calc));
	}

	@Override
	public void igual() {
		calc.setDisplay(
				calc.getUltimaOp().faz(calc.getDisplay()));
		calc.setEstado(new EstadoNormal(calc));
	}

	public void conecta(ModeloCalc calc) {
		this.calc = calc;
	}
	
	@Override
	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException { }

	@Override
	public void writeExternal(ObjectOutput out) throws IOException { }

}
