package compii.calc;

public interface Observador<E> {
	void evento(E fonte);
}
