package compii.calc;

import android.widget.Button;

public class BotaoSoma extends BotaoCalc {

	public BotaoSoma(Button bot, ModeloCalc _calc) {
		super(bot, _calc);
		bot.setText("+");
	}

	@Override
	protected void acao() {
		calc.soma();
	}

}
