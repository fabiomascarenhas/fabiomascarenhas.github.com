package compii.calc;

import android.widget.Button;

public class BotaoDiv extends BotaoCalc {

	public BotaoDiv(Button bot, ModeloCalc _calc) {
		super(bot, _calc);
		bot.setText("/");
	}

	@Override
	protected void acao() {
		calc.div();
	}

}
