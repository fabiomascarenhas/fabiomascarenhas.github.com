package compii.calc;

public class EstadoNormalAumenta extends EstadoNormal {

	public EstadoNormalAumenta() {
		super();
	}

	public EstadoNormalAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public void digito(int n) {
		calc.setDisplay(calc.getDisplay() * 10 + n);
	}

}
