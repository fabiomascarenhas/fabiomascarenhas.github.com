package compii.calc;

public class EstadoSubAumenta extends EstadoOpAumenta {

	public EstadoSubAumenta() {
		super();
	}

	public EstadoSubAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public OpCalc criaOp(int dir) {
		return new OpSub(dir);
	}
	
}
