package compii.calc;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public abstract class EstadoOpAumenta implements EstadoCalc {
	protected ModeloCalc calc;
	
	public EstadoOpAumenta() { }
	
	public EstadoOpAumenta(ModeloCalc calc) {
		this.calc = calc;
	}
	
	@Override
	public void digito(int n) {
		calc.setDisplay(calc.getDisplay() * 10 + n);
	}
	
	private void fazOp(EstadoCalc estado) {
		OpCalc op = criaOp(calc.getDisplay());
		calc.setDisplay(op.faz(calc.getOperando()));
		calc.setOperando(calc.getDisplay());
		calc.setEstado(estado);
	}
	
	@Override
	public void soma() {
		fazOp(new EstadoSoma(calc));
	}

	@Override
	public void sub() {
		fazOp(new EstadoSub(calc));
	}

	@Override
	public void mult() {
		fazOp(new EstadoMult(calc));
	}

	@Override
	public void div() {
		fazOp(new EstadoDiv(calc));
	}
	
	public void igual() {
		OpCalc op = criaOp(calc.getDisplay());
		calc.setUltimaOp(op);
		fazOp(new EstadoNormal(calc));
	}

	public void conecta(ModeloCalc calc) {
		this.calc = calc;
	}
	
	public abstract OpCalc criaOp(int dir);

	@Override
	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException { }

	@Override
	public void writeExternal(ObjectOutput out) throws IOException { }
	
}
