package compii.calc;

public class EstadoSomaAumenta extends EstadoOpAumenta {

	public EstadoSomaAumenta() {
		super();
	}

	public EstadoSomaAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public OpCalc criaOp(int dir) {
		return new OpSoma(dir);
	}
	
}
