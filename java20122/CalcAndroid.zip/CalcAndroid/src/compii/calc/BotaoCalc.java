package compii.calc;

import android.view.View;
import android.widget.Button;

public abstract class BotaoCalc {
	protected ModeloCalc calc;

	public BotaoCalc(Button bot, ModeloCalc _calc) {
		calc = _calc;
		bot.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				acao();
			}
		});
	}

	protected abstract void acao();
	
}
