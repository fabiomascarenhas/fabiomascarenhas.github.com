package compii.calc;

public interface Sujeito<E> {
	void observador(Observador<E> obs);
	void esquecer(Observador<E> obs);
	void notificar();
}
