package compii.calc;

import android.widget.Button;

public class BotaoReset extends BotaoCalc {

	public BotaoReset(Button bot, ModeloCalc _calc) {
		super(bot, _calc);
		bot.setText("C");
	}

	@Override
	protected void acao() {
		calc.reset();
	}

}
