package compii.calc;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.Button;
import android.widget.TextView;

public class Calculadora extends Activity {
	
	private ModeloCalc calc;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.calculadora);
		TextView display = (TextView)this.findViewById(R.id.display);
		calc = new ModeloCalc();
		if(savedInstanceState != null &&
				savedInstanceState.containsKey("display")) {
			calc.setDisplay(savedInstanceState.getInt("display"));
			calc.setOperando(savedInstanceState.getInt("operando"));
			calc.setUltimaOp((OpCalc)savedInstanceState.getSerializable("ultimaOp"));
			EstadoCalc estado = (EstadoCalc)savedInstanceState.getSerializable("estado");
			estado.conecta(calc);
			calc.setEstado(estado);
		}
		calc.observador(new ObservadorDisplay(display));
		calc.notificar();
		new BotaoDigito((Button)this.findViewById(R.id.botao0),
				calc, 0);
		new BotaoDigito((Button)this.findViewById(R.id.botao1),
				calc, 1);
		new BotaoDigito((Button)this.findViewById(R.id.botao2),
				calc, 2);
		new BotaoDigito((Button)this.findViewById(R.id.botao3),
				calc, 3);
		new BotaoDigito((Button)this.findViewById(R.id.botao4),
				calc, 4);
		new BotaoDigito((Button)this.findViewById(R.id.botao5),
				calc, 5);
		new BotaoDigito((Button)this.findViewById(R.id.botao6),
				calc, 6);
		new BotaoDigito((Button)this.findViewById(R.id.botao7),
				calc, 7);
		new BotaoDigito((Button)this.findViewById(R.id.botao8),
				calc, 8);
		new BotaoDigito((Button)this.findViewById(R.id.botao9),
				calc, 9);
		new BotaoSoma((Button)this.findViewById(R.id.botaoSoma), calc);
		new BotaoSub((Button)this.findViewById(R.id.botaoSub), calc);
		new BotaoMult((Button)this.findViewById(R.id.botaoMult), calc);
		new BotaoDiv((Button)this.findViewById(R.id.botaoDiv), calc);
		new BotaoIgual((Button)this.findViewById(R.id.botaoIgual), calc);
		new BotaoReset((Button)this.findViewById(R.id.botaoReset), calc);
	}

	protected void onSaveInstanceState(Bundle state) {
		state.putInt("display", calc.getDisplay());
		state.putInt("operando", calc.getOperando());
		state.putSerializable("ultimaOp", calc.getUltimaOp());
		state.putSerializable("estado", calc.getEstado());
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.calculadora, menu);
		return true;
	}

}
