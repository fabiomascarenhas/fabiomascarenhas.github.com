package compii.calc;

public class EstadoMultAumenta extends EstadoOpAumenta {
	
	public EstadoMultAumenta() {
		super();
	}

	public EstadoMultAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public OpCalc criaOp(int dir) {
		return new OpMult(dir);
	}
	
}
