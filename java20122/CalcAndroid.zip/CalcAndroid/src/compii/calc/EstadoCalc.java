package compii.calc;

import java.io.Externalizable;

public interface EstadoCalc extends Externalizable {
	void digito(int n);
	void soma();
	void sub();
	void mult();
	void div();
	void igual();
	void conecta(ModeloCalc calc);
}
