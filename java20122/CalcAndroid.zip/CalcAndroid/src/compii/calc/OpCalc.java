package compii.calc;

import java.io.Serializable;

public abstract class OpCalc implements Serializable {
	protected int dir;
	
	public OpCalc(int dir) {
		this.dir = dir;
	}
	
	public abstract int faz(int esq);
}
