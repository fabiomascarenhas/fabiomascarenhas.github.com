package compii.calc;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class EstadoDiv extends EstadoOp {

	public EstadoDiv() {
		super();
	}
	
	public EstadoDiv(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public EstadoCalc estadoAumenta(ModeloCalc calc) {
		return new EstadoDivAumenta(calc);
	}
	
	@Override
	public OpCalc criaOp(int dir) {
		return new OpDiv(dir);
	}
	
}
