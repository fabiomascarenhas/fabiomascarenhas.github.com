package compii.calc;
import java.util.HashSet;


public class ModeloCalc implements Sujeito<ModeloCalc> {
	private EstadoCalc estado;
	
	private int display;
	private int operando;
	private OpCalc ultimaOp;

	private HashSet<Observador<ModeloCalc>> obs =
			new HashSet<Observador<ModeloCalc>>();
	
	public ModeloCalc() {
		reset();
	}
	
	public void digito(int i) {
		estado.digito(i);
	}
	
	public void soma() {
		estado.soma();
	}
	
	public void sub() {
		estado.sub();
	}
	
	public void mult() {
		estado.mult();
	}
	
	public void div() {
		estado.div();
	}

	public void igual() {
		estado.igual();
	}
	
	public void reset() {
		setDisplay(0);
		setOperando(0);
		setUltimaOp(new OpSoma(0));
		setEstado(new EstadoNormal(this));
	}
	
	public EstadoCalc getEstado() {
		return estado;
	}
	
	public void setEstado(EstadoCalc estado) {
		this.estado = estado;
	}
	
	public int getDisplay() {
		return display;
	}
	
	public void setDisplay(int display) {
		this.display = display;
		notificar();
	}
	
	public void setOperando(int operando) {
		this.operando = operando;
	}

	public OpCalc getUltimaOp() {
		return ultimaOp;
	}

	public void setUltimaOp(OpCalc ultimaOp) {
		this.ultimaOp = ultimaOp;
	}

	public int getOperando() {
		return operando;
	}

	@Override
	public void observador(Observador<ModeloCalc> obs) {
		this.obs.add(obs);
	}

	@Override
	public void esquecer(Observador<ModeloCalc> obs) {
		this.obs.remove(obs);
	}

	@Override
	public void notificar() {
		for(Observador<ModeloCalc> o: this.obs){
			o.evento(this);
		}
	}
}
