package compii.calc;

public class EstadoMult extends EstadoOp {

	public EstadoMult() {
		super();
	}

	public EstadoMult(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public EstadoCalc estadoAumenta(ModeloCalc calc) {
		return new EstadoMultAumenta(calc);
	}
	
	@Override
	public OpCalc criaOp(int dir) {
		return new OpMult(dir);
	}
	
}
