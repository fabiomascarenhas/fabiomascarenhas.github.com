package compii.calc;

import android.widget.TextView;

public class ObservadorDisplay implements Observador<ModeloCalc> {
	private TextView display;

	public ObservadorDisplay(TextView display) {
		this.display = display;
	}
	
	@Override
	public void evento(ModeloCalc fonte) {
		display.setText(""+fonte.getDisplay());
	}
	
}
