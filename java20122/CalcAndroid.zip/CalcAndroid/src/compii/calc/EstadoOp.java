package compii.calc;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public abstract class EstadoOp implements EstadoCalc {
	private ModeloCalc calc;
	
	public EstadoOp() { }
	
	public EstadoOp(ModeloCalc calc) {
		this.calc = calc;
	}
	
	public abstract EstadoCalc estadoAumenta(ModeloCalc calc);

	public abstract OpCalc criaOp(int dir);

	@Override
	public void digito(int n) {
		calc.setDisplay(n);
		calc.setEstado(estadoAumenta(calc));
	}

	@Override
	public void soma() {
		calc.setEstado(new EstadoSoma(calc));
	}

	@Override
	public void sub() {
		calc.setEstado(new EstadoSub(calc));
	}

	@Override
	public void mult() {
		calc.setEstado(new EstadoMult(calc));
	}

	@Override
	public void div() {
		calc.setEstado(new EstadoDiv(calc));
	}

	@Override
	public void igual() {
		OpCalc op = criaOp(calc.getDisplay());
		calc.setDisplay(op.faz(calc.getOperando()));
		calc.setUltimaOp(op);
		calc.setEstado(new EstadoNormal(calc));
	}
	
	public void conecta(ModeloCalc calc) {
		this.calc = calc;
	}
	
	@Override
	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException { }

	@Override
	public void writeExternal(ObjectOutput out) throws IOException { }

}
