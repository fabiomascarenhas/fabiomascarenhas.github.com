package compii.calc;

import android.widget.Button;

public class BotaoIgual extends BotaoCalc {

	public BotaoIgual(Button bot, ModeloCalc _calc) {
		super(bot, _calc);
		bot.setText("=");
	}

	@Override
	protected void acao() {
		calc.igual();
	}

}
