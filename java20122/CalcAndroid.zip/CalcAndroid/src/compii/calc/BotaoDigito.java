package compii.calc;

import android.widget.Button;

public class BotaoDigito extends BotaoCalc {
	private int n;

	public BotaoDigito(Button bot, ModeloCalc _calc, int _n) {
		super(bot, _calc);
		n = _n;
		bot.setText("" + n);
	}

	@Override
	protected void acao() {
		calc.digito(n);
	}
	
}
