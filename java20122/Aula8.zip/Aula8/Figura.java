import java.awt.Rectangle;

public interface Figura
{
    void mover(double dx, double dy);
    void desenhar(Tela t);
    boolean colidiu(Figura f);
    boolean cantoEsquerdo();
    boolean cantoDireito(int largura);
    boolean cantoInferior(int altura);
    boolean cantoSuperior();
    Rectangle getCaixa();
}
