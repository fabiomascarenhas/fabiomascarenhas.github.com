import java.awt.Rectangle;

public class Circulo implements Figura
{
    private double cx;
    private double cy;
    private int raio;
    private Cor cor;
    
    public Circulo(double cx, double cy, int raio, Cor cor) {
        this.cx = cx;
        this.cy = cy;
        this.raio = raio;
        this.cor = cor;
    }
    
    public void mover(double dx, double dy) {
        cx += dx;
        cy += dy;
    }
    
    public void desenhar(Tela t) {
        t.circulo(cx, cy, raio, cor);
    }
    
    public boolean cantoEsquerdo() {
        return cx - raio <= 0;
    }

    public boolean cantoSuperior() {
        return cy - raio <= 0;
    }

    public boolean cantoDireito(int largura) {
       return cx + raio >= largura;
    }
    
    public boolean cantoInferior(int altura) {
        return cy + raio >= altura;
    }
    
    public boolean colidiu(Figura f) {
        Rectangle c = f.getCaixa();
        return c.intersects(this.getCaixa());
    }
    
    public Rectangle getCaixa() {
        return new Rectangle(
            (int)Math.round(cx - raio), 
            (int)Math.round(cy - raio), 
            (int)Math.round(raio * 2),
            (int)Math.round(raio * 2));
    }
}
