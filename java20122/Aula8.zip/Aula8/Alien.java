
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    private Figura figura;
    // Vivo ou morto
    private boolean vivo = true;
    
    // Velocidade inicial de *todos* os aliens
    private static double vx = Jogo.LARGURA/4;
    private static double vy = Jogo.ALTURA/60;
    
    private static int TAMANHO = 30;
    
    /*
     * Construtor
     */ 
    public Alien(double x, double y, Cor cor) {
        if(Math.random() > 0.5) {
            this.figura = new Quadrado(x, y, TAMANHO, cor);
        } else if(Math.random() > 0.5) {
            this.figura = new Triangulo(x + TAMANHO/2,
                y, x, y + TAMANHO, x + TAMANHO, y + TAMANHO, cor); 
        } else {
            this.figura = new Circulo(x + TAMANHO/2,
                y + TAMANHO/2, TAMANHO/2, cor);
        }
    }

    /*
     * Faz o movimento do alienígena em um intervalo de tempo dt
     * em segundos
     */
    public boolean mover(double dt) {
        if(this.vivo) {
            // this é a instância na qual o método foi chamado
            figura.mover(vx * dt, vy * dt);
            return (vx > 0 && figura.cantoDireito(Jogo.LARGURA)) ||
                (vx < 0 && figura.cantoEsquerdo());
        }
        return false;
    }
    
    public static void inverter() {
        vx = -vx;
    }
    
    public void desenhar(Tela tela) {
        if(this.vivo) {
            figura.desenhar(tela);
        }
    }
    
    public void morrer() {
        this.vivo = false;
    }
    
    public boolean colidiu(Tiro t) {
        return vivo && figura.colidiu(t.figura);
    }

    public boolean pousou() {
        return figura.cantoInferior(Jogo.ALTURA);
    }
}



