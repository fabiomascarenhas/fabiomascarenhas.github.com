import java.awt.Rectangle;

public class Retangulo implements Figura
{
    private double x;
    private double y;
    private int largura;
    private int altura;
    private Cor cor;
    
    public Retangulo(double x, double y, int largura,
        int altura, Cor cor) {
            this.x = x;
            this.y = y;
            this.largura = largura;
            this.altura = altura;
            this.cor = cor;
    }
    
    public void mover(double dx, double dy) {
        x += dx;
        y += dy;
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
    
    public boolean cantoEsquerdo() {
        return x <= 0;
    }

    public boolean cantoSuperior() {
        return y <= 0;
    }
    
    public boolean cantoDireito(int largura) {
       return x + this.largura >= largura;
    }
    
    public boolean cantoInferior(int altura) {
        return y + this.altura >= altura;
    }
    
    public boolean colidiu(Figura f) {
        Rectangle c = f.getCaixa();
        return c.intersects(this.getCaixa());
    }
    
    public Rectangle getCaixa() {
        return new Rectangle(
            (int)Math.round(x), 
            (int)Math.round(y), 
            (int)Math.round(largura),
            (int)Math.round(altura));
    }
    
}
