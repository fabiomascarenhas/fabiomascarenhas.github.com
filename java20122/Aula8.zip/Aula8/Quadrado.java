import java.awt.Rectangle;

public class Quadrado implements Figura
{
    private double x;
    private double y;
    private int lado;
    private Cor cor;
    
    public Quadrado(double x, double y, int lado, Cor cor) {
        this.x = x;
        this.y = y;
        this.lado = lado;
        this.cor = cor;
    }
    
    public void mover(double dx, double dy) {
        x += dx;
        y += dy;
    }
    
    public void desenhar(Tela t) {
        t.quadrado(x, y, lado, cor);
    }
    
    public boolean cantoEsquerdo() {
        return x <= 0;
    }
    
    public boolean cantoSuperior() {
        return y <= 0;
    }
    
    public boolean cantoDireito(int largura) {
       return x + lado >= largura;
    }
    
    public boolean cantoInferior(int altura) {
        return y + lado >= altura;
    }
    
    public boolean colidiu(Figura f) {
        Rectangle c = f.getCaixa();
        return c.intersects(this.getCaixa());
    }
    
    public Rectangle getCaixa() {
        return new Rectangle(
            (int)Math.round(x), 
            (int)Math.round(y), 
            (int)Math.round(lado),
            (int)Math.round(lado));
    }
}
