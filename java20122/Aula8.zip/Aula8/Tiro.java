
/**
 * Tiro do canhão
 */
public class Tiro
{
    public Figura figura;
    // De onde esse tiro saiu
    private Canhao origem;
    // Vivo ou morto
    private boolean vivo = true;
    
    // Velocidade de *todos* os tiros
    private static double vy = -Jogo.ALTURA/3;
    public static int ALTURA = 5;
    public static int LARGURA = 2;
    
    public Tiro(Canhao origem, double x, double y) {
        this.figura = new Retangulo(x, y, LARGURA, ALTURA, new Cor("branco"));
        this.origem = origem;
    }
    
    public void desenhar(Tela tela) {
        if(this.vivo) {
            figura.desenhar(tela);
        }
    }
    
    public void mover(double dt, Alien[] aliens) {
        if(this.vivo) {
            figura.mover(0, vy * dt);
            for(Alien alien: aliens) {
                if(alien.colidiu(this)) {
                    this.vivo = false;
                    alien.morrer();
                    origem.pontue();
                }
            }
        }
    }
    
    public void morra() {
        this.vivo = false;
    }
}
