/** Automatically generated file. DO NOT MODIFY */
package com.example.buscatwitter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}