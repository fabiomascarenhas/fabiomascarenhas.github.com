package com.example.buscatwitter;

import android.os.Bundle;
import android.os.Handler;
import android.app.Activity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.widget.EditText;
import android.widget.ListView;

public class BuscaTwitter extends Activity {
	private Handler handler;
	private Runnable buscador;
	private ListView listaTweets;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_busca_twitter);
		listaTweets = (ListView)this.findViewById(R.id.listaTweets);
		EditText textoBusca = (EditText)this.findViewById(R.id.textBusca);
		handler = new Handler();
		textoBusca.addTextChangedListener(new TextWatcher() {
			@Override
			public void afterTextChanged(Editable arg0) {
			}

			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1,
					int arg2, int arg3) {
			}

			@Override
			public void onTextChanged(CharSequence t, int arg1, int arg2,
					int arg3) {
				final String texto = t.toString();
				if(buscador != null)
					handler.removeCallbacks(buscador);
				buscador = new Runnable() {
					@Override
					public void run() {
						new TarefaBusca(listaTweets).execute(texto);
					}
				};
				handler.postDelayed(buscador, 2000);
			}
			
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_busca_twitter, menu);
		return true;
	}

}
