package com.example.buscatwitter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.ListView;

public class TarefaBusca extends AsyncTask<String,Void,List<Tweet>> {
	private ListView lista;
	
	public TarefaBusca(ListView lista) {
		this.lista = lista;
	}
	
	@Override
	protected List<Tweet> doInBackground(String... termos) {
		Busca b;
		try {
			b = new Busca(termos[0]);
			Log.d("SUCESSO", b.toString());
			return b.getTweets();
		} catch (IOException e) {
			Log.d("ERRO", e.toString());
			return new ArrayList<Tweet>();
		}
	}
	
	@Override
	protected void onPostExecute(List<Tweet> tweets) {
		ListaTweetsAdapter lta = (ListaTweetsAdapter)lista.getAdapter();
		if(lta == null) {
			lta = new ListaTweetsAdapter(tweets);
			lista.setAdapter(lta);
		} else
			lta.setTweets(tweets);
	}

}
