package com.example.buscatwitter;

import java.util.List;

import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;

public class ListaTweetsAdapter extends BaseAdapter {
	private List<Tweet> tweets;
	
	public ListaTweetsAdapter(List<Tweet> tweets) {
		this.tweets = tweets;
	}
	
	public void setTweets(List<Tweet> tweets) {
		this.tweets = tweets;
		this.notifyDataSetChanged();
	}
	
	@Override
	public int getCount() {
		return tweets.size();
	}

	@Override
	public Object getItem(int i) {
		return tweets.get(i);
	}

	@Override
	public long getItemId(int i) {
		return i;
	}

	@Override
	public View getView(int i, View view, ViewGroup pai) {
		if(view == null) {
			view = new WebView(pai.getContext());
		}
		StringBuffer buf = new StringBuffer();
		Tweet t = tweets.get(i);
		buf.append("<table><tr><td><img src = \"");
		buf.append(t.getFoto());
		buf.append("\"></td><td><b>@");
		buf.append(t.getUsuario());
		buf.append("</b> ");
		buf.append(t.getTexto());
		buf.append("</td></tr></table>");
		((WebView)view).loadData(buf.toString(), "text/html; charset=UTF-8", null);
		return view;
	}

}
