package com.example.buscatwitter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

public class Busca {
	private List<Tweet> tweets;
	
	public Busca(String termo) throws IOException {
		URL url = new URL("http://search.twitter.com/search.json?q="
					+ URLEncoder.encode(termo, "UTF-8"));
		BufferedReader entrada = new BufferedReader(
				new InputStreamReader(url.openStream()));
		tweets = new ArrayList<Tweet>();
		leTweets(entrada.readLine());
	}
	
	void leTweets(String entrada) {
		Log.d("DEBUG", entrada);
		try {
			JSONObject resultado = new JSONObject(entrada);
			JSONArray jstweets = resultado.getJSONArray("results");
			for(int i = 0; i < jstweets.length(); i++)
				tweets.add(new Tweet(jstweets.getJSONObject(i)));
		} catch (JSONException e) {
		}
	}
	
	public List<Tweet> getTweets() {
		return tweets;
	}
}
