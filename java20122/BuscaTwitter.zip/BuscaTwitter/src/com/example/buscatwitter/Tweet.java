package com.example.buscatwitter;

import org.json.JSONException;
import org.json.JSONObject;

public class Tweet {
	private String usuario;
	private String texto;
	private String foto;
	
	public Tweet(JSONObject json) {
		try {
			usuario = json.getString("from_user");
			texto = json.getString("text");
			foto = json.getString("profile_image_url");
		} catch (JSONException e) {
			usuario = "erro";
			texto = "Erro: " + e.toString();
			foto = null;
		}
	}

	public String getUsuario() {
		return usuario;
	}

	public String getTexto() {
		return texto;
	}

	public String getFoto() {
		return foto;
	}

}
