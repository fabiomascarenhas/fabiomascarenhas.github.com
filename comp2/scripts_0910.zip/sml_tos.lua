local casef = require "casefunc"

local tos = casef("tos", tostring)

function tos.stats(node, ident)
    local out = {}
    for _, stat in ipairs(node.seq) do
        out[#out+1] = tos(stat, ident)
    end
    return table.concat(out)
end

function tos.params(node)
    local out = {}
    for _, id in ipairs(node.seq) do
        out[#out+1] = tostring(id)
    end
    return table.concat(out, ", ")
end

function tos.exps(node)
    local out = {}
    for _, exp in ipairs(node.seq) do
        out[#out+1] = tos(exp)
    end
    return table.concat(out, ", ")
end

tos["while"] = function (node, ident)
    local out = {
        (" "):rep(ident), "while ", tos(node.cond), " do\n",
        tos(node.body, ident+4),
        (" "):rep(ident) .. "end\n"
    }
    return table.concat(out)
end

tos["if"] = function (node, ident)
    local out = {
        (" "):rep(ident), "if ", tos(node.cond), " then\n",
        tos(node["then"], ident+4) 
    }
    if node["else"] then
        out[#out+1] = (" "):rep(ident) .. "else\n"
        out[#out+1] = tos(node["else"], ident+4)
    end
    out[#out+1] = (" "):rep(ident) .. "end\n"
    return table.concat(out)
end

function tos.def(node, ident)
    return (" "):rep(ident) .. "local " .. node.var ..
        " = " .. tos(node.exp) .. "\n"
end

function tos.func(node, ident)
    return (" "):rep(ident) .. "function " .. node.name ..
        "(" .. tos(node.params) .. ")\n" ..
        tos(node.body, ident+4) .. (" "):rep(ident) .. "end\n"
end

function tos.lmb(node)
    return "function " ..
        "(" .. tos(node.params) .. ")\n" ..
        tos(node.body, 4) .. "end"
end

function tos.num(node)
    return tostring(node.val)
end

function tos.str(node)
    return string.format("%q", node.text)
end

function tos.id(node)
    return tostring(node.name)
end

tos["true"] = function (node) return "true" end

tos["false"] = function (node) return "false" end

tos["return"] = function (node, ident)
    return (" "):rep(ident) .. "return " .. tos(node.exp) .. "\n"
end

function tos.call(node, ident)
    local func = tos(node.func)
    if node.func.tag ~= "id" then
        func = "(" .. func .. ")"
    end
    if ident then
        return (" "):rep(ident) .. func .. 
            "(" .. tos(node.args) .. ")\n"
    else
        return "(" .. func .. "(" .. tos(node.args) .. "))"
    end
end

function tos.set(node, ident)
    return (" "):rep(ident) .. 
        tos(node.lval) .. 
        " = " .. tos(node.rval) .. "\n"
end

function tos.add(node)
    return "(" .. tos(node.left) .. 
        " + " .. tos(node.right) .. ")"
end

function tos.sub(node)
    return "(" .. tos(node.left) .. 
        " - " .. tos(node.right) .. ")"
end

function tos.mul(node)
    return "(" .. tos(node.left) .. 
        " * " .. tos(node.right) .. ")"
end

function tos.div(node)
    return "(" .. tos(node.left) .. 
        " / " .. tos(node.right) .. ")"
end

function tos.lt(node)
    return "(" .. tos(node.left) .. 
        " < " .. tos(node.right) .. ")"
end

function tos.concat(node)
    return "(" .. tos(node.left) .. 
        " .. " .. tos(node.right) .. ")"
end

function tos.eq(node)
    return "(" .. tos(node.left) .. 
        " == " .. tos(node.right) .. ")"
end
function tos.neq(node)
    return "(" .. tos(node.left) .. 
        " ~= " .. tos(node.right) .. ")"
end

tos["or"] = function (node)
    return "(" .. tos(node.left) .. 
        " or " .. tos(node.right) .. ")"
end

tos["not"] = function (node)
    return "(not " .. tos(node.exp) .. ")"
end

tos["and"] = function (node)
    return "(" .. tos(node.left) .. 
        " and " .. tos(node.right) .. ")"
end

return tos
