local sml = require "sml"
local tos = require "sml_tos"
local fixpos = require "fixpos"

local PROG = [[
    local cond = true or false and true

    function fat(n)
        local f = 1
        while 0 < n do
            f = f * n
            n = n - 1       
        end
        return f
    end

    function fat_rec(n)
        if n < 2 then
            return 1
        else
            return n * fat(n-1)
        end
    end

    (function (x) print("Fat:" .. tostring(fat(x))) end)(5)
]]

local prog = assert(sml.compile(PROG))

print(prog)
print(tos(prog, 0))
