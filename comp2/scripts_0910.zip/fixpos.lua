local casef = require "casefunc"

local function pos_to_lincol(input, toks, pos)
   pos = #toks - pos + 1
   pos = #input - toks:byte(pos).pos + 1
   local lin = 1
   local last = 1
   input = input:sub(1, pos)
   local br = string.find(input, "\n")
   while br do
       lin = lin + 1
       last = last + br
       input = input:sub(br+1, #input)
       br = string.find(input, "\n")
   end
   return lin, pos - last + 1
end

local function fixpos_self(node, input, toks)
    local lin, col = pos_to_lincol(input, toks, node.pos)
    node.pos = nil
    node.lin = lin
    node.col = col
end

local fixpos = casef("fixpos", fixpos_self)

local function fixpos_seq(node, input, toks)
    local out = {}
    for _, node in ipairs(node.seq) do
        fixpos(node, input, toks)
    end
end

fixpos.stat = fixpos_seq
fixpos.params = fixpos_seq
fixpos.exp = fixpos_seq

fixpos["while"] = function (node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.cond, input, toks)
    fixpos(node.body, input, toks)
end

fixpos["if"] = function (node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.cond, input, toks)
    fixpos(node["then"], input, toks)
    if node["else"] then
        fixpos(node["else"], input, toks)
    end
end

function fixpos.def(node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.exp, input, toks)
end

function fixpos.func(node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.body, input, toks)
end

function fixpos.lmb(node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.body, input, toks)
end

fixpos["return"] = function (node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.exp, input, toks)
end

function fixpos.call(node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.func, input, toks)
    fixpos(node.args, input, toks)
end

function fixpos.set(node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.rval, input, toks)
end

local function fixpos_binop(node, input, toks)
    fixpos_self(node, input, toks)
    fixpos(node.left, input, toks)
    fixpos(node.right, input, toks)
end

fixpos.add = fixpos_binop
fixpos.sub = fixpos_binop
fixpos.mul = fixpos_binop
fixpos.div = fixpos_binop
fixpos.lt = fixpos_binop
fixpos.eq = fixpos_binop
fixpos.neq = fixpos_binop
fixpos.concat = fixpos_binop
fixpos["or"] = fixpos_binop
fixpos["and"] = fixpos_binop
fixpos["not"] = fixpos_binop

return fixpos
