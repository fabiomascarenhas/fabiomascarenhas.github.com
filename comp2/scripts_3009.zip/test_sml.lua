local sml = require "sml"

local PROG = [[
    local cond = true or false and true

    function fat(n)
        local f = 1
        while 0 < n do
            f = f * n
            n = n - 1       
        end
        return f
    end

    (function (x) print("Fat:" .. tostring(fat(x))) end)(5)
]]

local prog = assert(sml.compile(PROG))

print(prog:byte(1))
print(prog:byte(2))
print(prog:byte(3))
