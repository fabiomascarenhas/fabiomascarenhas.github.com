--local ast = require "ast"
local scanp = require "scanp"
local classes = require "charclass"
local peg = require "cpeg"

local M = { foo = 10 }

local F = {}

F.idbegin = classes.is_idbegin
F.idrest = classes.is_idrest
F.space = classes.is_space
F.digit = classes.is_digit
F.any = classes.is_any

function F.numt(toks)
    local tok = toks:byte(1)
    local l = tok.lexeme
    local s = tostring(l)
    local n = tonumber(s)
    return n
    --return ast.num{ n = n }
end

function F.idt(toks)
    local tok = toks:byte(1)
    local l = tostring(tok.lexeme)
    return M[l]
    --return ast.id{ nome = l}
end

function F.numc(l)
    local s = tostring(l)
    local n = tonumber(s)
    return n
    --return ast.num{ n = n }
end

function F.idc(l)
    return M[l]
    --return ast.id{ nome = l}
end

local function binop(tag)
    return function ()
               return function (n1, n2)
                          return ast[tag]{
                                    left = n1,
                                    right = n2
                                 }
                      end
           end
end

--F.plus = binop("add")
F.plus = function () return function (n1, n2) return n1 + n2 end end
--F.minus = binop("sub")
F.minus = function () return function (n1, n2) return n1 - n2 end end
--F.times = binop("mul")
F.times = function () return function (n1, n2) return n1 * n2 end end
--F.div = binop("div")
F.div = function () return function (n1, n2) return n1 / n2 end end
--F.pow = binop("pow")
F.pow = function () return function (n1, n2) return n1 ^ n2 end end

function F.chain(seed, ...)
    local seq = { ... }
    for i = 1, #seq, 2 do
        local op, termo = seq[i], seq[i+1]
        seed = op(seed, termo)
    end
    return seed
end

local EXP = [[
  prog <- exp "eof"
  exp  <- (term (aop term)*) -> chain
  term <- (fac (mop fac)*) -> chain
  fac  <- (simp ("^" -> pow simp)*) -> chain
  simp <- {"number"} -> numt / {"id"} -> idt / "(" exp  ")"
  aop  <- "+" -> plus / "-" -> minus
  mop  <- "*" -> times / "/" -> div
]]

local EXP_SL = [[
  -- parte léxica
  SPACES <- [space]*
  NUMBER <- SPACES {[digit] [digit]*}
  ID     <- SPACES {[idbegin] [idrest]*}
  PLUS   <- SPACES '+'
  TIMES  <- SPACES '*'
  DIV    <- SPACES '/'
  MINUS  <- SPACES '-'
  POW    <- SPACES '^'
  PARE   <- SPACES '('
  PARD   <- SPACES ')'
  
  -- parte sintática
  prog <- exp SPACES ![any]
  exp  <- (term (aop term)*) -> chain
  term <- (fac (mop fac)*) -> chain
  fac  <- (simp (POW -> pow simp)*) -> chain
  simp <- NUMBER -> numc / ID -> idc / PARE exp PARD
  aop  <- PLUS -> plus / MINUS -> minus
  mop  <- TIMES -> times / DIV -> div
]]


--local mypeg = assert(peg.compile(EXP_SL, F))
local mypeg = assert(peg.compile(EXP, F))

local toks = scanp.scan("  10-20+5*(30-foo)/2")
--local toks = "  10-20+5*(30-foo)/2"
local root = assert(peg.parse(mypeg.prog, toks))

print(root)

--[[
add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}

add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}

add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}
]]
