local classes = require "charclass"
local parser = require "cparser"

local token = parser.token
local P = parser.promise
local C = parser.cap

local space = parser.class(classes.is_space) +
             (parser.char('-') * parser.char('-') * 
              parser.poss(parser.class(function (char)
                                           return char ~= 10
                                       end)))

-- 0 ou mais espaços
local spaces = parser.poss(space)

local non_squote = parser.class(function (char)
                                    return char ~= ("'"):byte()
                                end)

local non_dquote = parser.class(function (char)
                                    return char ~= ('"'):byte()
                                end)

local strs = parser.seq(spaces, parser.char("'"),
                        C(parser.poss(non_squote)),
                        parser.char("'")) / 
             function (s)
                 return tostring(s)
             end
          
local strd = parser.seq(spaces, parser.char('"'),
                        C(parser.poss(non_dquote)),
                        parser.char('"')) /
             function (s)
                 return tostring(s)
             end
                         
local idbegin = parser.class(classes.is_idbegin)

local idrest = parser.class(classes.is_idrest)

local id = spaces * C(idbegin * parser.poss(idrest)) /
           function (s)
               return tostring(s)
           end

local function symb(str, nonfollow)
    if nonfollow then
        return spaces * parser.char(str) * parser.pnot(nonfollow)
    else
        return spaces * parser.char(str)
    end
end

local seta = symb("<-")
local setad = symb("->")
local barra = symb("/")
local excl = symb("!")
local pare = symb("(")
local pard = symb(")")
local star = symb("*")

-- / é ação semântica, + é escolha ordenada
local exp
local prom_exp = parser.promise(function () return exp end)
local simp = strs / function (res)
                        return parser.char(res)
                    end +
             strd / function (res)
                        return parser.token(res)
                    end +
             parser.extra * id * parser.pnot(seta) /
                 function(extra, res)
                    return parser.promise(function ()
                                              return extra.G[res]
                                          end)
                 end +
             symb("#") /
                 function ()
                     return parser.pos
                 end +
             symb("$") /
                 function ()
                     return parser.extra
                 end +
             symb("{") * prom_exp * symb("}") /
                 function (res)
                     return parser.cap(res)
                 end +
             parser.extra * symb("[") * id * symb("]") /
                 function (extra, res)
                     return parser.class(extra.F[res])
                 end +
             pare * prom_exp * pard
                  
local many = simp * star / function (res)
                               return parser.many(res)
                           end + simp
                  
local pred = excl * many / function(res)
                               return parser.pnot(res)
                           end + many
              
local bind = parser.extra * pred * parser.many(setad * id) /
                  function (extra, res, ...)
                     local funcs = { ... }
                     for _, func in ipairs(funcs) do
                         res = parser.action(res, extra.F[func])
                     end
                     return res
                  end
              
local term = parser.chainr(bind, parser.char('') / 
                                 function ()
                                     return function(par1, par2)
                                                return par1 * par2
                                            end                
                                 end)                               
                               
exp = parser.chainr(term, barra / function()
                                     return function(par1, par2)
                                        return par1 + par2
                                     end
                                  end)

local prod = parser.extra * id * seta * exp /
             function (extra, naoterm, pexp)
                 extra.G[naoterm] = pexp
                 return pexp
             end

local peg = prod * parser.many(prod) * spaces * parser.pnot(parser.class(classes.is_any)) /
            function (pexp)
               return exp
            end

local function pos_to_lincol(input, pos)
   local lin = 1
   local last = 1
   input = input:sub(1, pos)
   local br = string.find(input, "\n")
   while br do
       lin = lin + 1
       last = last + br
       input = input:sub(br+1, #input)
       br = string.find(input, "\n")
   end
   return lin, pos - last + 1
end

local IGNORE = { [classes.is_space] = true }
local TRANS = { [classes.is_idbegin] = "idbegin",
    [classes.is_idrest] = "idrest", [classes.is_digit] = "digit",
    [classes.is_any] = "any" }

local function set_tos(set, ignore, trans)
    local t = {}
    for x, _ in pairs(set) do
        if not ignore[x] then
            t[#t+1] = trans[x] or x
        end
    end
    return "{ " .. table.concat(t, ", ") .. " }"
end

-- Executa o parser passado em "peg" usando
-- a entrada dada, e a tabela de definições
-- extras
-- Retorna a primeira captura do parser
-- em caso de sucesso, ou nil e a mensagem
-- de erro em caso de erro de sintaxe
local function parse(peg, input, extra)
    local state = { pos = #input, follow = {}, extra = extra }
    local res, nstate = peg(input, state)
    if not res or #res[2] > 0 then
        local pos = #input - nstate.pos + 1
        local lin, col = pos_to_lincol(input, pos)
        return nil, "erro no caractere " .. input:sub(pos, pos) ..
            " na linha " .. lin .. " coluna " .. col ..
            ", esperados " .. set_tos(nstate.follow, IGNORE, TRANS)
    else
        return res[1]:byte(1, #res[1])
    end
end

-- Como parse, mas retorna o resultado puro,
-- sem processá-lo para detectar erros
local function rawparse(peg, input, extra)
    local state = { pos = #input, follow = {}, extra = extra }
    return peg(input, state)
end

-- Compila a PEG dada pela gramática grammar,
-- usando as definições na tabela defs para
-- classes de caracteres e ações semânticas
-- Retorna a gramática compilada caso não
-- haja erros de sintaxe, ou nil e a mensagem
-- de erro
local function compile(grammar, defs)
    local extra = { G = {}, F = defs }
    local res, error = parse(peg, grammar, extra)
    if res then
        return extra.G
    else
        return nil, error
    end
end


return { compile = compile, parse = parse, rawparse = rawparse }
