local Seq = require "seq"
local vector = require "vector"
local tuple = require "tuple"
local parser = {}

function parser:__call(...)
    return self[1](...)
end

local function new(f)
    return setmetatable({ f }, parser)
end

local function fail(input, state, terminal)
    local novo_nsuf = #input
    if novo_nsuf < state.pos then
        return nil, { pos = novo_nsuf, 
                      follow = { [terminal] = true }, 
                      extra = state.extra }
    elseif novo_nsuf == state.pos then
        state.follow[terminal] = true
        return nil, state
    else
        return nil, state
    end
end

-- reconhece um caractere ou strings
local function char(c)
    return new(function (input, state)
                   local n = #c
                   for i = 1, n do
                       local byte = input:byte(i)
                       if not byte or byte ~= c:byte(i) then
                           return fail(input, state, c)
                       end
                   end
                   return tuple(Seq:new{}, input:sub(n+1)), state
               end)
end

-- reconhece uma classe de caracteres
local function class(p)
    return new(function (input, state)
                   local byte = input:byte(1)
                   if byte and p(byte) then
                       return tuple(Seq:new{}, input:sub(2)), state
                   else
                       return fail(input, state, p)
                   end
               end)
end


-- reconhece um tipo de token
local function token(t)
    return new(function (input, state)
                   local tok = input:byte(1)
                   if tok and tok.type == t then
                       return tuple(Seq:new{}, input:sub(2)), state
                   else
                       return fail(input, state, t)
                   end
               end)
end

-- sequência passando o resultado (^)
local function bind(p, f)
    return new(function (input, state1)
                   local res, state2 = p(input, state1)
                   if res then
                       res, state2 = f(res[1])(res[2], state2)
                   end
                   return res, state2
               end)
end

parser.__pow = bind

-- não consome nada, apenas gera um resultado
local function unit(x)
    return new(function (input, state)
                   return tuple(x, input), state
               end)
end

-- sequência combinando resultados em um par
local function seq(p1, p2)
    return p1 ^ function (caps1)
                     return p2 ^ function (caps2)
                                     return unit(caps1 .. caps2)
                                 end
                 end
end

parser.__mul = seq

-- sequência combinando resultados (*)
local function seqn(p, ...)
    local ps = { p, ... }
    local seed = ps[#ps]
    for i = #ps-1, 1, -1 do
        seed = ps[i] * seed
    end
    return seed
end

-- escolha ordenada (+)
local function ochoice(p1, p2)
    return new(function (input, state1)
                   local res, state2 = p1(input, state1)
                   if res then
                       return res, state2
                   else
                       return p2(input, state2)
                   end
               end)
end

local choice = ochoice
parser.__add = choice

-- repetição possessiva
local function poss(p)
    -- p * poss(p) + unit()
    return (p ^ function (caps1)
                    return poss(p) ^ function (caps2)
                                         return unit(caps1 .. caps2)
                                     end
                end) + unit(Seq:new{})
end

local many = poss

-- prom é uma função que dá um parser
local function promise(prom)
    local p
    return new(function (input, state)
                   p = p or prom()
                   return p(input, state)
               end)
end

local function pnot(p)
    return new(function (input, state1)
                   local res, state2 = p(input, state1)
                   if res then
                       return nil, state2
                   else
                       return unit(Seq:new{})(input, state1)
                   end
               end)
end

local function cap(p)
    return new(function (input, state1)
                   local res, state2 = p(input, state1)
                   if res then
                       local caps = res[1]
                       local rest = res[2]
                       local prefix = 
                           input:sub(1, #input - #rest)
                       return tuple(caps .. 
                                 Seq:new{ prefix }, rest), state2
                   else
                       return nil, state2
                   end
               end)
end

-- captura a posição atual (quantos elementos no sufixo)
local pos = new(function (input, state)
                    return tuple(Seq:new{ #input }, input), state
                end)

-- captura o estado "extra"
local extra = new(function (input, state)
                      return tuple(Seq:new{ state.extra }, input), state
                  end)

-- ação semântica com capturas (/)
local function action(p, f)
    return p ^ function (caps)
                   local ncaps = Seq:new{ f(caps:byte(1, #caps)) } 
                   return unit(ncaps)
               end
end

parser.__div = action

local function chainl(p, op)
    local function rest(caps1)
        return seq(op, p) ^ function (caps2)
                                local e1 = caps1:byte(1)
                                local f, e2 = caps2:byte(1, 2)
                                return rest(Seq:new{f(e1, e2)}) 
                            end + unit(caps1)
    end    
    return p ^ rest
end

local function chainr(p, op)
    return p ^ function (caps1)
                   return seq(op, chainr(p, op)) ^ 
                          function (caps2)
                              local e1 = caps1:byte(1)
                              local f, e2 = caps2:byte(1, 2)
                              return unit(Seq:new{f(e1, e2)})
                          end + unit(caps1)
               end
end


return { new = new, class = class, token = token, char = char,
    bind = bind, unit = unit, seq = seqn, choice = choice,
    ochoice = ochoice, many = many, poss = poss,
    promise = promise, pnot = pnot, cap = cap, action = action,
    chainl = chainl, chainr = chainr, pos = pos, extra = extra }

