local token = {}

local function new(type, lexeme, pos)
    return setmetatable({ type = type, lexeme = lexeme, pos = pos }, token)
end

function token:__tostring()
    if self.lexeme then
        return self.type .. "(" .. tostring(self.lexeme) .. ")"
    else
        return self.type
    end
end

return new
