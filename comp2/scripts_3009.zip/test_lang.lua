local ast = require "ast"
local classes = require "charclass"
local peg = require "cpeg"

local F = {}

F.idbegin = classes.is_idbegin
F.idrest = classes.is_idrest
F.space = classes.is_space
F.digit = classes.is_digit
F.any = classes.is_any

local LANG = [[
  -- parte léxica
  SPACES <- [space]*
  NUMBER <- SPACES [digit] [digit]*
  ID     <- !KW SPACES [idbegin] [idrest]*
  PLUS   <- SPACES '+'
  TIMES  <- SPACES '*'
  DIV    <- SPACES '/'
  MINUS  <- SPACES '-'
  PARE   <- SPACES '('
  GT     <- SPACES '>'
  PARD   <- SPACES ')'
  EQ     <- SPACES '='
  WHILE  <- SPACES 'while' ![idrest]
  END    <- SPACES 'end' ![idrest]
  DO     <- SPACES 'do' ![idrest]
  KW     <- WHILE / END / DO
  EOF    <- SPACES ![any]
  
  prog  <- bloco EOF
  bloco <- stat*
  stat  <- WHILE exp DO bloco END / ID EQ exp
  exp   <- aexp GT aexp / aexp
  aexp  <- term (aop term)*
  term  <- fac (mop fac)*
  fac   <- NUMBER / ID / PARE exp PARD
  aop   <- PLUS / MINUS
  mop   <- TIMES / DIV
]]

local mypeg = assert(peg.compile(LANG, F))

local PROG = [[
    n = 5
    f = 1
    while n > 0 do
        f = f * n
        n = n + 1       
    end
]]

local _, err = peg.parse(mypeg.prog, PROG)

if err then print(err) end

