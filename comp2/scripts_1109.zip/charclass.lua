local tochar = string.byte

local M = {}

function M.is_space(char)
	return char == tochar(' ') or 
           char == tochar('\n') or
           char == tochar('\r') or
           char == tochar('\t')
end

function M.is_digit(char)
	return char >= tochar('0') and
		   char <= tochar('9')
end

function M.is_idbegin(char)
	return (char >= tochar('a') and
		    char <= tochar('z')) or
           (char >= tochar('A') and
            char <= tochar('Z')) or
           char == tochar('_')
end

function M.is_idrest(char)
	return M.is_digit(char) or M.is_idbegin(char)
end

return M
