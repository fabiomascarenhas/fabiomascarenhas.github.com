local parser = require "dparser"
local scanp = require "scanp"
local class = require "charclass"
local ast = require "ast"

local number = parser.token("number") ^ function (tok)
                                            local l = tok.lexeme
                                            local s = tostring(l)
                                            local n = tonumber(s)
                                            return parser.unit(ast.num{ n = n })
                                        end
                                        
local id = parser.token("id") ^ function(tok)
                                    local l = tostring(tok.lexeme)
                                    return parser.unit(
                                        ast.id{ nome = l})
                                end

local function binop(tok, tag)
    return parser.token(tok) ^
           function (_)
               return parser.unit(function (n1, n2)
                                      return ast[tag]{
                                                 left = n1,
                                                 right = n2
                                             }
                                  end)
           end
end

local plus = binop("+", "add")
local minus = binop("-", "sub")
local mult = binop("*", "mul")
local div = binop("/", "div")

--[[
  exp  -> exp aop term | term
  term -> term mop fac | fac
  fac  -> number | id | '(' exp ')'
  aop -> '+' | '-'
  mop -> '*' | '/'
]]

local exp = nil
-- promessa para parexp
local function parexp()
    return parser.seq(parser.token("("), exp, parser.token(")")) ^
                      function(res)
                          return parser.unit(res[2])
                      end
end
local fac = number / id / parser.promise(parexp)
local term = parser.chainl(fac, mult / div)
exp = parser.chainl(term, plus / minus)

local toks = scanp.scan("  10+20*(30-foo)/2")
local root = exp(toks)

print(toks)
print(root)
