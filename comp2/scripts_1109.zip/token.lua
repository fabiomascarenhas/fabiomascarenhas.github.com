local token = {}

local function new(type, lexeme)
    return setmetatable({ type = type, lexeme = lexeme }, token)
end

function token:__tostring()
    if self.lexeme then
        return self.type .. "(" .. tostring(self.lexeme) .. ")"
    else
        return self.type
    end
end

return new
