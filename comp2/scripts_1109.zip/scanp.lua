
local Seq = require "seq"
local classes = require "charclass"
local parser = require "dparser"
local token = require "token"

local function str_to_vec(s)
    local vec = {}
    for i = 1, #s do
        vec[i] = s:byte(i)
    end
    return vec
end

local TESTE_SEQ = Seq:new(str_to_vec([[
"foo\n"3236 100.0 foo _ f12    end if . .. = 
== ++ -- comentário fora
for while
]]), '', '', string.char, '')

local TESTE_STR = [[
"foo\n"3236 100.0 foo _ f12    end if . .. = 
== ++ fora
for while
]]

local KEYWORDS = {
    ["function"] = true,
    ["end"] = true,
    ["for"] = true,
    ["while"] = true,
    ["local"] = true,
    ["true"] = true,
    ["and"] = true,
    ["false"] = true,
    ["else"] = true,
    ["if"] = true,
    ["elseif"] = true,
    ["not"] = true,
    ["nil"] = true,
    ["or"] = true,
    ["return"] = true,
    ["then"] = true,
    ["do"] = true
}

local space = parser.class(classes.is_space) /
             (parser.char('-') * parser.char('-') * 
              parser.poss(parser.class(function (char)
                                           return char ~= 10
                                       end)))

-- 0 ou mais espaços
local spaces = parser.poss(space)

-- 1 dígito
local digit = parser.class(classes.is_digit)

-- 1 ou mais dígitos
local digits = (digit * parser.poss(digit, '', '', string.char, '')) ^
               function (par)
                   local fst = par[1]
                   local rest = par[2]
                   return parser.unit(string.char(fst) .. rest)
               end

local real = parser.seq(digits, parser.char('.'), digits) ^ 
             function (res)
                 local lexem = res[1] .. string.char(res[2]) .. res[3]
                 return parser.unit(token('number', lexem))
             end

local integer = digits ^ function (seq)
                             return parser.unit(token("number", seq))
                         end

local number = real / integer

local idbegin = parser.class(classes.is_idbegin)

local idrest = parser.class(classes.is_idrest)

local idorkw = (idbegin * parser.poss(idrest, '', '', string.char, '')) ^
               function (par)
                   local fst, rest = par()
                   local lexema = string.char(fst) .. rest
                   if KEYWORDS[tostring(lexema)] then
                       return parser.unit(token(tostring(lexema)))
                   else
                       return parser.unit(token("id", lexema))
                   end
               end

local str = parser.seq(parser.char('"'),
                       parser.poss(parser.class(function (char)
                                                    return char ~=
                                                           ('"'):byte()
                                                end), '', '', string.char, ''),
                       parser.char('"')) ^
            function (trip)
                local s, m, e = trip()
                return parser.unit(token("string",
                                         string.char(s) .. m .. string.char(e)))
            end

local function symb(str)
    local chars = {}
    for i = 1, #str do
        chars[i] = parser.char(str:sub(i, i))
    end
    return parser.seq(table.unpack(chars)) ^
           function (tuple)
               return parser.unit(token(str))
           end
end

local equals = symb("==")

local noteq = symb("~=")

local concat = symb("..")

local any = parser.class(function (_) return true end)

local op = any ^ function (res)
                     return parser.unit(token(string.char(res)))
                 end

local eof = parser.unit(token("eof"))

local scan = spaces ^ function (_)
                          return idorkw / number / str / equals /
                                 noteq / concat / op / eof
                      end

local function all_tokens(seq)
    local toks = {}
    repeat
        local tok, rest = scan(seq)()
        toks[#toks+1] = tok
        seq = rest
    until tok.type == "eof"
    return Seq:new(toks)
end

return { TESTE_SEQ = TESTE_SEQ, TESTE_STR = TESTE_STR,
         token = scan, scan = all_tokens, spaces = spaces,
         number = number, idorkw = idorkw, symb = symb }
