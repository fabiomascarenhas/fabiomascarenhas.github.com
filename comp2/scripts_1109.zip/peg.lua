local scanp = require "scanp"
local parser = require "dparser"

local token = parser.token
local P = parser.promise

--[[
  exp  <- term (aop term)*
  term <- fac (mop fac)*
  fac  <- 'number' / 'id' / '(' exp ')'
  aop  <- '+' / '-'
  mop  <- '*' / '/'
]]

local G = {}

function G.exp()
    --return P(G.exp) * P(G.aop) * P(G.term) + P(G.term)
    return P(G.term) * parser.many(P(G.aop) * P(G.term))
end

function G.term()
    return P(G.fac) * parser.many(P(G.mop) * P(G.fac))
end

function G.fac()
    return token("number") + token("id") + 
       token('(') * P(G.exp) * token(')')
end

function G.aop()
    return token('+') + token('-')
end    

function G.mop()
    return token('*') + token('/')
end    

local toks = scanp.scan("  10+20*(30-foo)/2")
local root = P(G.exp)(toks)

print(toks)
print(root)

