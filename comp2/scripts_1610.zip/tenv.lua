local ptype = require "printtype"

local TypeEnv = {}
TypeEnv.__index = TypeEnv

function TypeEnv:new(t)
    t = t or {}
    return setmetatable(t, self)
end

function TypeEnv:extend(name, type)
    return TypeEnv:new({ [name] = type, ["$next"] = self }) 
end

function TypeEnv:lookup(name, lin, col)
    if self[name] then
        return self[name]
    end
    if self["$next"] then
        return self["$next"]:lookup(name, lin, col)
    end
    error("nome " .. name .. " não encontrado na linha " .. lin ..
        " coluna " .. col)
end

function TypeEnv:__tostring()
    local out = {}
    for name, type in pairs(self) do
        if name ~= "$next" then
            out[#out+1] = name .. ": " .. ptype(type)
        end
    end
    if self["$next"] then
        out[#out+1] = tostring(self["$next"])
    end
    return table.concat(out, ", ")
end

return TypeEnv
