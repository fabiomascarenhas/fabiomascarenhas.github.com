local casef = require "casefunc"

local ptype = casef("print_type", tostring)

function ptype.tnum(t)
    return "number"
end

function ptype.tstr(t)
    return "string"
end

function ptype.tbool(t)
    return "boolean"
end

function ptype.tunit(t)
    return "()"
end

function ptype.types(ts)
    local out = {}
    for _, t in ipairs(ts.seq) do
        out[#out+1] = ptype(t)
    end
    return table.concat(out, ", ")
end

function ptype.tfunc(t)
    return "(" .. ptype(t.params) .. ")->" .. ptype(t.ret)
end

return ptype
