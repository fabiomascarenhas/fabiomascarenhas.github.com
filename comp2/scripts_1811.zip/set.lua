local Set = {}
Set.__index = Set

function Set:new(...)
    local s = {}
    for _, elem in ipairs{ ... } do
        s[#s+1] = elem
    end
    return setmetatable(s, self)
end

function Set:add(...)
    return self:addAll{ ... }
end

function Set:addAll(oset)
    for _, elem in ipairs(oset) do
        if not self:contains(elem) then
            self[#self+1] = elem
        end
    end
    return self
end

function Set:contains(e)
    for i, elem in ipairs(self) do
        if elem == e then
            return i
        end
    end
    return false
end

function Set:removeAll(oset)
    for _, elem in ipairs(oset) do
        local i = self:contains(elem)
        if i then
            table.remove(self, i)
        end
    end
    return self
end

function Set:remove(...)
    return self:removeAll{ ... }
end

function Set:__tostring()
    local elems = {}
    for _, elem in pairs(self) do
        if type(elem) == "string" then
            elems[#elems+1] = elem
        else
            elems[#elems+1] = elem.name .. " has " .. 
               tostring(elem.tags)
        end
    end
    return "<" .. table.concat(elems, ", ") .. ">"
end

return Set
