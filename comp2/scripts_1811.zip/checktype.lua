local casef = require "casefunc"
local ast = require "ast"
local Seq = require "seq"
local Set = require "set"
local ptype = require "printtype"
local tequal = require "eqtype"
local tparams = require "tparams"
local tvars = require "tvars"
local TypeEnv = require "tenv"
local replace = require "reptype"
local unify = require "unify"
local concrete = require "concrete"
local constrain = require "constrain"

local checkprim = {}

local function prune(t)
    if t.tag == "tvar" and t.type then
        return prune(t.type)
    else
        return t
    end
end

local function generalize(t, tenv)
    if t.tag ~= "tgen" then
        local params = Set:new():addAll(tparams(t)):
                                 removeAll(tenv:params())
        local vars = Set:new():addAll(tvars(t)):
                                 removeAll(tenv:vars())
        local r = {}
        for i, var in ipairs(vars) do
            var.type = ast.tparam{ name = "t" .. i, tags = var.tags }
            params:add({ name = "t" .. i, tags = var.tags })
        end
        if #params > 0 then
            return ast.tgen{ lin = t.lin, col = t.col,
                             params = params, type = concrete(t) }
        end
    end
    return t
end

local function especialize(tgen, tother, lin, col)
    tgen = prune(tgen)
    if tgen.tag ~= "tgen" then
        return tgen
    end
    local r = {}
    for _, param in ipairs(tgen.params) do
        if type(param) == "string" then
            r[param] = ast.tvar{ tags = Set:new() }
        else
            r[param.name] = ast.tvar{ tags = param.tags }
        end
    end
    local t = replace(tgen.type, r)
    unify(t, tother, lin, col)
    return concrete(t)
end

local function especialize_func(tgen, targs, lin, col)
    tgen = prune(tgen)
    if tgen.tag ~= "tgen" then
        return tgen
    end
    if not tgen.type.tag == "tfunc" then
        error("esperado função, mas dado " .. ptype(tgen.type) ..
              " na linha " .. lin .. " coluna " .. col)
    end
    local r = {}
    for _, param in ipairs(tgen.params) do
        if type(param) == "string" then
            r[param] = ast.tvar{ tags = Set:new() }
        else
            r[param.name] = ast.tvar{ tags = param.tags }
        end
    end
    local tfunc = replace(tgen.type, r)
    local tother = ast.tfunc{
            params = ast.types{ seq = Seq:new(targs) },
            ret = tfunc.ret
        }
    unify(tfunc, tother, lin, col)
    return concrete(tfunc) -- elimina variáveis
end

function checkprim.seq(targs, lin, col)
    if #targs == 0 then
        return generalize(ast.tseq{ lin = lin, col = col,
                                    elem = ast.tparam{ lin = lin,
                                                       col = col,
                                                       name = "a" } },
                          TypeEnv:new())
    end
    local tprimeiro = targs[1]
    for i = 2, #targs do
        unify(tprimeiro, especialize(targs[i], tprimeiro, lin, col),
              lin, col)
    end
    return ast.tseq{ lin = lin, col = col, elem = tprimeiro }
end

local checktype = casef("checktype")

function checktype.stats(node, tenv)
    local t
    for _, cmd in ipairs(node.seq) do
        t, tenv = checktype(cmd, tenv)
        if t.tag ~= "tunit" then
            return t, tenv
        end
    end
    return t, tenv
end

checktype["while"] = function (node, tenv)
    local tcond = checktype(node.cond, tenv)
    unify(tcond, ast.tbool{}, node.lin, node.col)
    checktype(node.body, tenv)
    return ast.tunit{ lin = node.lin, col = node.col }, tenv
end

checktype["if"] = function (node, tenv)
    local tcond = checktype(node.cond, tenv)
    unify(tcond, ast.tbool{}, node.lin, node.col)
    local tthen, _ = checktype(node["then"], tenv)
    if node["else"] then
        local telse, _ = checktype(node["else"], tenv)
        if tthen.tag ~= "tunit" and telse.tag ~= "tunit" then 
            return tthen, tenv
        end 
    end
    return ast.tunit{ lin = node.lin, col = node.col }, tenv
end

function checktype.def(node, tenv)
    return ast.tunit{ lin = node.lin, col = node.col },
           tenv:extend(node.var, 
               generalize(checktype(node.exp, tenv), tenv))
end

function checktype.func(node, tenv)
    local tenvb = tenv
    local ptypes = {}
    for _, prm in ipairs(node.params.seq) do
        tenvb = tenvb:extend(prm.name, prm.type)
        ptypes[#ptypes+1] = prm.type
    end
    local tfunc = ast.tfunc{ lin = node.lin,
                   col = node.col, ret = node.tret,
                   params = ast.types{ seq = Seq:new(ptypes) } }
    local tprms = tparams(tfunc)
    tenvb = tenvb:extend(node.name, tfunc)
    tenvb = tenvb:extend("$ret", node.tret)
    local tret = checktype(node.body, tenvb)
    unify(tret, node.tret, node.lin, node.col)
    return ast.tunit{ lin = node.lin, col = node.col },
           tenv:extend(node.name, generalize(tfunc, tenv))
end

function checktype.lmb(node, tenv)
    local tenvb
    local ptypes = {}
    for _, prm in ipairs(node.params.seq) do
        tenvb = tenv:extend(prm.name, prm.type)
        ptypes[#ptypes+1] = prm.type
    end
    tenvb = tenvb:extend("$ret", node.tret)
    local tret = checktype(node.body, tenvb)
    unify(tret, node.tret, node.lin, node.col)
    return ast.tfunc{ lin = node.lin,
                      col = node.col, ret = node.tret,
                      params = ast.types{ seq = Seq:new(ptypes) } }
end

checktype["return"] = function (node, tenv)
    local t = checktype(node.exp, tenv)
    local tret = tenv:lookup("$ret", node.lin, node.col)
    unify(tret, t, node.lin, node.col)
    return t, tenv
end

function checktype.call(node, tenv)
    local targs = checktype(node.args, tenv)
    local tfunc = especialize_func(checktype(node.func, tenv),
                                   targs, node.lin, node.col)
    if tfunc.tag == "tprim" then
        return checkprim[tfunc.prim](targs, node.lin, node.col), tenv
    else
        local tother = ast.tfunc{
                params = ast.types{ seq = Seq:new(targs) },
                ret = ast.tvar{ tags = Set:new() }
            }
        unify(tfunc, tother, node.lin, node.col)
        return concrete(tother.ret), tenv
    end
end

function checktype.exps(node, tenv)
    local targs = {}
    for _, arg in ipairs(node.seq) do
        targs[#targs + 1] =  checktype(arg, tenv)
    end
    return targs
end

function checktype.set(node, tenv)
    local trval = checktype(node.rval, tenv)
    local tlval = tenv:lookup(node.lval, node.lin, node.col)
    unify(tlval, trval, node.lin, node.col)
    return ast.tunit{ lin = node.lin, col = node.col }, tenv
end

function checktype.num(node, tenv)
    return ast.tnum{ lin = node.lin, col = node.col }
end

function checktype.str(node, tenv)
    return ast.tstr{ lin = node.lin, col = node.col }
end

function checktype.id(node, tenv)
    return tenv:lookup(node.name, node.lin, node.col)
end

checktype["true"] = function (node, tenv)
    return ast.tbool{ lin = node.lin, col = node.col }
end

checktype["false"] = function (node, tenv)
    return ast.tbool{ lin = node.lin, col = node.col }
end

local function checktype_arith(node, tenv)
    local tleft = checktype(node.left, tenv)
    unify(tleft, ast.tnum{}, node.lin, node.col)
    local tright = checktype(node.right, tenv)
    unify(tright, ast.tnum{}, node.lin, node.col)
    return ast.tnum{ lin = node.lin, col = node.col }
end

local function checktype_rel(node, tenv)
    local tleft = checktype(node.left, tenv)
    unify(tleft, ast.tnum{}, node.lin, node.col)
    local tright = checktype(node.right, tenv)
    unify(tright, ast.tnum{}, node.lin, node.col)
    return ast.tbool{ lin = node.lin, col = node.col }
end

local function checktype_log(node, tenv)
    local tleft = checktype(node.left, tenv)
    unify(tleft, ast.tbool{}, node.lin, node.col)
    local tright = checktype(node.right, tenv)
    unify(tright, ast.tbool{}, node.lin, node.col)
    return ast.tbool{ lin = node.lin, col = node.col }
end

checktype.add = checktype_arith
checktype.sub = checktype_arith
checktype.mul = checktype_arith
checktype.div = checktype_arith

checktype.lt = checktype_rel
checktype.neq = checktype_rel

checktype["or"] = checktype_log
checktype["and"] = checktype_log

checktype["not"] = function (node, tenv)
    local texp = checktype(node.exp, tenv)
    unify(texp, ast.tbool{}, node.lin, node.col)
    return ast.tbool{ lin = node.lin, col = node.col }
end

function checktype.eq(node, tenv)
    local tleft = checktype(node.left, tenv)
    constrain(tleft, "eq", node.lin, node.col)
    local tright = checktype(node.right, tenv)
    constrain(tright, "eq", node.lin, node.col)
    unify(tleft, tright, node.lin, node.col)
    return ast.tbool{ lin = node.lin, col = node.col }
end

function checktype.concat(node, tenv)
    local tleft = prune(checktype(node.left, tenv))
    local tright = prune(checktype(node.right, tenv))
    if tleft.tag == "tgen" and tright.tag ~= "tgen" then
        tleft = especialize(tleft, tright, node.lin, node.col)
    end
    if tright.tag == "tgen" and tleft.tag ~= "tgen" then
        tright = especialize(tright, tleft, node.lin, node.col)
    end
    constrain(tleft, "concat", node.lin, node.col)
    constrain(tright, "concat", node.lin, node.col)
    unify(tleft, tright, node.lin, node.col)
    return tleft
end

return checktype
