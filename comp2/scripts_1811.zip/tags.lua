local ast = require "ast"
local Set = require "set"

local tags = {}

tags.eq = Set:new("tnum", "tstr", "tbool")
tags.concat = Set:new("tstr", "tseq")

return tags
