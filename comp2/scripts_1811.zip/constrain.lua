local casef = require "casefunc"
local ptype = require "printtype"
local rename = require "rentype"
local tags = require "tags"

local pconst = casef("constrain",
      function (t, tag, lin, col)
         if not tags[tag]:contains(t.tag) then
             error("tipo " .. ptype(t) ..
                   " não suporta tag " ..
                   tag .. " na linha "
                   .. lin .. 
                   " coluna " .. col)
         end
      end)
                         
local function prune(t)
    if t.tag == "tvar" and t.type then
        return prune(t.type)
    else
        return t
    end
end
       
local function constrain(t, tag, lin, col)
    t = prune(t)
    pconst(t, tag, lin, col)
end
       
function pconst.tvar(t, tag, lin, col)
    t.tags:add(tag)
end

function pconst.tparam(t, tag, lin, col)
    if not t.tags:contains(tag) then
        error("parâmetro de tipo " .. ptype(t) ..
            " não está restrito pela tag " .. tag ..
            " na linha " .. lin .. " coluna " .. col)
    end
end

function pconst.tgen(t, tag)
    return constrain(t.type, tag)
end

return constrain

