local casef = require "casefunc"
local ast = require "ast"
local Seq = require "Seq"
local ptype = require "printtype"
local tequal = require "eqtype"

local checkprim = {}

function checkprim.seq(targs, lin, col)
    if #targs == 0 then
        error("sequência não pode ser vazia na linha " .. lin ..
              " coluna " .. col)
    end
    local tprimeiro = targs[1]
    for i = 2, #targs do
        if not tequal(tprimeiro, targs[i]) then
            error("tipo do elemento " .. i .. " (" .. targs[i] ..
                  ") incompatível " .. " com " .. tprimeiro ..
                  " na linha " .. lin .. " coluna " .. col)
        end
    end
    return ast.tseq{ lin = lin, col = col, elem = tprimeiro }
end

function checkprim.byte(targs, lin, col)
    if #targs ~= 2 then
        error("byte espera 2 argumentos e foram passados " ..
              #targs .. " na linha " .. lin .. " coluna " .. col)
    end
    if targs[1].tag ~= "tseq" then
        error("primeiro argumento de byte é " .. ptype(targs[1]) ..
              " ao invés de sequência na linha " .. lin ..
              " coluna " .. col)
    end
    if not tequal(targs[2], "tnum") then
        error("segundo argumento de byte é " .. ptype(targs[2]) ..
              " ao invés de number na linha " .. lin ..
              " coluna " .. col)
    end
    return targs[1].elem
end

function checkprim.sub(targs, lin, col)
    if #targs ~= 3 then
        error("sub espera 3 argumentos e foram passados " ..
              #targs .. " na linha " .. lin .. " coluna " .. col)
    end
    if targs[1].tag ~= "tseq" then
        error("primeiro argumento de sub é " .. targs[1] ..
              " ao invés de sequência na linha " .. lin ..
              " coluna " .. col)
    end
    if not tequal(targs[2], "tnum") then
        error("segundo argumento de sub é " .. targs[2] ..
              " ao invés de number na linha " .. lin ..
              " coluna " .. col)
    end
    if not tequal(targs[3], "tnum") then
        error("terceiro argumento de sub é " .. targs[3] ..
              " ao invés de number na linha " .. lin ..
              " coluna " .. col)
    end
    return targs[1]
end

local checktype = casef("checktype")

function checktype.stats(node, tenv)
    local t
    for _, cmd in ipairs(node.seq) do
        t, tenv = checktype(cmd, tenv)
        if not tequal(t, "tunit") then
            return t, tenv
        end
    end
    return t, tenv
end

checktype["while"] = function (node, tenv)
    local tcond = checktype(node.cond, tenv)
    if not tequal(tcond, "tbool") then
        error("condição do while não é booleana na linha " ..
            node.lin .. " coluna " .. node.col)
    end
    checktype(node.body, tenv)
    return ast.tunit{ lin = node.lin, col = node.col }, tenv
end

checktype["if"] = function (node, tenv)
    local tcond = checktype(node.cond, tenv)
    if not tequal(tcond, "tbool") then
        error("condição do if não é booleana na linha " ..
            node.lin .. " coluna " .. node.col)
    end
    local tthen, _ = checktype(node["then"], tenv)
    if node["else"] then
        local telse, _ = checktype(node["else"], tenv)
        if not tequal(tthen, "tunit") and
           not tequal(telse, "tunit") then
            return tthen, tenv
        end 
    end
    return ast.tunit{ lin = node.lin, col = node.col }, tenv
end

function checktype.def(node, tenv)
    return ast.tunit{ lin = node.lin, col = node.col },
           tenv:extend(node.var, checktype(node.exp, tenv))
end

function checktype.func(node, tenv)
    local tenvb = tenv
    local ptypes = {}
    for _, prm in ipairs(node.params.seq) do
        tenvb = tenvb:extend(prm.name, prm.type)
        ptypes[#ptypes+1] = prm.type
    end
    local tfunc = ast.tfunc{ lin = node.lin,
                   col = node.col, ret = node.tret,
                   params = ast.types{ seq = Seq:new(ptypes) } }
    tenvb = tenvb:extend(node.name, tfunc)
    tenvb = tenvb:extend("$ret", node.tret)
    local tret = checktype(node.body, tenvb)
    if not tequal(tret, node.tret) then
        error("nem todos os caminhos estão retornando " ..
            ptype(node.tret) .. " na função na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    return ast.tunit{ lin = node.lin, col = node.col },
           tenv:extend(node.name, tfunc)
end

function checktype.lmb(node, tenv)
    local tenvb
    local ptypes = {}
    for _, prm in ipairs(node.params.seq) do
        tenvb = tenv:extend(prm.name, prm.type)
        ptypes[#ptypes+1] = prm.type
    end
    tenvb = tenvb:extend("$ret", node.tret)
    local tret = checktype(node.body, tenvb)
    if not tequal(tret, node.tret) then
        error("nem todos os caminhos estão retornando " ..
            node.tret .. " na função na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    return ast.tfunc{ lin = node.lin,
                      col = node.col, ret = node.tret,
                      params = ast.types{ seq = Seq:new(ptypes) } }
end

checktype["return"] = function (node, tenv)
    local t = checktype(node.exp, tenv)
    local tret = tenv:lookup("$ret", node.lin, node.col)
    if not tequal(tret, t) then
        error("tipo da expressão do return " .. ptype(t) .. 
            " não bate com tipo de retorno " .. ptype(tret) ..
            " na linha " .. node.lin .. " coluna " .. node.col)
    end
    return t, tenv
end

function checktype.call(node, tenv)
    local tfunc = checktype(node.func, tenv)
    local targs = checktype(node.args, tenv)
    if tfunc.tag == 'tfunc' then 
        if #tfunc.params.seq == #targs then
            for pos, tparam in ipairs(tfunc.params.seq) do
                if not tequal(tparam, targs[pos]) then
                   error("o tipo do parametro " .. ptype(tparam) ..
                    " não bate com tipo do argumento " .. 
                    ptype(targs[pos]) ..
                    " sendo o argumento " .. pos .. " na linha " ..
                    node.lin .." coluna " .. node.col)
                end        
            end
            return tfunc.ret, tenv
        else 
             error("o numero de parametros não bate, era esperado " ..
                #tfunc.params.seq .. ", mas foi passado " ..#targs .. 
                " na linha" .. node.lin .." coluna " .. node.col)
        end
    elseif tfunc.tag == "tprim" then
        return checkprim[tfunc.prim](targs, node.lin, node.col), tenv
    else
        error("não é uma função, é " .. ptype(tfunc)..
            " na linha " .. node.lin
              .." coluna " .. node.col)
    end    
end

function checktype.exps(node, tenv)
    local targs = {}
    for _, arg in ipairs(node.seq) do
        targs[#targs + 1] =  checktype(arg, tenv)
    end
    return targs
end

function checktype.set(node, tenv)
    local trval = checktype(node.rval, tenv)
    local tlval = tenv:lookup(node.lval, node.lin, node.col)
    if tequal(trval, tlval) then
       return ast.tunit{ lin = node.lin, col = node.col },
              tenv
    else
        error("tipo do lado direito " .. ptype(trval) .. 
            " não bate com tipo do lado esquerda " .. ptype(tlval) ..
            " na linha " .. node.lin .. " coluna " .. node.col)
    end
end

function checktype.num(node, tenv)
    return ast.tnum{ lin = node.lin, col = node.col }
end

function checktype.str(node, tenv)
    return ast.tstr{ lin = node.lin, col = node.col }
end

function checktype.id(node, tenv)
    return tenv:lookup(node.name, node.lin, node.col)
end

checktype["true"] = function (node, tenv)
    return ast.tbool{ lin = node.lin, col = node.col }
end

checktype["false"] = function (node, tenv)
    return ast.tbool{ lin = node.lin, col = node.col }
end

local function checktype_arith(node, tenv)
    local tleft = checktype(node.left, tenv)
    if not tequal(tleft, "tnum") then
        error("tipo do operando esquerdo da operação aritm. " ..
            tleft .. " não é número na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    local tright = checktype(node.right, tenv)
    if not tequal(tright, "tnum") then
        error("tipo do operando direito da operação aritm. " ..
            tleft .. " não é número na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    return ast.tnum{ lin = node.lin, col = node.col }
end

local function checktype_rel(node, tenv)
    local tleft = checktype(node.left, tenv)
    if not tequal(tleft, "tnum") then
        error("tipo do operando esquerdo da operação rel. " ..
            tleft .. " não é número na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    local tright = checktype(node.right, tenv)
    if not tequal(tright, "tnum") then
        error("tipo do operando direito da operação rel. " ..
            tleft .. " não é número na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    return ast.tbool{ lin = node.lin, col = node.col }
end

local function checktype_log(node, tenv)
    local tleft = checktype(node.left, tenv)
    if not tequal(tleft, "tbool") then
        error("tipo do operando esquerdo da operação lógica " ..
            tleft .. " não é booleano na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    local tright = checktype(node.right, tenv)
    if not tequal(tright, "tbool") then
        error("tipo do operando direito da operação lógica " ..
            tleft .. " não é booleano na linha " .. node.lin ..
            " coluna " .. node.col)
    end
    return ast.tbool{ lin = node.lin, col = node.col }
end

checktype.add = checktype_arith
checktype.sub = checktype_arith
checktype.mul = checktype_arith
checktype.div = checktype_arith

checktype.lt = checktype_rel
checktype.eq = checktype_rel
checktype.neq = checktype_rel

checktype["or"] = checktype_log
checktype["and"] = checktype_log

checktype["not"] = function (node, tenv)
end

function checktype.concat(node, tenv)
    local tleft = checktype(node.left, tenv)
    local tright = checktype(node.right, tenv)
    if tleft.tag == "tseq" or tright.tag == "tseq" then
        if not tequal(tleft, tright) then
            error("tipos não batem na concatenação, lado esquerdo " ..
                ptype(tleft) .. " e lado direito " .. 
                ptype(tright)  ..
                " na linha " .. node.lin .. " coluna " .. node.col)
        end
    else
        if not tequal(tleft, "tstr") then
            error("tipo do operando esquerdo da concatenação " ..
                tleft .. " não é string na linha " .. node.lin ..
                " coluna " .. node.col)
        end
        if not tequal(tright, "tstr") then
            error("tipo do operando direito da concatenação " ..
                tleft .. " não é string na linha " .. node.lin ..
                " coluna " .. node.col)
        end
    end
    return tleft, tenv
end

return checktype
