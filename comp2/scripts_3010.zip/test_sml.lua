local sml = require "sml"
local tos = require "sml_tos"
local ct = require "checktype"
local env = require "tenv"
local ast = require "ast"
local Seq = require "seq"

local PROG = [[
    local cond = true or false and true

    function fat(n: number): number
        local f = 1
        while 0 < n do
            f = f * n
            n = n - 1     
        end
        return f
    end

    function fat_rec(n: number): number
        if n < 2 then
            return 1
        else
            return n * fat_rec(n-1)
        end
    end
    
    function f(s: string, g: (string)->number): string
        return tostring(g(s))
    end
   
    local nums = seq(1, 2, 3)
    
    local x = byte(nums, 2)
    
    local snums = sub(nums, 1, 2)
    
    nums = nums .. snums
    
    --nums = nums .. seq("foo")
    
    function segundo(s: { { number } }): {number}
        return byte(s, 2)
    end
    
    local _ = (function (x: number): () print("Fat:" ..
               tostring(fat(x))) end)(5)
]]

local prog = assert(sml.compile(PROG))

print(prog)
print(tos(prog, 0))

local tenv = env:new{ tostring = ast.tfunc{
        params = ast.types{ seq = Seq:new{ ast.tnum{} } },
        ret = ast.tstr{} }, print = ast.tfunc{
        params = ast.types{ seq = Seq:new{ ast.tstr{} } },
        ret = ast.tunit{} },
        seq = ast.tprim{ prim = "seq" },
        sub = ast.tprim{ prim = "sub" },
        byte = ast.tprim{ prim = "byte" } }
    
print(ct(prog, tenv))

