local Set = require "set"
local casef = require "casefunc"

local tparams = casef("tparams", function () return Set:new() end)

function tparams.tfunc(t)
    return Set:new():addAll(tparams(t.params)):addAll(tparams(t.ret))
end

function tparams.tseq(t)
    return tparams(t.elem)
end

function tparams.types(ts)
    local ps = Set:new()
    for _, t in ipairs(ts.seq) do
        ps:addAll(tparams(t))
    end
    return ps
end

function tparams.tparam(t)
    return Set:new(t.name)
end

function tparams.tgen(t)
    return Set:new():addAll(tparams(t.type)):removeAll(t.params)
end

return tparams
