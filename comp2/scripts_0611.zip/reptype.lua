local Seq = require "seq"
local casef = require "casefunc"
local ast = require "ast"

local replace = casef("replace", function (t, r) return t end)

function replace.tfunc(t, r)
    return ast.tfunc{ lin = t.lin, pos = t.pos,
                      params = ast.types{ seq = replace(t.params, r) },
                      ret = replace(t.ret, r) }
end

function replace.tseq(t, r)
    return ast.tseq{ lin = t.lin, pos = t.pos,
                     elem = replace(t.elem, r) }
end

function replace.tparam(t, r)
    if r[t.name] then
        return r[t.name]
    else
        return t
    end
end

function replace.types(ts, r)
    local out = {}
    for _, t in ipairs(ts.seq) do
        out[#out+1] = replace(t, r)
    end
    return Seq:new(out)
end

function replace.tgen(t, r)
    error("tipo paramétrico não deve aparecer aqui")
end

return replace

