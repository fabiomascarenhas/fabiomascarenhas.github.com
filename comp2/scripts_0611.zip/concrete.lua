local casef = require "casefunc"
local Seq = require "seq"
local ast = require "ast"

local concrete = casef("concrete", function (t) return t end)

function concrete.tvar(t)
    if not t.type then
        return t
    else
        return concrete(t.type)
    end
end

function concrete.tseq(t)
    return ast.tseq{ lin = t.lin, col = t.col,
                     elem = concrete(t.elem) }
end

function concrete.tfunc(t)
    return ast.tfunc{ lin = t.lin, col = t.col,
                      params = concrete(t.params),
                      ret = concrete(t.ret) }
end

function concrete.types(t)
    local s = Seq:new{}
    for _, t in ipairs(t.seq) do
        s = s .. Seq:new{ concrete(t) }
    end
    return ast.types{ seq = s }
end

return concrete