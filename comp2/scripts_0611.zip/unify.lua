local casef = require "casefunc"
local ptype = require "printtype"

local punify = casef("unify", function (t1, t2, lin, col)
                                  error("tipo " .. ptype(t1) ..
                                        " incompatível com " ..
                                        ptype(t2) .. " na linha "
                                        .. lin .. " coluna " .. col)
                              end)
                         
local function prune(t)
    if t.tag == "tvar" and t.type then
        return prune(t.type)
    else
        return t
    end
end
       
local function unify(t1, t2, lin, col)
    t1 = prune(t1)
    t2 = prune(t2)
    punify(t1, t2, lin, col)
end
       
function punify.tvar(t1, t2, lin, col)
    t1.type = t2
end

function punify.tparam(t1, t2, lin, col)
    if t2.tag == "tvar" then
       unify(t2, t1, lin, col)
    elseif t2.tag ~= "tparam" or t1.name ~= t2.name then
             error("tipo " .. ptype(t1) ..
                   " incompatível com " ..
                   ptype(t2) .. " na linha "
                   .. lin .. " coluna " .. col)
    end
end

local function unify_base(t1, t2, lin, col)
    if t2.tag == "tvar" then
       unify(t2, t1, lin, col)
    else
        if t1.tag ~= t2.tag then
             error("tipo " .. ptype(t1) ..
                   " incompatível com " ..
                   ptype(t2) .. " na linha "
                   .. lin .. " coluna " .. col)
        end
    end
end
       
punify.tstr = unify_base       
punify.tnum = unify_base       
punify.tbool = unify_base       
punify.tunit = unify_base
       
function punify.tfunc(t1, t2, lin, col)
    if t2.tag == "tvar" then
       unify(t2, t1, lin, col)
    elseif t2.tag ~= "tfunc" then
        error("tipo " .. ptype(t1) ..
               " incompatível com " ..
               ptype(t2) .. " na linha "
               .. lin .. " coluna " .. col)
    else
        unify(t1.params, t2.params, lin, col)
        unify(t1.ret, t2.ret, lin, col)
    end

end

function punify.tseq(t1, t2, lin, col)
    if t2.tag == "tvar" then
       unify(t2, t1, lin, col)
    elseif t2.tag ~= "tseq" then
        error("tipo " .. ptype(t1) ..
               " incompatível com " ..
               ptype(t2) .. " na linha "
               .. lin .. " coluna " .. col)
    else
        unify(t1.elem, t2.elem, lin, col)
    end
end

function punify.types(t1, t2, lin, col)
    if #t1.seq ~= #t2.seq then
        error("erro de aridade")
    else 
        for i = 1, #t1.seq do
            unify(t1.seq:byte(i), t2.seq:byte(i), lin, col)
        end
    end
end

return unify

