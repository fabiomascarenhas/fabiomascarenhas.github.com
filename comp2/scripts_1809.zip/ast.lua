local ast = {}
local node = {}

function ast:__index(key)
    self[key] = function (fields)
                    local t = setmetatable({ tag = key }, node)
                    for k, v in pairs(fields) do
                        t[k] = v
                    end
                    return t
                end
    return self[key]
end

function node:__tostring()
    local out = {}
    for k, v in pairs(self) do
        if k ~= "tag" then
            out[#out+1] = k .. " = " .. tostring(v)
        end
    end
    table.sort(out)
    return self.tag .. "{" .. table.concat(out, ", ") .. "}"
end

return setmetatable({}, ast)
