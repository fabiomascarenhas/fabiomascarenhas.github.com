local ast = require "ast"
local scanp = require "scanp"
local classes = require "charclass"
local parser = require "dparser"

local token = parser.token
local P = parser.promise

local G = {}
local F = {}

local space = parser.class(classes.is_space) /
             (parser.char('-') * parser.char('-') * 
              parser.poss(parser.class(function (char)
                                           return char ~= 10
                                       end)))

-- 0 ou mais espaços
local spaces = parser.poss(space)

local str = parser.seq(spaces, parser.char("'"),
                       parser.poss(parser.class(function (char)
                                                    return char ~=
                                                           ("'"):byte()
                                                end), '', '',
                                                string.char, ''),
                       parser.char("'")) ^
            function (quad)
                local _, s, m, e = quad()
                return parser.unit(tostring(m))
            end
            
local idbegin = parser.class(classes.is_idbegin)

local idrest = parser.class(classes.is_idrest)

local id = parser.seq(spaces, idbegin, 
                      parser.poss(idrest, '', '', string.char, '')) ^
               function (trip)
                   local _, fst, rest = trip()
                   return parser.unit(tostring(string.char(fst) .. rest))
               end

local function symb(str)
    local chars = {}
    for i = 1, #str do
        chars[i] = parser.char(str:sub(i, i))
    end
    return parser.seq(spaces, table.unpack(chars)) ^
           function (tuple)
               return parser.unit(str)
           end
end

local seta = symb("<-")
local setad = symb("->")
local barra = symb("/")
local excl = symb("!")
local pare = symb("(")
local pard = symb(")")
local star = symb("*")

local exp 
local simp = str ^ function(res)
                       return parser.unit(parser.token(res))
                   end
            /
            (id * parser.pnot(seta)) ^ function(res2)
                    return parser.unit(
                               parser.promise(function ()
                                                 return G[res2[1]]
                                              end))
                 end
            /
            parser.seq(pare, parser.promise(function () return exp end                          ),pard)
                ^ function(res3)
                      return parser.unit(res3[2])
                  end
                  
local many = (simp * star) ^ function (res)
                               return parser.unit(parser.many(res[1]))
                             end / simp
                  
local pred = (excl * many) ^ function(res)
                               return parser.unit(parser.pnot(res[2]))
                             end / many
              
local bind = parser.seq(pred, setad, id) ^
             function (res)
                 local pexp, _, func = res()
                 return parser.unit(pexp ^ F[func])
             end / pred
              
local term = parser.chainr(bind, parser.unit(function(par1, par2)
                                                 return par1 * par2
                                             end))
                               
                               
exp = parser.chainr(term, barra ^ function()
                                      return parser.unit(
                                              function(par1, par2)
                                                  return par1 / par2
                                              end
                                          )
                                  end)

local prod = parser.seq(id, seta, exp) ^
             function (res)
                 local naoterm, _, pexp = res()
                 G[naoterm] = pexp
                 return parser.unit(pexp)
             end

local peg = (prod * parser.many(prod)) ^ function (res)
                                             return parser.unit(res[1])
                                         end

function F.num(tok)
    local l = tok.lexeme
    local s = tostring(l)
    local n = tonumber(s)
    return parser.unit(ast.num{ n = n })
end

function F.id(tok)
    local l = tostring(tok.lexeme)
    return parser.unit(ast.id{ nome = l})
end

function F.cadr(par)
    return parser.unit(par[2][1])
end

local function binop(tag)
    return function (_)
               return parser.unit(function (n1, n2)
                                      return ast[tag]{
                                                 left = n1,
                                                 right = n2
                                             }
                                  end)
           end
end

F.plus = binop("add")
F.minus = binop("sub")
F.times = binop("mul")
F.div = binop("div")
F.exp = binop("exp")

function F.chain(par)
    local seed, seq = par()
    for i = 1, #seq do
        local elem = seq:byte(i)
        local op, termo = elem()
        seed = op(seed, termo)
    end
    return parser.unit(seed)
end

local EXP = [[
  exp  <- (term (aop term)*) -> chain
  term <- (fac (mop fac)*) -> chain
  fac  <- (simp ('^' -> exp simp)*) -> chain
  simp  <- 'number' -> num / 'id' -> id / ('(' exp ')') -> cadr
  aop  <- '+' -> plus / '-' -> minus
  mop  <- '*' -> times / '/' -> div
]]

print(peg(EXP))

local toks = scanp.scan("  10+20+5*(30-foo)/2")
local root = G.exp(toks)

print(toks)
print(root[1])
print(root[2])

--[[
add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}

add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}
]]

