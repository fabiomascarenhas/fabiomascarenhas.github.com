function print_array(a)
	print("{ " .. table.concat(a, ", ") .. " }")
end

function print_set(s)
	local buf = {}
	for x, b in pairs(s) do
		if b then
			buf[#buf+1] = tostring(x)
		end
	end
	print_array(buf)
end

function freq(pkg)
    package.loaded[pkg] = nil
    return require(pkg)
end

MT = {}

function MT.__index(t, k)
    return rawget(t, string.lower(k))
end

function MT.__newindex(t, k, v)
    rawset(t, string.lower(k), v)
end
