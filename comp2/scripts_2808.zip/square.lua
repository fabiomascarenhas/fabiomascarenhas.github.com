local Shape = require "shape"
local Square = setmetatable({}, Shape)
Square.__index = Square

function Square:new(x, y, side)
  local square = Shape.new(self, x, y)
  square.side = side
  return square
end

function Square:area()
  return self.side * self.side
end

function Square:tostring()
  return string.format("Square(%d,%d,%d)", self.x, self.y, self.side)
end

Square.__tostring = Square.tostring

return Square
