local M = {}

local mt = {}

function M.new(r, i)
  if i == 0 then
    return r
  else
    return setmetatable({ real = r or 0, im = i or 0 }, mt)
  end
end

function M.is_complex(t)
  return getmetatable(t) == mt
end

M.i = M.new(0, 1)

function M.add(c1, c2)
  if not M.is_complex(c1) then
    return M.new(c1 + c2.real, c2.im)
  end
  if not M.is_complex(c2) then
    return M.new(c1.real + c2, c1.im)
  end
  return M.new(c1.real + c2.real, c1.im + c2.im)
end

mt.__add = M.add

function M.mod(c)
  return math.sqrt(c.real * c.real + c.im * c.im)
end

mt.__len = M.mod

function M.tostring(c)
  return tostring(c.real) .. "+" .. tostring(c.im) .. "i"
end

mt.__tostring = M.tostring

function M.equal(c1, c2)
  return c1.real == c2.real and c1.im == c2.im
end

mt.__eq = M.equal

function M.lessthan(c1, c2)
    if not M.is_complex(c1) then
        return c1 < c2.real and c2.im > 0
    end
    if not M.is_complex(c2) then
        return c1.real < c2 and c1.im < 0
    end
    return c1.real < c2.real and c1.im < c2.im
end

mt.__lt = M.lessthan

function M.lessoreq(c1, c2)
    if not M.is_complex(c1) then
        return c1 <= c2.real and c2.im >= 0
    end
    if not M.is_complex(c2) then
        return c1.real <= c2 and c1.im <= 0
    end
    return c1.real <= c2.real and c1.im <= c2.im
end

mt.__le = M.lessoreq

return M
