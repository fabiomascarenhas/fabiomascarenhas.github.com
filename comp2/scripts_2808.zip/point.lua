local Shape = require "shape"
local Point = setmetatable({}, Shape)
Point.__index = Point

function Point:area()
    return 0
end

Point.__tostring = Point.tostring

return Point