local Shape = {}
Shape.__index = Shape

function Shape:new(x, y)
  return setmetatable({ x = x, y = y }, self)
end

function Shape:move(dx, dy)
  self.x = self.x + dx
  self.y = self.y + dy
end

function Shape:tostring()
  return string.format("Shape(%d,%d)", self.x, self.y)
end

Shape.__tostring = Shape.tostring

return Shape
