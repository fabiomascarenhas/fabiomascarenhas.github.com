local sml = require "sml"
local tos = require "sml_tos"
local ct = require "checktype"
local env = require "tenv"
local ast = require "ast"
local Seq = require "seq"
local Set = require "set"

local PROG = [[
    local cond = true or false and true

    function fat(n)
        local f = 1
        while 0 < n do
            f = f * n
            n = n - 1     
        end
        return f
    end

    function fat_rec(n)
        if n < 2 then
            return 1
        else
            return n * fat_rec(n-1)
        end
    end
    
    function f(s, g)
        return tostring(g(s))
    end
 
    -- tipo de f é <a,b>(a, (a)->b)->string
    -- tentamos unificar (X, (X)->Y)->string com
    --                   (number, (number)->string)->string
    print(f(5, function (x) return "foo" end))
 
    local nums = seq(1, 2, 3)
    
    local x = byte(nums, 2)
    
    local snums = sub(nums, 1, 2)
    
    nums = nums .. snums
    
    --nums = nums .. seq("foo")
    
    function aninhada(s1)
        function segundo(s2)
            return byte(s2, 2)
        end
        local x = segundo(sub(s1, 1, 2))
        local y = segundo(seq(1, 2))
        return segundo(s1)
    end
    
    function segundo(s: {a}): a
        return byte(s, 2)
    end
    
    function bar(x, z)
        local baz = function (y: a): a
                        return x
                    end
        local x = baz(z)            
        return 1
    end

    function primeiro(s)
        return byte(s, 1)
    end
    
    function foo(s)
        return byte(s, 1) + 0
    end
    
    local h = segundo
    h = primeiro
    
    -- tipo de h é <a>({a})->a
    -- tipo de nums é {number}
    -- tentamos unificar ({X})->X com ({number})->X
    -- descobrimos que X é number
    -- usamos ({number})->number como tipo de h
    print(h(nums))
    -- tipo de h é <a>({a})->a
    -- tipo de seq("foo", "bar") é {string}
    -- tentamos unificar ({X})->X com ({string})->X
    -- descobrimos que X é string
    -- usamos ({string})->string como tipo de h
    print(h(seq("foo", "bar")))
    
    --print(h(5))
    
    local empty = seq()
    
    -- tipo de segundo é igual ao tipo de primeiro?
        
    local _ = (function (x: number): () print("Fat:" ..
               tostring(fat(x))) end)(5)
]]

local prog = assert(sml.compile(PROG))

--print(prog)
--print(tos(prog, 0))

local tenv = env:new{ tostring = ast.tgen{
            params = Set:new("a"),
            type = ast.tfunc{
                   params = ast.types{ seq = Seq:new{ ast.tparam{ 
                               name = "a" } } },
                   ret = ast.tstr{} } }, 
        print = ast.tgen{
            params = Set:new("a"),
            type = ast.tfunc{
               params = ast.types{ seq = Seq:new{ 
                 ast.tparam{ name = "a" } } },
                 ret = ast.tunit{} } },
        seq = ast.tprim{ prim = "seq" },
        sub = ast.tgen{
            params = Set:new("a"),
            type = ast.tfunc{
                    params = ast.types{
                       seq =  Seq:new{
                           ast.tseq{ elem = ast.tparam{ name = "a" } },
                           ast.tnum{},
                           ast.tnum{}
                       }
                    },
                    ret = ast.tseq{ elem = ast.tparam{ name = "a" } }
                }
        },
        byte = ast.tgen{
            params = Set:new("a"),
            type = ast.tfunc{
                    params = ast.types{
                       seq =  Seq:new{
                           ast.tseq{ elem = ast.tparam{ name = "a" } },
                           ast.tnum{}
                       }
                    },
                    ret = ast.tparam{ name = "a" } 
                }
        } }
    
print(ct(prog, tenv, Set:new()))

