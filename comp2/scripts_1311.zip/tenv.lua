local ptype = require "printtype"
local tparams = require "tparams"
local tvars = require "tvars"
local Set = require "set"

local TypeEnv = {}
TypeEnv.__index = TypeEnv

function TypeEnv:new(t)
    t = t or {}
    return setmetatable(t, self)
end

function TypeEnv:extend(name, type)
    return TypeEnv:new({ [name] = type, ["$next"] = self }) 
end

function TypeEnv:lookup(name, lin, col)
    if self[name] then
        return self[name]
    end
    if self["$next"] then
        return self["$next"]:lookup(name, lin, col)
    end
    error("nome " .. name .. " não encontrado na linha " .. lin ..
        " coluna " .. col)
end

function TypeEnv:params()
    local ps = Set:new()
    for _, type in pairs(self) do
        ps:addAll(tparams(type))
    end
    if self["$next"] then
        ps:addAll(self["$next"]:params())
    end
    return ps
end

function TypeEnv:vars()
    local ps = Set:new()
    for _, type in pairs(self) do
        ps:addAll(tvars(type))
    end
    if self["$next"] then
        ps:addAll(self["$next"]:vars())
    end
    return ps
end

function TypeEnv:__tostring()
    local out = {}
    for name, type in pairs(self) do
        if name ~= "$next" then
            out[#out+1] = name .. ": " .. ptype(type)
        end
    end
    if self["$next"] then
        out[#out+1] = tostring(self["$next"])
    end
    return table.concat(out, ", ")
end

return TypeEnv
