local ast = require "ast"
local classes = require "charclass"
local peg = require "cpeg"
local token = require "token"
local Seq = require "Seq"
local fixpos = require "fixpos"

local FS = {}

local KEYWORDS = {
    ["function"] = true,
    ["end"] = true,
    ["for"] = true,
    ["while"] = true,
    ["local"] = true,
    ["true"] = true,
    ["and"] = true,
    ["false"] = true,
    ["else"] = true,
    ["if"] = true,
    ["elseif"] = true,
    ["not"] = true,
    ["nil"] = true,
    ["or"] = true,
    ["return"] = true,
    ["then"] = true,
    ["do"] = true,
    ["number"] = true,
    ["boolean"] = true,
    ["string"] = true
}

FS.idbegin = classes.is_idbegin
FS.idrest = classes.is_idrest
FS.space = classes.is_space
FS.digit = classes.is_digit
FS.any = classes.is_any

function FS.lbr(char)
    return char == string.byte('\n') or char == string.byte('\r')
end

function FS.num(pos, l)
    return token("num", l, pos)
end

function FS.idorkw(pos, l)
    local lex = tostring(l)
    if KEYWORDS[lex] then
        return token(lex, l, pos)
    else
        return token("id", l, pos)
    end
end

function FS.tok(pos, l)
    return token(tostring(l), l, pos)
end

function FS.str(pos, l)
    return token("str", l, pos)
end

function FS.eof()
    return token("eof")
end

function FS.collect(...)
    return Seq:new{ ... }
end

local SCAN = [[
  -- parte léxica
  SPACE  <- [space] / '-' '-' (![lbr] [any])*
  SPACES <- SPACE*
  NUMBER <- (# {[digit] [digit]*}) -> num
  IDORKW <- (# {[idbegin] [idrest]*}) -> idorkw
  STR    <- (# {'"' (!'"' [any])* '"'}) -> str
  ARROW  <- (# {'->'}) -> tok
  EQUALS <- (# {'=='}) -> tok
  NOTEQ  <- (# {'~='}) -> tok
  CONCAT <- (# {'..'}) -> tok
  OP     <- (# {[any]}) -> tok
  EOF    <- ![any] -> eof
  
  token  <- SPACES (IDORKW / NUMBER / STR / EQUALS / 
                    NOTEQ / CONCAT / ARROW / OP)
  tokens <- (token* SPACES EOF) -> collect
]]

local scanner = peg.compile(SCAN, FS)

--[[

GRAMÁTICA (PARSER)

]]

local FG = {}

function FG.num(pos, toks)
    local tok = toks:byte(1)
    local l = tok.lexeme
    local s = tostring(l)
    local n = tonumber(s)
    return ast.num{ pos = pos, val = n }
end

function FG.str(pos, toks)
    local tok = toks:byte(1)
    local l = tok.lexeme
    local s = tostring(l)
    return ast.str{ pos = pos, text = s:sub(2, #s-1) }
end

function FG.id(pos, toks)
    local tok = toks:byte(1)
    local l = tostring(tok.lexeme)
    return ast.id{ pos = pos, name = l }
end

local function binop(tag)
    return function ()
               return function (pos, n1, n2)
                          return ast[tag]{
                                    pos = pos,
                                    left = n1,
                                    right = n2
                                 }
                      end
           end
end

FG["or"] = binop("or")
FG["and"] = binop("and")
FG.concat = binop("concat")
FG.lt = binop("lt")
FG.eq = binop("eq")
FG.neq = binop("neq")
FG.plus = binop("add")
FG.minus = binop("sub")
FG.times = binop("mul")
FG.div = binop("div")
FG.pow = binop("pow")

function FG.chain(seed, ...)
    local seq = { ... }
    for i = 1, #seq, 3 do
        local pos, op, termo = seq[i], seq[i+1], seq[i+2]
        seed = op(pos, seed, termo)
    end
    return seed
end

function FG.collect_params(...)
    return ast.params{ seq = Seq:new{ ... } }
end

function FG.collect_exps(...)
    return ast.exps{ seq = Seq:new{ ... } }
end

function FG.collect_stats(...)
    return ast.stats{ seq = Seq:new{ ... } }
end

function FG.collect_types(...)
    return ast.types{ seq = Seq:new{ ... } }
end

FG["while"] = function (pos, exp, bloco)
    return ast["while"]{ pos = pos, cond = exp, body = bloco }
end

function FG.set(pos, toks, exp)
    local tid = toks:byte(1)
    local name = tostring(tid.lexeme)
    return ast.set{ pos = pos, lval = name, rval = exp }
end

function FG.def(pos, toks, exp)
    local tid = toks:byte(1)
    local name = tostring(tid.lexeme)
    return ast.def{ pos = pos, var = name, exp = exp }
end

function FG.func(pos, toks, params, tret, body)
    local tid = toks:byte(1)
    local name = tostring(tid.lexeme)
    return ast.func{ pos = pos, name = name,
                     params = params, body = body,
                     tret = tret }
end

FG["if"] = function (pos, cond, blocot, blocoe)
    return ast["if"]{ pos = pos, cond = cond,
                         ["then"] = blocot, ["else"] = blocoe  }
end

FG["return"] = function (pos, exp)
    return ast["return"]{ pos = pos, exp = exp }
end

function FG.nome(toks)
    local tid = toks:byte(1)
    local name = tostring(tid.lexeme)
    return name
end

function FG.negacao(pos, exp)
    return ast.minus{ pos = pos, right = exp,
                      left = ast.num{ pos = pos , val = 0 } }
end

FG["not"] = function (pos, exp)
    return ast["not"]{ pos = pos , exp = exp }
end

FG["true"] = function (pos)
    return ast["true"]{ pos = pos }
end

FG["false"] = function (pos)
    return ast["false"]{ pos = pos }
end

function FG.lmb(pos, params, tret, body)
    return ast.lmb{ pos = pos, params = params, body = body, 
        tret = tret }
end

function FG.call()
    return function (pos, f, args)
               return ast.call{ pos = pos, func = f, args = args }
           end
end

function FG.tnum(pos)
    return ast.tnum{ pos = pos }
end

function FG.tstr(pos)
    return ast.tstr{ pos = pos }
end

function FG.tbool(pos)
    return ast.tbool{ pos = pos }
end

function FG.tunit(pos)
    return ast.tunit{ pos = pos }
end

function FG.tseq(pos, t)
    return ast.tseq{ pos = pos, elem = t }
end

function FG.tfunc(pos, tparms, tret)
    return ast.tfunc{ pos = pos, params = tparms, ret = tret }
end

function FG.tparam(pos, toks)
    local tok = toks:byte(1)
    local l = tostring(tok.lexeme)
    return ast.tparam{ pos = pos, name = l }
end

function FG.param(name, type)
    return ast.param{ name = name, type = type }
end

function FG.typevar(pos)
    return ast.tvar{ pos = pos }
end

local LANG = [[
  prog  <- bloco "eof"
  bloco <- (stat* (ret / '')) -> collect_stats
  stat  <- (# "while" exp "do" bloco "end") -> while /
           (# {"id"} "=" exp) -> set   /
           (# "local" {"id"} "=" exp) -> def /
           (# "function" {"id"}  "(" ids
               ")" typan bloco "end") -> func /
           (# "if" exp "then" bloco ("else" bloco / '') "end") -> if /
           pexp  
  ret   <- (# "return" exp) -> return
  ids   <- ((param ("," param)*) / '') -> collect_params
  param <- ({"id"} -> nome typan) -> param
  exps  <- ((exp ("," exp)*) / '') -> collect_exps
  exp   <- (lexp (# "or" -> or lexp )*) -> chain
  lexp  <- (rexp (# "and" -> and rexp)*) -> chain
  rexp  <- (cexp (# rop cexp)*) -> chain
  cexp  <- (aexp # ".." -> concat cexp) -> chain / aexp
  aexp  <- (mexp (# aop mexp)*) -> chain
  mexp  <- (sexp (# mop sexp)*) -> chain
  sexp  <- (# "-" sexp) -> negacao /
           (# "not" sexp) -> not /
           (# "false") -> false /
           (# "true") -> true /
           {# "num"} -> num / 
           {# "str"} -> str /
           lmb / 
           pexp
  lmb   <- (# "function" "(" ids ")" typan bloco "end") 
                  -> lmb
  typan <- (":" type) / # -> typevar
  pexp  <- (("(" exp ")" / (# {"id"}) -> id) 
           (# "(" -> call exps ")" )*) -> chain
  rop   <- "<" -> lt / "==" -> eq / "~=" -> neq
  aop   <- "+" -> plus / "-" -> minus
  mop   <- "*" -> times / "/" -> div
  
  type  <- (# "number") -> tnum /
           (# "string") -> tstr /
           (# "boolean") -> tbool /
           tfunc /
           (# "(" ")") -> tunit /
           (# "{" type "}") -> tseq /
           (# {"id"}) -> tparam
  tfunc <- (# "(" types ")" "->" type) -> tfunc
  types <- ((type ("," type)*) / '') -> collect_types
]]

local parser = assert(peg.compile(LANG, FG))

local function pos_to_lincol(input, pos)
   local lin = 1
   local last = 1
   input = input:sub(1, pos)
   local br = string.find(input, "\n")
   while br do
       lin = lin + 1
       last = last + br
       input = input:sub(br+1, #input)
       br = string.find(input, "\n")
   end
   return lin, pos - last + 1
end

local function set_tos(set, ignore, trans)
    local t = {}
    for x, _ in pairs(set) do
        t[#t+1] = x
    end
    return "{ " .. table.concat(t, ", ") .. " }"
end

local function compile(input)
    local toks = assert(peg.parse(scanner.tokens, input))
    local res, state = peg.rawparse(parser.prog, toks)
    if not res or #res[2] > 0 then
        local tpos = #toks - state.pos + 1
        local pos = #input - toks:byte(tpos).pos + 1
        local lin, col = pos_to_lincol(input, pos)
        return nil, "erro no token " .. input:sub(pos, pos) ..
            " na linha " .. lin .. " coluna " .. col ..
            ", esperados " .. set_tos(state.follow)
    else
        local prog = res[1]:byte(1, #res[1])
        fixpos(prog, input, toks)
        return prog
    end
end

return { compile = compile }

