local Set = require "set"
local casef = require "casefunc"

local tvars = casef("tvars", function () return Set:new() end)

function tvars.tfunc(t)
    return Set:new():addAll(tvars(t.params)):addAll(tvars(t.ret))
end

function tvars.tseq(t)
    return tvars(t.elem)
end

function tvars.types(ts)
    local ps = Set:new()
    for _, t in ipairs(ts.seq) do
        ps:addAll(tvars(t))
    end
    return ps
end

function tvars.tvar(t)
    if not t.type then
        return Set:new(t)
    else
        return Set:new():addAll(tvars(t.type))
    end
end

function tvars.tgen(t)
    return Set:new():addAll(tvars(t.type))
end

return tvars
