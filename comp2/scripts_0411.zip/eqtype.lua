local casef = require "casefunc"
local ast = require "ast"
local ptype = require "printtype"
local rename = require "rentype"

local eqtype = casef("type_equal", rawequal)

local function eqtype_base(t1, t2)
    if type(t2) == "string" then
        t2 = ast[t2]{}
    end
    return t1.tag == t2.tag
end

eqtype.tnum = eqtype_base
eqtype.tstr = eqtype_base
eqtype.tbool = eqtype_base
eqtype.tunit = eqtype_base

function eqtype.tprim(t1, t2)
    return t2.tag == "tprim" and t1.prim == t2.prim
end

function eqtype.types(ts1, ts2)
    if ts2.tag ~= "types" then
        return false
    end
    local n1, n2 = #ts1.seq, #ts2.seq
    if n1 ~= n2 then
        return false
    end
    for i = 1, n1 do
        if not eqtype(ts1.seq:byte(i), ts2.seq:byte(i)) then
            return false
        end
    end
    return true
end

function eqtype.tfunc(t1, t2)
    if t2.tag ~= "tfunc" then
        return false
    end
    return eqtype(t1.ret, t2.ret) and
           eqtype(t1.params, t2.params)
end

function eqtype.tseq(t1, t2)
    if t2.tag ~= "tseq" then
        return false
    end
    return eqtype(t1.elem, t2.elem)
end

function eqtype.tparam(t1, t2)
    return t1.name == t2.name
end

function eqtype.tgen(t1, t2)
    if t2.tag ~= "tgen" then
        return false
    end
    if #t1.params ~= #t2.params then
        return false
    end
    local r1, r2 = {}, {}
    for i = 1,#t1.params do
        r1[t1.params:byte(i)] = "t" .. i
        r2[t2.params:byte(i)] = "t" .. i
    end
    return eqtype(rename(t1.type, r1), rename(t2.type, r2))
end

return eqtype

