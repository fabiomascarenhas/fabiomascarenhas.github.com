local Set = {}
Set.__index = Set

function Set:new(t)
    t = t or {}
    return setmetatable(t, self)
end

function Set:extend(...)
    local t = { ["$next"] = self }
    for _, name in ipairs{ ... } do
        t[name] = true
    end
    return Set:new(t) 
end

function Set:lookup(name)
    if self[name] then
        return self[name]
    end
    if self["$next"] then
        return self["$next"]:lookup(name)
    end
    return nil
end

function Set:__tostring()
    local out = {}
    for name, _ in pairs(self) do
        if name ~= "$next" then
            out[#out+1] = name
        end
    end
    if self["$next"] then
        out[#out+1] = tostring(self["$next"])
    end
    return table.concat(out, ", ")
end

return Set
