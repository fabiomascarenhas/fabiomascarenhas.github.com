local Seq = require "seq"
local casef = require "casefunc"
local ast = require "ast"

local rename = casef("rename", function (t, r) return t end)

function rename.tfunc(t, r)
    return ast.tfunc{ lin = t.lin, pos = t.pos,
                      params = ast.types{ seq = rename(t.params, r) },
                      ret = rename(t.ret, r) }
end

function rename.tseq(t, r)
    return ast.tseq{ lin = t.lin, pos = t.pos,
                     elem = rename(t.elem, r) }
end

function rename.tparam(t, r)
    if r[t.name] then
        return ast.tparam{ lin = t.lin, pos = t.pos,
                           name = r[t.name] }
    else
        return t
    end
end

function rename.types(ts, r)
    local out = {}
    for _, t in ipairs(ts.seq) do
        out[#out+1] = rename(t, r)
    end
    return Seq:new(out)
end

function rename.tgen(t, r)
    error("tipo paramétrico não deve aparecer aqui")
end

return rename

