local Seq = require "seq"
local casef = require "casefunc"

local tparams = casef("tparams", function () return Seq:new{} end)

function tparams.tfunc(t)
    return tparams(t.params) .. tparams(t.ret)
end

function tparams.tseq(t)
    return tparams(t.elem)
end

function tparams.types(ts)
    local ps = Seq:new{}
    for _, t in ipairs(ts.seq) do
        ps = ps .. tparams(t)
    end
    return ps
end

function tparams.tparam(t)
    return Seq:new{ t.name }
end

return tparams
