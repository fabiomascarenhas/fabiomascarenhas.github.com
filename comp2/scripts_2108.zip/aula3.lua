function print_array(a)
	print("{ " .. table.concat(a, ", ") .. " }")
end

function print_set(s)
	local buf = {}
	for x, b in pairs(s) do
		if b then
			buf[#buf+1] = tostring(x)
		end
	end
	print_array(buf)
end

function assert(ok, msg, ...)
    if ok then
        return ok, msg, ...
    else
        error(msg)
    end
end

function freq(pkg)
    package.loaded[pkg] = nil
    return require(pkg)
end

function pack(...)
    return { ... }
end
