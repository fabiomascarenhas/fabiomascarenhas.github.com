local M = {}

function M.new(r, i)
  return { real = r or 0, im = i or 0 }
end

M.i = M.new(0, 1)

function M.add(c1, c2)
  return M.new(c1.real + c2.real, c1.im + c2.im)
end

function M.tostring(c)
  return tostring(c.real) .. "+" .. tostring(c.im) .. "i"
end

return M
