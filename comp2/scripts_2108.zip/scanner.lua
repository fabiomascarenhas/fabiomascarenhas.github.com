
local tochar = string.byte
local classes = require "charclass"

-- tokens:
--     { tipo = "string", lexema = '"foo\n"' }

local TESTE = [[
"foo\n"3236 100.0 foo _ f12    end if . .. = 
== ++ fora
for while
]] 

local KEYWORDS = {
    ["function"] = true,
    ["end"] = true,
    ["while"] = true,
    ["local"] = true,
    ["true"] = true,
    ["and"] = true,
    ["false"] = true,
    ["else"] = true,
    ["if"] = true,
    ["elseif"] = true,
    ["not"] = true,
    ["nil"] = true,
    ["or"] = true,
    ["return"] = true,
    ["then"] = true,
    ["do"] = true
}

local function token_string(str) 
	local indice = 1
    repeat
        indice = indice + 1
        local char = tochar(str, indice)
        assert(char, "string nao terminada")
    until char == tochar('"')
	return { tipo = "string", 
             lexema = string.sub(str, 1, indice) }, 
           string.sub(str, indice+1)
end

local function skip_digits(str, indice)
    repeat
        indice = indice + 1
        local char = tochar(str, indice)
    until (not char) or (not classes.is_digit(char))
    return indice
end

local function token_number(str)
    local char
    local indice = skip_digits(str, 1)
    if tochar(str, indice) == tochar('.') then
        indice = skip_digits(str, indice)
    end
    return { tipo = "number",
             lexema = string.sub(str, 1, indice-1) },
           string.sub(str, indice)
end

local function token_idorkw(str)
    local indice = 1
    repeat
        indice = indice + 1
        local char = tochar(str, indice)
    until (not char) or (not classes.is_idrest(char))
    local lexema = string.sub(str, 1, indice-1)
    local rest = string.sub(str, indice)
    if KEYWORDS[lexema] then
        return { tipo = lexema, lexema = lexema }, rest
    else
        return { tipo = "id", lexema = lexema }, rest
    end
end

local function token(str)
	local indice = 1
	while classes.is_space(tochar(str, indice)) do
		indice = indice + 1
	end
	local char = tochar(str, indice)
    local rest = string.sub(str, indice)
    if not char then -- final
        return { tipo = "eof", lexema = "" }, rest
    elseif char == tochar('"') then
		return token_string(rest)
	elseif classes.is_digit(char) then
        return token_number(rest)
	elseif classes.is_idbegin(char) then
        return token_idorkw(rest)
	elseif char == tochar('=') then
        indice = indice + 1
        if tochar(str, indice) == tochar('=') then
            indice = indice + 1
            return { tipo = "==", lexema = "==" },
                   string.sub(str, indice)
        else
            return { tipo = "=", lexema = "=" }, 
                   string.sub(str, indice)
        end
	elseif char == tochar('~') then
        indice = indice + 1
        if tochar(str, indice) == tochar('=') then
            indice = indice + 1
            return { tipo = "~=", lexema = "~=" },
                   string.sub(str, indice)
        else
            return { tipo = "~", lexema = "~" }, 
                   string.sub(str, indice)
        end
	elseif char == tochar('.') then
        indice = indice + 1
        if tochar(str, indice) == tochar('.') then
            indice = indice + 1
            return { tipo = "..", lexema = ".." },
                   string.sub(str, indice)
        else
            return { tipo = ".", lexema = "." }, 
                   string.sub(str, indice)
        end
	else
        indice = indice + 1
        return { tipo = string.char(char), 
                 lexema = string.char(char) },
               string.sub(str, indice)
	end
end

local function all_tokens(str)
    local toks = {}
    repeat
        local tok, rest = token(str)
        toks[#toks+1] = tok
        str = rest
    until tok.tipo == "eof"
    return toks
end

return { TESTE = TESTE, token = token,
         all_tokens = all_tokens }
