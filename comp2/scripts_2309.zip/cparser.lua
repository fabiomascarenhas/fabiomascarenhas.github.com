local Seq = require "seq"
local vector = require "vector"
local tuple = require "tuple"
local parser = {}

function parser:__call(...)
    return self[1](...)
end

local function new(f)
    return setmetatable({ f }, parser)
end

-- reconhece um caractere ou strings
local function char(c)
    return new(function (input)
                   local n = #c
                   for i = 1, n do
                       local byte = input:byte(i)
                       if not byte or byte ~= c:byte(i) then
                           return nil
                       end
                   end
                   return tuple(Seq:new{}, input:sub(n+1))
               end)
end

-- reconhece uma classe de caracteres
local function class(p)
    return new(function (input)
                   local byte = input:byte(1)
                   if byte and p(byte) then
                       return tuple(Seq:new{}, input:sub(2))
                   else
                       return nil
                   end
               end)
end


-- reconhece um tipo de token
local function token(t)
    return new(function (input)
                   local tok = input:byte(1)
                   if tok and tok.type == t then
                       return tuple(Seq:new{}, input:sub(2))
                   else
                       return nil
                   end
               end)
end

-- sequência passando o resultado (^)
local function bind(p, f)
    return new(function (input)
                   local res = p(input)
                   if res then
                       res = f(res[1])(res[2])
                   end
                   return res
               end)
end

parser.__pow = bind

-- não consome nada, apenas gera um resultado
local function unit(x)
    return new(function (input)
                   return tuple(x, input)
               end)
end

-- sequência combinando resultados em um par
local function seq(p1, p2)
    return p1 ^ function (caps1)
                     return p2 ^ function (caps2)
                                     return unit(caps1 .. caps2)
                                 end
                 end
end

parser.__mul = seq

-- sequência combinando resultados (*)
local function seqn(p, ...)
    local ps = { p, ... }
    local seed = ps[#ps]
    for i = #ps-1, 1, -1 do
        seed = ps[i] * seed
    end
    return seed
end

-- escolha ordenada (+)
local function ochoice(p1, p2)
    return new(function (input)
                   local res = p1(input)
                   if res then
                       return res
                   else
                       return p2(input)
                   end
               end)
end

local choice = ochoice
parser.__add = choice

-- repetição possessiva
local function poss(p)
    -- p * poss(p) + unit()
    return (p ^ function (caps1)
                    return poss(p) ^ function (caps2)
                                         return unit(caps1 .. caps2)
                                     end
                end) + unit(Seq:new{})
end

local many = poss

-- prom é uma função que dá um parser
local function promise(prom)
    local p
    return new(function (input)
                   p = p or prom()
                   return p(input)
               end)
end

local function pnot(p)
    return new(function (input)
                   local res = p(input)
                   if res then
                       return nil
                   else
                       return unit(Seq:new{})(input)
                   end
               end)
end

local function cap(p)
    return new(function (input)
                   local res = p(input)
                   if res then
                       local caps = res[1]
                       local rest = res[2]
                       local prefix = 
                           input:sub(1, #input - #rest)
                       return tuple(caps .. Seq:new{ prefix }, rest)
                   else
                       return nil
                   end
               end)
end

-- ação semântica com capturas (/)
local function action(p, f)
    return p ^ function (caps)
                   local ncaps = Seq:new{ f(caps:byte(1, #caps)) } 
                   return unit(ncaps)
               end
end

parser.__div = action

local function chainl(p, op)
    local function rest(caps1)
        return seq(op, p) ^ function (caps2)
                                local e1 = caps1:byte(1)
                                local f, e2 = caps2:byte(1, 2)
                                return rest(Seq:new{f(e1, e2)}) 
                            end + unit(caps1)
    end    
    return p ^ rest
end

local function chainr(p, op)
    return p ^ function (caps1)
                   return seq(op, chainr(p, op)) ^ 
                          function (caps2)
                              local e1 = caps1:byte(1)
                              local f, e2 = caps2:byte(1, 2)
                              return unit(Seq:new{f(e1, e2)})
                          end + unit(caps1)
               end
end


return { new = new, class = class, token = token, char = char,
    bind = bind, unit = unit, seq = seqn, choice = choice,
    ochoice = ochoice, many = many, poss = poss,
    promise = promise, pnot = pnot, cap = cap, action = action,
    chainl = chainl, chainr = chainr }

