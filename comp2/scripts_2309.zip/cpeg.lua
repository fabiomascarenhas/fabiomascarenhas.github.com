local ast = require "ast"
local scanp = require "scanp"
local classes = require "charclass"
local parser = require "cparser"
local Seq = require "Seq"

local token = parser.token
local P = parser.promise
local C = parser.cap

local G = {}
local F = {}

local space = parser.class(classes.is_space) +
             (parser.char('-') * parser.char('-') * 
              parser.poss(parser.class(function (char)
                                           return char ~= 10
                                       end)))

-- 0 ou mais espaços
local spaces = parser.poss(space)

local non_squote = parser.class(function (char)
                                    return char ~= ("'"):byte()
                                end)

local non_dquote = parser.class(function (char)
                                    return char ~= ('"'):byte()
                                end)

local strs = parser.action(parser.seq(spaces, parser.char("'"),
                                      C(parser.poss(non_squote)),
                                      parser.char("'")),
                           function (s)
                               return tostring(s)
                           end)
          
local strd = parser.action(parser.seq(spaces, parser.char('"'),
                                      C(parser.poss(non_dquote)),
                                      parser.char('"')),
                           function (s)
                               return tostring(s)
                           end)
                         
local idbegin = parser.class(classes.is_idbegin)

local idrest = parser.class(classes.is_idrest)

local id = parser.action(spaces * C(idbegin * parser.poss(idrest)),
                         function (s)
                             return tostring(s)
                         end)

local function symb(str, nonfollow)
    if nonfollow then
        return spaces * parser.char(str) * parser.pnot(nonfollow)
    else
        return spaces * parser.char(str)
    end
end

local seta = symb("<-")
local setad = symb("->")
local barra = symb("/")
local excl = symb("!")
local pare = symb("(")
local pard = symb(")")
local star = symb("*")

-- / é ação semântica, + é escolha ordenada
local exp
local prom_exp = parser.promise(function () return exp end)
local simp = strs / function (res)
                        return parser.char(res)
                    end +
             strd / function (res)
                        return parser.token(res)
             end +
             id * parser.pnot(seta) /
                 function(res)
                    return parser.promise(function ()
                                              return G[res]
                                          end)
                 end +
            symb("{") * prom_exp * symb("}") /
                 function (res)
                     return parser.cap(res)
                 end +
            symb("[") * id * symb("]") /
                 function (res)
                     return parser.class(F[res])
                 end +
            pare * prom_exp * pard
                  
local many = simp * star / function (res)
                               return parser.many(res)
                           end + simp
                  
local pred = excl * many / function(res)
                               return parser.pnot(res)
                           end + many
              
local bind = pred * parser.many(setad * id) /
                  function (res, ...)
                     local funcs = { ... }
                     for _, func in ipairs(funcs) do
                         res = parser.action(res, F[func])
                     end
                     return res
                  end
              
local term = parser.chainr(bind, 
                           parser.unit(Seq:new{function(par1, par2)
                                                   return par1 * par2
                                               end}))
                               
                               
exp = parser.chainr(term, barra / function()
                                     return function(par1, par2)
                                        return par1 + par2
                                     end
                                  end)

local prod = id * seta * exp / function (naoterm, pexp)
                                   G[naoterm] = pexp
                                   return pexp
                               end

local peg = prod * parser.many(prod) / function (pexp)
                                           return exp
                                       end

local M = { foo = 10 }

F.idbegin = classes.is_idbegin
F.idrest = classes.is_idrest
F.space = classes.is_space
F.digit = classes.is_digit

function F.numt(toks)
    local tok = toks:byte(1)
    local l = tok.lexeme
    local s = tostring(l)
    local n = tonumber(s)
    return n
    --return ast.num{ n = n }
end

function F.idt(toks)
    local tok = toks:byte(1)
    local l = tostring(tok.lexeme)
    return M[l]
    --return ast.id{ nome = l}
end

function F.numc(l)
    local s = tostring(l)
    local n = tonumber(s)
    return n
    --return ast.num{ n = n }
end

function F.idc(l)
    return M[l]
    --return ast.id{ nome = l}
end

local function binop(tag)
    return function ()
               return function (n1, n2)
                          return ast[tag]{
                                    left = n1,
                                    right = n2
                                 }
                      end
           end
end

--F.plus = binop("add")
F.plus = function () return function (n1, n2) return n1 + n2 end end
--F.minus = binop("sub")
F.minus = function () return function (n1, n2) return n1 - n2 end end
--F.times = binop("mul")
F.times = function () return function (n1, n2) return n1 * n2 end end
--F.div = binop("div")
F.div = function () return function (n1, n2) return n1 / n2 end end
--F.pow = binop("pow")
F.pow = function () return function (n1, n2) return n1 ^ n2 end end

function F.chain(seed, ...)
    local seq = { ... }
    for i = 1, #seq, 2 do
        local op, termo = seq[i], seq[i+1]
        seed = op(seed, termo)
    end
    return seed
end

local EXP = [[
  exp  <- (term (aop term)*) -> chain
  term <- (fac (mop fac)*) -> chain
  fac  <- (simp ("^" -> pow simp)*) -> chain
  simp <- {"number"} -> numt / {"id"} -> idt / "(" exp  ")"
  aop  <- "+" -> plus / "-" -> minus
  mop  <- "*" -> times / "/" -> div
]]

local EXP_SL = [[
  SPACES <- [space]*
  NUMBER <- SPACES {[digit] [digit]*}
  ID     <- SPACES {[idbegin] [idrest]*}
  PLUS   <- SPACES '+'
  TIMES  <- SPACES '*'
  DIV    <- SPACES '/'
  MINUS  <- SPACES '-'
  POW    <- SPACES '^'
  PARE   <- SPACES '('
  PARD   <- SPACES ')'
  
  exp  <- (term (aop term)*) -> chain
  term <- (fac (mop fac)*) -> chain
  fac  <- (simp (POW -> pow simp)*) -> chain
  simp <- {NUMBER} -> numc / {ID} -> idc / PARE exp PARD
  aop  <- PLUS -> plus / MINUS -> minus
  mop  <- TIMES -> times / DIV -> div
]]

print(peg(EXP))
--print(peg(EXP_SL))

local toks = scanp.scan("  10-20+5*(30-foo)/2")
--local toks = "  10-20+5*(30-foo)/2"
local root = G.exp(toks)

print(toks)
print(root[1]:byte(1))
print(root[2])

--[[
add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}

add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}

add{left = add{left = num{n = 10}, right = num{n = 20}}, right = div{left = mul{left = num{n = 5}, right = sub{left = num{n = 30}, right = id{nome = foo}}}, right = num{n = 2}}}
]]

