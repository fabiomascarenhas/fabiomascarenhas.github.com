local vector = {}
vector.__index = vector

local function new(v, lbra, rbra, tos, sep)
    v = v or {}
    v.lbra = lbra or "{"
    v.rbra = rbra or "}"
    v.tos = tos or tostring
    v.sep = sep or ", "
    return setmetatable(v, vector)
end

function vector:add(x, i)
    if i then
        table.insert(self, i, x)
    else
        self[#self + 1] = x
    end
    return self
end

function vector:__concat(other)
    local nv = new({}, self.lbra, self.rbra, self.tos, self.sep)
    for i = 1, #self do
        nv[#nv+1] = self[i]
    end
    for i = 1, #other do
        nv[#nv+1] = other[i]
    end
    return nv
end

function vector:__tostring()
    local out = {}
    for k = 1, #self do
        out[#out+1] = self.tos(self[k])
    end
    return self.lbra .. table.concat(out, self.sep) .. self.rbra
end

return new
