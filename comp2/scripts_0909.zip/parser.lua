local Seq = require "seq"
local vector = require "vector"
local tuple = require "tuple"
local parser = {}

function parser:__call(...)
    return self[1](...)
end

local function new(f)
    return setmetatable({ f }, parser)
end

-- reconhece um caractere
local function char(c)
    return new(function (input)
                   local byte = input:byte(1)
                   if byte and byte == c:byte(1) then
                       return vector{ tuple(byte, input:sub(2)) }
                   else
                       return vector{ }
                   end
               end)
end

-- reconhece uma classe de caracteres
local function class(p)
    return new(function (input)
                   local byte = input:byte(1)
                   if byte and p(byte) then
                       return vector{ tuple(byte, input:sub(2)) }
                   else
                       return vector{ }
                   end
               end)
end

-- reconhece um tipo de token
local function token(t)
    return new(function (input)
                   local tok = input:byte(1)
                   if tok and tok.tipo == t then
                       return vector{ tuple(tok, input:sub(2)) }
                   else
                       return vector{ }
                   end
               end)
end

-- sequência passando o resultado
local function bind(p, f)
    return new(function (input)
                   local lres = p(input)
                   local out = vector{}
                   for _, par in ipairs(lres) do
                       local lres = f(par[1])(par[2])
                       for _, par in ipairs(lres) do
                           out[#out+1] = par
                       end
                   end
                   return out
               end)
end

parser.__pow = bind

-- não consome nada, apenas gera um resultado
local function unit(x)
    return new(function (input)
                   return vector{ tuple(x, input) }
               end)
end

-- sequência combinando resultados em um par
local function seq(p1, p2)
    return p1 ^ function (res1)
                     return p2 ^ function (res2)
                                     return unit(tuple(res1, res2))
                                 end
                 end
end

parser.__mul = seq

-- sequência combinando resultados em uma tupla
local function seqn(p, ...)
    local ps = { ... }
    if #ps == 0 then
       return p ^ function(res)
                    return unit(tuple(res))
                  end
    end
    return p ^ function(res1)
                   return seqn(table.unpack(ps)) ^
                          function(res2)
                              return unit(tuple(res1, res2()))
                          end
               end
end

-- escolha não-determinística
local function choice(p1, p2)
    return new(function (input)
                   local lres1 = p1(input)
                   local lres2 = p2(input)
                   return lres1 .. lres2
               end)
end

parser.__add = choice

-- escolha ordenada
local function ochoice(p1, p2)
    return new(function (input)
                   local lres1 = p1(input)
                   if #lres1 > 0 then
                       return vector{ lres1[1] }
                   else
                       local lres2 = p2(input)
                       return vector{ lres2[1] }
                   end
               end)
end

parser.__div = ochoice

-- repetição gulosa não-determinística
local function many(p)
    return (p ^ function (res1)
                    return many(p) ^ function (res2)
                                         return unit(res2:add(res1, 1))
                                     end
                end) + unit(vector{})
end

-- repetição possessiva
local function poss(p)
    return (p ^ function (res1)
                    return poss(p) ^ function (res2)
                                         return unit(res2:add(res1, 1))
                                     end
                end) / unit(vector{})
end

-- repetição gulosa determinística
local function greedy(p, next)
    return (p ^ function (res1)
                    return greedy(p, next) ^ function (par)
                                                 par[1]:add(res1, 1)
                                                 return unit(par)
                                             end
                end) / (next ^ function (res) 
                                   return unit(tuple(vector{}, res))
                               end)
end

-- repetição preguiçosa determinística
local function lazy(p, next)
    return (next ^ function (res) 
                       return unit(tuple(vector{}, res))
                   end) /
           (p ^ function (res1)
                    return lazy(p, next) ^ function (par)
                                              par[1]:add(res1, 1)
                                              return unit(par)
                                           end
                end)
end

-- joga fora todos os resultados exceto o primeiro
local function first(p)
    return new(function (input)
                   local lres = p(input)
                   return vector{ lres[1] }
               end)
end

local function pchoice(pred, p1, p2)
    return new(function (input)
                   local fst = input:byte(1)
                   if pred(fst) then
                       return p1(input)
                   else
                       return p2(input)
                   end
               end)
end

-- transforma um combinador de repetição de um
-- para gerar parsers que produzem sequências ao invés de
-- vetores
local function mseq(comb)
    return function (p, lbra, rbra, tos, sep)
               return comb(p) ^ function (tab)
                                    return unit(Seq:new(tab, lbra, rbra, tos, sep))
                                end
           end
end

local function chainl(p, op)
    local function rest(e1)
        return seq(op, p) ^ function (tup)
                                local f, e2 = tup()
                                return rest(f(e1, e2)) 
                            end / unit(e1)
    end    
    return p ^ rest
end

local function chainr(p, op)
    return p ^ function (e1)
                   return seq(op, chainr(p, op)) ^ function (tup)
                                                       local f, e2 = tup()
                                                       return unit(f(e1, e2))
                                                   end / unit(e1)
               end
end

local function listof(p, sep)
    return seq(p, poss(sep ^ function (_) return p end)) ^
                      function (tup)
                          local a, as = tup()
                          return unit(as:add(a, 1))
                      end
end

return { new = new, class = class, token = token, char = char,
    bind = bind, unit = unit, seq = seqn, choice = choice,
    ochoice = ochoice, many = mseq(many), poss = mseq(poss),
    lazy = lazy, greedy = greedy, first = first, pchoice = pchoice,
    chainl = chainl, chainr = chainr, listof = listof }

