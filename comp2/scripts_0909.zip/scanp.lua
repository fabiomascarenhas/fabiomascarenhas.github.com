
local Seq = require "seq"
local classes = require "charclass"
local parser = require "parser"

-- tokens:
--     { tipo = "string", lexema = '"foo\n"' }

local function str_to_vec(s)
    local vec = {}
    for i = 1, #s do
        vec[i] = s:byte(i)
    end
    return vec
end

local TESTE_SEQ = Seq:new(str_to_vec([[
"foo\n"3236 100.0 foo _ f12    end if . .. = 
== ++ -- comentário fora
for while
]]), '', '', string.char, '')

local TESTE_STR = [[
"foo\n"3236 100.0 foo _ f12    end if . .. = 
== ++ fora
for while
]]

local KEYWORDS = {
    ["function"] = true,
    ["end"] = true,
    ["for"] = true,
    ["while"] = true,
    ["local"] = true,
    ["true"] = true,
    ["and"] = true,
    ["false"] = true,
    ["else"] = true,
    ["if"] = true,
    ["elseif"] = true,
    ["not"] = true,
    ["nil"] = true,
    ["or"] = true,
    ["return"] = true,
    ["then"] = true,
    ["do"] = true
}

local space = parser.class(classes.is_space) /
             (parser.char('-') * parser.char('-') * 
              parser.poss(parser.class(function (char)
                                         return char ~= 10
                                     end)))

-- 0 ou mais espaços
local spaces = parser.poss(space)

-- 1 dígito
local digit = parser.class(classes.is_digit)

-- 1 ou mais dígitos
local digits = (digit * parser.poss(digit)) ^
               function (par)
                   local fst = par[1]
                   local rest = par[2]
                   return parser.unit(
                       Seq:new({fst}, '', '', string.char, '') .. rest)
               end

local real = parser.seq(digits, parser.char('.'), digits) ^ 
             function (res)
                 local lexem = res[1] .. Seq:new({res[2]}) .. res[3]
                 return parser.unit({tipo = 'number', lexema = lexem})
             end

local integer = digits ^ function (seq)
                             return parser.unit({
                                        tipo = "number",
                                        lexema = seq
                                    })
                         end

local number = real / integer

local idbegin = parser.class(classes.is_idbegin)

local idrest = parser.class(classes.is_idrest)

local idorkw = (idbegin * parser.poss(idrest)) ^
               function (par)
                   local fst, rest = par()
                   local lexema = Seq:new({fst}, 
                       '', '', string.char, '') .. rest
                   if KEYWORDS[tostring(lexema)] then
                       return parser.unit{ tipo = tostring(lexema), 
                                           lexema = lexema }
                   else
                       return parser.unit{ tipo = "id",
                                           lexema = lexema }
                   end
               end

local str = parser.seq(parser.char('"'),
                       parser.poss(parser.class(function (char)
                                                    return char ~=
                                                           ('"'):byte()
                                                end)),
                       parser.char('"')) ^
            function (trip)
                local s, m, e = trip()
                return parser.unit{ tipo = "string",
                                    lexema = Seq:new({s}, '', '', string.char, '') .. m ..
                                             Seq:new{e} }
            end

local function symb(str)
    local chars = {}
    for i = 1, #str do
        chars[i] = parser.char(str:sub(i, i))
    end
    return parser.seq(table.unpack(chars)) ^
           function (tuple)
               return parser.unit{
                          tipo = str,
                          lexema = Seq:new({ tuple() }, '', '', string.char, '')
                      }
           end
end

local equals = symb("==")

local noteq = symb("~=")

local concat = symb("..")

local any = parser.class(function (_) return true end)

local op = any ^ function (res)
                     return parser.unit{ tipo = string.char(res),
                                         lexema = Seq:new({ res }, 
                                             '', '', string.char, '') }
                 end

local eof = parser.unit({ tipo = "eof" })

local token = spaces ^ function (_)
                           return idorkw / number / str / equals /
                                  noteq / concat / op / eof
                       end

local function all_tokens(seq)
    local toks = {}
    repeat
        local tok, rest = token(seq)[1]()
        toks[#toks+1] = tok
        seq = rest
    until tok.tipo == "eof"
    return Seq:new(toks)
end

return { TESTE_SEQ = TESTE_SEQ, TESTE_STR = TESTE_STR,
         token = token, all_tokens = all_tokens }
