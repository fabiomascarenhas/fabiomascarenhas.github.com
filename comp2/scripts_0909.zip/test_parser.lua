parser = require "parser"
scanp = require "scanp"
class = require "charclass"

digit = parser.class(class.is_digit)

digits = parser.poss(digit, '"', '"', string.char, '')

print(digits("123"))

number = parser.token("number") ^ function (tok)
                                      return parser.unit(
                                        tonumber(tostring(tok.lexema))
                                      )
                                  end

minus = parser.token("-") ^ function (_)
                               return parser.unit(function (n1, n2)
                                                      return { tag = "-",
                                                          left = n1,
                                                          right = n2 }
                                                  end)
                           end

exp = parser.chainl(number, minus)

print("")
