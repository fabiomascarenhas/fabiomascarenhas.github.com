local tuple = {}

local function new(...)
    return setmetatable(table.pack(...), tuple)
end

function tuple:__len()
    return self.n
end

function tuple:__call(i, j)
    i = i or 1
    j = j or self.n
    return table.unpack(self, i, j)
end

function tuple:__tostring()
    local out = {}
    for k = 1, #self do
        local v = self[k]
        if type(v) == "string" then
            out[#out+1] = string.format("%q", v)
        else
            out[#out+1] = tostring(v)
        end
    end
    return '(' .. table.concat(out, ', ') .. ')'
end

return new
