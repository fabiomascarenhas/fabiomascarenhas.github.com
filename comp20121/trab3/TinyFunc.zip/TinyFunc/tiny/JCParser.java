// Output created by jacc on Tue Jun 12 16:26:26 BRT 2012

package tiny;


import java.util.Map;
import java.util.List;
import java.util.ArrayList;


class JCParser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    switch (yytok) {
                        case FUNCTION:
                            yyn = 4;
                            continue;
                        case VAR:
                            yyn = 5;
                            continue;
                        case BEGIN:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 274;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case ';':
                            yyn = 6;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 7;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    switch (yytok) {
                        case ID:
                            yyn = 8;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    switch (yytok) {
                        case FUNCTION:
                            yyn = 4;
                            continue;
                        case VAR:
                            yyn = 5;
                            continue;
                        case BEGIN:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    yyn = yys7();
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case '(':
                            yyn = 22;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ':':
                            yyn = 23;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case BEGIN:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case END:
                            yyn = 24;
                            continue;
                        case ';':
                            yyn = 25;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ASSIGN:
                            yyn = 26;
                            continue;
                        case '.':
                            yyn = 27;
                            continue;
                        case '[':
                            yyn = 28;
                            continue;
                        case '^':
                            yyn = 29;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys14();
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    switch (yytok) {
                        case '(':
                            yyn = 31;
                            continue;
                        case '^':
                        case '[':
                        case '.':
                        case ASSIGN:
                            yyn = yyr29();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    yyn = yys16();
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    switch (yytok) {
                        case ID:
                            yyn = 42;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    yyn = yys18();
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case ID:
                            yyn = 45;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    yyn = yys21();
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case ID:
                            yyn = 48;
                            continue;
                        case ')':
                            yyn = 49;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case '.':
                            yyn = 56;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys25();
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    switch (yytok) {
                        case ID:
                            yyn = 59;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys28();
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys29();
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case END:
                            yyn = 61;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys31();
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys33();
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    yyn = yys34();
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    switch (yytok) {
                        case ID:
                            yyn = 42;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case UNTIL:
                            yyn = 79;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    switch (yytok) {
                        case ':':
                            yyn = 80;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    yyn = yys46();
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    switch (yytok) {
                        case ')':
                            yyn = 81;
                            continue;
                        case ',':
                            yyn = 82;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    switch (yytok) {
                        case ':':
                            yyn = 83;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ':':
                            yyn = 84;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    switch (yytok) {
                        case ';':
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    switch (yytok) {
                        case '[':
                            yyn = 85;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    yyn = yys53();
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    switch (yytok) {
                        case ID:
                            yyn = 87;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    yyn = yys59();
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr21();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    yyn = yys62();
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    switch (yytok) {
                        case ')':
                            yyn = 90;
                            continue;
                        case ',':
                            yyn = 91;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 204:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 205:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 206:
                    switch (yytok) {
                        case ID:
                            yyn = 96;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 207:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 208:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 209:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 210:
                    yyn = yys73();
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 211:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 212:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 213:
                    yyn = yys76();
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 214:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 215:
                    yyn = yys78();
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 216:
                    yyn = yys79();
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 217:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 218:
                    switch (yytok) {
                        case ':':
                            yyn = 106;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 219:
                    switch (yytok) {
                        case ID:
                            yyn = 107;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 220:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 221:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 222:
                    switch (yytok) {
                        case NUM:
                            yyn = 110;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 223:
                    switch (yytok) {
                        case END:
                            yyn = 111;
                            continue;
                        case ';':
                            yyn = 112;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 224:
                    switch (yytok) {
                        case ':':
                            yyn = 113;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 225:
                    yyn = yys88();
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 226:
                    yyn = yys89();
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 227:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 228:
                    yyn = yys91();
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 229:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case ELSE:
                            yyn = 115;
                            continue;
                        case END:
                            yyn = 116;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 230:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 231:
                    yyn = yys94();
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 232:
                    yyn = yys95();
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 233:
                    yyn = yys96();
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 234:
                    yyn = yys97();
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 235:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 236:
                    yyn = yys99();
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 237:
                    yyn = yys100();
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 238:
                    switch (yytok) {
                        case ',':
                            yyn = 91;
                            continue;
                        case ')':
                            yyn = 118;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 102:
                    yyst[yysp] = 102;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 239:
                    yyn = yys102();
                    continue;

                case 103:
                    yyst[yysp] = 103;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 240:
                    yyn = yys103();
                    continue;

                case 104:
                    yyst[yysp] = 104;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 241:
                    yyn = yys104();
                    continue;

                case 105:
                    yyst[yysp] = 105;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 242:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr25();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 106:
                    yyst[yysp] = 106;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 243:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 107:
                    yyst[yysp] = 107;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 244:
                    switch (yytok) {
                        case ':':
                            yyn = 120;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 108:
                    yyst[yysp] = 108;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 245:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 109:
                    yyst[yysp] = 109;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 246:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 121;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 110:
                    yyst[yysp] = 110;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 247:
                    switch (yytok) {
                        case ']':
                            yyn = 122;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 111:
                    yyst[yysp] = 111;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 248:
                    yyn = yys111();
                    continue;

                case 112:
                    yyst[yysp] = 112;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 249:
                    switch (yytok) {
                        case ID:
                            yyn = 123;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 113:
                    yyst[yysp] = 113;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 250:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 114:
                    yyst[yysp] = 114;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 251:
                    yyn = yys114();
                    continue;

                case 115:
                    yyst[yysp] = 115;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 252:
                    yyn = yys115();
                    continue;

                case 116:
                    yyst[yysp] = 116;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 253:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 117:
                    yyst[yysp] = 117;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 254:
                    yyn = yys117();
                    continue;

                case 118:
                    yyst[yysp] = 118;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 255:
                    yyn = yys118();
                    continue;

                case 119:
                    yyst[yysp] = 119;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 256:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 126;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 120:
                    yyst[yysp] = 120;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 257:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 121:
                    yyst[yysp] = 121;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 258:
                    yyn = yys121();
                    continue;

                case 122:
                    yyst[yysp] = 122;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 259:
                    switch (yytok) {
                        case OF:
                            yyn = 129;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 123:
                    yyst[yysp] = 123;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 260:
                    switch (yytok) {
                        case ':':
                            yyn = 130;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 124:
                    yyst[yysp] = 124;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 261:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 125:
                    yyst[yysp] = 125;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 262:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case END:
                            yyn = 131;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 126:
                    yyst[yysp] = 126;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 263:
                    yyn = yys126();
                    continue;

                case 127:
                    yyst[yysp] = 127;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 264:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 128:
                    yyst[yysp] = 128;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 265:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case END:
                            yyn = 133;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 129:
                    yyst[yysp] = 129;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 266:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 130:
                    yyst[yysp] = 130;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 267:
                    switch (yytok) {
                        case ARRAY:
                            yyn = 51;
                            continue;
                        case BOOL:
                            yyn = 52;
                            continue;
                        case INT:
                            yyn = 53;
                            continue;
                        case RECORD:
                            yyn = 54;
                            continue;
                        case '^':
                            yyn = 55;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 131:
                    yyst[yysp] = 131;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 268:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ';':
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 132:
                    yyst[yysp] = 132;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 269:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case END:
                            yyn = 136;
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 133:
                    yyst[yysp] = 133;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 270:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 134:
                    yyst[yysp] = 134;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 271:
                    yyn = yys134();
                    continue;

                case 135:
                    yyst[yysp] = 135;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 272:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 136:
                    yyst[yysp] = 136;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 273:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 277;
                    continue;

                case 274:
                    return true;
                case 275:
                    yyerror("stack overflow");
                case 276:
                    return false;
                case 277:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys7() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys14() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys16() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys18() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys19() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys21() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys25() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys26() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys28() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys29() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case '-':
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
            case ASSIGN:
                return yyr32();
        }
        return 277;
    }

    private int yys31() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
            case ')':
                return 64;
        }
        return 277;
    }

    private int yys32() {
        switch (yytok) {
            case THEN:
                return 65;
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
        }
        return 277;
    }

    private int yys33() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr51();
        }
        return 277;
    }

    private int yys34() {
        switch (yytok) {
            case '(':
                return 75;
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr48();
        }
        return 277;
    }

    private int yys35() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr49();
        }
        return 277;
    }

    private int yys36() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr47();
        }
        return 277;
    }

    private int yys37() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr50();
        }
        return 277;
    }

    private int yys38() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys39() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys41() {
        switch (yytok) {
            case '.':
                return 27;
            case '[':
                return 28;
            case '^':
                return 29;
            case END:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr23();
        }
        return 277;
    }

    private int yys42() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr29();
        }
        return 277;
    }

    private int yys44() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case END:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr26();
        }
        return 277;
    }

    private int yys46() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case END:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr24();
        }
        return 277;
    }

    private int yys52() {
        switch (yytok) {
            case ',':
            case ')':
            case END:
            case BEGIN:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr14();
        }
        return 277;
    }

    private int yys53() {
        switch (yytok) {
            case ',':
            case ')':
            case END:
            case BEGIN:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr13();
        }
        return 277;
    }

    private int yys58() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case END:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr22();
        }
        return 277;
    }

    private int yys59() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case '-':
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
            case ASSIGN:
                return yyr31();
        }
        return 277;
    }

    private int yys60() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case ']':
                return 89;
        }
        return 277;
    }

    private int yys62() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case ',':
            case ')':
                return yyr53();
        }
        return 277;
    }

    private int yys65() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys66() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys67() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys68() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys70() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys71() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys72() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys73() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys74() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr41();
        }
        return 277;
    }

    private int yys75() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
            case ')':
                return 102;
        }
        return 277;
    }

    private int yys76() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case ')':
                return 103;
        }
        return 277;
    }

    private int yys77() {
        switch (yytok) {
            case '.':
                return 69;
            case '[':
                return 73;
            case '^':
                return 74;
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr39();
        }
        return 277;
    }

    private int yys78() {
        switch (yytok) {
            case '.':
                return 27;
            case '[':
                return 28;
            case '^':
                return 29;
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr44();
        }
        return 277;
    }

    private int yys79() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys88() {
        switch (yytok) {
            case ',':
            case ')':
            case END:
            case BEGIN:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr17();
        }
        return 277;
    }

    private int yys89() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case '-':
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
            case ASSIGN:
                return yyr30();
        }
        return 277;
    }

    private int yys91() {
        switch (yytok) {
            case FALSE:
                return 33;
            case ID:
                return 34;
            case NIL:
                return 35;
            case NUM:
                return 36;
            case TRUE:
                return 37;
            case '(':
                return 38;
            case '-':
                return 39;
            case '@':
                return 40;
        }
        return 277;
    }

    private int yys93() {
        switch (yytok) {
            case '.':
                return 69;
            case '[':
                return 73;
            case '^':
                return 74;
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr35();
        }
        return 277;
    }

    private int yys94() {
        switch (yytok) {
            case '*':
                return 66;
            case '.':
                return 69;
            case '/':
                return 70;
            case '[':
                return 73;
            case '^':
                return 74;
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr33();
        }
        return 277;
    }

    private int yys95() {
        switch (yytok) {
            case '*':
                return 66;
            case '.':
                return 69;
            case '/':
                return 70;
            case '[':
                return 73;
            case '^':
                return 74;
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr34();
        }
        return 277;
    }

    private int yys96() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr45();
        }
        return 277;
    }

    private int yys97() {
        switch (yytok) {
            case '.':
                return 69;
            case '[':
                return 73;
            case '^':
                return 74;
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr36();
        }
        return 277;
    }

    private int yys98() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '[':
                return 73;
            case '^':
                return 74;
            case ',':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr38();
        }
        return 277;
    }

    private int yys99() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '[':
                return 73;
            case '^':
                return 74;
            case ',':
            case ')':
            case END:
            case UNTIL:
            case ']':
            case ELSE:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr37();
        }
        return 277;
    }

    private int yys100() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case ']':
                return 117;
        }
        return 277;
    }

    private int yys102() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr43();
        }
        return 277;
    }

    private int yys103() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr46();
        }
        return 277;
    }

    private int yys104() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case END:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr20();
        }
        return 277;
    }

    private int yys111() {
        switch (yytok) {
            case ',':
            case ')':
            case END:
            case BEGIN:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr16();
        }
        return 277;
    }

    private int yys114() {
        switch (yytok) {
            case '*':
                return 66;
            case '+':
                return 67;
            case '-':
                return 68;
            case '.':
                return 69;
            case '/':
                return 70;
            case '<':
                return 71;
            case '=':
                return 72;
            case '[':
                return 73;
            case '^':
                return 74;
            case ',':
            case ')':
                return yyr52();
        }
        return 277;
    }

    private int yys115() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys117() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr40();
        }
        return 277;
    }

    private int yys118() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case '-':
            case END:
            case UNTIL:
            case '^':
            case ']':
            case ELSE:
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case '.':
                return yyr42();
        }
        return 277;
    }

    private int yys121() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys126() {
        switch (yytok) {
            case BEGIN:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 277;
    }

    private int yys134() {
        switch (yytok) {
            case ',':
            case ')':
            case END:
            case BEGIN:
            case UNTIL:
            case ELSE:
            case ';':
                return yyr15();
        }
        return 277;
    }

    private int yyr1() { // tiny : decl_seq BEGIN cmd_seq END '.'
        { output = new Programa(((List)yysv[yysp-5]), ((Comando)yysv[yysp-3])); }
        yysv[yysp-=5] = yyrv;
        return 1;
    }

    private int yyr11() { // campos : ID ':' tipo
        { Registro m = new Registro(); 
            m.put(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); yyrv = m; }
        yysv[yysp-=3] = yyrv;
        return 86;
    }

    private int yyr12() { // campos : campos ';' ID ':' tipo
        { ((Registro)yysv[yysp-5]).put(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); yyrv = ((Registro)yysv[yysp-5]); }
        yysv[yysp-=5] = yyrv;
        return 86;
    }

    private int yyr18() { // cmd : IF exp THEN cmd_seq END
        { yyrv = new If(((Expressao)yysv[yysp-4]), ((Comando)yysv[yysp-2]), new Vazio()); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr19() { // cmd : IF exp THEN cmd_seq ELSE cmd_seq END
        { yyrv = new If(((Expressao)yysv[yysp-6]), ((Comando)yysv[yysp-4]), ((Comando)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr20() { // cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = new Repeat(((Comando)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr21() { // cmd : BEGIN cmd_seq END
        { yyrv = new Bloco(((Comando)yysv[yysp-2])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr22() { // cmd : lval ASSIGN exp
        { yyrv = new Atrib(((Lvalue)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr23() { // cmd : READ lval
        { yyrv = new Read(((Lvalue)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr24() { // cmd : WRITE exp
        { yyrv = new Write(((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr25() { // cmd : VAR ID ':' tipo
        { yyrv = new DeclVar(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr26() { // cmd : RETURN exp
        { yyrv = new Return(((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr27() { // cmd : ID '(' args ')'
        { yyrv = new FuncallCmd(((String)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr28() { // cmd : ID '(' ')'
        { yyrv = new FuncallCmd(((String)yysv[yysp-3]), new ArrayList<Expressao>()); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 25: return 57;
            default: return 11;
        }
    }

    private int yyr9() { // cmd_seq : cmd
        yysp -= 1;
        return yypcmd_seq();
    }

    private int yyr10() { // cmd_seq : cmd_seq ';' cmd
        { yyrv = new Seq(((Comando)yysv[yysp-3]), ((Comando)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 121: return 128;
            case 115: return 125;
            case 65: return 92;
            case 18: return 43;
            case 14: return 30;
            case 7: return 12;
            default: return 132;
        }
    }

    private int yyr4() { // decl : VAR ID ':' tipo
        { yyrv = new DeclVar(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return 2;
    }

    private int yyr5() { // decl : FUNCTION ID '(' params ')' ':' tipo BEGIN cmd_seq END
        { yyrv = new DeclFunc(((String)yysv[yysp-9]), ((FuncParams)yysv[yysp-7]), ((Tipo)yysv[yysp-4]), ((Comando)yysv[yysp-2])); }
        yysv[yysp-=10] = yyrv;
        return 2;
    }

    private int yyr6() { // decl : FUNCTION ID '(' ')' ':' tipo BEGIN cmd_seq END
        { yyrv = new DeclFunc(((String)yysv[yysp-8]), new FuncParams(), ((Tipo)yysv[yysp-4]), ((Comando)yysv[yysp-2])); }
        yysv[yysp-=9] = yyrv;
        return 2;
    }

    private int yyr2() { // decl_seq : decl ';' decl_seq
        { ((List)yysv[yysp-1]).add(((Decl)yysv[yysp-3])); yyrv = ((List)yysv[yysp-1]); }
        yysv[yysp-=3] = yyrv;
        return yypdecl_seq();
    }

    private int yyr3() { // decl_seq : /* empty */
        { yyrv = new ArrayList<Decl>(); }
        yysv[yysp-=0] = yyrv;
        return yypdecl_seq();
    }

    private int yypdecl_seq() {
        switch (yyst[yysp-1]) {
            case 0: return 3;
            default: return 10;
        }
    }

    private int yyr33() { // exp : exp '+' exp
        { yyrv = new Soma(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr34() { // exp : exp '-' exp
        { yyrv = new Sub(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : exp '*' exp
        { yyrv = new Mul(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : exp '/' exp
        { yyrv = new Div(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : exp '=' exp
        { yyrv = new Igual(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : exp '<' exp
        { yyrv = new Menor(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : '-' exp
        { yyrv = new Sub(new Num(0), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : exp '[' exp ']'
        { yyrv = new IndexaVetor(((Expressao)yysv[yysp-4]), ((Expressao)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : exp '^'
        { yyrv = new Deref(((Expressao)yysv[yysp-2])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr42() { // exp : ID '(' args ')'
        { yyrv = new Funcall(((String)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr43() { // exp : ID '(' ')'
        { yyrv = new Funcall(((String)yysv[yysp-3]), new ArrayList<Expressao>()); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr44() { // exp : '@' lval
        { yyrv = new Ref(((Lvalue)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr45() { // exp : exp '.' ID
        { yyrv = new IndexaReg(((Expressao)yysv[yysp-3]), ((String)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : '(' exp ')'
        { yyrv = ((Expressao)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : NUM
        { yyrv = new Num(((Integer)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : ID
        { yyrv = new Var(((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr49() { // exp : NIL
        { yyrv = new Nil(); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr50() { // exp : TRUE
        { yyrv = new True(); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr51() { // exp : FALSE
        { yyrv = new False(); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 91: return 114;
            case 79: return 104;
            case 73: return 100;
            case 72: return 99;
            case 71: return 98;
            case 70: return 97;
            case 68: return 95;
            case 67: return 94;
            case 66: return 93;
            case 39: return 77;
            case 38: return 76;
            case 28: return 60;
            case 26: return 58;
            case 21: return 46;
            case 19: return 44;
            case 16: return 32;
            default: return 62;
        }
    }

    private int yyr29() { // lval : ID
        { yyrv = new Var(((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yyplval();
    }

    private int yyr30() { // lval : lval '[' exp ']'
        { yyrv = new IndexaVetor(((Lvalue)yysv[yysp-4]), ((Expressao)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yyplval();
    }

    private int yyr31() { // lval : lval '.' ID
        { yyrv = new IndexaReg(((Lvalue)yysv[yysp-3]), ((String)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yyplval();
    }

    private int yyr32() { // lval : lval '^'
        { yyrv = new Deref(((Lvalue)yysv[yysp-2])); }
        yysv[yysp-=2] = yyrv;
        return yyplval();
    }

    private int yyplval() {
        switch (yyst[yysp-1]) {
            case 40: return 78;
            case 17: return 41;
            default: return 13;
        }
    }

    private int yyr7() { // params : params ',' ID ':' tipo
        { ((FuncParams)yysv[yysp-5]).add(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); yyrv = ((FuncParams)yysv[yysp-5]); }
        yysv[yysp-=5] = yyrv;
        return 47;
    }

    private int yyr8() { // params : ID ':' tipo
        { FuncParams p = new FuncParams(); 
                       p.add(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); yyrv = p; }
        yysv[yysp-=3] = yyrv;
        return 47;
    }

    private int yyr52() { // args : args ',' exp
        { ((List)yysv[yysp-3]).add(((Expressao)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypargs();
    }

    private int yyr53() { // args : exp
        { List<Expressao> l = new ArrayList<Expressao>();
             l.add(((Expressao)yysv[yysp-1])); yyrv = l; }
        yysv[yysp-=1] = yyrv;
        return yypargs();
    }

    private int yypargs() {
        switch (yyst[yysp-1]) {
            case 31: return 63;
            default: return 101;
        }
    }

    private int yyr13() { // tipo : INT
        { yyrv = new Inteiro(); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr14() { // tipo : BOOL
        { yyrv = new Booleano(); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr15() { // tipo : ARRAY '[' NUM ']' OF tipo
        { yyrv = new Vetor(((Tipo)yysv[yysp-1]), ((Integer)yysv[yysp-4])); }
        yysv[yysp-=6] = yyrv;
        return yyptipo();
    }

    private int yyr16() { // tipo : RECORD campos END
        { yyrv = ((Registro)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yyptipo();
    }

    private int yyr17() { // tipo : '^' tipo
        { yyrv = new Ponteiro(((Tipo)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 129: return 134;
            case 120: return 127;
            case 113: return 124;
            case 106: return 119;
            case 84: return 109;
            case 83: return 108;
            case 80: return 105;
            case 55: return 88;
            case 23: return 50;
            default: return 135;
        }
    }

    protected String[] yyerrmsgs = {
    };


// C�digo extra

int tokenType;
Object tokenVal;
Token tok;

JFScanner scanner;
Programa output;

JCParser(java.io.Reader input) {
  scanner = new JFScanner(input);
  getToken();
}

int getToken() {
  try {
    tok = scanner.getToken();
    tokenType = tok.type;
    tokenVal = (tokenType == NUM ? tok.intVal :
                                tok.strVal);
    return tokenType;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException(msg + " no token " + tok);
}

}
