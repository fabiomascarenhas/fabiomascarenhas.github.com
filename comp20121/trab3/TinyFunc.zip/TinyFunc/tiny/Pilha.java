package tiny;

public class Pilha {
	int total;
	int topo;
	
	public Pilha(int topo) {
		this.topo = topo;
		this.total = topo;
	}
	
	public int aloca(int tamanho) {
		this.topo += tamanho;
		if(this.topo > this.total)
			this.total = this.topo;
		return this.topo;
	}
	
	public void libera(int tamanho) {
		this.topo -= tamanho;
	}
}
