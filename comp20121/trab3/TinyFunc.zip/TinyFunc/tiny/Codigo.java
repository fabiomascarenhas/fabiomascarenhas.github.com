package tiny;

import java.util.Stack;

public class Codigo {
	Stack<Integer> temps;
	SymbolTable<Local> vars;
	StringBuilder corpo;
	Pilha pilha;
	int nRotulo;
	
	Codigo() {
		this.vars = new SymbolTable<Local>();
		this.corpo = new StringBuilder();
		this.pilha = new Pilha(0);
		this.temps = new Stack<Integer>();
		nRotulo = 1;
	}
	
	void emiteMov(String op1, String op2) {
		this.emiteOp("mov", op1, op2);
	}
	
	void emiteOp(String opcode, String op1, String op2) {
		corpo.append("  " + opcode + " "+ op1 + ","+ op2 + "\n");
	}

	void emiteOp(String opcode) {
		corpo.append("  " + opcode + "\n");
	}

	void emiteOp(String opcode, String op1) {
		corpo.append("  " + opcode + " "+ op1 + "\n");
	}
	
	void emiteRotulo(String rotulo) {
		corpo.append(rotulo + ":\n");
	}

	Local novoTemp() {
		// Pilha cresce pra "baixo"
		int pos = pilha.aloca(4);
		return new LocalPilha(-pos);
	}
	
	Local novaVar(Tipo t) {
		// Pilha cresce pra "baixo"
		int pos = pilha.aloca(t.tamanho());
		return new LocalPilha(-pos);
	}
	
	void push() {
		temps.add(pilha.topo);
	}
	
	void pop() {
		pilha.topo = temps.pop();
	}
	
	String novoRotulo() {
		return "l" + (nRotulo++) + "$";
	}
	
}
