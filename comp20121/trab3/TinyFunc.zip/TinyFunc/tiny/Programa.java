package tiny;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Programa {
	List<Decl> decls;
	Comando corpo;
		
	Programa(List<Decl> decls, Comando corpo) {
		this.decls = decls;
		this.corpo = corpo;
	}

	public void executa() {
		SymbolTable<Object> globais = new SymbolTable<Object>();
		SymbolTable<Funcao> funcs = new SymbolTable<Funcao>();
		for(Decl decl : decls) {
			if(decl instanceof DeclVar) {
				DeclVar dv = (DeclVar)decl;
				globais.insert(dv.nome, dv.tipo.zero());
			} else {
				DeclFunc df = (DeclFunc)decl;
				funcs.insert(df.nome, new Funcao(df.params.nomes,
						df.corpo));
			}
		}
		corpo.executa(globais, funcs);
	}

	public void geraCod(Writer output) throws IOException {
		output.write("extern _printf\n");
		output.write("extern _exit\n");
		output.write("extern _scanf\n");
		output.write("segment .data\n");
		output.write("fmt_printf$ db \"%d\",10,0\n");
		output.write("fmt_scanf$ db \"%d\",0\n");
		output.write("segment .bss\n");
		SymbolTable<Local> globais = new SymbolTable<Local>();
		for(Decl decl : decls) {
			if(decl instanceof DeclVar) {
				DeclVar dv = (DeclVar)decl;
				globais.insert(dv.nome, new LocalGlobal(dv.nome));
				output.write(dv.nome + " resb " + dv.tipo.tamanho() + "\n");
			}
		}
		output.write("segment .text\n");
		output.write("global _main\n");
		Map<String, Codigo> funcs = new HashMap<String, Codigo>();
		for(Decl decl : decls) {
			if(decl instanceof DeclFunc) {
				DeclFunc df = (DeclFunc)decl;
				funcs.put(df.nome, df.geraCod(globais));
				output.write("global _" + df.nome + "\n");
			}
		}
		for(Decl decl : decls) {
			if(decl instanceof DeclFunc) {
				DeclFunc df = (DeclFunc)decl;
				output.write("_" + df.nome+":\n");
				Codigo ctx = df.geraCod(globais);
				output.write(ctx.corpo.toString());
			}
		}
		Codigo ctx = new Codigo();
		ctx.vars = globais;
		corpo.geraCod(ctx);
		output.write("_main:\n");
		output.write("  push ebp\n");
		output.write("  mov ebp, esp\n");
		output.write("  sub esp, " + ctx.pilha.total + "\n");
		output.write("  and esp,0xFFFFFFF0\n");
		output.write(ctx.corpo.toString());
		output.write("  mov esp, ebp\n");
		output.write("  pop ebp\n");
		output.write("  ret\n");
		output.close();
	}

	public void verificaTipo() {
		SymbolTable<Tipo> globais = new SymbolTable<Tipo>();
		SymbolTable<DeclFunc> funcs = new SymbolTable<DeclFunc>();
		for(Decl decl : decls) {
			if(decl instanceof DeclVar) {
				DeclVar dv = (DeclVar)decl;
				globais.insert(dv.nome, dv.tipo);
			} else {
				DeclFunc df = (DeclFunc)decl;
				funcs.insert(df.nome, df);
			}
		}
		for(Decl decl : decls) {
			if(decl instanceof DeclFunc) {
				DeclFunc df = (DeclFunc)decl;
				df.verificaTipo(globais, funcs);
			}
		}
		corpo.verificaTipo(globais, funcs, null);
	}

}
