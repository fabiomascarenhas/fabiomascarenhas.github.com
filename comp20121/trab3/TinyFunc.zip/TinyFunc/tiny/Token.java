package tiny;

public class Token implements Tokens {	
	public static int EOF = 0;
	
	int type;
	
	int intVal;       // para type == NUM
	String strVal;    // para type == ID

	int line;
	int column;
	
	public Token(int type) {
		this.type = type;
	}

	public Token(int type, int line, int col) {
		this.type = type;
		this.line = line;
		this.column = col;
	}

	public Token(int type, int intVal) {
		this.type = type;
		this.intVal = intVal;
	}

	public Token(int type, int intVal, int line, int col) {
		this.type = type;
		this.intVal = intVal;
		this.line = line;
		this.column = col;
	}

	public Token(int type, String strVal) {
		this.type = type;
		this.strVal = strVal;
	}

	public Token(int type, String strVal, int line, int col) {
		this.type = type;
		this.strVal = strVal;
		this.line = line;
		this.column = col;
	}

	public String toString() {
		return "Token(" + this.type + ", " +
				(this.strVal == null ?
						this.intVal : this.strVal) + ")";
	}
}
