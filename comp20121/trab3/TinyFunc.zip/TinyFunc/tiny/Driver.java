package tiny;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;

public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Reader input = new FileReader(args[0]);
		JCParser parser = new JCParser(input);
		parser.parse();
		parser.output.verificaTipo();
		parser.output.executa();
		String outfile = args[0].replace(".tiny", ".asm");
		Writer output = new FileWriter(outfile);
		parser.output.geraCod(output);
	}

}
