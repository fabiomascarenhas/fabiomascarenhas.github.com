package tiny;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

interface Decl {}

interface Expressao {
	Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs);
	// retorna endere�o onde est� o valor dessa exp
	Local geraCod(Codigo ctx);
	// salta para label se o resultado dessa exp � falso
	void saltaSeFalso(Codigo ctx, String lab);
	// interpretador
	Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs);
}

interface Lvalue extends Expressao {
	// interpretador
	interface Endereco {
		void valor(Object val);
		Object valor();
	}
	Endereco endereco(SymbolTable<Object> vars, SymbolTable<Funcao> funcs);	
}

interface Comando {
	void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret);
	void geraCod(Codigo ctx);
	// interpretador
	void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs);
}

interface Tipo {
	boolean igual(Tipo outro);
	boolean escalar();
	int tamanho();
	Object zero();  // interpretador
}

class Num implements Expressao {
	int val;
	
	public Num(int val) {
		this.val = val;
	}
	
	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		return new Inteiro();
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalImm(val);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return this.val;
	}
}

class Var implements Lvalue {
	private String nome;
	
	public Var(String nome) {
		this.nome = nome;
	}
	
	class EnderecoVar implements Endereco {
		private String nome;
		private SymbolTable<Object> vars;
				
		EnderecoVar(String nome, SymbolTable<Object> vars) {
			this.nome = nome;
			this.vars = vars;
		}
		
		@Override
		public Object valor() {
			return vars.lookup(nome);
		}

		@Override
		public void valor(Object val) {
			vars.replace(nome, val);
		}

	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return new EnderecoVar(nome, vars);
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return vars.lookup(nome);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		return vars.lookup(nome);
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		return ctx.vars.lookup(nome);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}
}

abstract class ExpressaoArit implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoArit(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract int fazOp(int valEsq, int valDir);
	
	abstract String opcode();
	
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return this.fazOp((Integer)esq.valor(vars, funcs),
						  (Integer)dir.valor(vars, funcs));
	}
	
	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		Tipo tesq = esq.tipo(vars, funcs);
		Tipo tdir = dir.tipo(vars, funcs);
		if(tesq instanceof Inteiro && tdir instanceof Inteiro)
			return new Inteiro();
		else
			throw new RuntimeException("express�o aritm�tica com argumento inv�lido");
	}
		
	@Override 
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		String le = esq.geraCod(ctx).deref(ctx);
		String ld = dir.geraCod(ctx).deref(ctx);
		ctx.emiteMov("eax", le);
		ctx.emiteOp(this.opcode(), "eax", ld);
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}
}

abstract class ExpressaoRel implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoRel(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract Boolean fazOp(int valEsq, int valDir);
	
	abstract String opcode();
	
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return this.fazOp((Integer)esq.valor(vars, funcs),
						  (Integer)dir.valor(vars, funcs));
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		String l1 = ctx.novoRotulo();
		String l2 = ctx.novoRotulo();
		this.saltaSeFalso(ctx, l1);
		ctx.emiteMov(tmp.deref(ctx), "1");
		ctx.emiteOp("jmp", l2);
		ctx.emiteRotulo(l1);
		ctx.emiteMov(tmp.deref(ctx), "0");
		ctx.emiteRotulo(l2);
		return tmp;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		String le = esq.geraCod(ctx).deref(ctx);
		String ld = dir.geraCod(ctx).deref(ctx);
		ctx.emiteMov("eax", le);
		ctx.emiteOp("cmp", "eax", ld);
		ctx.emiteOp(this.opcode(), lab);
	}

}

class Soma extends ExpressaoArit {
	
	public Soma(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq + valDir;
	}

	@Override
	String opcode() {
		return "add";
	}
	
}

class Sub extends ExpressaoArit {
	
	public Sub(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq - valDir;
	}

	@Override
	String opcode() {
		return "sub";
	}

}

class Mul extends ExpressaoArit {
	
	public Mul(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq * valDir;
	}

	@Override
	String opcode() {
		return "imul";
	}

}

class Div extends ExpressaoArit {
	
	public Div(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq / valDir;
	}
	
	@Override
	String opcode() {
		return "idiv dword";
	}

	@Override
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		String le = esq.geraCod(ctx).deref(ctx);
		String ld;
		Local ldir = dir.geraCod(ctx);
		if(ldir instanceof LocalImm) {
			ld = tmp.deref(ctx);
			ctx.emiteMov(ld, ldir.deref(ctx));
		} else {
			ld = ldir.deref(ctx);
		}
		ctx.emiteMov("eax", le);
		ctx.emiteOp("cdq");
		ctx.emiteOp(this.opcode(), ld);
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp;
	}
}

class Igual extends ExpressaoRel {
	
	public Igual(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	Boolean fazOp(int valEsq, int valDir) {
		return valEsq == valDir;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		Tipo tesq = esq.tipo(vars, funcs);
		Tipo tdir = dir.tipo(vars, funcs);
		if(tesq instanceof Inteiro 
				|| tesq instanceof Booleano
				|| tesq instanceof Ponteiro
				|| tesq instanceof Nil) {
			if(tesq.igual(tdir))
				return new Booleano();
			else
				throw new RuntimeException("comparando tipos diferentes");
		} else
			throw new RuntimeException("comparando tipo n�o escalar");
	}

	@Override
	String opcode() {
		return "jne";
	}

}

class Menor extends ExpressaoRel {
	
	public Menor(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	Boolean fazOp(int valEsq, int valDir) {
		return valEsq < valDir;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		Tipo tesq = esq.tipo(vars, funcs);
		Tipo tdir = dir.tipo(vars, funcs);
		if(tesq instanceof Inteiro && tdir instanceof Inteiro)
			return new Booleano();
		else
			throw new RuntimeException("compara��o com argumento inv�lido");
	}

	@Override
	String opcode() {
		return "jge";
	}
}

class Deref implements Lvalue {
	Expressao ref;
	
	Deref(Expressao ref) {
		this.ref = ref;
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		Endereco end = (Endereco)ref.valor(vars, funcs);
		return end.valor();
	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return (Endereco)ref.valor(vars, funcs);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		Tipo texp = ref.tipo(vars, funcs);
		if(texp instanceof Ponteiro) {
			Ponteiro p = (Ponteiro)texp;
			return p.base;
		} else
			throw new RuntimeException("tipo inv�lido na deref");
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalPonteiro(ref.geraCod(ctx));
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}
	
}

class Nil implements Expressao, Tipo {

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return null;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		return this;
	}

	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Ponteiro ||
				outro instanceof Nil;
	}

	@Override
	public Object zero() {
		return null;
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalImm(0);
	}

	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}

}

class Ref implements Expressao {
	Lvalue exp;
	
	Ref(Lvalue exp) {
		this.exp = exp;
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return exp.endereco(vars, funcs);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		return new Ponteiro(exp.tipo(vars, funcs));
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return exp.geraCod(ctx).ref(ctx);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}
	
}

class IndexaReg implements Lvalue {
	Expressao reg;
	String campo;
	
	int offset;

	IndexaReg(Expressao reg, String campo) {
		this.reg = reg;
		this.campo = campo;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		Map<Integer, Object> registro = 
				(Map<Integer, Object>)reg.valor(vars, funcs);
		return registro.get(offset);
	}

	class EnderecoIndexaReg implements Endereco {
		private Map<Integer, Object> map;
		private int offset;
				
		EnderecoIndexaReg(Map<Integer, Object> map, 
				int offset) {
			this.map = map;
			this.offset = offset;
		}
		
		@Override
		public void valor(Object val) {
			map.put(offset, val);
		}

		@Override
		public Object valor() {
			return map.get(offset);
		}
		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Endereco endereco(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return new EnderecoIndexaReg(
				(Map<Integer, Object>)reg.valor(vars, funcs), offset);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		Tipo treg = reg.tipo(vars, funcs);
		if(treg instanceof Registro) {
			Registro tr = (Registro)treg;
			if(tr.nomes.contains(campo)) {
				this.offset = tr.offset(campo);
				return tr.tipos.get(tr.nomes.indexOf(campo));
			}
			else
				throw new RuntimeException("indexa��o por campo que n�o existe: " + campo);
		} else
			throw new RuntimeException("indexa��o inv�lida");
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return reg.geraCod(ctx).offset(ctx, offset);
	}

	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}

}

class IndexaVetor implements Lvalue {
	Expressao vetor;
	Expressao indice;

	int tamanhoBase;
	
	IndexaVetor(Expressao vetor, Expressao indice) {
		this.vetor = (Lvalue)vetor;
		this.indice = indice;
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		Object[] vet = (Object[])vetor.valor(vars, funcs);
		int ind = (Integer)indice.valor(vars, funcs);
		return vet[ind];
	}

	class EnderecoIndexaVetor implements Endereco {
		private Object[] vetor;
		private int indice;
		
		EnderecoIndexaVetor(Object[] vetor, int indice) {
			this.vetor = vetor;
			this.indice = indice;
		}

		@Override
		public void valor(Object val) {
			vetor[indice] = val;
		}

		@Override
		public Object valor() {
			return vetor[indice];
		}
	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return new EnderecoIndexaVetor(
					(Object[])vetor.valor(vars, funcs),
					(Integer)indice.valor(vars, funcs)
				);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		Tipo tvetor = vetor.tipo(vars, funcs);
		Tipo tind = indice.tipo(vars, funcs);
		if(tvetor instanceof Vetor) {
			Vetor tv = (Vetor)tvetor;
			if(tind instanceof Inteiro) {
				this.tamanhoBase = tv.base.tamanho();
				return tv.base;
			} else
				throw new RuntimeException("indexa��o com �ndice inv�lido");
		} else
			throw new RuntimeException("indexa��o de n�o-vetor");
	}

	@Override
	public Local geraCod(Codigo ctx) {
		if(indice instanceof Num) {
			int offset = ((Num)indice).val * tamanhoBase;
			return vetor.geraCod(ctx).offset(ctx, offset);
		} else {
			return vetor.geraCod(ctx).offset(ctx, indice.geraCod(ctx), tamanhoBase);
		}
	}

	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}

}

class Vazio implements Comando {
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) { }

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {	}

	@Override
	public void geraCod(Codigo ctx) {
	}
}

class True implements Expressao {
	True() { }

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		return new Booleano();
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalImm(1);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return true;
	}
}

class False implements Expressao {
	False() { }

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		return new Booleano();
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalImm(0);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		ctx.emiteOp("jmp", lab);
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		return false;
	}
}

class Funcall implements Expressao {
	String nome;
	List<Expressao> args;
	
	Funcall(String nome, List<Expressao> args) {
		this.nome = nome;
		this.args = args;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		// TODO verifica tipo dos argumentos vs par�metros
		return funcs.lookup(nome).tipoRet;
	}

	@Override
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		// TODO gera c�digo para chamada de fun��o
		// guarda resultado em tmp
		// lembre que os argumentos s�o empilhados
		// de tr�s pra frente, e que o nome da fun��o
		// ganha um _ na frente
		return tmp;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		// TODO gera c�digo para salto se o
		// resultado da chamada for falso
		// (an�lise sem�ntica garante que � booleano)
	}

	@Override
	public Object valor(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		Object[] args = new Object[this.args.size()];
		for(int i = 0; i < this.args.size(); i++)
			args[i] = this.args.get(i).valor(vars, funcs);
		return funcs.lookup(nome).valor(vars, funcs, args);
	}
}

class DeclVar implements Comando, Decl {
	String nome;
	Tipo tipo;
	
	DeclVar(String nome, Tipo tipo) {
		this.nome = nome;
		this.tipo = tipo;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		vars.insert(nome, tipo.zero());
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		vars.insert(nome, tipo);
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.vars.insert(nome, ctx.novaVar(tipo));
	}

}

class DeclFunc implements Decl {
	String nome;
	FuncParams params;
	Tipo tipoRet;
	Comando corpo;
	
	DeclFunc(String nome, FuncParams params, Tipo tipoRet, Comando corpo) {
		this.nome = nome;
		this.params = params;
		this.tipoRet = tipoRet;
		this.corpo = corpo;
	}

	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs) {
		// TODO: verifica tipos na declara��o da fun��o
		// lembre que os par�metros s� podem ter tipos
		// escalares (inteiro, booleano, ponteiro)
	}
	
	public Codigo geraCod(SymbolTable<Local> globais) {
		Codigo ctx = new Codigo();
		ctx.vars = globais;
		// TODO: gera c�digo para essa fun��o, incluindo
		// pr�logo e ep�logo
		return ctx;
	}
}

class Seq implements Comando {
	private Comando cmd1;
	private Comando cmd2;
	
	public Seq(Comando cmd1, Comando cmd2) {
		this.cmd1 = cmd1;
		this.cmd2 = cmd2;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		cmd1.executa(vars, funcs);
		cmd2.executa(vars, funcs);
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		cmd1.verificaTipo(vars, funcs, tret);
		cmd2.verificaTipo(vars, funcs, tret);
	}

	@Override
	public void geraCod(Codigo ctx) {
		cmd1.geraCod(ctx);
		cmd2.geraCod(ctx);
	}

}

class Atrib implements Comando {
	private Lvalue lval;
	private Expressao rval;
	
	public Atrib(Lvalue lval, Expressao rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		lval.endereco(vars, funcs).valor(rval.valor(vars, funcs));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		Tipo tlval = lval.tipo(vars, funcs);
		Tipo trval = rval.tipo(vars, funcs);
		if(tlval instanceof Inteiro 
				|| tlval instanceof Booleano
				|| tlval instanceof Ponteiro) {
			if(!tlval.igual(trval))
				throw new RuntimeException("atribuindo tipos diferentes");
		} else
			throw new RuntimeException("atribuindo tipo n�o escalar");
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		lval.geraCod(ctx).deref(ctx, rval.geraCod(ctx));
		ctx.pop();
	}
	
}

class If implements Comando {
	private Expressao cond;
	private Comando cmdThen;
	private Comando cmdElse;
	
	public If(Expressao cond, Comando cmdThen, Comando cmdElse) {
		this.cond = cond;
		this.cmdThen = cmdThen;
		this.cmdElse = cmdElse;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		if((Boolean)cond.valor(vars, funcs)) {
			SymbolTable<Object> vthen =
					new SymbolTable<Object>(vars);
			cmdThen.executa(vthen, funcs);
		} else {
			SymbolTable<Object> velse =
					new SymbolTable<Object>(vars);
			cmdElse.executa(velse, funcs);
		}
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		Tipo tcond = cond.tipo(vars, funcs);
		if(!(tcond instanceof Booleano))
			throw new RuntimeException("condi��o do if n�o � booleana");
		cmdThen.verificaTipo(new SymbolTable<Tipo>(vars), funcs, tret);
		cmdElse.verificaTipo(new SymbolTable<Tipo>(vars), funcs, tret);
	}

	@Override
	public void geraCod(Codigo ctx) {
		String saida = ctx.novoRotulo();
		String lelse = ctx.novoRotulo();
		ctx.push();
		cond.saltaSeFalso(ctx, lelse);
		ctx.pop();
		ctx.vars = new SymbolTable<Local>(ctx.vars);
		cmdThen.geraCod(ctx);
		ctx.emiteOp("jmp", saida);
		ctx.emiteRotulo(lelse);
		ctx.vars = new SymbolTable<Local>(ctx.vars.parent);
		cmdElse.geraCod(ctx);
		ctx.vars = ctx.vars.parent;
		ctx.emiteRotulo(saida);
	}
}

class FuncallCmd implements Comando {
	Funcall fc;
	
	FuncallCmd(String nome, List<Expressao> args) {
		this.fc = new Funcall(nome, args);
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars,
			SymbolTable<DeclFunc> funcs, Tipo tret) {
		fc.tipo(vars, funcs);
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		fc.geraCod(ctx);
		ctx.pop();
	}

	@Override
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		fc.valor(vars, funcs);
	}
}

class Repeat implements Comando {
	private Comando corpo;
	private Expressao cond;
	
	public Repeat(Comando corpo, Expressao cond) {
		this.corpo = corpo;
		this.cond = cond;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		SymbolTable<Object> vcorpo;
		do {
			vcorpo =
					new SymbolTable<Object>(vars);
			corpo.executa(vcorpo, funcs);
		} while(!(Boolean)cond.valor(vcorpo, funcs));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		SymbolTable<Tipo> stab = new SymbolTable<Tipo>(vars);
		corpo.verificaTipo(stab, funcs, tret);
		Tipo tcond = cond.tipo(stab, funcs);
		if(!(tcond instanceof Booleano))
			throw new RuntimeException("condi��o do if n�o � booleana");
	}

	@Override
	public void geraCod(Codigo ctx) {
		String inicio = ctx.novoRotulo();
		ctx.emiteRotulo(inicio);
		ctx.vars = new SymbolTable<Local>(ctx.vars);
		corpo.geraCod(ctx);
		ctx.push();
		cond.saltaSeFalso(ctx, inicio);
		ctx.pop();
		ctx.vars = ctx.vars.parent;
	}
}

class Return implements Comando {
	Expressao exp;
	
	Return(Expressao exp) {
		this.exp = exp;
	}
	
	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		// TODO verifica que o tipo de exp
		// � compat�vel com o tipo de retorno da
		// fun��o (tret)
	}

	@Override
	public void geraCod(Codigo ctx) {
		// TODO gera c�digo para return,
		// lembre que a fun��o retorna o valor
		// em EAX, e lembre do ep�logo
	}

	@Override
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		throw new Funcao.RetornoFuncao(exp.valor(vars,  funcs));
	}
	
}

class Bloco implements Comando {
	Comando corpo;
	
	Bloco(Comando corpo) {
		this.corpo = corpo;
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars,
			SymbolTable<DeclFunc> funcs, Tipo tret) {
		// TODO Verifica tipos no bloco
		// lembre do escopo!
	}

	@Override
	public void geraCod(Codigo ctx) {
		// TODO gera c�digo para o bloco
		// lembre do escopo!
	}

	@Override
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		corpo.executa(new SymbolTable<Object>(vars), funcs);
	}
}

class Write implements Comando {
	private Expressao exp;
	
	public Write(Expressao exp) {
		this.exp = exp;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		System.out.println(exp.valor(vars, funcs));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		Tipo texp = exp.tipo(vars, funcs);
		if(!(texp instanceof Inteiro))
			throw new RuntimeException("tipo inv�lido na escrita");
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		Local tmp = exp.geraCod(ctx);
		ctx.emiteMov("eax", tmp.deref(ctx));
		ctx.emiteOp("sub", "esp", "8");
		ctx.emiteOp("push", "eax");
		ctx.emiteOp("push dword", "fmt_printf$");
		ctx.emiteOp("call", "_printf");
		ctx.emiteOp("add", "esp", "16");
		ctx.pop();
	}
}

class Read implements Comando {
	private Lvalue var;
	
	static BufferedReader CONSOLE =
			new BufferedReader(new InputStreamReader(System.in));
	
	static int leNumero() {
		try {
			return Integer.parseInt(CONSOLE.readLine());
		} catch(IOException e) {
			throw new RuntimeException("n�o consegui ler do console");
		} catch(NumberFormatException e) {
			throw new RuntimeException("voc� n�o passou um n�mero: " + e.getMessage());
		}
	}
	
	public Read(Lvalue var) {
		this.var = var;
	}
	
	public void executa(SymbolTable<Object> vars, SymbolTable<Funcao> funcs) {
		var.endereco(vars, funcs).valor(leNumero());
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> vars, SymbolTable<DeclFunc> funcs, Tipo tret) {
		if(!(var.tipo(vars, funcs) instanceof Inteiro))
			throw new RuntimeException("lendo para lval n�o inteiro");
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		Local tmp = ctx.novoTemp();
		ctx.emiteOp("lea", "eax", tmp.deref(ctx));
		ctx.emiteOp("sub", "esp", "8");
		ctx.emiteOp("push", "eax");
		ctx.emiteOp("push dword", "fmt_scanf$");
		ctx.emiteOp("call", "_scanf");
		ctx.emiteOp("add", "esp", "16");
		var.geraCod(ctx).deref(ctx, tmp);
		ctx.pop();
	}
}

class Inteiro implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Inteiro;
	}

	@Override
	public Object zero() {
		return (int)0;
	}

	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}
}

class Booleano implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Booleano;
	}

	@Override
	public Object zero() {
		return false;
	}

	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}
}

class Vetor implements Tipo {
	Tipo base;
	int tamanho;
	
	Vetor(Tipo base, int tamanho) {
		this.base = base;
		this.tamanho = tamanho;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Vetor) {
			Vetor vOutro = (Vetor)outro;
			return base.igual(vOutro);
		}
		return false;
	}
	
	@Override
	public Object zero() {
		Object[] arr = new Object[tamanho];
		for(int i = 0; i < arr.length; i++)
			arr[i] = base.zero();
		return arr;
	}
	
	@Override
	public int tamanho() {
		return tamanho * base.tamanho();
	}

	@Override
	public boolean escalar() {
		return false;
	}

}

class Ponteiro implements Tipo {
	Tipo base;
	
	Ponteiro(Tipo base) {
		this.base = base;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Ponteiro) {
			return base.igual(((Ponteiro)outro).base);
		}
		return false;
	}
	
	@Override
	public Object zero() {
		return null;
	}
	
	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}

}

class Registro implements Tipo {
	List<String> nomes;
	List<Tipo> tipos;
	
	Registro() {
		this.nomes = new ArrayList<String>();
		this.tipos = new ArrayList<Tipo>();
	}
	
	void put(String nome, Tipo tipo) {
		nomes.add(nome);
		tipos.add(tipo);
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Registro) {
			Registro rOutro = (Registro)outro;
			if(tipos.size() > rOutro.tipos.size())
				return false;
			for(int i = 0; i < tipos.size(); i++)
				if(!tipos.get(i).igual(rOutro.tipos.get(i)))
					return false;
			return true;
		}
		return false;
	}
	
	@Override
	public Object zero() {
		Map<Integer, Object> reg = new HashMap<Integer, Object>();
		int offset = 0;
		for(Tipo t : tipos) {
			reg.put(offset, t.zero());
			offset += t.tamanho();
		}
		return reg;
	}
	
	@Override
	public int tamanho() {
		int tamanho = 0;
		for(Tipo t : tipos) {
			tamanho += t.tamanho();
		}
		return tamanho;
	}
	
	public int offset(String campo) {
		int i = nomes.indexOf(campo);
		int offset = 0;
		for(int j = 0; j < i; j++)
			offset += tipos.get(j).tamanho();
		return offset;
	}

	@Override
	public boolean escalar() {
		return false;
	}
}

class FuncParams {
	List<String> nomes;
	List<Tipo> tipos;
	
	FuncParams() {
		this.nomes = new ArrayList<String>();
		this.tipos = new ArrayList<Tipo>();
	}
	
	void add(String nome, Tipo tipo) {
		nomes.add(nome);
		tipos.add(tipo);
	}
}

// Fun��o no interpretador
class Funcao {
	List<String> params;
	Comando corpo;
	
	static class RetornoFuncao extends RuntimeException {
		private static final long serialVersionUID = 6283218338493932333L;

		Object val;
		
		RetornoFuncao(Object val) {
			this.val = val;
		}
	}
	
	Funcao(List<String> params, Comando corpo) {
		this.params = params;
		this.corpo = corpo;
	}
	
	Object valor(SymbolTable<Object> globais, SymbolTable<Funcao> funcs, Object[] args) {
		SymbolTable<Object> vars = new SymbolTable<Object>(globais);
		for(int i = 0; i < args.length; i++) {
			vars.insert(params.get(i), args[i]);
		}
		try {
			corpo.executa(vars, funcs);
			return null;
		} catch(RetornoFuncao rf) {
			return rf.val;
		}
	}
}
