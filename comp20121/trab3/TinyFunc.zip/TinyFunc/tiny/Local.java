package tiny;

interface Local {
	// C�digo para ler local
	String deref(Codigo ctx);
	// Escreve valor no local
	void deref(Codigo ctx, Local val);
	// Guarda endere�o em ponteiro e retorna
	Local ref(Codigo ctx);
	// Desloca local de offset
	Local offset(Codigo ctx, int offset);
	// Desloca local de (valor do indice)*tamanho
	Local offset(Codigo ctx, Local indice, int tamanho);
}

class LocalImm implements Local {
	int val;
	
	LocalImm(int val) {
		this.val = val;
	}
	
	public String deref(Codigo ctx) {
		return "dword " + String.valueOf(val);
	}

	@Override
	public Local ref(Codigo ctx) {
		throw new RuntimeException("opera��o inv�lida");
	}

	@Override
	public Local offset(Codigo ctx, int offset) {
		throw new RuntimeException("opera��o inv�lida");
	}

	@Override
	public Local offset(Codigo ctx, Local indice, int tamanho) {
		throw new RuntimeException("opera��o inv�lida");
	}

	@Override
	public void deref(Codigo ctx, Local val) {
		throw new RuntimeException("opera��o inv�lida");
	}
}

class LocalPilha implements Local {
	int offset;
	
	LocalPilha(int offset) {
		this.offset = offset;
	}
	
	@Override
	public String deref(Codigo ctx) {
		return offset < 0 ?
				"[ebp - " + (-offset) + "]"
				: "[ebp + " + offset + "]";
	}
		
	@Override
	public Local ref(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		ctx.emiteOp("lea", "eax", deref(ctx));
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp;
	}
	
	@Override
	public Local offset(Codigo ctx, int offset) {
		return new LocalPilha(this.offset + offset);
	}
	
	@Override
	public Local offset(Codigo ctx, Local indice, int tamanho) {
		switch(tamanho) {
		case 1:
		case 2:
		case 4:
		case 8:
			ctx.emiteOp("lea", "eax", deref(ctx));
			ctx.emiteMov("edx", indice.deref(ctx));
			ctx.emiteOp("lea", "eax", "[eax+edx*" +
					String.valueOf(tamanho) + "]");
		default:
			ctx.emiteOp("lea", "eax", deref(ctx));
			ctx.emiteMov("edx", indice.deref(ctx));
			ctx.emiteOp("imul", "edx", String.valueOf(tamanho));
			ctx.emiteOp("add", "eax", "edx");
		}
		Local tmp = ctx.novoTemp();
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return new LocalPonteiro(tmp);
	}

	@Override
	public void deref(Codigo ctx, Local val) {
		ctx.emiteMov("eax", val.deref(ctx));
		ctx.emiteMov(deref(ctx), "eax");
	}
}

class LocalGlobal implements Local {
	String nome;
	int offset;
	
	LocalGlobal(String nome) {
		this.nome = nome;
		this.offset = 0;
	}
	
	LocalGlobal(String nome, int offset) {
		this.nome = nome;
		this.offset = offset;
	}

	@Override
	public String deref(Codigo ctx) {
		if(offset == 0)
			return "[" + nome + "]";
		else
			return offset < 0 ?
					"[" + nome +" - " + (-offset) + "]"
					: "[" + nome +" + " + offset + "]";
	}

	@Override
	public Local ref(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		ctx.emiteOp("lea", "eax", deref(ctx));
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp;
	}

	@Override
	public Local offset(Codigo ctx, int offset) {
		return new LocalGlobal(nome, this.offset +
				offset);
	}

	@Override
	public Local offset(Codigo ctx, Local indice, int tamanho) {
		String ind = indice.deref(ctx);
		switch(tamanho) {
		case 1:
		case 2:
		case 4:
		case 8:
			ctx.emiteOp("lea", "eax", deref(ctx));
			ctx.emiteMov("edx", ind);
			ctx.emiteOp("lea", "eax", "[eax+edx*" +
					String.valueOf(tamanho) + "]");
		default:
			ctx.emiteOp("lea", "eax", deref(ctx));
			ctx.emiteMov("edx", ind);
			ctx.emiteOp("imul", "edx", String.valueOf(tamanho));
			ctx.emiteOp("add", "eax", "edx");
		}
		Local tmp = ctx.novoTemp();
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return new LocalPonteiro(tmp);
	}
	
	@Override
	public void deref(Codigo ctx, Local val) {
		ctx.emiteMov("eax", val.deref(ctx));
		ctx.emiteMov(deref(ctx), "eax");
	}
	
}

class LocalPonteiro implements Local {
	// Local onde est� guardado o endere�o de mem�ria
	Local ref;
	
	LocalPonteiro(Local ref) {
		this.ref = ref;
	}
	
	@Override
	public String deref(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		ctx.emiteMov("eax", ref.deref(ctx));
		ctx.emiteMov("eax", "[eax]");
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp.deref(ctx);
	}
	
	@Override
	public Local ref(Codigo ctx) {
		return ref;
	}
	
	@Override
	public Local offset(Codigo ctx, int offset) {		
		ctx.emiteMov("eax", ref.deref(ctx));
		ctx.emiteOp("add", "eax", String.valueOf(offset));
		Local tmp = ctx.novoTemp();
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return new LocalPonteiro(tmp);
	}
	
	@Override
	public Local offset(Codigo ctx, Local indice, int tamanho) {
		String ind = indice.deref(ctx);
		switch(tamanho) {
		case 1:
		case 2:
		case 4:
		case 8:
			ctx.emiteOp("mov", "eax", ref.deref(ctx));
			ctx.emiteMov("edx", ind);
			ctx.emiteOp("lea", "eax", "[eax+edx*" +
					String.valueOf(tamanho) + "]");
		default:
			ctx.emiteOp("mov", "eax", ref.deref(ctx));
			ctx.emiteMov("edx", ind);
			ctx.emiteOp("imul", "edx", String.valueOf(tamanho));
			ctx.emiteOp("add", "eax", "edx");
		}
		Local tmp = ctx.novoTemp();
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return new LocalPonteiro(tmp);
	}

	@Override
	public void deref(Codigo ctx, Local val) {
		String lr = ref.deref(ctx);
		String lv = val.deref(ctx);
		ctx.emiteMov("eax", lr);    // endere�o
		ctx.emiteMov("edx", lv);    // valor
		ctx.emiteMov("[eax]", "edx");
	}

}
