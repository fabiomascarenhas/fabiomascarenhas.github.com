package tiny;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;

public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Reader input = new FileReader(args[0]);
		JCParser parser = new JCParser(input);
		parser.parse();
		parser.output.verificaTipo(new SymbolTable<Tipo>());
		parser.output.executa(
				new SymbolTable<Object>());
		Codigo ctx = new Codigo();
		parser.output.geraCod(ctx);
		String outfile = args[0].replace(".tiny", ".asm");
		Writer output = new FileWriter(outfile);
		output.write("extern _printf\n");
		output.write("extern _exit\n");
		output.write("extern _scanf\n");
		output.write("segment .data\n");
		output.write("fmt_printf$ db \"%d\",10,0\n");
		output.write("fmt_scanf$ db \"%d\",0\n");
		output.write("segment .text\n");
		output.write("global _main\n");
		output.write("_main:\n");
		output.write("  push ebp\n");
		output.write("  mov ebp, esp\n");
		output.write("  sub esp, " + ctx.pilha.total + "\n");
		output.write("  and esp,0xFFFFFFF0\n");
		output.write(ctx.corpo.toString());
		output.write("  mov esp, ebp\n");
		output.write("  pop ebp\n");
		output.write("  ret\n");
		output.close();
	}

}
