package tiny;

import java.util.HashMap;
import java.util.Map;

public class SymbolTable<T> {
	SymbolTable<T> parent;
	
	private Map<String, T> map;
	
	public SymbolTable() {
		this.parent = null;
		this.map = new HashMap<String, T>();
	}

	public SymbolTable(SymbolTable<T> parent) {
		this.parent = parent;
		this.map = new HashMap<String, T>();
	}

	T lookup(String id) {
		if(map.containsKey(id)) {
			return map.get(id);
		} else {
			if(parent != null)
				return parent.lookup(id);
			else
				throw new RuntimeException("vari�vel " + id + " n�o declarada");
		}
	}
	
	void insert(String id, T data) {
		if(map.containsKey(id))
			throw new RuntimeException("vari�vel " + id + " redefinida");
		map.put(id,  data);
	}
	
	// interpretador
	void replace(String id, T data) {
		if(map.containsKey(id)) {
			map.put(id, data);
		} else {
			if(parent == null)
				throw new RuntimeException("vari�vel " + id + " n�o declarada");
			else
				parent.replace(id, data);
		}
	}
}
