package tiny;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

interface Expressao {
	Tipo tipo(SymbolTable<Tipo> symtab);
	// retorna endere�o onde est� o valor dessa exp
	Local geraCod(Codigo ctx);
	// salta para label se o resultado dessa exp � falso
	void saltaSeFalso(Codigo ctx, String lab);
	// interpretador
	Object valor(SymbolTable<Object> vars);
}

interface Lvalue extends Expressao {
	// interpretador
	interface Endereco {
		void valor(Object val);
		Object valor();
	}
	Endereco endereco(SymbolTable<Object> vars);	
}

interface Comando {
	void verificaTipo(SymbolTable<Tipo> symtab);
	void geraCod(Codigo ctx);
	// interpretador
	void executa(SymbolTable<Object> vars);
}

interface Tipo {
	boolean igual(Tipo outro);
	boolean escalar();
	int tamanho();
	Object zero();  // interpretador
}

class Num implements Expressao {
	int val;
	
	public Num(int val) {
		this.val = val;
	}
	
	public Object valor(SymbolTable<Object> vars) {
		return this.val;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return new Inteiro();
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalImm(val);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}
}

class Var implements Lvalue {
	private String nome;
	
	public Var(String nome) {
		this.nome = nome;
	}
	
	class EnderecoVar implements Endereco {
		private String nome;
		private SymbolTable<Object> vars;
				
		EnderecoVar(String nome, SymbolTable<Object> vars) {
			this.nome = nome;
			this.vars = vars;
		}
		
		@Override
		public Object valor() {
			return vars.lookup(nome);
		}

		@Override
		public void valor(Object val) {
			vars.replace(nome, val);
		}

	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars) {
		return new EnderecoVar(nome, vars);
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return vars.lookup(nome);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return symtab.lookup(nome);
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		return ctx.vars.lookup(nome);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}
}

abstract class ExpressaoArit implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoArit(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract int fazOp(int valEsq, int valDir);
	
	abstract String opcode();
	
	public Object valor(SymbolTable<Object> vars) {
		return this.fazOp((Integer)esq.valor(vars),
						  (Integer)dir.valor(vars));
	}
	
	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tesq = esq.tipo(symtab);
		Tipo tdir = dir.tipo(symtab);
		if(tesq instanceof Inteiro && tdir instanceof Inteiro)
			return new Inteiro();
		else
			throw new RuntimeException("express�o aritm�tica com argumento inv�lido");
	}
		
	@Override 
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		String le = esq.geraCod(ctx).deref(ctx);
		String ld = dir.geraCod(ctx).deref(ctx);
		ctx.emiteMov("eax", le);
		ctx.emiteOp(this.opcode(), "eax", ld);
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}
}

abstract class ExpressaoRel implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoRel(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract Boolean fazOp(int valEsq, int valDir);
	
	abstract String opcode();
	
	public Object valor(SymbolTable<Object> vars) {
		return this.fazOp((Integer)esq.valor(vars),
						  (Integer)dir.valor(vars));
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		String l1 = ctx.novoRotulo();
		String l2 = ctx.novoRotulo();
		this.saltaSeFalso(ctx, l1);
		ctx.emiteMov(tmp.deref(ctx), "1");
		ctx.emiteOp("jmp", l2);
		ctx.emiteRotulo(l1);
		ctx.emiteMov(tmp.deref(ctx), "0");
		ctx.emiteRotulo(l2);
		return tmp;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		String le = esq.geraCod(ctx).deref(ctx);
		String ld = dir.geraCod(ctx).deref(ctx);
		ctx.emiteMov("eax", le);
		ctx.emiteOp("cmp", "eax", ld);
		ctx.emiteOp(this.opcode(), lab);
	}

}

class Soma extends ExpressaoArit {
	
	public Soma(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq + valDir;
	}

	@Override
	String opcode() {
		return "add";
	}
	
}

class Sub extends ExpressaoArit {
	
	public Sub(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq - valDir;
	}

	@Override
	String opcode() {
		return "sub";
	}

}

class Mul extends ExpressaoArit {
	
	public Mul(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq * valDir;
	}

	@Override
	String opcode() {
		return "imul";
	}

}

class Div extends ExpressaoArit {
	
	public Div(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq / valDir;
	}
	
	@Override
	String opcode() {
		return "idiv dword";
	}

	@Override
	public Local geraCod(Codigo ctx) {
		Local tmp = ctx.novoTemp();
		String le = esq.geraCod(ctx).deref(ctx);
		String ld;
		Local ldir = dir.geraCod(ctx);
		if(ldir instanceof LocalImm) {
			ld = tmp.deref(ctx);
			ctx.emiteMov(ld, ldir.deref(ctx));
		} else {
			ld = ldir.deref(ctx);
		}
		ctx.emiteMov("eax", le);
		ctx.emiteOp("cdq");
		ctx.emiteOp(this.opcode(), ld);
		ctx.emiteMov(tmp.deref(ctx), "eax");
		return tmp;
	}
}

class Igual extends ExpressaoRel {
	
	public Igual(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	Boolean fazOp(int valEsq, int valDir) {
		return valEsq == valDir;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tesq = esq.tipo(symtab);
		Tipo tdir = dir.tipo(symtab);
		if(tesq instanceof Inteiro 
				|| tesq instanceof Caractere
				|| tesq instanceof Booleano
				|| tesq instanceof Ponteiro
				|| tesq instanceof Nil) {
			if(tesq.igual(tdir))
				return new Booleano();
			else
				throw new RuntimeException("comparando tipos diferentes");
		} else
			throw new RuntimeException("comparando tipo n�o escalar");
	}

	@Override
	String opcode() {
		return "jne";
	}

}

class Menor extends ExpressaoRel {
	
	public Menor(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	Boolean fazOp(int valEsq, int valDir) {
		return valEsq < valDir;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tesq = esq.tipo(symtab);
		Tipo tdir = dir.tipo(symtab);
		if(tesq instanceof Inteiro && tdir instanceof Inteiro)
			return new Booleano();
		else if(tesq instanceof Caractere && tdir instanceof Caractere)
			return new Booleano();
		else
			throw new RuntimeException("compara��o com argumento inv�lido");
	}

	@Override
	String opcode() {
		return "jge";
	}
}

class Deref implements Lvalue {
	Expressao ref;
	
	Deref(Expressao ref) {
		this.ref = ref;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		Endereco end = (Endereco)ref.valor(vars);
		return end.valor();
	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars) {
		return (Endereco)ref.valor(vars);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo texp = ref.tipo(symtab);
		if(texp instanceof Ponteiro) {
			Ponteiro p = (Ponteiro)texp;
			return p.base;
		} else
			throw new RuntimeException("tipo inv�lido na deref");
	}
	
	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalPonteiro(ref.geraCod(ctx));
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}
	
}

class Nil implements Expressao, Tipo {

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return null;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return this;
	}

	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Ponteiro ||
				outro instanceof Nil;
	}

	@Override
	public Object zero() {
		return null;
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return new LocalImm(0);
	}

	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}

}

class Str implements Expressao {
	Object[] str;
	
	Str(String str) {
		char[] cs = str.toCharArray();
		this.str = new Object[cs.length + 1];
		for(int i = 0; i < cs.length; i++)
			this.str[i] = cs[i];
		this.str[cs.length] = (char)0;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return str;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return new Vetor(new Caractere(), str.length);
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return null;
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}

}

class Ref implements Expressao {
	Lvalue exp;
	
	Ref(Lvalue exp) {
		this.exp = exp;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return exp.endereco(vars);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return new Ponteiro(exp.tipo(symtab));
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return exp.geraCod(ctx).ref(ctx);
	}

	@Override
	public void saltaSeFalso(Codigo ctx, String lab) {
		throw new RuntimeException("c�digo morto");
	}
	
}

class IndexaReg implements Lvalue {
	Expressao reg;
	String campo;
	
	int offset;

	IndexaReg(Expressao reg, String campo) {
		this.reg = reg;
		this.campo = campo;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object valor(SymbolTable<Object> vars) {
		Map<String, Object> registro = 
				(Map<String, Object>)reg.valor(vars);
		return registro.get(campo);
	}

	class EnderecoIndexaReg implements Endereco {
		private Map<String, Object> map;
		private String campo;
				
		EnderecoIndexaReg(Map<String, Object> map, 
				String campo) {
			this.map = map;
			this.campo = campo;
		}
		
		@Override
		public void valor(Object val) {
			map.put(campo, val);
		}

		@Override
		public Object valor() {
			return map.get(campo);
		}
		
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Endereco endereco(SymbolTable<Object> vars) {
		return new EnderecoIndexaReg(
				(Map<String, Object>)reg.valor(vars), campo);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo treg = reg.tipo(symtab);
		if(treg instanceof Registro) {
			Registro tr = (Registro)treg;
			if(tr.nomes.contains(campo)) {
				this.offset = tr.offset(campo);
				return tr.tipos.get(tr.nomes.indexOf(campo));
			}
			else
				throw new RuntimeException("indexa��o por campo que n�o existe: " + campo);
		} else
			throw new RuntimeException("indexa��o inv�lida");
	}

	@Override
	public Local geraCod(Codigo ctx) {
		return reg.geraCod(ctx).offset(ctx, offset);
	}

	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}

}

class IndexaVetor implements Lvalue {
	Expressao vetor;
	Expressao indice;

	int tamanhoBase;
	
	IndexaVetor(Expressao vetor, Expressao indice) {
		this.vetor = (Lvalue)vetor;
		this.indice = indice;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		Object[] vet = (Object[])vetor.valor(vars);
		int ind = (Integer)indice.valor(vars);
		return vet[ind];
	}

	class EnderecoIndexaVetor implements Endereco {
		private Object[] vetor;
		private int indice;
		
		EnderecoIndexaVetor(Object[] vetor, int indice) {
			this.vetor = vetor;
			this.indice = indice;
		}

		@Override
		public void valor(Object val) {
			vetor[indice] = val;
		}

		@Override
		public Object valor() {
			return vetor[indice];
		}
	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars) {
		return new EnderecoIndexaVetor(
					(Object[])vetor.valor(vars),
					(Integer)indice.valor(vars)
				);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tvetor = vetor.tipo(symtab);
		Tipo tind = indice.tipo(symtab);
		if(tvetor instanceof Vetor) {
			Vetor tv = (Vetor)tvetor;
			if(tind instanceof Inteiro) {
				this.tamanhoBase = tv.base.tamanho();
				return tv.base;
			} else
				throw new RuntimeException("indexa��o com �ndice inv�lido");
		} else
			throw new RuntimeException("indexa��o de n�o-vetor");
	}

	@Override
	public Local geraCod(Codigo ctx) {
		if(indice instanceof Num) {
			int offset = ((Num)indice).val * tamanhoBase;
			return vetor.geraCod(ctx).offset(ctx, offset);
		} else {
			return vetor.geraCod(ctx).offset(ctx, indice.geraCod(ctx), tamanhoBase);
		}
	}

	public void saltaSeFalso(Codigo ctx, String lab) {
		String val = this.geraCod(ctx).deref(ctx);
		ctx.emiteOp("cmp", val, "0");
		ctx.emiteOp("je", lab);
	}

}

class Vazio implements Comando {
	public void executa(SymbolTable<Object> vars) { }

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {	}

	@Override
	public void geraCod(Codigo ctx) {
	}
}

class DeclVar implements Comando {
	String nome;
	Tipo tipo;
	
	DeclVar(String nome, Tipo tipo) {
		this.nome = nome;
		this.tipo = tipo;
	}
	
	public void executa(SymbolTable<Object> vars) {
		vars.insert(nome, tipo.zero());
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		symtab.insert(nome, tipo);
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.vars.insert(nome, ctx.novaVar(tipo));
	}
}

class Seq implements Comando {
	private Comando cmd1;
	private Comando cmd2;
	
	public Seq(Comando cmd1, Comando cmd2) {
		this.cmd1 = cmd1;
		this.cmd2 = cmd2;
	}
	
	public void executa(SymbolTable<Object> vars) {
		cmd1.executa(vars);
		cmd2.executa(vars);
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		cmd1.verificaTipo(symtab);
		cmd2.verificaTipo(symtab);
	}

	@Override
	public void geraCod(Codigo ctx) {
		cmd1.geraCod(ctx);
		cmd2.geraCod(ctx);
	}

}

class Atrib implements Comando {
	private Lvalue lval;
	private Expressao rval;
	
	public Atrib(Lvalue lval, Expressao rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	public void executa(SymbolTable<Object> vars) {
		lval.endereco(vars).valor(rval.valor(vars));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		Tipo tlval = lval.tipo(symtab);
		Tipo trval = rval.tipo(symtab);
		if(tlval instanceof Inteiro 
				|| tlval instanceof Caractere
				|| tlval instanceof Booleano
				|| tlval instanceof Ponteiro) {
			if(!tlval.igual(trval))
				throw new RuntimeException("atribuindo tipos diferentes");
		} else
			throw new RuntimeException("atribuindo tipo n�o escalar");
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		lval.geraCod(ctx).deref(ctx, rval.geraCod(ctx));
		ctx.pop();
	}
	
}

class If implements Comando {
	private Expressao cond;
	private Comando cmdThen;
	private Comando cmdElse;
	
	public If(Expressao cond, Comando cmdThen, Comando cmdElse) {
		this.cond = cond;
		this.cmdThen = cmdThen;
		this.cmdElse = cmdElse;
	}
	
	public void executa(SymbolTable<Object> vars) {
		if((Boolean)cond.valor(vars)) {
			SymbolTable<Object> vthen =
					new SymbolTable<Object>(vars);
			cmdThen.executa(vthen);
		} else {
			SymbolTable<Object> velse =
					new SymbolTable<Object>(vars);
			cmdElse.executa(velse);
		}
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		Tipo tcond = cond.tipo(symtab);
		if(!(tcond instanceof Booleano))
			throw new RuntimeException("condi��o do if n�o � booleana");
		cmdThen.verificaTipo(new SymbolTable<Tipo>(symtab));
		cmdElse.verificaTipo(new SymbolTable<Tipo>(symtab));
	}

	@Override
	public void geraCod(Codigo ctx) {
		String saida = ctx.novoRotulo();
		String lelse = ctx.novoRotulo();
		ctx.push();
		cond.saltaSeFalso(ctx, lelse);
		ctx.pop();
		ctx.vars = new SymbolTable<Local>(ctx.vars);
		cmdThen.geraCod(ctx);
		ctx.emiteOp("jmp", saida);
		ctx.emiteRotulo(lelse);
		ctx.vars = new SymbolTable<Local>(ctx.vars.parent);
		cmdElse.geraCod(ctx);
		ctx.vars = ctx.vars.parent;
		ctx.emiteRotulo(saida);
	}
}

class Repeat implements Comando {
	private Comando corpo;
	private Expressao cond;
	
	public Repeat(Comando corpo, Expressao cond) {
		this.corpo = corpo;
		this.cond = cond;
	}
	
	public void executa(SymbolTable<Object> vars) {
		SymbolTable<Object> vcorpo;
		do {
			vcorpo =
					new SymbolTable<Object>(vars);
			corpo.executa(vcorpo);
		} while(!(Boolean)cond.valor(vcorpo));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		SymbolTable<Tipo> stab = new SymbolTable<Tipo>(symtab);
		corpo.verificaTipo(stab);
		Tipo tcond = cond.tipo(stab);
		if(!(tcond instanceof Booleano))
			throw new RuntimeException("condi��o do if n�o � booleana");
	}

	@Override
	public void geraCod(Codigo ctx) {
		String inicio = ctx.novoRotulo();
		ctx.emiteRotulo(inicio);
		ctx.vars = new SymbolTable<Local>(ctx.vars);
		corpo.geraCod(ctx);
		ctx.push();
		cond.saltaSeFalso(ctx, inicio);
		ctx.pop();
		ctx.vars = ctx.vars.parent;
	}
}

class Write implements Comando {
	private Expressao exp;
	
	public Write(Expressao exp) {
		this.exp = exp;
	}
	
	public void executa(SymbolTable<Object> vars) {
		System.out.println(exp.valor(vars));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		Tipo texp = exp.tipo(symtab);
		if(!(texp instanceof Inteiro))
			throw new RuntimeException("tipo inv�lido na escrita");
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		Local tmp = exp.geraCod(ctx);
		ctx.emiteMov("eax", tmp.deref(ctx));
		ctx.emiteOp("sub", "esp", "8");
		ctx.emiteOp("push", "eax");
		ctx.emiteOp("push dword", "fmt_printf$");
		ctx.emiteOp("call", "_printf");
		ctx.emiteOp("add", "esp", "16");
		ctx.pop();
	}
}

class Read implements Comando {
	private Lvalue var;
	
	static BufferedReader CONSOLE =
			new BufferedReader(new InputStreamReader(System.in));
	
	static int leNumero() {
		try {
			return Integer.parseInt(CONSOLE.readLine());
		} catch(IOException e) {
			throw new RuntimeException("n�o consegui ler do console");
		} catch(NumberFormatException e) {
			throw new RuntimeException("voc� n�o passou um n�mero: " + e.getMessage());
		}
	}
	
	public Read(Lvalue var) {
		this.var = var;
	}
	
	public void executa(SymbolTable<Object> vars) {
		var.endereco(vars).valor(leNumero());
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		if(!(var.tipo(symtab) instanceof Inteiro))
			throw new RuntimeException("lendo para lval n�o inteiro");
	}

	@Override
	public void geraCod(Codigo ctx) {
		ctx.push();
		Local tmp = ctx.novoTemp();
		ctx.emiteOp("lea", "eax", tmp.deref(ctx));
		ctx.emiteOp("sub", "esp", "8");
		ctx.emiteOp("push", "eax");
		ctx.emiteOp("push dword", "fmt_scanf$");
		ctx.emiteOp("call", "_scanf");
		ctx.emiteOp("add", "esp", "16");
		var.geraCod(ctx).deref(ctx, tmp);
		ctx.pop();
	}
}

class Inteiro implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Inteiro;
	}

	@Override
	public Object zero() {
		return (int)0;
	}

	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}
}

class Caractere implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Caractere;
	}

	@Override
	public Object zero() {
		return (char)0;
	}

	@Override
	public int tamanho() {
		return 1;
	}
	
	@Override
	public boolean escalar() {
		return true;
	}

}

class Booleano implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Booleano;
	}

	@Override
	public Object zero() {
		return false;
	}

	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}
}

class Vetor implements Tipo {
	Tipo base;
	int tamanho;
	
	Vetor(Tipo base, int tamanho) {
		this.base = base;
		this.tamanho = tamanho;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Vetor) {
			Vetor vOutro = (Vetor)outro;
			return base.igual(vOutro);
		}
		return false;
	}
	
	@Override
	public Object zero() {
		Object[] arr = new Object[tamanho];
		for(int i = 0; i < arr.length; i++)
			arr[i] = base.zero();
		return arr;
	}
	
	@Override
	public int tamanho() {
		return tamanho * base.tamanho();
	}

	@Override
	public boolean escalar() {
		return false;
	}

}

class Ponteiro implements Tipo {
	Tipo base;
	
	Ponteiro(Tipo base) {
		this.base = base;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Ponteiro) {
			return base.igual(((Ponteiro)outro).base);
		}
		return false;
	}
	
	@Override
	public Object zero() {
		return null;
	}
	
	@Override
	public int tamanho() {
		return 4;
	}

	@Override
	public boolean escalar() {
		return true;
	}

}

class Registro implements Tipo {
	List<String> nomes;
	List<Tipo> tipos;
	
	Registro() {
		this.nomes = new ArrayList<String>();
		this.tipos = new ArrayList<Tipo>();
	}
	
	void put(String nome, Tipo tipo) {
		nomes.add(nome);
		tipos.add(tipo);
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Registro) {
			Registro rOutro = (Registro)outro;
			if(tipos.size() > rOutro.tipos.size())
				return false;
			for(int i = 0; i < tipos.size(); i++)
				if(!tipos.get(i).igual(rOutro.tipos.get(i)))
					return false;
			return true;
		}
		return false;
	}
	
	@Override
	public Object zero() {
		Map<String, Object> reg = new HashMap<String, Object>();
		for(int i = 0; i < nomes.size(); i++) {
			reg.put(nomes.get(i), tipos.get(i).zero());
		}
		return reg;
	}
	
	@Override
	public int tamanho() {
		int tamanho = 0;
		for(Tipo t : tipos) {
			tamanho += t.tamanho();
		}
		return tamanho;
	}
	
	public int offset(String campo) {
		int i = nomes.indexOf(campo);
		int offset = 0;
		for(int j = 0; j < i; j++)
			offset += tipos.get(j).tamanho();
		return offset;
	}

	@Override
	public boolean escalar() {
		return false;
	}
}



