class TinyProg {
static java.util.Scanner STDIN = new java.util.Scanner(System.in);
static int readInteger() {
  return STDIN.nextInt();
}
public static void main(String[] args) {
java.util.HashMap<String,Integer> vars = new java.util.HashMap<String,Integer>();
vars.put("x",readInteger());
if(0 < vars.get("x")) {
vars.put("fact",1);
do {
vars.put("fact",vars.get("fact")*vars.get("x"));
vars.put("x",vars.get("x")-1);
} while(!(vars.get("x") == 0));
System.out.println(vars.get("fact"));
}
}
}
