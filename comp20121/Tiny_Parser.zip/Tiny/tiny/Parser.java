package tiny;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.Reader;
import java.io.Writer;

/*

tiny       ::= cmd-seq EOF
cmd-seq    ::= cmd {';' cmd}
cmd        ::= if-cmd | repeat-cmd | assign-cmd 
              | read-cmd | write-cmd
if-cmd     ::= IF exp THEN cmd-seq
               [ELSE cmd-seq] END
repeat-cmd ::= REPEAT cmd-seq UNTIL exp
assign-cmd ::= ID ':=' exp 
read-cmd   ::= READ ID
write-cmd  ::= WRITE exp
exp        ::= simple-exp [rel-op simple-exp]
rel-op     ::= '<' | '='
simple-exp ::= term {add-op term}
add-op     ::= '+' | '-'
term       ::= factor {mul-op factor}
mul-op     ::= '*' | '/'
factor     ::= '(' exp ')' | NUMBER | ID
 
 */

public class Parser {
	Token lookAhead;
	Scanner scanner;
	PrintStream output;
	
	public Parser(Reader input, PrintStream output) {
		scanner = new Scanner(input);
		lookAhead = scanner.getToken();
		this.output = output;
	}

	void match(int tok) {
		if(lookAhead.type == tok) {
			lookAhead = scanner.getToken();
		} else {
			throw new RuntimeException("esperava " + tok + ", lido " + lookAhead.type);
		}
	}
	
	// tiny       ::= cmd-seq EOF
	void tiny() {
		output.println("class TinyProg {");
		output.println("static java.util.Scanner STDIN = new java.util.Scanner(System.in);");
		output.println("static int readInteger() {");
		output.println("  return STDIN.nextInt();");
		output.println("}");
		output.println("public static void main(String[] args) {");
		output.println("java.util.HashMap<String,Integer> vars = new java.util.HashMap<String,Integer>();");
		cmdSeq();
		if(lookAhead.type != Token.EOF)
			throw new RuntimeException("entrada n�o foi lida completamente");
		output.println("}");
		output.println("}");
	}
	
	// cmd-seq    ::= cmd {';' cmd}
	void cmdSeq() {
		cmd();
		while(lookAhead.type == ';') {
			match(';');
			cmd();
		}
	}

	//cmd        ::= if-cmd | repeat-cmd | assign-cmd 
    //        | read-cmd | write-cmd
	void cmd() {
		switch(lookAhead.type) {
		case Token.IF:
			ifCmd();
			break;
		case Token.REPEAT:
			repeatCmd();
			break;
		case Token.ID:
			assignCmd();
			break;
		case Token.READ:
			readCmd();
			break;
		case Token.WRITE:
			writeCmd();
			break;
		default:
			throw new RuntimeException("comando inv�lido: " + lookAhead.type);
		}
	}
	
	// if-cmd     ::= IF exp THEN cmd-seq
    //        [ELSE cmd-seq] END
	void ifCmd() {
		match(Token.IF);
		output.print("if(");
		exp();
		output.println(") {");
		match(Token.THEN);
		cmdSeq();
		output.println("}");
		if(lookAhead.type == Token.ELSE) {
			output.println("else {");
			match(Token.ELSE);
			cmdSeq();
			output.println("}");
		}
		match(Token.END);
	}
	

	//repeat-cmd ::= REPEAT cmd-seq UNTIL exp
	void repeatCmd() {
		output.println("do {");
		match(Token.REPEAT);
		cmdSeq();
		match(Token.UNTIL);
		output.print("} while(!(");
		exp();
		output.println("));");
	}
	
	// assign-cmd ::= ID ':=' exp
	void assignCmd() {
		output.print("vars.put(\"");
		output.print(lookAhead.strVal);
		output.print("\",");
		match(Token.ID);
		match(Token.ASSIGN);
		exp();
		output.println(");");
	}

	// read-cmd   ::= READ ID
	void readCmd() {
		match(Token.READ);
		output.print("vars.put(\"");
		output.print(lookAhead.strVal);
		output.println("\",readInteger());");
		match(Token.ID);
	}
	
	// write-cmd  ::= WRITE exp
	void writeCmd() {
		match(Token.WRITE);
		output.print("System.out.println(");
		exp();
		output.println(");");
	}

	// exp        ::= simple-exp [rel-op simple-exp]
	// rel-op     ::= '<' | '='
	void exp() {
		simpleExp();
		if(lookAhead.type == '<') {
			lookAhead = scanner.getToken();
			output.print(" < ");
			simpleExp();
		} else if(lookAhead.type == '=') {
			lookAhead = scanner.getToken();
			output.print(" == ");
			simpleExp();
		}
	}
			
	// simple-exp ::= term {add-op term}
	// add-op     ::= '+' | '-'
	void simpleExp() {
		term();
		while(lookAhead.type == '+' ||
				lookAhead.type == '-') {
			output.print(Character.toString((char)lookAhead.type));
			lookAhead = scanner.getToken();
			term();
		}
	}

	// term       ::= factor {mul-op factor}
	// mul-op     ::= '*' | '/'
	void term() {
		factor();
		while(lookAhead.type == '*' ||
				lookAhead.type == '/') {
			output.print(Character.toString((char)lookAhead.type));
			lookAhead = scanner.getToken();
			factor();
		}
	}
	
	// factor     ::= '(' exp ')' | NUMBER | ID
	void factor() {
		switch(lookAhead.type) {
		case '(':
			match('(');
			output.print("(");
			exp();
			match(')');
			output.print(")");
			break;
		case Token.NUM:
			output.print(lookAhead.intVal);
			match(Token.NUM);
			break;
		case Token.ID:
			output.print("vars.get(\"");
			output.print(lookAhead.strVal);
			output.print("\")");
			match(Token.ID);
			break;
		default:
			throw new RuntimeException("express�o at�mica n�o reconhecida: " + lookAhead.type);
		}
	}
			
}
