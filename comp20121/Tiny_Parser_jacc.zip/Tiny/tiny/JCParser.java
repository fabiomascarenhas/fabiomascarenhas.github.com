// Output created by jacc on Wed May 16 16:11:14 BRT 2012

package tiny;

class JCParser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 44:
                    switch (yytok) {
                        case ID:
                            yyn = 4;
                            continue;
                        case IF:
                            yyn = 5;
                            continue;
                        case READ:
                            yyn = 6;
                            continue;
                        case REPEAT:
                            yyn = 7;
                            continue;
                        case WRITE:
                            yyn = 8;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 45:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 88;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 46:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 47:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case ELSE:
                        case ';':
                        case END:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 48:
                    switch (yytok) {
                        case ASSIGN:
                            yyn = 10;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 49:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 50:
                    switch (yytok) {
                        case ID:
                            yyn = 16;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 51:
                    switch (yytok) {
                        case ID:
                            yyn = 4;
                            continue;
                        case IF:
                            yyn = 5;
                            continue;
                        case READ:
                            yyn = 6;
                            continue;
                        case REPEAT:
                            yyn = 7;
                            continue;
                        case WRITE:
                            yyn = 8;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 52:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 53:
                    switch (yytok) {
                        case ID:
                            yyn = 4;
                            continue;
                        case IF:
                            yyn = 5;
                            continue;
                        case READ:
                            yyn = 6;
                            continue;
                        case REPEAT:
                            yyn = 7;
                            continue;
                        case WRITE:
                            yyn = 8;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 54:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 55:
                    yyn = yys11();
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 56:
                    yyn = yys12();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 57:
                    yyn = yys13();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 58:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 59:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 60:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case ELSE:
                        case ';':
                        case END:
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 61:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                        case UNTIL:
                            yyn = 30;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 62:
                    yyn = yys18();
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 63:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case ELSE:
                        case ';':
                        case END:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 64:
                    yyn = yys20();
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 65:
                    switch (yytok) {
                        case ID:
                            yyn = 4;
                            continue;
                        case IF:
                            yyn = 5;
                            continue;
                        case READ:
                            yyn = 6;
                            continue;
                        case REPEAT:
                            yyn = 7;
                            continue;
                        case WRITE:
                            yyn = 8;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 66:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 67:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 68:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 69:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 70:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 71:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 72:
                    yyn = yys28();
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 73:
                    yyn = yys29();
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 74:
                    switch (yytok) {
                        case ID:
                            yyn = 12;
                            continue;
                        case NUM:
                            yyn = 13;
                            continue;
                        case '(':
                            yyn = 14;
                            continue;
                        case '-':
                            yyn = 15;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 75:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                        case ELSE:
                            yyn = 40;
                            continue;
                        case END:
                            yyn = 41;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 76:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 77:
                    yyn = yys33();
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 78:
                    yyn = yys34();
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 79:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 80:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 81:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 82:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 83:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 84:
                    switch (yytok) {
                        case ID:
                            yyn = 4;
                            continue;
                        case IF:
                            yyn = 5;
                            continue;
                        case READ:
                            yyn = 6;
                            continue;
                        case REPEAT:
                            yyn = 7;
                            continue;
                        case WRITE:
                            yyn = 8;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 85:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case ELSE:
                        case ';':
                        case END:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 86:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                        case END:
                            yyn = 43;
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 87:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case ELSE:
                        case ';':
                        case END:
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 91;
                    continue;

                case 88:
                    return true;
                case 89:
                    yyerror("stack overflow");
                case 90:
                    return false;
                case 91:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys11() {
        switch (yytok) {
            case THEN:
                return 21;
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case '<':
                return 26;
            case '=':
                return 27;
        }
        return 91;
    }

    private int yys12() {
        switch (yytok) {
            case READ:
            case WRITE:
            case ID:
            case BEGIN:
            case error:
            case NUM:
            case ASSIGN:
            case UNM:
            case IF:
            case REPEAT:
            case '(':
                return 91;
        }
        return yyr19();
    }

    private int yys13() {
        switch (yytok) {
            case READ:
            case WRITE:
            case ID:
            case BEGIN:
            case error:
            case NUM:
            case ASSIGN:
            case UNM:
            case IF:
            case REPEAT:
            case '(':
                return 91;
        }
        return yyr18();
    }

    private int yys18() {
        switch (yytok) {
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case '<':
                return 26;
            case '=':
                return 27;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case ';':
            case END:
                return yyr9();
        }
        return 91;
    }

    private int yys20() {
        switch (yytok) {
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case '<':
                return 26;
            case '=':
                return 27;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case ';':
            case END:
                return yyr7();
        }
        return 91;
    }

    private int yys28() {
        switch (yytok) {
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case '<':
                return 26;
            case '=':
                return 27;
            case ')':
                return 38;
        }
        return 91;
    }

    private int yys29() {
        switch (yytok) {
            case READ:
            case WRITE:
            case ID:
            case BEGIN:
            case error:
            case NUM:
            case ASSIGN:
            case UNM:
            case IF:
            case REPEAT:
            case '(':
                return 91;
        }
        return yyr16();
    }

    private int yys32() {
        switch (yytok) {
            case READ:
            case WRITE:
            case ID:
            case BEGIN:
            case error:
            case NUM:
            case ASSIGN:
            case UNM:
            case IF:
            case REPEAT:
            case '(':
                return 91;
        }
        return yyr12();
    }

    private int yys33() {
        switch (yytok) {
            case '*':
                return 22;
            case '/':
                return 25;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case '<':
            case ';':
            case THEN:
            case '-':
            case '+':
            case '=':
            case ')':
            case END:
                return yyr10();
        }
        return 91;
    }

    private int yys34() {
        switch (yytok) {
            case '*':
                return 22;
            case '/':
                return 25;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case '<':
            case ';':
            case THEN:
            case '-':
            case '+':
            case '=':
            case ')':
            case END:
                return yyr11();
        }
        return 91;
    }

    private int yys35() {
        switch (yytok) {
            case READ:
            case WRITE:
            case ID:
            case BEGIN:
            case error:
            case NUM:
            case ASSIGN:
            case UNM:
            case IF:
            case REPEAT:
            case '(':
                return 91;
        }
        return yyr13();
    }

    private int yys36() {
        switch (yytok) {
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case '<':
            case ';':
            case THEN:
            case '=':
            case ')':
            case END:
                return yyr15();
        }
        return 91;
    }

    private int yys37() {
        switch (yytok) {
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case '<':
            case ';':
            case THEN:
            case '=':
            case ')':
            case END:
                return yyr14();
        }
        return 91;
    }

    private int yys38() {
        switch (yytok) {
            case READ:
            case WRITE:
            case ID:
            case BEGIN:
            case error:
            case NUM:
            case ASSIGN:
            case UNM:
            case IF:
            case REPEAT:
            case '(':
                return 91;
        }
        return yyr17();
    }

    private int yys39() {
        switch (yytok) {
            case '*':
                return 22;
            case '+':
                return 23;
            case '-':
                return 24;
            case '/':
                return 25;
            case '<':
                return 26;
            case '=':
                return 27;
            case ENDINPUT:
            case UNTIL:
            case ELSE:
            case ';':
            case END:
                return yyr6();
        }
        return 91;
    }

    private int yyr1() { // tiny : cmd_seq
        { output = ((Comando)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr2() { // cmd_seq : cmd
        yysp -= 1;
        return yypcmd_seq();
    }

    private int yyr3() { // cmd_seq : cmd_seq ';' cmd
        { yyrv = new Seq(((Comando)yysv[yysp-3]), ((Comando)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 21: return 31;
            case 7: return 17;
            case 0: return 2;
            default: return 42;
        }
    }

    private int yyr10() { // exp : exp '+' exp
        { yyrv = new Soma(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr11() { // exp : exp '-' exp
        { yyrv = new Sub(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr12() { // exp : exp '*' exp
        { yyrv = new Mul(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr13() { // exp : exp '/' exp
        { yyrv = new Div(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr14() { // exp : exp '=' exp
        { yyrv = new Igual(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr15() { // exp : exp '<' exp
        { yyrv = new Menor(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr16() { // exp : '-' exp
        { yyrv = new Sub(new Num(0), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr17() { // exp : '(' exp ')'
        { yyrv = ((Expressao)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr18() { // exp : NUM
        { yyrv = new Num(((Integer)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr19() { // exp : ID
        { yyrv = new Var(((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 27: return 37;
            case 26: return 36;
            case 25: return 35;
            case 24: return 34;
            case 23: return 33;
            case 22: return 32;
            case 15: return 29;
            case 14: return 28;
            case 10: return 20;
            case 8: return 18;
            case 5: return 11;
            default: return 39;
        }
    }

    private int yyr4() { // cmd : IF exp THEN cmd_seq END
        { yyrv = new If(((Expressao)yysv[yysp-4]), ((Comando)yysv[yysp-2]), new Vazio()); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr5() { // cmd : IF exp THEN cmd_seq ELSE cmd_seq END
        { yyrv = new If(((Expressao)yysv[yysp-6]), ((Comando)yysv[yysp-4]), ((Comando)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr6() { // cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = new Repeat(((Comando)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr7() { // cmd : ID ASSIGN exp
        { yyrv = new Atrib(((String)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr8() { // cmd : READ ID
        { yyrv = new Read(((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr9() { // cmd : WRITE exp
        { yyrv = new Write(((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 9: return 19;
            default: return 3;
        }
    }

    protected String[] yyerrmsgs = {
    };


// C�digo extra

int tokenType;
Object tokenVal;
Token tok;

JFScanner scanner;
Comando output;

JCParser(java.io.Reader input) {
  scanner = new JFScanner(input);
  getToken();
}

int getToken() {
  try {
    tok = scanner.getToken();
    tokenType = tok.type;
    tokenVal = (tokenType == NUM ? tok.intVal :
                                tok.strVal);
    return tokenType;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException(msg + " no token " + tok);
}

}
