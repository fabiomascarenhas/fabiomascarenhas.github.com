package tiny;

import java.io.FileReader;
import java.io.Reader;
import java.util.HashMap;

public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Reader input = new FileReader(args[0]);
		JCParser parser = new JCParser(input);
		parser.parse();
		parser.output.executa(
				new HashMap<String, Integer>());
	}

}
