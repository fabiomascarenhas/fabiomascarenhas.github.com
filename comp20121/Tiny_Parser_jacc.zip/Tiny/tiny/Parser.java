package tiny;

import java.io.PrintStream;
import java.io.Reader;

/*

tiny       ::= cmd-seq EOF
cmd-seq    ::= cmd {';' cmd}
cmd        ::= if-cmd | repeat-cmd | assign-cmd 
              | read-cmd | write-cmd
if-cmd     ::= IF exp THEN cmd-seq
               [ELSE cmd-seq] END
repeat-cmd ::= REPEAT cmd-seq UNTIL exp
assign-cmd ::= ID ':=' exp 
read-cmd   ::= READ ID
write-cmd  ::= WRITE exp
exp        ::= simple-exp [rel-op simple-exp]
rel-op     ::= '<' | '='
simple-exp ::= term {add-op term}
add-op     ::= '+' | '-'
term       ::= factor {mul-op factor}
mul-op     ::= '*' | '/'
factor     ::= '(' exp ')' | NUMBER | ID
 
 */

public class Parser {
	Token lookAhead;
	Scanner scanner;
	Comando output;
	
	public Parser(Reader input) {
		scanner = new Scanner(input);
		lookAhead = scanner.getToken();
	}

	void match(int tok) {
		if(lookAhead.type == tok) {
			lookAhead = scanner.getToken();
		} else {
			throw new RuntimeException("esperava " + tok + ", lido " + lookAhead.type);
		}
	}
	
	// tiny       ::= cmd-seq EOF
	void parse() {
		output = cmdSeq();
		if(lookAhead.type != Token.EOF)
			throw new RuntimeException("entrada n�o foi lida completamente");
	}
	
	// cmd-seq    ::= cmd {';' cmd}
	Comando cmdSeq() {
		Comando cmd = cmd();
		while(lookAhead.type == ';') {
			match(';');
			cmd = new Seq(cmd, cmd());
		}
		return cmd;
	}

	//cmd        ::= if-cmd | repeat-cmd | assign-cmd 
    //        | read-cmd | write-cmd
	Comando cmd() {
		switch(lookAhead.type) {
		case Token.IF:
			return ifCmd();
		case Token.REPEAT:
			return repeatCmd();
		case Token.ID:
			return assignCmd();
		case Token.READ:
			return readCmd();
		case Token.WRITE:
			return writeCmd();
		default:
			throw new RuntimeException("comando inv�lido: " + lookAhead.type);
		}
	}
	
	// if-cmd     ::= IF exp THEN cmd-seq
    //        [ELSE cmd-seq] END
	Comando ifCmd() {
		If res;
		match(Token.IF);
		Expressao cond = exp();
		match(Token.THEN);
		Comando then = cmdSeq();
		if(lookAhead.type == Token.ELSE) {
			match(Token.ELSE);
			res = new If(cond, then, cmdSeq());
		} else {
			res = new If(cond, then, new Vazio());
		}
		match(Token.END);
		return res;
	}
	

	//repeat-cmd ::= REPEAT cmd-seq UNTIL exp
	Comando repeatCmd() {
		match(Token.REPEAT);
		Comando corpo = cmdSeq();
		match(Token.UNTIL);
		return new Repeat(corpo, exp());
	}
	
	// assign-cmd ::= ID ':=' exp
	Comando assignCmd() {
		String id = lookAhead.strVal;
		match(Token.ID);
		match(Token.ASSIGN);
		return new Atrib(id, exp());
	}

	// read-cmd   ::= READ ID
	Comando readCmd() {
		match(Token.READ);
		String id = lookAhead.strVal;
		match(Token.ID);
		return new Read(id);
	}
	
	// write-cmd  ::= WRITE exp
	Comando writeCmd() {
		match(Token.WRITE);
		return new Write(exp());
	}

	// exp        ::= simple-exp [rel-op simple-exp]
	// rel-op     ::= '<' | '='
	Expressao exp() {
		Expressao exp = simpleExp();
		if(lookAhead.type == '<') {
			lookAhead = scanner.getToken();
			return new Menor(exp, simpleExp());
		} else if(lookAhead.type == '=') {
			lookAhead = scanner.getToken();
			return new Igual(exp, simpleExp());
		}
		return exp;
	}
			
	// simple-exp ::= term {add-op term}
	// add-op     ::= '+' | '-'
	Expressao simpleExp() {
		Expressao exp = term();
		while(lookAhead.type == '+' ||
				lookAhead.type == '-') {
			if(lookAhead.type == '+') {
				match('+');
				exp = new Soma(exp, term());
			} else {
				match('-');
				exp = new Sub(exp, term());
			}
		}
		return exp;
	}

	// term       ::= factor {mul-op factor}
	// mul-op     ::= '*' | '/'
	Expressao term() {
		Expressao exp = factor();
		while(lookAhead.type == '*' ||
				lookAhead.type == '/') {
			if(lookAhead.type == '*') {
				match('*');
				exp = new Mul(exp, factor());
			} else {
				match('/');
				exp = new Div(exp, factor());
			}
		}
		return exp;
	}
	
	// factor     ::= '(' exp ')' | NUMBER | ID
	Expressao factor() {
		switch(lookAhead.type) {
		case '(':
			match('(');
			Expressao exp = exp();
			match(')');
			return exp;
		case Token.NUM:
			int val = lookAhead.intVal;
			match(Token.NUM);
			return new Num(val);
		case Token.ID:
			String id = lookAhead.strVal;
			match(Token.ID);
			return new Var(id);
		default:
			throw new RuntimeException("express�o at�mica n�o reconhecida: " + lookAhead.type);
		}
	}
			
}
