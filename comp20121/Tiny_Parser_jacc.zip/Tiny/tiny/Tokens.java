// Output created by jacc on Wed May 16 16:11:14 BRT 2012

package tiny;

interface Tokens {
    int ENDINPUT = 0;
    int ASSIGN = 1;
    int BEGIN = 2;
    int ELSE = 3;
    int END = 4;
    int ID = 5;
    int IF = 6;
    int NUM = 7;
    int READ = 8;
    int REPEAT = 9;
    int THEN = 10;
    int UNM = 11;
    int UNTIL = 12;
    int WRITE = 13;
    int error = 14;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // '-' (code=45)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
