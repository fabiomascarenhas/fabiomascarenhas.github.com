package tiny;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;

interface Expressao {
	int valor(Map<String,Integer> vars);
}

interface Comando {
	void executa(Map<String,Integer> vars);
}

class Num implements Expressao {
	private int val;
	
	public Num(int val) {
		this.val = val;
	}
	
	public int valor(Map<String, Integer> vars) {
		return this.val;
	}
}

class Var implements Expressao {
	private String nome;
	
	public Var(String nome) {
		this.nome = nome;
	}
		
	public int valor(Map<String, Integer> vars) {
		return vars.get(nome);
	}
}

abstract class ExpressaoBinaria implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoBinaria(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract int fazOp(int valEsq, int valDir);
	
	public int valor(Map<String, Integer> vars) {
		return this.fazOp(esq.valor(vars), dir.valor(vars));
	}
}

class Soma extends ExpressaoBinaria {
	
	public Soma(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	int fazOp(int valEsq, int valDir) {
		return valEsq + valDir;
	}
	
}

class Sub extends ExpressaoBinaria {
	
	public Sub(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	int fazOp(int valEsq, int valDir) {
		return valEsq - valDir;
	}
	
}

class Mul extends ExpressaoBinaria {
	
	public Mul(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	int fazOp(int valEsq, int valDir) {
		return valEsq * valDir;
	}
	
}

class Div extends ExpressaoBinaria {
	
	public Div(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	int fazOp(int valEsq, int valDir) {
		return valEsq / valDir;
	}
	
}

class Igual extends ExpressaoBinaria {
	
	public Igual(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq == valDir ? 1 : 0;
	}
	
}

class Menor extends ExpressaoBinaria {
	
	public Menor(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	int fazOp(int valEsq, int valDir) {
		return valEsq < valDir ? 1 : 0;
	}
	
}

class Vazio implements Comando {
	public void executa(Map<String, Integer> vars) { }
}

class Seq implements Comando {
	private Comando cmd1;
	private Comando cmd2;
	
	public Seq(Comando cmd1, Comando cmd2) {
		this.cmd1 = cmd1;
		this.cmd2 = cmd2;
	}
	
	public void executa(Map<String, Integer> vars) {
		cmd1.executa(vars);
		cmd2.executa(vars);
	}
}

class Atrib implements Comando {
	private String lval;
	private Expressao rval;
	
	public Atrib(String lval, Expressao rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	public void executa(Map<String, Integer> vars) {
		vars.put(lval, rval.valor(vars));
	}
	
}

class If implements Comando {
	private Expressao cond;
	private Comando cmdThen;
	private Comando cmdElse;
	
	public If(Expressao cond, Comando cmdThen, Comando cmdElse) {
		this.cond = cond;
		this.cmdThen = cmdThen;
		this.cmdElse = cmdElse;
	}
	
	public void executa(Map<String, Integer> vars) {
		if(cond.valor(vars) != 0) {
			cmdThen.executa(vars);
		} else {
			cmdElse.executa(vars);
		}
	}
}

class Repeat implements Comando {
	private Comando corpo;
	private Expressao cond;
	
	public Repeat(Comando corpo, Expressao cond) {
		this.corpo = corpo;
		this.cond = cond;
	}
	
	public void executa(Map<String, Integer> vars) {
		do {
			corpo.executa(vars);
		} while(cond.valor(vars) == 0);
	}
}

class Write implements Comando {
	private Expressao exp;
	
	public Write(Expressao exp) {
		this.exp = exp;
	}
	
	public void executa(Map<String, Integer> vars) {
		System.out.println(exp.valor(vars));
	}
}

class Read implements Comando {
	private String var;
	
	static BufferedReader CONSOLE =
			new BufferedReader(new InputStreamReader(System.in));
	
	static int leNumero() {
		try {
			return Integer.parseInt(CONSOLE.readLine());
		} catch(IOException e) {
			throw new RuntimeException("n�o consegui ler do console");
		} catch(NumberFormatException e) {
			throw new RuntimeException("voc� n�o passou um n�mero: " + e.getMessage());
		}
	}
	
	public Read(String var) {
		this.var = var;
	}
	
	public void executa(Map<String, Integer> vars) {
		vars.put(this.var, leNumero());
	}
}

