// Output created by jacc on Mon May 28 15:27:43 BRT 2012

package tiny;


import java.util.Map;
import java.util.TreeMap;


class JCParser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 86:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 87:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 172;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 88:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 89:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 90:
                    switch (yytok) {
                        case ASSIGN:
                            yyn = 12;
                            continue;
                        case '.':
                            yyn = 13;
                            continue;
                        case '[':
                            yyn = 14;
                            continue;
                        case '^':
                            yyn = 15;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 91:
                    yyn = yys5();
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 92:
                    yyn = yys6();
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 93:
                    switch (yytok) {
                        case ID:
                            yyn = 5;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 94:
                    yyn = yys8();
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 95:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 96:
                    yyn = yys10();
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 97:
                    yyn = yys11();
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    yyn = yys12();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 100:
                    yyn = yys14();
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    yyn = yys15();
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    yyn = yys16();
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    yyn = yys17();
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    yyn = yys18();
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    yyn = yys20();
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    yyn = yys21();
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    yyn = yys22();
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    switch (yytok) {
                        case ID:
                            yyn = 5;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    yyn = yys24();
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case UNTIL:
                            yyn = 45;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    switch (yytok) {
                        case ':':
                            yyn = 46;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    yyn = yys27();
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    yyn = yys29();
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    yyn = yys30();
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    yyn = yys31();
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    yyn = yys33();
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    yyn = yys34();
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    switch (yytok) {
                        case ID:
                            yyn = 52;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    yyn = yys45();
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    yyn = yys46();
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ELSE:
                            yyn = 66;
                            continue;
                        case END:
                            yyn = 67;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    yyn = yys49();
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    yyn = yys50();
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    yyn = yys51();
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    yyn = yys53();
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    yyn = yys54();
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    yyn = yys57();
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case '[':
                            yyn = 69;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ID:
                            yyn = 71;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case NUM:
                            yyn = 74;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case END:
                            yyn = 75;
                            continue;
                        case ';':
                            yyn = 76;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case ':':
                            yyn = 77;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 78;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ']':
                            yyn = 79;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    switch (yytok) {
                        case ID:
                            yyn = 80;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    switch (yytok) {
                        case OF:
                            yyn = 82;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    switch (yytok) {
                        case ':':
                            yyn = 83;
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys82();
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys83();
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    switch (yytok) {
                        case END:
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 175;
                    continue;

                case 172:
                    return true;
                case 173:
                    yyerror("stack overflow");
                case 174:
                    return false;
                case 175:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case ID:
                return 5;
            case IF:
                return 6;
            case READ:
                return 7;
            case REPEAT:
                return 8;
            case VAR:
                return 9;
            case WRITE:
                return 10;
        }
        return 175;
    }

    private int yys5() {
        switch (yytok) {
            case '-':
            case '*':
            case END:
            case ')':
            case '+':
            case ELSE:
            case '.':
            case UNTIL:
            case ENDINPUT:
            case '^':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ']':
            case ';':
            case '/':
            case ASSIGN:
                return yyr19();
        }
        return 175;
    }

    private int yys6() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys8() {
        switch (yytok) {
            case ID:
                return 5;
            case IF:
                return 6;
            case READ:
                return 7;
            case REPEAT:
                return 8;
            case VAR:
                return 9;
            case WRITE:
                return 10;
        }
        return 175;
    }

    private int yys10() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys11() {
        switch (yytok) {
            case ID:
                return 5;
            case IF:
                return 6;
            case READ:
                return 7;
            case REPEAT:
                return 8;
            case VAR:
                return 9;
            case WRITE:
                return 10;
        }
        return 175;
    }

    private int yys12() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys14() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys15() {
        switch (yytok) {
            case '-':
            case '*':
            case END:
            case ')':
            case '+':
            case ELSE:
            case '.':
            case UNTIL:
            case ENDINPUT:
            case '^':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ']':
            case ';':
            case '/':
            case ASSIGN:
                return yyr22();
        }
        return 175;
    }

    private int yys16() {
        switch (yytok) {
            case THEN:
                return 32;
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
        }
        return 175;
    }

    private int yys17() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr36();
        }
        return 175;
    }

    private int yys18() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr37();
        }
        return 175;
    }

    private int yys19() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr35();
        }
        return 175;
    }

    private int yys20() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr38();
        }
        return 175;
    }

    private int yys21() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys22() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys24() {
        switch (yytok) {
            case '.':
                return 13;
            case '[':
                return 14;
            case '^':
                return 15;
            case END:
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
                return yyr16();
        }
        return 175;
    }

    private int yys27() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
            case END:
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
                return yyr17();
        }
        return 175;
    }

    private int yys29() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
            case END:
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
                return yyr15();
        }
        return 175;
    }

    private int yys30() {
        switch (yytok) {
            case '-':
            case '*':
            case END:
            case ')':
            case '+':
            case ELSE:
            case '.':
            case UNTIL:
            case ENDINPUT:
            case '^':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ']':
            case ';':
            case '/':
            case ASSIGN:
                return yyr21();
        }
        return 175;
    }

    private int yys31() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
            case ']':
                return 47;
        }
        return 175;
    }

    private int yys32() {
        switch (yytok) {
            case ID:
                return 5;
            case IF:
                return 6;
            case READ:
                return 7;
            case REPEAT:
                return 8;
            case VAR:
                return 9;
            case WRITE:
                return 10;
        }
        return 175;
    }

    private int yys33() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys34() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys35() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys37() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys38() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys39() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys40() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys41() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr31();
        }
        return 175;
    }

    private int yys42() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
            case ')':
                return 57;
        }
        return 175;
    }

    private int yys43() {
        switch (yytok) {
            case '.':
                return 36;
            case '[':
                return 40;
            case '^':
                return 41;
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr29();
        }
        return 175;
    }

    private int yys44() {
        switch (yytok) {
            case '.':
                return 13;
            case '[':
                return 14;
            case '^':
                return 15;
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr32();
        }
        return 175;
    }

    private int yys45() {
        switch (yytok) {
            case ID:
                return 17;
            case NIL:
                return 18;
            case NUM:
                return 19;
            case STRING:
                return 20;
            case '(':
                return 21;
            case '-':
                return 22;
            case '@':
                return 23;
        }
        return 175;
    }

    private int yys46() {
        switch (yytok) {
            case ARRAY:
                return 60;
            case BOOL:
                return 61;
            case CHAR:
                return 62;
            case INT:
                return 63;
            case RECORD:
                return 64;
            case '^':
                return 65;
        }
        return 175;
    }

    private int yys47() {
        switch (yytok) {
            case '-':
            case '*':
            case END:
            case ')':
            case '+':
            case ELSE:
            case '.':
            case UNTIL:
            case ENDINPUT:
            case '^':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ']':
            case ';':
            case '/':
            case ASSIGN:
                return yyr20();
        }
        return 175;
    }

    private int yys49() {
        switch (yytok) {
            case '.':
                return 36;
            case '[':
                return 40;
            case '^':
                return 41;
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr25();
        }
        return 175;
    }

    private int yys50() {
        switch (yytok) {
            case '*':
                return 33;
            case '.':
                return 36;
            case '/':
                return 37;
            case '[':
                return 40;
            case '^':
                return 41;
            case '-':
            case '+':
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr23();
        }
        return 175;
    }

    private int yys51() {
        switch (yytok) {
            case '*':
                return 33;
            case '.':
                return 36;
            case '/':
                return 37;
            case '[':
                return 40;
            case '^':
                return 41;
            case '-':
            case '+':
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr24();
        }
        return 175;
    }

    private int yys52() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr33();
        }
        return 175;
    }

    private int yys53() {
        switch (yytok) {
            case '.':
                return 36;
            case '[':
                return 40;
            case '^':
                return 41;
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr26();
        }
        return 175;
    }

    private int yys54() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '[':
                return 40;
            case '^':
                return 41;
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr28();
        }
        return 175;
    }

    private int yys55() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '[':
                return 40;
            case '^':
                return 41;
            case END:
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr27();
        }
        return 175;
    }

    private int yys56() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
            case ']':
                return 68;
        }
        return 175;
    }

    private int yys57() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr34();
        }
        return 175;
    }

    private int yys58() {
        switch (yytok) {
            case '*':
                return 33;
            case '+':
                return 34;
            case '-':
                return 35;
            case '.':
                return 36;
            case '/':
                return 37;
            case '<':
                return 38;
            case '=':
                return 39;
            case '[':
                return 40;
            case '^':
                return 41;
            case END:
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
                return yyr14();
        }
        return 175;
    }

    private int yys65() {
        switch (yytok) {
            case ARRAY:
                return 60;
            case BOOL:
                return 61;
            case CHAR:
                return 62;
            case INT:
                return 63;
            case RECORD:
                return 64;
            case '^':
                return 65;
        }
        return 175;
    }

    private int yys66() {
        switch (yytok) {
            case ID:
                return 5;
            case IF:
                return 6;
            case READ:
                return 7;
            case REPEAT:
                return 8;
            case VAR:
                return 9;
            case WRITE:
                return 10;
        }
        return 175;
    }

    private int yys68() {
        switch (yytok) {
            case '-':
            case '+':
            case '*':
            case END:
            case ')':
            case '.':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '^':
            case ']':
            case '[':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
                return yyr30();
        }
        return 175;
    }

    private int yys77() {
        switch (yytok) {
            case ARRAY:
                return 60;
            case BOOL:
                return 61;
            case CHAR:
                return 62;
            case INT:
                return 63;
            case RECORD:
                return 64;
            case '^':
                return 65;
        }
        return 175;
    }

    private int yys82() {
        switch (yytok) {
            case ARRAY:
                return 60;
            case BOOL:
                return 61;
            case CHAR:
                return 62;
            case INT:
                return 63;
            case RECORD:
                return 64;
            case '^':
                return 65;
        }
        return 175;
    }

    private int yys83() {
        switch (yytok) {
            case ARRAY:
                return 60;
            case BOOL:
                return 61;
            case CHAR:
                return 62;
            case INT:
                return 63;
            case RECORD:
                return 64;
            case '^':
                return 65;
        }
        return 175;
    }

    private int yyr1() { // tiny : cmd_seq
        { output = ((Comando)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr12() { // cmd : IF exp THEN cmd_seq END
        { yyrv = new If(((Expressao)yysv[yysp-4]), ((Comando)yysv[yysp-2]), new Vazio()); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr13() { // cmd : IF exp THEN cmd_seq ELSE cmd_seq END
        { yyrv = new If(((Expressao)yysv[yysp-6]), ((Comando)yysv[yysp-4]), ((Comando)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr14() { // cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = new Repeat(((Comando)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr15() { // cmd : lval ASSIGN exp
        { yyrv = new Atrib(((Lvalue)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr16() { // cmd : READ lval
        { yyrv = new Read(((Lvalue)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr17() { // cmd : WRITE exp
        { yyrv = new Write(((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr18() { // cmd : VAR ID ':' tipo
        { yyrv = new DeclVar(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 11: return 28;
            default: return 2;
        }
    }

    private int yyr2() { // cmd_seq : cmd
        yysp -= 1;
        return yypcmd_seq();
    }

    private int yyr3() { // cmd_seq : cmd_seq ';' cmd
        { yyrv = new Seq(((Comando)yysv[yysp-3]), ((Comando)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 32: return 48;
            case 8: return 25;
            case 0: return 3;
            default: return 73;
        }
    }

    private int yyr23() { // exp : exp '+' exp
        { yyrv = new Soma(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr24() { // exp : exp '-' exp
        { yyrv = new Sub(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr25() { // exp : exp '*' exp
        { yyrv = new Mul(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr26() { // exp : exp '/' exp
        { yyrv = new Div(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr27() { // exp : exp '=' exp
        { yyrv = new Igual(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr28() { // exp : exp '<' exp
        { yyrv = new Menor(((Expressao)yysv[yysp-3]), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr29() { // exp : '-' exp
        { yyrv = new Sub(new Num(0), ((Expressao)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr30() { // exp : exp '[' exp ']'
        { yyrv = new IndexaVetor(((Expressao)yysv[yysp-4]), ((Expressao)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr31() { // exp : exp '^'
        { yyrv = new Deref(((Expressao)yysv[yysp-2])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr32() { // exp : '@' lval
        { yyrv = new Ref(((Lvalue)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr33() { // exp : exp '.' ID
        { yyrv = new IndexaReg(((Expressao)yysv[yysp-3]), ((String)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr34() { // exp : '(' exp ')'
        { yyrv = ((Expressao)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : NUM
        { yyrv = new Num(((Integer)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : ID
        { yyrv = new Var(((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : NIL
        { yyrv = new Nil(); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : STRING
        { yyrv = new Str(((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 40: return 56;
            case 39: return 55;
            case 38: return 54;
            case 37: return 53;
            case 35: return 51;
            case 34: return 50;
            case 33: return 49;
            case 22: return 43;
            case 21: return 42;
            case 14: return 31;
            case 12: return 29;
            case 10: return 27;
            case 6: return 16;
            default: return 58;
        }
    }

    private int yyr19() { // lval : ID
        { yyrv = new Var(((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yyplval();
    }

    private int yyr20() { // lval : lval '[' exp ']'
        { yyrv = new IndexaVetor(((Lvalue)yysv[yysp-4]), ((Expressao)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yyplval();
    }

    private int yyr21() { // lval : lval '.' ID
        { yyrv = new IndexaReg(((Lvalue)yysv[yysp-3]), ((String)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yyplval();
    }

    private int yyr22() { // lval : lval '^'
        { yyrv = new Deref(((Lvalue)yysv[yysp-2])); }
        yysv[yysp-=2] = yyrv;
        return yyplval();
    }

    private int yyplval() {
        switch (yyst[yysp-1]) {
            case 23: return 44;
            case 7: return 24;
            default: return 4;
        }
    }

    private int yyr4() { // campos : ID ':' tipo
        { TreeMap<String,Tipo> m = new TreeMap<String,Tipo>(); 
            m.put(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); yyrv = m; }
        yysv[yysp-=3] = yyrv;
        return 70;
    }

    private int yyr5() { // campos : campos ';' ID ':' tipo
        { ((TreeMap)yysv[yysp-5]).put(((String)yysv[yysp-3]), ((Tipo)yysv[yysp-1])); yyrv = ((TreeMap)yysv[yysp-5]); }
        yysv[yysp-=5] = yyrv;
        return 70;
    }

    private int yyr6() { // tipo : INT
        { yyrv = new Inteiro(); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr7() { // tipo : BOOL
        { yyrv = new Booleano(); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr8() { // tipo : CHAR
        { yyrv = new Caractere(); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr9() { // tipo : ARRAY '[' NUM ']' OF tipo
        { yyrv = new Vetor(((Tipo)yysv[yysp-1]), ((Integer)yysv[yysp-4])); }
        yysv[yysp-=6] = yyrv;
        return yyptipo();
    }

    private int yyr10() { // tipo : RECORD campos END
        { yyrv = new Registro((java.util.TreeMap<String,Tipo>)((TreeMap)yysv[yysp-2])); }
        yysv[yysp-=3] = yyrv;
        return yyptipo();
    }

    private int yyr11() { // tipo : '^' tipo
        { yyrv = new Ponteiro(((Tipo)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 82: return 84;
            case 77: return 81;
            case 65: return 72;
            case 46: return 59;
            default: return 85;
        }
    }

    protected String[] yyerrmsgs = {
    };


// C�digo extra

int tokenType;
Object tokenVal;
Token tok;

JFScanner scanner;
Comando output;

JCParser(java.io.Reader input) {
  scanner = new JFScanner(input);
  getToken();
}

int getToken() {
  try {
    tok = scanner.getToken();
    tokenType = tok.type;
    tokenVal = (tokenType == NUM ? tok.intVal :
                                tok.strVal);
    return tokenType;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException(msg + " no token " + tok);
}

}
