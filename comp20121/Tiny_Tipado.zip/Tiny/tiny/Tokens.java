// Output created by jacc on Mon May 28 15:27:43 BRT 2012

package tiny;

interface Tokens {
    int ENDINPUT = 0;
    int ARRAY = 1;
    int ASSIGN = 2;
    int BEGIN = 3;
    int BOOL = 4;
    int CHAR = 5;
    int ELSE = 6;
    int END = 7;
    int FALSE = 8;
    int ID = 9;
    int IF = 10;
    int INT = 11;
    int NIL = 12;
    int NUM = 13;
    int OF = 14;
    int READ = 15;
    int RECORD = 16;
    int REPEAT = 17;
    int STRING = 18;
    int THEN = 19;
    int TRUE = 20;
    int UNM = 21;
    int UNTIL = 22;
    int VAR = 23;
    int WRITE = 24;
    int error = 25;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // '-' (code=45)
    // '.' (code=46)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
    // '@' (code=64)
    // '[' (code=91)
    // ']' (code=93)
    // '^' (code=94)
}
