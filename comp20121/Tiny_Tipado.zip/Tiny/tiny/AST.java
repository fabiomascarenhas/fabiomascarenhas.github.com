package tiny;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

interface Expressao {
	Object valor(SymbolTable<Object> vars);
	Tipo tipo(SymbolTable<Tipo> symtab);
}

interface Lvalue extends Expressao {
	interface Endereco {
		void valor(Object val);
		Object valor();
	}
	
	Endereco endereco(SymbolTable<Object> vars);
}

interface Comando {
	void executa(SymbolTable<Object> vars);
	void verificaTipo(SymbolTable<Tipo> symtab);
}

interface Tipo {
	boolean igual(Tipo outro);
	Object zero();  // interpretador
}

class Num implements Expressao {
	private int val;
	
	public Num(int val) {
		this.val = val;
	}
	
	public Object valor(SymbolTable<Object> vars) {
		return this.val;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return new Inteiro();
	}
}

class Var implements Lvalue {
	private String nome;
	
	public Var(String nome) {
		this.nome = nome;
	}
	
	class EnderecoVar implements Endereco {
		private String nome;
		private SymbolTable<Object> vars;
		
		EnderecoVar(String nome, SymbolTable<Object> vars) {
			this.nome = nome;
			this.vars = vars;
		}
		
		@Override
		public Object valor() {
			return vars.lookup(nome);
		}

		@Override
		public void valor(Object val) {
			vars.replace(nome, val);
		}
	}
	
	public Endereco endereco(SymbolTable<Object> vars) {
		return new EnderecoVar(nome, vars);
	}
	
	public Object valor(SymbolTable<Object> vars) {
		return vars.lookup(nome);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return symtab.lookup(nome);
	}
}

abstract class ExpressaoArit implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoArit(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract int fazOp(int valEsq, int valDir);
	
	public Object valor(SymbolTable<Object> vars) {
		return this.fazOp((Integer)esq.valor(vars),
						  (Integer)dir.valor(vars));
	}
	
	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tesq = esq.tipo(symtab);
		Tipo tdir = dir.tipo(symtab);
		if(tesq instanceof Inteiro && tdir instanceof Inteiro)
			return new Inteiro();
		else
			throw new RuntimeException("express�o aritm�tica com argumento inv�lido");
	}
}

abstract class ExpressaoRel implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoRel(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract Boolean fazOp(int valEsq, int valDir);
	
	public Object valor(SymbolTable<Object> vars) {
		return this.fazOp((Integer)esq.valor(vars),
						  (Integer)dir.valor(vars));
	}
		
}

class Soma extends ExpressaoArit {
	
	public Soma(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq + valDir;
	}
	
}

class Sub extends ExpressaoArit {
	
	public Sub(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq - valDir;
	}
	
}

class Mul extends ExpressaoArit {
	
	public Mul(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq * valDir;
	}
	
}

class Div extends ExpressaoArit {
	
	public Div(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	int fazOp(int valEsq, int valDir) {
		return valEsq / valDir;
	}
	
}

class Igual extends ExpressaoRel {
	
	public Igual(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	Boolean fazOp(int valEsq, int valDir) {
		return valEsq == valDir;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tesq = esq.tipo(symtab);
		Tipo tdir = dir.tipo(symtab);
		if(tesq instanceof Inteiro 
				|| tesq instanceof Caractere
				|| tesq instanceof Booleano
				|| tesq instanceof Ponteiro
				|| tesq instanceof Nil) {
			if(tesq.igual(tdir))
				return new Booleano();
			else
				throw new RuntimeException("comparando tipos diferentes");
		} else
			throw new RuntimeException("comparando tipo n�o escalar");
	}

}

class Menor extends ExpressaoRel {
	
	public Menor(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	@Override
	Boolean fazOp(int valEsq, int valDir) {
		return valEsq < valDir;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tesq = esq.tipo(symtab);
		Tipo tdir = dir.tipo(symtab);
		if(tesq instanceof Inteiro && tdir instanceof Inteiro)
			return new Booleano();
		else if(tesq instanceof Caractere && tdir instanceof Caractere)
			return new Booleano();
		else
			throw new RuntimeException("compara��o com argumento inv�lido");
	}

}

class Deref implements Lvalue {
	Expressao ref;
	
	Deref(Expressao ref) {
		this.ref = ref;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		Endereco end = (Endereco)ref.valor(vars);
		return end.valor();
	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars) {
		return (Endereco)ref.valor(vars);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo texp = ref.tipo(symtab);
		if(texp instanceof Ponteiro) {
			Ponteiro p = (Ponteiro)texp;
			return p.base;
		} else
			throw new RuntimeException("tipo inv�lido na deref");
	}
		
}

class Nil implements Expressao, Tipo {

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return null;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return this;
	}

	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Ponteiro ||
				outro instanceof Nil;
	}

	@Override
	public Object zero() {
		return null;
	}
	
}

class Str implements Expressao {
	Object[] str;
	
	Str(String str) {
		char[] cs = str.toCharArray();
		this.str = new Object[cs.length + 1];
		for(int i = 0; i < cs.length; i++)
			this.str[i] = cs[i];
		this.str[cs.length] = (char)0;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return str;
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return new Vetor(new Caractere(), str.length);
	}
}

class Ref implements Expressao {
	Lvalue exp;
	
	Ref(Lvalue exp) {
		this.exp = exp;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		return exp.endereco(vars);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		return new Ponteiro(exp.tipo(symtab));
	}
}

class IndexaReg implements Lvalue {
	Expressao reg;
	String campo;

	IndexaReg(Expressao reg, String campo) {
		this.reg = reg;
		this.campo = campo;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Object valor(SymbolTable<Object> vars) {
		Map<String, Object> registro = 
				(Map<String, Object>)reg.valor(vars);
		return registro.get(campo);
	}

	class EnderecoIndexaReg implements Endereco {
		private Map<String, Object> map;
		private String campo;
		
		EnderecoIndexaReg(Map<String, Object> map, 
				String campo) {
			this.map = map;
			this.campo = campo;
		}

		@Override
		public void valor(Object val) {
			map.put(campo, val);
		}

		@Override
		public Object valor() {
			return map.get(campo);
		}
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Endereco endereco(SymbolTable<Object> vars) {
		return new EnderecoIndexaReg(
				(Map<String, Object>)reg.valor(vars), campo);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo treg = reg.tipo(symtab);
		if(treg instanceof Registro) {
			Registro tr = (Registro)treg;
			if(tr.campos.containsKey(campo))
				return tr.campos.get(campo);
			else
				throw new RuntimeException("indexa��o por campo que n�o existe: " + campo);
		} else
			throw new RuntimeException("indexa��o inv�lida");
	}
}

class IndexaVetor implements Lvalue {
	Expressao vetor;
	Expressao indice;
	
	IndexaVetor(Expressao vetor, Expressao indice) {
		this.vetor = vetor;
		this.indice = indice;
	}

	@Override
	public Object valor(SymbolTable<Object> vars) {
		Object[] vet = (Object[])vetor.valor(vars);
		int ind = (Integer)indice.valor(vars);
		return vet[ind];
	}

	class EnderecoIndexaVetor implements Endereco {
		private Object[] vetor;
		private int indice;
		
		EnderecoIndexaVetor(Object[] vetor, int indice) {
			this.vetor = vetor;
			this.indice = indice;
		}

		@Override
		public void valor(Object val) {
			vetor[indice] = val;
		}

		@Override
		public Object valor() {
			return vetor[indice];
		}
	}
	
	@Override
	public Endereco endereco(SymbolTable<Object> vars) {
		return new EnderecoIndexaVetor(
					(Object[])vetor.valor(vars),
					(Integer)indice.valor(vars)
				);
	}

	@Override
	public Tipo tipo(SymbolTable<Tipo> symtab) {
		Tipo tvetor = vetor.tipo(symtab);
		Tipo tind = indice.tipo(symtab);
		if(tvetor instanceof Vetor) {
			Vetor tv = (Vetor)tvetor;
			if(tind instanceof Inteiro) {
				return tv.base;
			} else
				throw new RuntimeException("indexa��o com �ndice inv�lido");
		} else
			throw new RuntimeException("indexa��o de n�o-vetor");
	}
}

class Vazio implements Comando {
	public void executa(SymbolTable<Object> vars) { }

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {	}
}

class DeclVar implements Comando {
	String nome;
	Tipo tipo;
	
	DeclVar(String nome, Tipo tipo) {
		this.nome = nome;
		this.tipo = tipo;
	}
	
	public void executa(SymbolTable<Object> vars) {
		vars.insert(nome, tipo.zero());
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		symtab.insert(nome, tipo);
	}
}

class Seq implements Comando {
	private Comando cmd1;
	private Comando cmd2;
	
	public Seq(Comando cmd1, Comando cmd2) {
		this.cmd1 = cmd1;
		this.cmd2 = cmd2;
	}
	
	public void executa(SymbolTable<Object> vars) {
		cmd1.executa(vars);
		cmd2.executa(vars);
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		cmd1.verificaTipo(symtab);
		cmd2.verificaTipo(symtab);
	}

}

class Atrib implements Comando {
	private Lvalue lval;
	private Expressao rval;
	
	public Atrib(Lvalue lval, Expressao rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	public void executa(SymbolTable<Object> vars) {
		lval.endereco(vars).valor(rval.valor(vars));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		Tipo tlval = lval.tipo(symtab);
		Tipo trval = rval.tipo(symtab);
		if(tlval instanceof Inteiro 
				|| tlval instanceof Caractere
				|| tlval instanceof Booleano
				|| tlval instanceof Ponteiro) {
			if(!tlval.igual(trval))
				throw new RuntimeException("atribuindo tipos diferentes");
		} else
			throw new RuntimeException("atribuindo tipo n�o escalar");
	}
	
}

class If implements Comando {
	private Expressao cond;
	private Comando cmdThen;
	private Comando cmdElse;
	
	public If(Expressao cond, Comando cmdThen, Comando cmdElse) {
		this.cond = cond;
		this.cmdThen = cmdThen;
		this.cmdElse = cmdElse;
	}
	
	public void executa(SymbolTable<Object> vars) {
		if((Boolean)cond.valor(vars)) {
			SymbolTable<Object> vthen =
					new SymbolTable<Object>(vars);
			cmdThen.executa(vthen);
		} else {
			SymbolTable<Object> velse =
					new SymbolTable<Object>(vars);
			cmdElse.executa(velse);
		}
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		Tipo tcond = cond.tipo(symtab);
		if(!(tcond instanceof Booleano))
			throw new RuntimeException("condi��o do if n�o � booleana");
		cmdThen.verificaTipo(new SymbolTable<Tipo>(symtab));
		cmdElse.verificaTipo(new SymbolTable<Tipo>(symtab));
	}
}

class Repeat implements Comando {
	private Comando corpo;
	private Expressao cond;
	
	public Repeat(Comando corpo, Expressao cond) {
		this.corpo = corpo;
		this.cond = cond;
	}
	
	public void executa(SymbolTable<Object> vars) {
		SymbolTable<Object> vcorpo;
		do {
			vcorpo =
					new SymbolTable<Object>(vars);
			corpo.executa(vcorpo);
		} while(!(Boolean)cond.valor(vcorpo));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		SymbolTable<Tipo> stab = new SymbolTable<Tipo>(symtab);
		corpo.verificaTipo(stab);
		Tipo tcond = cond.tipo(stab);
		if(!(tcond instanceof Booleano))
			throw new RuntimeException("condi��o do if n�o � booleana");
	}
}

class Write implements Comando {
	private Expressao exp;
	
	public Write(Expressao exp) {
		this.exp = exp;
	}
	
	public void executa(SymbolTable<Object> vars) {
		System.out.println(exp.valor(vars));
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		Tipo texp = exp.tipo(symtab);
		if(!(texp instanceof Inteiro))
			throw new RuntimeException("tipo inv�lido na escrita");
	}
}

class Read implements Comando {
	private Lvalue var;
	
	static BufferedReader CONSOLE =
			new BufferedReader(new InputStreamReader(System.in));
	
	static int leNumero() {
		try {
			return Integer.parseInt(CONSOLE.readLine());
		} catch(IOException e) {
			throw new RuntimeException("n�o consegui ler do console");
		} catch(NumberFormatException e) {
			throw new RuntimeException("voc� n�o passou um n�mero: " + e.getMessage());
		}
	}
	
	public Read(Lvalue var) {
		this.var = var;
	}
	
	public void executa(SymbolTable<Object> vars) {
		var.endereco(vars).valor(leNumero());
	}

	@Override
	public void verificaTipo(SymbolTable<Tipo> symtab) {
		if(!(var.tipo(symtab) instanceof Inteiro))
			throw new RuntimeException("lendo para lval n�o inteiro");
	}
}

class Inteiro implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Inteiro;
	}

	@Override
	public Object zero() {
		return (int)0;
	}
}

class Caractere implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Caractere;
	}

	@Override
	public Object zero() {
		return (char)0;
	}
}

class Booleano implements Tipo {
	@Override
	public boolean igual(Tipo outro) {
		return outro instanceof Booleano;
	}

	@Override
	public Object zero() {
		return false;
	}
}

class Vetor implements Tipo {
	Tipo base;
	int tamanho;
	
	Vetor(Tipo base, int tamanho) {
		this.base = base;
		this.tamanho = tamanho;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Vetor) {
			Vetor vOutro = (Vetor)outro;
			return base.igual(vOutro);
		}
		return false;
	}
	
	@Override
	public Object zero() {
		Object[] arr = new Object[tamanho];
		for(int i = 0; i < arr.length; i++)
			arr[i] = base.zero();
		return arr;
	}
}

class Ponteiro implements Tipo {
	Tipo base;
	
	Ponteiro(Tipo base) {
		this.base = base;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Ponteiro) {
			return base.igual(((Ponteiro)outro).base);
		}
		return false;
	}
	
	@Override
	public Object zero() {
		return null;
	}
}

class Registro implements Tipo {
	TreeMap<String, Tipo> campos;
	
	Registro(TreeMap<String, Tipo> campos) {
		this.campos = campos;
	}
	
	@Override
	public boolean igual(Tipo outro) {
		if(outro instanceof Registro) {
			Registro rOutro = (Registro)outro;
			Collection<Tipo> c1 = campos.values();
			Collection<Tipo> c2 = rOutro.campos.values();
			Tipo[] l1 = new Tipo[c1.size()];
			c1.toArray(l1);
			Tipo[] l2 = new Tipo[c2.size()];
			c2.toArray(l2);
			if(l1.length > l2.length)
				return false;
			for(int i = 0; i < l1.length; i++)
				if(!l1[i].igual(l2[i]))
					return false;
			return true;
		}
		return false;
	}
	
	@Override
	public Object zero() {
		Map<String, Object> reg = new HashMap<String, Object>();
		for(Entry<String, Tipo> campo : campos.entrySet()) {
			reg.put(campo.getKey(), campo.getValue().zero());
		}
		return reg;
	}
}



