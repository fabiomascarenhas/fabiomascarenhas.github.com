package gossip;

import java.io.*;

public class Driver {
    public static void main(String[] args) throws Exception {
        FileReader input = new FileReader(args[0]);
        Scanner scanner = new Scanner(input);
        Token token;
        while((token = scanner.getToken()) != null) {
            System.out.println(token);
        }
    }
}
