package tiny;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

/*
Palavras reservadas:
 if, then, else, end, repeat, until, read, write.

Operadores: 
  +, -, *, /, =, <, (, ), ;, :=.

N�meros:
 um ou mais d�gitos. -> [0-9]+
 
Identificadores: 
 letras seguidas de letras, n�meros ou _.
   -> [a-zA-Z][a-zA-Z0-9_]*
   
Coment�rios: 
 cercados por chaves ({...}), n�o podem ser aninhados. * 
     -> {[^}]*}

Espa�o em branco:
  -> [ \r\n\t]+

 * 
 * 
 */

public class Scanner {
	int lookAhead;
	Reader input;
	
	static Map<String, Integer> resWords = 
			new HashMap<String, Integer>();


	{
		resWords.put("if", Token.IF);
		resWords.put("then", Token.THEN);
		resWords.put("else", Token.ELSE);
		resWords.put("repeat", Token.REPEAT);
		resWords.put("until", Token.UNTIL);
		resWords.put("end", Token.END);
		resWords.put("read", Token.READ);
		resWords.put("write", Token.WRITE);
	}
	
	void nextChar() {
		try {
			lookAhead = input.read();
		} catch(IOException e) {
			lookAhead = -1;
		}
	}
	
	public Scanner(Reader input) {
		this.input = input;
		nextChar();
	}
	
	Token getToken() {
		while(true) {
			switch((char)lookAhead) {
			case '\r': case '\n': case '\t': case ' ':
				nextChar();
				continue;
			case '{':
				nextChar();
				while((char)lookAhead != '}' &&
						lookAhead != -1)
					nextChar();
				if((char)lookAhead != '}')
					throw new Error("coment�rio n�o terminado");
				nextChar();
				continue;
			case '+': case '-': case '*': case '/':
			case '(': case ')': case ';': case '=':
			case '<':
				int op = lookAhead;
				nextChar();
				return new Token(op);
			case ':':
				nextChar();
				if((char)lookAhead == '=') {
					nextChar();
					return new Token(Token.ASSIGN);
				}
				throw new Error("atribui��o incompleta");
			case '0': case '1': case '2':
			case '3': case '4': case '5':
			case '6': case '7': case '8':
			case '9':
				String lexeme = ""; 
				while((char)lookAhead >= '0' &&
						(char)lookAhead <= '9') {
					lexeme = lexeme + 
							Character.toString((char)lookAhead);
					nextChar();
				}
				return new Token(Token.NUM, 
						Integer.parseInt(lexeme));
			default:
				if(lookAhead == -1)
					return new Token(Token.EOF);
				if(Character.isLetter(lookAhead)) {
					String lexemeId = ""; 
					while(Character.isLetterOrDigit(lookAhead)
							|| (char)lookAhead == '_') {
						lexemeId = lexemeId + 
								Character.toString((char)lookAhead);
						nextChar();
					}
					if(resWords.containsKey(lexemeId)) {
						return new Token(resWords.get(lexemeId).intValue());
					} else
						return new Token(Token.ID, lexemeId);
				}
				throw new Error("caractere n�o identificado: " + lookAhead);
			}
		}
	}
	
}
