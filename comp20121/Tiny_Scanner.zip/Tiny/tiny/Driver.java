package tiny;

import java.io.FileReader;
import java.io.Reader;

public class Driver {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Reader input = new FileReader(args[0]);
		Scanner scan = new Scanner(input);
		Token tok;
		while((tok = scan.getToken()).type !=
				Token.EOF)
			System.out.println(tok);
	}

}
