package tiny;

public class Token {
	public static final int IF = 1000;
	public static final int THEN = 1001;
	public static final int ELSE = 1002;
	public static final int END = 1003;
	public static final int REPEAT = 1004;
	public static final int UNTIL = 1005;
	public static final int READ = 1006;
	public static final int WRITE = 1007;
	public static final int ASSIGN = 1008;
	public static final int EOF = 1009;
	public static final int ID = 1010;
	public static final int NUM = 1011;
	
	int type;
	
	int intVal;       // para type == NUM
	String strVal;    // para type == ID

	public Token(int type) {
		this.type = type;
	}

	public Token(int type, int intVal) {
		this.type = type;
		this.intVal = intVal;
	}

	public Token(int type, String strVal) {
		this.type = type;
		this.strVal = strVal;
	}
	
	public String toString() {
		return "Token(" + this.type + ", " +
				(this.strVal == null ?
						this.intVal : this.strVal) + ")";
	}
}
