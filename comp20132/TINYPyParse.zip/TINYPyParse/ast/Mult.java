package ast;

public class Mult implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Mult(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}
}
