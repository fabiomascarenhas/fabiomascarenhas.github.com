package ast;

import java.util.List;

public class Teste {
	public Exp cond;
	public List<Cmd> corpo;
	public int lin;
	
	public Teste(Exp _cond, List<Cmd> _corpo, int _lin) {
		cond = _cond;
		corpo = _corpo;
		lin = _lin;
	}
}
