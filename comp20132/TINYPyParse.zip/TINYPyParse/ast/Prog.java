package ast;

import java.util.List;

public class Prog {
	public List<Func> funcs;
	
	public Prog(List<Func> _funcs) {
		funcs = _funcs;
	}
}
