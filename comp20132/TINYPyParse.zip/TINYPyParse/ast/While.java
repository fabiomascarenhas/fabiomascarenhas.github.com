package ast;

import java.util.List;

public class While implements Cmd {
	public Exp cond;
	public List<Cmd> corpo;
	public int lin;
	
	public While(Exp _cond, List<Cmd> _corpo, int _lin) {
		cond = _cond;
		corpo = _corpo;
		lin = _lin;
	}
}
