package ast;

import java.util.List;

public class Chamada implements Cmd, Exp {
	public String func;
	public List<Exp> args;
	public int lin;
	
	public Chamada(String _func, List<Exp> _args, int _lin) {
		func = _func;
		args = _args;
		lin = _lin;
	}
}
