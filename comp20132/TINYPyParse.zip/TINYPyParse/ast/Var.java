package ast;

public class Var implements Exp {
	public String nome;
	public int lin;
	
	public Var(String _nome, int _lin) {
		nome = _nome;
		lin = _lin;
	}
}
