package ast;

public class Igual implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Igual(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}
}
