package ast;

import java.util.List;

public class If implements Cmd{
	public List<Teste> testes;
	public List<Cmd> celse;
	
	public If(List<Teste> _testes, List<Cmd> _celse) {
		testes = _testes;
		celse = _celse;
	}
}
