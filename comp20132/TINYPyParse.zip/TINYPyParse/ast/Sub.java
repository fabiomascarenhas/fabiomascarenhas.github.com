package ast;

public class Sub implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Sub(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}
}
