package ast;

public class Soma implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Soma(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}
}
