package ast;

public interface Exp {

}
