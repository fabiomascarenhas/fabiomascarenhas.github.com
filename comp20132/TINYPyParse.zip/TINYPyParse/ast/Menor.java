package ast;

public class Menor implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Menor(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}
}
