package ast;

public interface Cmd {

}
