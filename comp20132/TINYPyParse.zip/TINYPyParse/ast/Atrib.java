package ast;

public class Atrib implements Cmd{
	public String lval;
	public Exp rval;
	public int lin;
		
	public Atrib(String _lval, Exp _rval, int _lin) {
		lval = _lval;
		rval = _rval;
		lin = _lin;
	}
}
