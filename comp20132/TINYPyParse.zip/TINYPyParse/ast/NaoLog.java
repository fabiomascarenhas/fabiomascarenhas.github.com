package ast;

public class NaoLog implements Exp {
	public Exp exp;
	public int lin;
	
	public NaoLog(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}
}
