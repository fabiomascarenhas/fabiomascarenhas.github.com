package ast;

public class Write implements Cmd {
	public Exp exp;
	public int lin;
	
	public Write(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}
}
