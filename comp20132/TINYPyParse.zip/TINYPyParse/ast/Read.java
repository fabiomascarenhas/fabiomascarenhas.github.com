package ast;

public class Read implements Cmd {
	public String var;
	public int lin;
	
	public Read(String _var, int _lin) {
		var = _var;
		lin = _lin;
	}
}
