package ast;

public class True implements Exp {

}
