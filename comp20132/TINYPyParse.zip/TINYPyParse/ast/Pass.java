package ast;

public class Pass implements Cmd {

}
