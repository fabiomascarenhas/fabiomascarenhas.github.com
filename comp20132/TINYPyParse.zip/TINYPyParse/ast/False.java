package ast;

public class False implements Exp {

}
