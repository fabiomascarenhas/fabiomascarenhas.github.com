package ast;

public class Num implements Exp {
	public int val;
	
	public Num(String _val) {
		val = Integer.parseInt(_val);
	}
}
