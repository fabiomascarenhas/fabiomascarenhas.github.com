package ast;

import java.util.List;

public class Func {
	public String tret;
	public String nome;
	public List<Param> params;
	public List<Cmd> corpo;
	public int lin;
	
	public Func(String _tret, String _nome, List<Param> _params, List<Cmd> _corpo, int _lin) {
		tret = _tret;
		nome = _nome;
		params = _params;
		corpo = _corpo;
		lin = _lin;
	}
}
