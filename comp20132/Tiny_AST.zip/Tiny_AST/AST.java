import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

interface Cmd {
	void run(Map<String, Integer> vars);
}

interface Exp {
	boolean bval(Map<String, Integer> vars);
	int ival(Map<String, Integer> vars);
}

class Tiny {
	List<Cmd> cmds;
	
	public Tiny(List<Cmd> _cmds) {
		cmds = _cmds;
	}
	
	public Map<String, Integer> run() {
		Map<String, Integer> vars = new HashMap<String, Integer>();
		for(Cmd cmd: cmds)
			cmd.run(vars);
		return vars;
	}
}

class If implements Cmd {
	Exp cond;
	List<Cmd> cthen;
	List<Cmd> celse;
	
	public If(Exp _cond, List<Cmd> _cthen) {
		cond = _cond;
		cthen = _cthen;
		celse = new ArrayList<Cmd>();
	}
	
	public If(Exp _cond, List<Cmd> _cthen, List<Cmd> _celse) {
		cond = _cond;
		cthen = _cthen;
		celse = _celse;
	}
	
	public void run(Map<String, Integer> vars) {
		if(cond.bval(vars)) {
			for(Cmd cmd: cthen)
				cmd.run(vars);
		} else {
			for(Cmd cmd: celse)
				cmd.run(vars);
		}
	}
}

class Repeat implements Cmd {
	List<Cmd> corpo;
	Exp cond;
	
	public Repeat(List<Cmd> _corpo, Exp _cond) {
		corpo = _corpo;
		cond = _cond;
	}

	@Override
	public void run(Map<String, Integer> vars) {
		do {
			for(Cmd cmd: corpo)
				cmd.run(vars);
		} while(!cond.bval(vars));
	}
}

class Atrib implements Cmd {
	String id;
	Exp exp;
	
	public Atrib(String _id, Exp _exp) {
		id = _id;
		exp = _exp;
	}

	@Override
	public void run(Map<String, Integer> vars) {
		vars.put(id, exp.ival(vars));
	}
}

class Read implements Cmd {
	String id;
	
	java.util.Scanner scan = new java.util.Scanner(System.in);
	
	public Read(String _id) {
		id = _id;
	}

	@Override
	public void run(Map<String, Integer> vars) {
		vars.put(id, scan.nextInt());
	}
}

class Write implements Cmd {
	Exp exp;
	
	public Write(Exp _exp) {
		exp = _exp;
	}

	@Override
	public void run(Map<String, Integer> vars) {
		System.out.println(exp.ival(vars));
	}
}

class Menor implements Exp {
	Exp el;
	Exp er;
	
	public Menor(Exp _el, Exp _er) {
		el = _el;
		er = _er;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		return el.ival(vars) < er.ival(vars);
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}
}

class Igual implements Exp {
	Exp el;
	Exp er;
	
	public Igual(Exp _el, Exp _er) {
		el = _el;
		er = _er;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		return el.ival(vars) == er.ival(vars);
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}
	
}

class Soma implements Exp {
	Exp el;
	Exp er;
	
	public Soma(Exp _el, Exp _er) {
		el = _el;
		er = _er;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		return el.ival(vars) + er.ival(vars);
	}
}

class Sub implements Exp {
	Exp el;
	Exp er;
	
	public Sub(Exp _el, Exp _er) {
		el = _el;
		er = _er;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		return el.ival(vars) - er.ival(vars);
	}
}

class Mul implements Exp {
	Exp el;
	Exp er;
	
	public Mul(Exp _el, Exp _er) {
		el = _el;
		er = _er;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		return el.ival(vars) * er.ival(vars);
	}
}

class Div implements Exp {
	Exp el;
	Exp er;
	
	public Div(Exp _el, Exp _er) {
		el = _el;
		er = _er;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		return el.ival(vars) / er.ival(vars);
	}
}

class Num implements Exp {
	int n;
	
	public Num(String lexeme) {
		n = Integer.parseInt(lexeme);
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		return n;
	}
}

class Id implements Exp {
	String id;
	
	public Id(String _id) {
		id = _id;
	}

	@Override
	public boolean bval(Map<String, Integer> vars) {
		throw new RuntimeException("erro de tipo");
	}

	@Override
	public int ival(Map<String, Integer> vars) {
		return vars.get(id);
	}
}
