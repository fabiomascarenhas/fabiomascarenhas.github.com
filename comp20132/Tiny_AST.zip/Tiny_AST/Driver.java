import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;

public class Driver {
	public static void main(String[] args) throws IOException {
		String name = args[0];
		File f = new File(name);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		parser.parse();
		Tiny prog = parser.saida;
		Map<String, Integer> vars = prog.run();
		System.out.println("===== GLOBAIS =====");
		for(String var: vars.keySet()) {
			System.out.println(var + ": " + vars.get(var));
		}
	}

}
