import java.util.List;


public class Id implements Exp {
	public String id;
	public int lin;
	
	public Id(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	public String toString() {
		return id;
	}

	@Override
	public void codigo(List<String> vars, StringBuffer out) {
		if(!vars.contains(id))
			throw new RuntimeException("variável não declarada na linha " + lin + ": " + id);
		out.append("iload " + vars.indexOf(id) + "\n");
	}
}
