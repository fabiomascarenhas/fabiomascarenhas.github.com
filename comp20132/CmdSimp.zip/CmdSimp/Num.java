import java.util.List;


public class Num implements Exp {
	public int val;
	public int lin;
	
	public Num(int _val, int _lin) {
		val = _val;
		lin = _lin;
	}

	public String toString() {
		return "" + val;
	}

	@Override
	public void codigo(List<String> vars, StringBuffer out) {
		out.append("ldc " + val + "\n");
	}
}
