import java.util.List;


public interface Cmd {
	void codigo(List<String> vars, StringBuffer out);
}
