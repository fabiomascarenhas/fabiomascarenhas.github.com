
public class Token {
	public int tipo;
	public String lexeme;
	public int lin;
	
	public final static int EOF = 0;
	public final static int NUM = 1;
	public final static int ID = 2;
	public final static int PRINT = 3;
	// outros: '(', ')', '+', ...
	
	public Token(int _tipo, String _lexeme, int _lin) {
		tipo = _tipo;
		lexeme = _lexeme;
		lin = _lin;
	}
	
	public String toString() {
		return "<" + tipo + "," + lexeme + ">";
	}
}
