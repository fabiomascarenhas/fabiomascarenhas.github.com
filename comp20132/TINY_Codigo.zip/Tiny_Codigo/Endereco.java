
public interface Endereco {
	void load(Contexto ctx); // emite c�digo para ler
	void store(Contexto ctx); // emite c�digo para escrever
}
