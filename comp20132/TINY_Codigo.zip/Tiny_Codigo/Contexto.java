import java.util.List;
import java.util.Stack;


public class Contexto {
	StringBuffer buf;
	int proxLabel;
	int proxLoc;
	int marca;
		
	String func;
	Stack<Integer> escopos;
	
	// C�digo para o programa completo
	public static String programa(List<String> globais, List<String> funcs) {
		StringBuffer buf = new StringBuffer();
		buf.append("extern _printf\n");
		buf.append("extern _scanf\n");
		buf.append("segment .data\n");
		buf.append("$fmt_printf db \"%d\",10,0\n");
		buf.append("$fmt_scanf db \"%d\",0\n");
		buf.append("segment .bss\n");
		for(String var: globais)
			buf.append(var + " resb 4\n"); 
		buf.append("segment .text\n");
		buf.append("global _main\n");
		for(String func: funcs)
			buf.append(func);
		return buf.toString();
	}
	
	public Contexto(String _func) {
		buf = new StringBuffer();
		func = _func;
		proxLabel = 1;
		proxLoc = 1;
		marca = 0;
		escopos = new Stack<Integer>();
	}
	
	public String codigo() {
		String codigo = buf.toString();
		codigo = "_" + func + ":\n" +
		         "  push ebp\n" +
				 "  mov ebp,esp\n" +
		         (marca > 0 ? "  sub esp," + marca*4 + "\n" : "") +
		         codigo;
		codigo += "  mov esp, ebp\n" +
				  "  pop ebp\n" +
		          "  ret\n";
		return codigo;
	}

	public int label() {
		return proxLabel++;
	}

	public int local() {
		return proxLoc++;
	}
	
	public void entraEscopo() {
		escopos.push(proxLoc);
	}
	
	public void saiEscopo() {
		if(proxLoc > marca)
			marca = proxLoc - 1;
		proxLoc = escopos.pop();
	}
	
	public void op(String inst) {
		buf.append("  " + inst + "\n");
	}

	public void op(String inst, String arg) {
		buf.append("  " + inst + " " + arg + "\n");
	}

	public void op(String inst, String arg1, String arg2) {
		buf.append("  " + inst + " " + arg1 + "," + arg2 + "\n");
	}

	public void icload(int i) {
		op("push", "eax");
		op("mov", "eax", "" + i);
	}
	
	public void getglobal(String nome) {
		op("push", "eax");
		op("mov", "eax", "[" + nome + "]");
	}
	
	public void putglobal(String nome) {
		op("mov", "[" + nome + "]", "eax");
		op("pop", "eax");
	}
	
	public void iload(int loc) {
		op("push", "eax");
		op("mov", "eax", "[ebp-" + loc*4 + "]");
	}
	
	public void istore(int loc) {
		op("mov", "[ebp-" + loc*4 + "]", "eax");
		op("pop", "eax");
	}

	public void iadd() {
		op("pop", "ebx");
		op("add", "eax", "ebx");
	}
	
	public void isub() {
		op("mov", "ebx", "eax");
		op("pop", "eax");
		op("sub", "eax", "ebx");
	}

	public void imul() {
		op("pop", "ebx");
		op("imul", "eax", "ebx");
	}

	public void idiv() {
		op("mov", "ebx", "eax");
		op("pop", "eax");
		op("cdq");
		op("idiv dword", "ebx");
	}
	
	public void invoke(String func) {
		op("call", "_" + func);
	}
		
	public void if_icmpneq(int label) {
		op("mov", "edx", "eax");
		op("pop", "ebx");
		op("pop", "eax");
		op("cmp", "ebx", "edx");
		op("jne", "$" + func + label);
	}
	
	public void if_icmpge(int label) {
		op("mov", "edx", "eax");
		op("pop", "ebx");
		op("pop", "eax");
		op("cmp", "ebx", "edx");
		op("jge", "$" + func + label);
	}
	
	public void jmp(int label) {
		op("jmp", "$" + func + label);
	}
	
	public void read() {
		op("push", "eax");
		op("sub", "esp", "4");
		op("lea", "ebx", "[esp]");
		op("push", "ebx");
		op("push dword $fmt_scanf");
		op("call", "_scanf");
		op("add", "esp", "8");
		op("pop", "eax");
	}
	
	public void write() {
		op("push", "eax");
		op("push dword $fmt_printf");
		op("call", "_printf");
		op("add", "esp", "8");
		op("pop", "eax");
	}
	
	public void label(int label) {
		buf.append("$" + func + label + ":\n");
	}
		
}

