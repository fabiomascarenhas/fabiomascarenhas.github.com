
public class Local implements Endereco {
	int loc;
	
	public Local(int _loc) {
		loc = _loc;
	}

	@Override
	public void load(Contexto ctx) {
		ctx.iload(loc);
	}

	@Override
	public void store(Contexto ctx) {
		ctx.istore(loc);
	}
	
	
}
