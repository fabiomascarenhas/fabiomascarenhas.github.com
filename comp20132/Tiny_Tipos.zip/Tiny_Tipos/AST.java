import java.util.ArrayList;
import java.util.List;

// Usamos strings "int", "bool", "real" para representar
// tipos

interface Cmd {
	void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> locais);
	void escopo(TabSimb<Void> procs, TabSimb<Void> escopo);
	void tipos(TabSimb<Void> procs, TabSimb<String> escopo);
}

interface Exp {
	Object val(TabSimb<Object> vars);
	void escopo(TabSimb<Void> escopo);
	String tipo(TabSimb<String> escopo);
}

class Decl {
	List<String> nomes;
	String tipo;
	int lin;
	
	public Decl(List<String> _nomes, String _tipo, int _lin) {
		nomes = _nomes;
		tipo = _tipo;
		lin = _lin;
	}
}

class Bloco {
	List<Decl> vars;
	List<Cmd> cmds;
	int lin;
	
	public Bloco() {
		vars = new ArrayList<Decl>();
		cmds = new ArrayList<Cmd>();
	}
	
	public Bloco(List<Decl> _vars, int _lin) {
		vars = _vars;
		lin = _lin;
		cmds = new ArrayList<Cmd>();
	}
	
	public TabSimb<Object> run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> locais) {
		TabSimb<Object> escopo = new TabSimb<Object>(locais);
		for(Decl decl: vars)
			for(String var: decl.nomes) {
				if(decl.tipo.equals("bool"))
					escopo.inserir(var, false, decl.lin);
				if(decl.tipo.equals("int"))
					escopo.inserir(var, 0, decl.lin);
				if(decl.tipo.equals("real"))
					escopo.inserir(var, 0.0, decl.lin);
			}
		for(Cmd cmd: cmds)
			cmd.run(procs, escopo);
		return escopo;
	}
	
	public TabSimb<Void> escopo(TabSimb<Void> procs, TabSimb<Void> escopoPai) {
		TabSimb<Void> escopo = new TabSimb<Void>(escopoPai);
		for(Decl decl: vars)
			for(String var: decl.nomes)
				escopo.inserir(var, null, decl.lin);
		for(Cmd cmd: cmds)
			cmd.escopo(procs, escopo);
		return escopo;
	}

	public TabSimb<String> tipos(TabSimb<Void> procs, TabSimb<String> escopoPai) {
		TabSimb<String> escopo = new TabSimb<String>(escopoPai);
		for(Decl decl: vars)
			for(String var: decl.nomes)
				escopo.inserir(var, decl.tipo, decl.lin);
		for(Cmd cmd: cmds)
			cmd.tipos(procs, escopo);
		return escopo;
	}
}

class Tiny {
	List<Proc> procs;
	Bloco cmds;
	
	public Tiny(Bloco _cmds) {
		procs = new ArrayList<Proc>();
		cmds = _cmds;
	}
	
	public Tiny(List<Proc> _procs, Bloco _cmds) {
		procs = _procs;
		cmds = _cmds;
	}
	
	public TabSimb<Object> run() {
		TabSimb<FechoProc<Object>> tsprocs = new TabSimb<FechoProc<Object>>();
		TabSimb<Object> globais = new TabSimb<Object>();
		for(Proc proc: procs)
			tsprocs.inserir(proc.nome, new FechoProc<Object>(globais, proc), proc.lin);
		for(Decl decl: cmds.vars)
			for(String var: decl.nomes) {
				if(decl.tipo.equals("bool"))
					globais.inserir(var, false, decl.lin);
				if(decl.tipo.equals("int"))
					globais.inserir(var, 0, decl.lin);
				if(decl.tipo.equals("real"))
					globais.inserir(var, 0.0, decl.lin);
			}
		for(Cmd cmd: cmds.cmds)
			cmd.run(tsprocs, globais);
		return globais;
	}
	
	public void escopo() {
		TabSimb<Void> tsprocs = new TabSimb<Void>();
		TabSimb<Void> globais = new TabSimb<Void>();
		// Fase de coleta dos nomes
		for(Proc proc: procs)
			tsprocs.inserir(proc.nome, null, proc.lin);
		for(Decl decl: cmds.vars)
			for(String var: decl.nomes)
				globais.inserir(var, null, 1);
		// Fase de verifica��o dos escopos
		for(Cmd cmd: cmds.cmds)
			cmd.escopo(tsprocs, globais);
		for(Proc proc: procs)
			proc.corpo.escopo(tsprocs, globais);
	}

	public void tipos() {
		TabSimb<Void> tsprocs = new TabSimb<Void>();
		TabSimb<String> globais = new TabSimb<String>();
		// Fase de coleta dos nomes
		for(Proc proc: procs)
			tsprocs.inserir(proc.nome, null, proc.lin);
		for(Decl decl: cmds.vars)
			for(String var: decl.nomes)
				globais.inserir(var, decl.tipo, 1);
		// Fase de verifica��o dos escopos
		for(Cmd cmd: cmds.cmds)
			cmd.tipos(tsprocs, globais);
		for(Proc proc: procs)
			proc.corpo.tipos(tsprocs, globais);
	}
}

class Proc {
	String nome;
	Bloco corpo;
	int lin;
	
	public Proc(String _nome, Bloco _corpo, int _lin) {
		nome = _nome;
		corpo = _corpo;
		lin = _lin;
	}
	
	void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> globais) {
		corpo.run(procs, new TabSimb<Object>(globais));
	}
}

class FechoProc<T> {
	TabSimb<T> globais;
	Proc proc;
	
	public FechoProc(TabSimb<T> _globais, Proc _proc) {
		globais = _globais;
		proc = _proc;
	}
}

class If implements Cmd {
	Exp cond;
	Bloco cthen;
	Bloco celse;
	int lin;
	
	public If(Exp _cond, Bloco _cthen, int _lin) {
		cond = _cond;
		cthen = _cthen;
		celse = new Bloco();
		lin = _lin;
	}
	
	public If(Exp _cond, Bloco _cthen, Bloco _celse, int _lin) {
		cond = _cond;
		cthen = _cthen;
		celse = _celse;
		lin = _lin;
	}
	
	public void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> vars) {
		boolean val = (boolean)cond.val(vars);
		if(val)
			cthen.run(procs, vars);
		else
			celse.run(procs, vars);
	}

	@Override
	public void escopo(TabSimb<Void> procs, TabSimb<Void> escopo) {
		cond.escopo(escopo);
		cthen.escopo(procs, escopo);
		celse.escopo(procs, escopo);
	}

	@Override
	public void tipos(TabSimb<Void> procs, TabSimb<String> escopo) {
		if(!cond.tipo(escopo).equals("bool"))
			throw new RuntimeException("condi��o do if n�o � booleana na linha " + lin);
		cthen.tipos(procs, escopo);
		celse.tipos(procs, escopo);
	}
}

class Repeat implements Cmd {
	Bloco corpo;
	Exp cond;
	int lin;
	
	public Repeat(Bloco _corpo, Exp _cond, int _lin) {
		corpo = _corpo;
		cond = _cond;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> vars) {
		TabSimb<Object> vcond;
		do {
			vcond = corpo.run(procs, vars);
		} while(!((boolean)cond.val(vcond)));
	}

	@Override
	public void escopo(TabSimb<Void> procs, TabSimb<Void> escopo) {
		TabSimb<Void> ecorpo = corpo.escopo(procs, escopo);
		cond.escopo(ecorpo);
	}

	@Override
	public void tipos(TabSimb<Void> procs, TabSimb<String> escopo) {
		TabSimb<String> ecorpo = corpo.tipos(procs, escopo);
		if(!cond.tipo(ecorpo).equals("bool"))
			throw new RuntimeException("condi��o do repeat n�o � booleano na linha " + lin);
	}
}

class Atrib implements Cmd {
	String id;
	Exp exp;
	int lin;
	
	public Atrib(String _id, Exp _exp, int _lin) {
		id = _id;
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> vars) {
		vars.atualizar(id, exp.val(vars), lin);
	}

	@Override
	public void escopo(TabSimb<Void> procs, TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
		exp.escopo(escopo);
	}

	@Override
	public void tipos(TabSimb<Void> procs, TabSimb<String> escopo) {
		String tvar = escopo.procurar(id, lin);
		String texp = exp.tipo(escopo);
		// !(tvar == texp || (tvar == "real" && texp == "int"))
		//   -> tvar != texp && !(tvar == "real" && texp == "int")
		//   -> tvar != texp && (tvar != "real" || texp != "int")
		if(!tvar.equals(texp) && 
				(!tvar.equals("real") || !texp.equals("int")))
			throw new RuntimeException("atribui��o de tipos incompat�veis (" + tvar + " e " + texp +") na linha " + lin);
	}
}

class Read implements Cmd {
	String id;
	int lin;
	String tipo;
	
	java.util.Scanner scan = new java.util.Scanner(System.in);
	
	public Read(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> vars) {
		if(tipo.equals("bool"))
			vars.atualizar(id, scan.nextBoolean(), lin);
		if(tipo.equals("int"))
			vars.atualizar(id, scan.nextInt(), lin);
		if(tipo.equals("real"))
			vars.atualizar(id, scan.nextDouble(), lin);
	}

	@Override
	public void escopo(TabSimb<Void> procs, TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
	}

	@Override
	public void tipos(TabSimb<Void> procs, TabSimb<String> escopo) {
		tipo = escopo.procurar(id, lin);
	}
}

class Write implements Cmd {
	Exp exp;
	int lin;
	
	public Write(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> vars) {
		System.out.println(exp.val(vars));
	}

	@Override
	public void escopo(TabSimb<Void> procs, TabSimb<Void> escopo) {
		exp.escopo(escopo);
	}

	@Override
	public void tipos(TabSimb<Void> procs, TabSimb<String> escopo) {
		// write pode escrever qualquer valor, ent�o basta verificar
		// que exp tem um tipo
		exp.tipo(escopo);
	}
}

class Menor implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Menor(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		Object oel = el.val(vars);
		Object oer = er.val(vars);
		if(oel instanceof Integer) {
			int iel = (int)oel;
			if(oer instanceof Integer)
				return iel < (int)oer;
			else
				return iel < (double)oer;
		} else {
			double del = (double)oel;
			if(oer instanceof Integer)
				return del < (int)oer;
			else
				return del < (double)oer;
			
		}
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		String tl = el.tipo(escopo);
		String tr = er.tipo(escopo);
		if(tl.equals("bool") || tr.equals("bool"))
			throw new RuntimeException("compara��o de " + tl + " com " + tr + " na linha " + lin);
		return "bool";
	}
}

class Igual implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Igual(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		return el.val(vars).equals(er.val(vars));
	}
	
	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		String tl = el.tipo(escopo);
		String tr = er.tipo(escopo);
		// !(tl == tr || (tl != "bool" && tr != "bool"))
		//   -> tl != tr && !(tl != "bool" && tr != "bool")
		//   -> tl != tr && (tl == "bool" || tr == "bool")
		if(!tl.equals("bool") &&
				(tl.equals("bool") || tr.equals("bool")))
			throw new RuntimeException("compara��o de " + tl + " com " + tr + " na linha " + lin);
		return "bool";
	}
}

class Soma implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Soma(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		Object oel = el.val(vars);
		Object oer = er.val(vars);
		if(oel instanceof Integer) {
			int iel = (int)oel;
			if(oer instanceof Integer)
				return iel + (int)oer;
			else
				return iel + (double)oer;
		} else {
			double del = (double)oel;
			if(oer instanceof Integer)
				return del + (int)oer;
			else
				return del + (double)oer;
			
		}
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		String tl = el.tipo(escopo);
		String tr = er.tipo(escopo);
		if(tl.equals("bool") || tr.equals("bool"))
			throw new RuntimeException("tentativa de somar " + tl + " com " + tr + " na linha " + lin);
		if(tl.equals("int") && tr.equals("int"))
			return "int";
		return "real";
	}
}

class Sub implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Sub(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		Object oel = el.val(vars);
		Object oer = er.val(vars);
		if(oel instanceof Integer) {
			int iel = (int)oel;
			if(oer instanceof Integer)
				return iel - (int)oer;
			else
				return iel - (double)oer;
		} else {
			double del = (double)oel;
			if(oer instanceof Integer)
				return del - (int)oer;
			else
				return del - (double)oer;
			
		}
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		String tl = el.tipo(escopo);
		String tr = er.tipo(escopo);
		if(tl.equals("bool") || tr.equals("bool"))
			throw new RuntimeException("tentativa de subtrair " + tr + " de " + tl + " na linha " + lin);
		if(tl.equals("int") && tr.equals("int"))
			return "int";
		return "real";
	}
}

class Mul implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Mul(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		Object oel = el.val(vars);
		Object oer = er.val(vars);
		if(oel instanceof Integer) {
			int iel = (int)oel;
			if(oer instanceof Integer)
				return iel * (int)oer;
			else
				return iel * (double)oer;
		} else {
			double del = (double)oel;
			if(oer instanceof Integer)
				return del * (int)oer;
			else
				return del * (double)oer;
			
		}
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		String tl = el.tipo(escopo);
		String tr = er.tipo(escopo);
		if(tl.equals("bool") || tr.equals("bool"))
			throw new RuntimeException("tentativa de multiplicar " + tl + " com " + tr + " na linha " + lin);
		if(tl.equals("int") && tr.equals("int"))
			return "int";
		return "real";
	}
}

class Div implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Div(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		Object oel = el.val(vars);
		Object oer = er.val(vars);
		if(oel instanceof Integer) {
			int iel = (int)oel;
			if(oer instanceof Integer)
				return iel / (int)oer;
			else
				return iel / (double)oer;
		} else {
			double del = (double)oel;
			if(oer instanceof Integer)
				return del / (int)oer;
			else
				return del / (double)oer;
			
		}
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		String tl = el.tipo(escopo);
		String tr = er.tipo(escopo);
		if(tl.equals("bool") || tr.equals("bool"))
			throw new RuntimeException("tentativa de dividir " + tl + " por " + tr + " na linha " + lin);
		if(tl.equals("int") && tr.equals("int"))
			return "int";
		return "real";
	}
}

class Num implements Exp {
	String tipo;
	int i;
	double d; 
	int lin;
	
	public Num(String lexeme, int _lin) {
		if(lexeme.contains(".")) {
			tipo = "real";
			d = Double.parseDouble(lexeme);
		} else {
			tipo = "int";
			i = Integer.parseInt(lexeme);
		}
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		if(tipo.equals("int"))
			return i;
		else
			return d;
	}

	@Override
	public void escopo(TabSimb<Void> escopo) { }

	@Override
	public String tipo(TabSimb<String> escopo) { 
		return tipo;
	}
}

class Id implements Exp {
	String id;
	int lin;
	
	public Id(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	@Override
	public Object val(TabSimb<Object> vars) {
		return vars.procurar(id, lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
	}

	@Override
	public String tipo(TabSimb<String> escopo) {
		return escopo.procurar(id, lin);
	}
}

class Chamada implements Cmd {
	String nome;
	int lin;
	
	public Chamada(String _nome, int _lin) {
		nome = _nome;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Object>> procs, TabSimb<Object> vars) {
		FechoProc<Object> proc = procs.procurar(nome, lin);
		proc.proc.run(procs, proc.globais);
	}

	@Override
	public void escopo(TabSimb<Void> procs, TabSimb<Void> escopo) {
		procs.procurar(nome, lin);
	}

	@Override
	public void tipos(TabSimb<Void> procs, TabSimb<String> escopo) {
		procs.procurar(nome, lin);
	}
}
