// Output created by jacc on Mon Nov 25 16:14:01 BRST 2013

interface Tokens {
    int ENDINPUT = 0;
    int ATRIB = 1;
    int BOOL = 2;
    int ELSE = 3;
    int END = 4;
    int ID = 5;
    int IF = 6;
    int INT = 7;
    int NUM = 8;
    int PROC = 9;
    int READ = 10;
    int REAL = 11;
    int REPEAT = 12;
    int THEN = 13;
    int UNTIL = 14;
    int VAR = 15;
    int WRITE = 16;
    int error = 17;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
