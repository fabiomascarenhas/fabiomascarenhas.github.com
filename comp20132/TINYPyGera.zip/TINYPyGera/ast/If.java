package ast;

import java.util.List;
import java.util.Map;

public class If implements Cmd{
	public List<Teste> testes;
	public List<Cmd> celse;
	
	public If(List<Teste> _testes, List<Cmd> _celse) {
		testes = _testes;
		celse = _celse;
	}

	@Override
	public void tipos(Map<String, Func> funcs, TabSimb<String> vars) {
		for(Teste teste: testes) {
			String tcond = teste.cond.tipo(funcs, vars);
			if(!tcond.equals("bool"))
				throw new RuntimeException("condição do while é " + tcond + " e não booleano na linha " + teste.lin);
			TabSimb<String> vcorpo = new TabSimb<String>(vars);
			for(Cmd cmd: teste.corpo)
				cmd.tipos(funcs, vcorpo);
		}
		TabSimb<String> velse = new TabSimb<String>(vars);
		for(Cmd cmd: celse)
			cmd.tipos(funcs, velse);
	}

	@Override
	public void run(Map<String, Func> funcs, TabSimb<Integer> vars) {
		for(Teste teste: testes) {
			if(teste.cond.val(funcs, vars) == 1) {
				TabSimb<Integer> vcorpo = new TabSimb<Integer>(vars);
				for(Cmd cmd: teste.corpo)
					cmd.run(funcs, vcorpo);
				return;
			}
		}
		TabSimb<Integer> velse = new TabSimb<Integer>(vars);
		for(Cmd cmd: celse)
			cmd.run(funcs, velse);
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		int labSaida = ctx.label();
		for(Teste teste: testes) {
			int labCorpo = ctx.label();
			int labProx = ctx.label();
			teste.cond.codigoSalto(ctx, vars, labCorpo);
			ctx.jmp(labProx);
			ctx.label(labCorpo);
			TabSimb<Endereco> vcorpo = new TabSimb<Endereco>(vars);
			ctx.entraEscopo();
			for(Cmd cmd: teste.corpo)
				cmd.codigo(ctx, vcorpo);
			ctx.saiEscopo();
			ctx.jmp(labSaida);
			ctx.label(labProx);
		}
		TabSimb<Endereco> velse = new TabSimb<Endereco>(vars);
		ctx.entraEscopo();
		for(Cmd cmd: celse)
			cmd.codigo(ctx, velse);
		ctx.saiEscopo();
		ctx.label(labSaida);
	}
}
