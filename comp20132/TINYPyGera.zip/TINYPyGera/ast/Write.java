package ast;

import java.util.Map;

public class Write implements Cmd {
	public Exp exp;
	public int lin;
	
	public Write(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void tipos(Map<String, Func> funcs, TabSimb<String> vars) {
		String texp = exp.tipo(funcs, vars);
		if(!texp.equals("int"))
			throw new RuntimeException("tipo do write é " + texp + " e não inteiro na linha" + lin);
	}

	@Override
	public void run(Map<String, Func> funcs, TabSimb<Integer> vars) {
		System.out.println(exp.val(funcs, vars));
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		exp.codigoVal(ctx, vars);
		ctx.write();
	}
}
