package ast;

import java.util.Map;

public class False implements Exp {

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		return "bool";
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return 0;
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(0);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		// nop
	}

}
