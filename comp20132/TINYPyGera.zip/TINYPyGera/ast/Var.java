package ast;

import java.util.Map;

public class Var implements Exp {
	public String nome;
	public int lin;
	
	public Var(String _nome, int _lin) {
		nome = _nome;
		lin = _lin;
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		String tv = vars.procurar(nome);
		if(tv == null)
			throw new RuntimeException("variável " + nome + " não definida na linha " + lin);
		return tv;
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return vars.procurar(nome);
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		vars.procurar(nome).get(ctx);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		codigoVal(ctx, esc);
		ctx.icload(1);
		ctx.if_icmpeq(label);
	}
}
