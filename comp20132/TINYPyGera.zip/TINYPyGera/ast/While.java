package ast;

import java.util.List;
import java.util.Map;

public class While implements Cmd {
	public Exp cond;
	public List<Cmd> corpo;
	public int lin;
	
	public While(Exp _cond, List<Cmd> _corpo, int _lin) {
		cond = _cond;
		corpo = _corpo;
		lin = _lin;
	}

	@Override
	public void tipos(Map<String, Func> funcs, TabSimb<String> vars) {
		String tcond = cond.tipo(funcs, vars);
		if(!tcond.equals("bool"))
			throw new RuntimeException("condição do while é " + tcond + " e não booleano na linha " + lin);
		TabSimb<String> vcorpo = new TabSimb<String>(vars);
		for(Cmd cmd: corpo)
			cmd.tipos(funcs,  vcorpo);
	}

	@Override
	public void run(Map<String, Func> funcs, TabSimb<Integer> vars) {
		while(cond.val(funcs, vars) == 1) {
			TabSimb<Integer> vcorpo = new TabSimb<Integer>(vars);
			for(Cmd cmd: corpo)
				cmd.run(funcs, vcorpo);
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		int labCorpo = ctx.label();
		int labCond = ctx.label();
		ctx.jmp(labCond);
		ctx.label(labCorpo);
		ctx.entraEscopo();
		TabSimb<Endereco> vcorpo = new TabSimb<Endereco>(vars);
		for(Cmd cmd: corpo)
			cmd.codigo(ctx, vcorpo);
		ctx.saiEscopo();
		ctx.label(labCond);
		cond.codigoSalto(ctx, vars, labCorpo);
	}
}
