package ast;

import java.util.Map;

public class True implements Exp {

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		return "bool";
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return 1;
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(1);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		ctx.jmp(label);
	}

}
