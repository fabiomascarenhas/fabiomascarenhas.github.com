package ast;
import java.util.HashMap;
import java.util.Map;

public class TabSimb<T> {
  TabSimb<T> pai;
  Map<String, T> nomes =
		  new HashMap<String, T>();
  
  public TabSimb(TabSimb<T> _pai) {
	  pai = _pai;
  }
  
  public TabSimb() { pai = null; }
  
  void inserir(String nome, T atrib, int lin) {
	  nome = nome.toLowerCase();
	  if(!nomes.containsKey(nome))
		  nomes.put(nome, atrib);
	  else
		  throw new RuntimeException(nome + " redeclarado na linha " + lin);
  }
  
  T procurar(String nome) {
	  nome = nome.toLowerCase();
	  if(nomes.containsKey(nome))
		  return nomes.get(nome);
	  else if(pai != null)
		  return pai.procurar(nome);
	  else
		  return null;
  }
  
  void atualizar(String nome, T atrib) {
	  nome = nome.toLowerCase();
	  if(nomes.containsKey(nome))
		  nomes.put(nome,  atrib);
	  else if(pai != null)
		  pai.atualizar(nome, atrib);
	  else
		  nomes.put(nome, atrib);
  }
}
