package ast;

import java.util.Map;

public class Num implements Exp {
	public int val;
	
	public Num(String _val) {
		val = Integer.parseInt(_val);
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		return "int";
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return val;
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(val);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		throw new RuntimeException("erro no verificador de tipos");
	}
}
