package ast;

import java.util.Map;

public class NaoLog implements Exp {
	public Exp exp;
	public int lin;
	
	public NaoLog(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		String texp = exp.tipo(funcs, vars);
		if(!texp.equals("bool"))
			throw new RuntimeException("operando do not é " + texp +
					" e não booleano na linha " + lin);
		return "bool";
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return exp.val(funcs, vars) == 1 ? 0 : 1;
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		int lab1 = ctx.label();
		int lab2 = ctx.label();
		codigoSalto(ctx, vars, lab1);
		ctx.icload(0);
		ctx.jmp(lab2);
		ctx.label(lab1);
		ctx.icload(1);
		ctx.label(lab2);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		int labSaida = ctx.label();
		exp.codigoSalto(ctx, esc, labSaida);
		ctx.jmp(label);
		ctx.label(labSaida);
	}
}
