package ast;

import java.util.Map;

public class Neg implements Exp {
	public Exp exp;
	public int lin;
	
	public Neg(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		String texp = exp.tipo(funcs, vars);
		if(!texp.equals("int"))
			throw new RuntimeException("operando da negação é " + texp +
					" e não inteiro na linha " + lin);
		return "int";
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return -exp.val(funcs, vars);
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(0);
		exp.codigoVal(ctx, vars);
		ctx.isub();
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		throw new RuntimeException("erro no verificador de tipos");
	}
}
