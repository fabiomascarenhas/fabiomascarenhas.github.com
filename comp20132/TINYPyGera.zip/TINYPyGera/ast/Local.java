package ast;

public class Local implements Endereco {
	int loc;
	
	public Local(int _loc) {
		loc = _loc;
	}

	@Override
	public void get(Contexto ctx) {
		ctx.iload(loc);
	}

	@Override
	public void put(Contexto ctx) {
		ctx.istore(loc);
	}
}