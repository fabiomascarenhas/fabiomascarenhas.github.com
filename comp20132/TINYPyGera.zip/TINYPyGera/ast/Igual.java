package ast;

import java.util.Map;

public class Igual implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Igual(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		String tl = el.tipo(funcs, vars);
		String tr = er.tipo(funcs, vars);
		if(!tl.equals(tr))
			throw new RuntimeException("operandos da comparação diferentes (" + tl +
					" e " + tr + ") na linha " + lin);
		return tl;
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return (el.val(funcs, vars) == er.val(funcs, vars)) ? 1 : 0;
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> esc) {
		int lab1 = ctx.label();
		int lab2 = ctx.label();
		codigoSalto(ctx, esc, lab1);
		ctx.icload(0);
		ctx.jmp(lab2);
		ctx.label(lab1);
		ctx.icload(1);
		ctx.label(lab2);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		el.codigoVal(ctx, esc);
		er.codigoVal(ctx, esc);
		ctx.if_icmpeq(label);
	}
}
