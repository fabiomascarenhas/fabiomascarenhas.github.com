package ast;

public interface Exp {
	String tipo(java.util.Map<String, Func> funcs, TabSimb<String> vars);
	int val(java.util.Map<String, Func> funcs, TabSimb<Integer> vars);
	void codigoVal(Contexto ctx, TabSimb<Endereco> vars);
	void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label);
}
