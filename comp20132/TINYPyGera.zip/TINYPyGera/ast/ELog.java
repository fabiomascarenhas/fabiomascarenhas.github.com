package ast;

import java.util.Map;

public class ELog implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public ELog(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		String tl = el.tipo(funcs, vars);
		if(!tl.equals("bool"))
			throw new RuntimeException("operando esquerdo do and é " + tl +
					" e não booleano na linha " + lin);
		String tr = er.tipo(funcs, vars);
		if(!tr.equals("bool"))
			throw new RuntimeException("operando direito do and é " + tr +
					" e não booleano na linha " + lin);
		return "bool";
	}
	
	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return el.val(funcs, vars) & er.val(funcs, vars);
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		int lab1 = ctx.label();
		int lab2 = ctx.label();
		codigoSalto(ctx, vars, lab1);
		ctx.icload(0);
		ctx.jmp(lab2);
		ctx.label(lab1);
		ctx.icload(1);
		ctx.label(lab2);
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		int labSaida = ctx.label();
		int labProx = ctx.label();
		el.codigoSalto(ctx, esc, labProx);
		ctx.jmp(labSaida);
		ctx.label(labProx);
		er.codigoSalto(ctx, esc, label);
		ctx.label(labSaida);
	}
}
