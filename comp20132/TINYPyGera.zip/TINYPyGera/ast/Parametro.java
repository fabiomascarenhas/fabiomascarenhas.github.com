package ast;

public class Parametro implements Endereco {
    int loc;
    
    public Parametro(int _loc) {
        loc = _loc;
    }

    @Override
    public void get(Contexto ctx) {
        ctx.iloadp(loc);
    }

    @Override
    public void put(Contexto ctx) {
        ctx.istorep(loc);
    }
    
}