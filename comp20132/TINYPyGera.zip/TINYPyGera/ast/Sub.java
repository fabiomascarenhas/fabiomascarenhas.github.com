package ast;

import java.util.Map;

public class Sub implements Exp {
	public Exp el;
	public Exp er;
	public int lin;
	
	public Sub(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public String tipo(Map<String, Func> funcs, TabSimb<String> vars) {
		String tl = el.tipo(funcs, vars);
		if(!tl.equals("int"))
			throw new RuntimeException("operando esquerdo da subtração é " + tl +
					" e não inteiro na linha " + lin);
		String tr = er.tipo(funcs, vars);
		if(!tr.equals("int"))
			throw new RuntimeException("operando direito da subtração é " + tr +
					" e não inteiro na linha " + lin);
		return "int";
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		return el.val(funcs, vars) - er.val(funcs, vars);
	}

	@Override
	public void codigoVal(Contexto ctx, TabSimb<Endereco> vars) {
		el.codigoVal(ctx, vars);
		er.codigoVal(ctx, vars);
		ctx.isub();
	}

	@Override
	public void codigoSalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		throw new RuntimeException("bug no verificador de tipos!");
	}
}
