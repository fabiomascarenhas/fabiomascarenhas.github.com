package ast;

public interface Endereco {
	void get(Contexto ctx);
	void put(Contexto ctx);
}