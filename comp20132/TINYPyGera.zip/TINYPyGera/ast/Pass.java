package ast;

import java.util.Map;

public class Pass implements Cmd {

	@Override
	public void tipos(Map<String, Func> funcs, TabSimb<String> vars) {}

	@Override
	public void run(Map<String, Func> funcs, TabSimb<Integer> vars) {}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {}

}
