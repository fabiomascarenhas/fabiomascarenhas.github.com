package ast;

import java.util.Map;
import java.util.Scanner;

public class Read implements Cmd {
	public String var;
	public int lin;
	
	public static final Scanner scan = new Scanner(System.in);
	
	public Read(String _var, int _lin) {
		var = _var;
		lin = _lin;
	}

	@Override
	public void tipos(Map<String, Func> funcs, TabSimb<String> vars) {
		String tvar = vars.procurar(var);
		if(tvar == null)
			vars.inserir(var, "int", lin);
		else if(!tvar.equals("int"))
			throw new RuntimeException("variável do read é " + tvar + " e não inteiro na linha "+ lin);
	}

	@Override
	public void run(Map<String, Func> funcs, TabSimb<Integer> vars) {
		vars.atualizar(var, scan.nextInt());
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		Endereco end = vars.procurar(var);
		if(end == null) {
			end = new Local(ctx.local());
			vars.inserir(var, end, lin);
		}
		ctx.read();
		end.put(ctx);
	}
}
