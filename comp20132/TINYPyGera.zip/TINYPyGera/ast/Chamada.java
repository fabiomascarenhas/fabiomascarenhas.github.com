package ast;

import java.util.List;
import java.util.Map;

public class Chamada implements Cmd, Exp {
	public String func;
	public List<Exp> args;
	public int lin;
	
	public Chamada(String _func, List<Exp> _args, int _lin) {
		func = _func;
		args = _args;
		lin = _lin;
	}

	@Override
	public int val(Map<String, Func> funcs, TabSimb<Integer> vars) {
		Func f = funcs.get(func);
		TabSimb<Integer> vfunc = new TabSimb<Integer>();
		vfunc.atualizar(func, 0);
		for(int i = args.size() - 1; i >= 0; i--)
			vfunc.atualizar(f.params.get(i).nome, args.get(i).val(funcs, vars));
		for(Cmd cmd: f.corpo)
			cmd.run(funcs, vfunc);
		return vfunc.procurar(func);
	}

	@Override
	public void run(Map<String, Func> funcs, TabSimb<Integer> vars) {
		val(funcs, vars);
	}

}
