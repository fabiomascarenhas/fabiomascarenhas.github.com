package ast;

public class Param {
	public String tipo;
	public String nome;
	public int lin;
	
	public Param(String _tipo, String _nome, int _lin) {
		tipo = _tipo;
		nome = _nome;
		lin = _lin;
	}
}
