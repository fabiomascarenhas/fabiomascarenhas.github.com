package ast;

public interface Cmd {
	void tipos(java.util.Map<String, Func> funcs, TabSimb<String> vars);
	void run(java.util.Map<String, Func> funcs, TabSimb<Integer> vars);
	void codigo(Contexto ctx, TabSimb<Endereco> vars);
}
