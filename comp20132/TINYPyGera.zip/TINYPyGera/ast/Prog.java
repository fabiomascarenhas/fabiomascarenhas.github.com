package ast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Prog {
	public List<Func> funcs;
	
	public Map<String, Func> fs;
	public Func main;
	
	public Prog(List<Func> _funcs) {
		funcs = _funcs;
	}
	
	public void tipos() {
		fs = new HashMap<String, Func>();
		for(Func f: funcs) {
			String nome = f.nome.toLowerCase();
			if(!fs.containsKey(nome))
				fs.put(nome, f);
			else
				throw new RuntimeException("função " + f.nome + " redeclarada na linha " + f.lin);
		}
		main = fs.get("main");
		if(main == null)
			throw new RuntimeException("programa não tem função main");
		if(main.params.size() != 0)
			throw new RuntimeException("função main não pode ter parâmetros");
		if(!main.tret.equals("void"))
			throw new RuntimeException("tipo de retorno de main deve ser void");
		for(Func f: funcs)
			f.tipos(fs);
	}
	
	public void run() {
		TabSimb<Integer> vmain = new TabSimb<Integer>();
		for(Cmd cmd: main.corpo)
			cmd.run(fs, vmain);
	}
	
	public String codigo() {
		List<String> cfuncs = new ArrayList<String>();
		for(Func func: funcs)
			cfuncs.add(func.codigo());
		return Contexto.programa(cfuncs);
	}

}
