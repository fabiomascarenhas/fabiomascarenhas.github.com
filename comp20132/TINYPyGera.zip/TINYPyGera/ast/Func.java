package ast;

import java.util.List;

public class Func {
	public String tret;
	public String nome;
	public List<Param> params;
	public List<Cmd> corpo;
	public int lin;
	
	public Func(String _tret, String _nome, List<Param> _params, List<Cmd> _corpo, int _lin) {
		tret = _tret;
		nome = _nome;
		params = _params;
		corpo = _corpo;
		lin = _lin;
	}
	
	public void tipos(java.util.Map<String, Func> funcs) {
		TabSimb<String> vcorpo = new TabSimb<String>();
		vcorpo.inserir(nome, tret, lin);
		for(Param param: params)
			vcorpo.inserir(param.nome, param.tipo, lin);
		for(Cmd cmd: corpo)
			cmd.tipos(funcs, vcorpo);
	}
	
	public String codigo() {
		Contexto ctx = new Contexto(nome);
		TabSimb<Endereco> esc = new TabSimb<Endereco>();
		ctx.entraEscopo();
		if(!tret.equals("void"))
			esc.inserir(nome, new Local(ctx.local()), lin);
		for(int i = 0; i < params.size(); i++)
			esc.inserir(params.get(i).nome, new Parametro(i+1), lin);
		for(Cmd cmd: corpo)
			cmd.codigo(ctx, esc);
		if(!tret.equals("void"))
			esc.procurar(nome).get(ctx);
		ctx.saiEscopo();
		return ctx.codigo();
	}
}
