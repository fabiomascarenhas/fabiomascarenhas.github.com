import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Driver {
	public static void main(String[] args) throws IOException {
		String name = args[0];
		String name_asm = name.substring(0, name.lastIndexOf('.')) + ".asm";
		File f = new File(name);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		parser.parse();
		ast.Prog prog = parser.saida;
		prog.tipos();
		prog.run();
		FileWriter fw = new FileWriter(new File(name_asm));
		fw.write(prog.codigo());
		fw.close();
	}
}
