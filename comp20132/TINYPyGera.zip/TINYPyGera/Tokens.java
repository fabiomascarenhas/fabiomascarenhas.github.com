// Output created by jacc on Tue Dec 03 11:10:40 BRST 2013

interface Tokens {
    int ENDINPUT = 0;
    int AND = 1;
    int ATRIB = 2;
    int BEGIN = 3;
    int BOOL = 4;
    int ELIF = 5;
    int ELSE = 6;
    int END = 7;
    int FALSE = 8;
    int ID = 9;
    int IF = 10;
    int INT = 11;
    int NEG = 12;
    int NOT = 13;
    int NUM = 14;
    int OR = 15;
    int PASS = 16;
    int READ = 17;
    int TRUE = 18;
    int VOID = 19;
    int WHILE = 20;
    int WRITE = 21;
    int error = 22;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ':' (code=58)
    // '<' (code=60)
    // '=' (code=61)
}
