// Output created by jacc on Tue Dec 03 11:10:40 BRST 2013


import ast.*;
import java.util.List;
import java.util.ArrayList;

class Parser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    switch (yytok) {
                        case BOOL:
                            yyn = 5;
                            continue;
                        case INT:
                            yyn = 6;
                            continue;
                        case VOID:
                            yyn = 7;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 196;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 100:
                    switch (yytok) {
                        case INT:
                        case VOID:
                        case ENDINPUT:
                        case BOOL:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    switch (yytok) {
                        case BOOL:
                            yyn = 5;
                            continue;
                        case INT:
                            yyn = 6;
                            continue;
                        case VOID:
                            yyn = 7;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    switch (yytok) {
                        case ID:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    switch (yytok) {
                        case ID:
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    switch (yytok) {
                        case ID:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    switch (yytok) {
                        case INT:
                        case VOID:
                        case ENDINPUT:
                        case BOOL:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    switch (yytok) {
                        case '(':
                            yyn = 10;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    switch (yytok) {
                        case BOOL:
                            yyn = 5;
                            continue;
                        case INT:
                            yyn = 6;
                            continue;
                        case VOID:
                            yyn = 7;
                            continue;
                        case ')':
                            yyn = 14;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    switch (yytok) {
                        case ')':
                            yyn = 15;
                            continue;
                        case ',':
                            yyn = 16;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    switch (yytok) {
                        case ID:
                            yyn = 17;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    switch (yytok) {
                        case ':':
                            yyn = 18;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    switch (yytok) {
                        case ':':
                            yyn = 19;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    switch (yytok) {
                        case BOOL:
                            yyn = 5;
                            continue;
                        case INT:
                            yyn = 6;
                            continue;
                        case VOID:
                            yyn = 7;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 21;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 22;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    yyn = yys21();
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    yyn = yys22();
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    yyn = yys23();
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    yyn = yys24();
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    switch (yytok) {
                        case ATRIB:
                            yyn = 34;
                            continue;
                        case '(':
                            yyn = 35;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    yyn = yys27();
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ID:
                            yyn = 43;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    yyn = yys29();
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    yyn = yys30();
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    yyn = yys31();
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case INT:
                        case VOID:
                        case ENDINPUT:
                        case BOOL:
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    yyn = yys34();
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    yyn = yys45();
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    switch (yytok) {
                        case INT:
                        case VOID:
                        case ENDINPUT:
                        case BOOL:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    yyn = yys48();
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ')':
                            yyn = 64;
                            continue;
                        case ',':
                            yyn = 65;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    yyn = yys50();
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    yyn = yys51();
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys53();
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    yyn = yys54();
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 72;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    yyn = yys59();
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    yyn = yys61();
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    yyn = yys62();
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 77;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    yyn = yys73();
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    switch (yytok) {
                        case ',':
                            yyn = 65;
                            continue;
                        case ')':
                            yyn = 80;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    yyn = yys76();
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    yyn = yys78();
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys79();
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys80();
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    yyn = yys81();
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys82();
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    yyn = yys83();
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    yyn = yys84();
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    yyn = yys85();
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    yyn = yys86();
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys87();
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ':':
                            yyn = 90;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    yyn = yys89();
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 92;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 93;
                            continue;
                    }
                    yyn = 199;
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    yyn = yys92();
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    yyn = yys94();
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    yyn = yys95();
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys96();
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    yyn = yys97();
                    continue;

                case 196:
                    return true;
                case 197:
                    yyerror("stack overflow");
                case 198:
                    return false;
                case 199:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys21() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
        }
        return 199;
    }

    private int yys22() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
        }
        return 199;
    }

    private int yys23() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
            case END:
                return 33;
        }
        return 199;
    }

    private int yys24() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr13();
        }
        return 199;
    }

    private int yys26() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys27() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr21();
        }
        return 199;
    }

    private int yys29() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys30() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys31() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
            case END:
                return 46;
        }
        return 199;
    }

    private int yys32() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr12();
        }
        return 199;
    }

    private int yys34() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys35() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
            case ')':
                return 50;
        }
        return 199;
    }

    private int yys36() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case ':':
                return 57;
            case '<':
                return 58;
            case '=':
                return 59;
        }
        return 199;
    }

    private int yys37() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr38();
    }

    private int yys38() {
        switch (yytok) {
            case BOOL:
            case ATRIB:
            case NUM:
            case INT:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case NEG:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
                return 199;
            case '(':
                return 60;
        }
        return yyr40();
    }

    private int yys39() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys40() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr39();
    }

    private int yys41() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr37();
    }

    private int yys42() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys43() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr19();
        }
        return 199;
    }

    private int yys44() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case ':':
                return 63;
        }
        return 199;
    }

    private int yys45() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr20();
        }
        return 199;
    }

    private int yys47() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr16();
        }
        return 199;
    }

    private int yys48() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case ',':
            case ')':
                return yyr44();
        }
        return 199;
    }

    private int yys50() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr18();
        }
        return 199;
    }

    private int yys51() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys52() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys53() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys54() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys55() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys56() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys58() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys59() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys60() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
            case ')':
                return 76;
        }
        return 199;
    }

    private int yys61() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case ':':
            case END:
            case ',':
            case ')':
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr36();
        }
        return 199;
    }

    private int yys62() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case ':':
            case END:
            case ',':
            case ')':
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr35();
        }
        return 199;
    }

    private int yys64() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr17();
        }
        return 199;
    }

    private int yys65() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys66() {
        switch (yytok) {
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case OR:
            case END:
            case ',':
            case ')':
            case WRITE:
            case WHILE:
            case IF:
            case ':':
            case ID:
            case READ:
            case PASS:
            case AND:
                return yyr33();
        }
        return 199;
    }

    private int yys67() {
        switch (yytok) {
            case AND:
                return 51;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case OR:
            case END:
            case ',':
            case ')':
            case WRITE:
            case WHILE:
            case ':':
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr34();
        }
        return 199;
    }

    private int yys68() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr29();
    }

    private int yys69() {
        switch (yytok) {
            case TRUE:
            case ATRIB:
            case ELSE:
            case NOT:
            case VOID:
            case ELIF:
            case ENDINPUT:
            case FALSE:
            case BEGIN:
            case INT:
            case '(':
            case NEG:
            case error:
            case NUM:
            case BOOL:
                return 199;
            case '*':
                return 53;
            case '/':
                return 56;
        }
        return yyr27();
    }

    private int yys70() {
        switch (yytok) {
            case TRUE:
            case ATRIB:
            case ELSE:
            case NOT:
            case VOID:
            case ELIF:
            case ENDINPUT:
            case FALSE:
            case BEGIN:
            case INT:
            case '(':
            case NEG:
            case error:
            case NUM:
            case BOOL:
                return 199;
            case '*':
                return 53;
            case '/':
                return 56;
        }
        return yyr28();
    }

    private int yys71() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr30();
    }

    private int yys72() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
        }
        return 199;
    }

    private int yys73() {
        switch (yytok) {
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case OR:
            case END:
            case ',':
            case ')':
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case ':':
            case '<':
            case '=':
            case PASS:
            case AND:
                return yyr31();
        }
        return 199;
    }

    private int yys74() {
        switch (yytok) {
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case OR:
            case END:
            case ',':
            case ')':
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case ':':
            case '<':
            case '=':
            case PASS:
            case AND:
                return yyr32();
        }
        return 199;
    }

    private int yys76() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr42();
    }

    private int yys77() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
        }
        return 199;
    }

    private int yys78() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case ',':
            case ')':
                return yyr43();
        }
        return 199;
    }

    private int yys79() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
            case END:
                return 82;
        }
        return 199;
    }

    private int yys80() {
        switch (yytok) {
            case '(':
            case ATRIB:
            case NUM:
            case NEG:
            case NOT:
            case TRUE:
            case ENDINPUT:
            case FALSE:
            case ELSE:
            case INT:
            case BEGIN:
            case error:
            case ELIF:
            case VOID:
            case BOOL:
                return 199;
        }
        return yyr41();
    }

    private int yys81() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
            case END:
                return 83;
        }
        return 199;
    }

    private int yys82() {
        switch (yytok) {
            case END:
            case ELSE:
            case WRITE:
            case WHILE:
            case IF:
            case ELIF:
            case ID:
            case READ:
            case PASS:
                return yyr23();
        }
        return 199;
    }

    private int yys83() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr15();
        }
        return 199;
    }

    private int yys84() {
        switch (yytok) {
            case ELIF:
                return 87;
            case ELSE:
                return 88;
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr26();
        }
        return 199;
    }

    private int yys85() {
        switch (yytok) {
            case END:
            case ELSE:
            case WRITE:
            case WHILE:
            case IF:
            case ELIF:
            case ID:
            case READ:
            case PASS:
                return yyr22();
        }
        return 199;
    }

    private int yys86() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr14();
        }
        return 199;
    }

    private int yys87() {
        switch (yytok) {
            case FALSE:
                return 37;
            case ID:
                return 38;
            case NOT:
                return 39;
            case NUM:
                return 40;
            case TRUE:
                return 41;
            case '-':
                return 42;
        }
        return 199;
    }

    private int yys89() {
        switch (yytok) {
            case AND:
                return 51;
            case OR:
                return 52;
            case '*':
                return 53;
            case '+':
                return 54;
            case '-':
                return 55;
            case '/':
                return 56;
            case '<':
                return 58;
            case '=':
                return 59;
            case ':':
                return 91;
        }
        return 199;
    }

    private int yys92() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
        }
        return 199;
    }

    private int yys93() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
        }
        return 199;
    }

    private int yys94() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
            case END:
                return 96;
        }
        return 199;
    }

    private int yys95() {
        switch (yytok) {
            case ID:
                return 25;
            case IF:
                return 26;
            case PASS:
                return 27;
            case READ:
                return 28;
            case WHILE:
                return 29;
            case WRITE:
                return 30;
            case END:
                return 97;
        }
        return 199;
    }

    private int yys96() {
        switch (yytok) {
            case END:
            case WRITE:
            case WHILE:
            case IF:
            case ID:
            case READ:
            case PASS:
                return yyr25();
        }
        return 199;
    }

    private int yys97() {
        switch (yytok) {
            case END:
            case ELSE:
            case WRITE:
            case WHILE:
            case IF:
            case ELIF:
            case ID:
            case READ:
            case PASS:
                return yyr24();
        }
        return 199;
    }

    private int yyr1() { // prog : funcs
        { saida = new Prog(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr12() { // cmds : cmds cmd
        { ((List)yysv[yysp-2]).add(((Cmd)yysv[yysp-1])); yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yyr13() { // cmds : cmd
        { List<Cmd> cs = new ArrayList<Cmd>(); cs.add(((Cmd)yysv[yysp-1])); yyrv = cs; }
        yysv[yysp-=1] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 92: return 94;
            case 77: return 81;
            case 72: return 79;
            case 22: return 31;
            case 21: return 23;
            default: return 95;
        }
    }

    private int yyr24() { // elif : ELIF exp ':' BEGIN cmds END
        { yyrv = new Teste(((Exp)yysv[yysp-5]), ((List)yysv[yysp-2]), ((Token)yysv[yysp-6]).lin); }
        yysv[yysp-=6] = yyrv;
        return 85;
    }

    private int yyr22() { // elifs : elifs elif
        { ((List)yysv[yysp-2]).add(((Teste)yysv[yysp-1])); yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return 84;
    }

    private int yyr23() { // elifs : /* empty */
        { yyrv = new ArrayList<Teste>(); }
        yysv[yysp-=0] = yyrv;
        return 84;
    }

    private int yyr25() { // else : ELSE ':' BEGIN cmds END
        { yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=5] = yyrv;
        return 86;
    }

    private int yyr26() { // else : /* empty */
        { yyrv = new ArrayList<Cmd>(); }
        yysv[yysp-=0] = yyrv;
        return 86;
    }

    private int yyr27() { // exp : exp '+' exp
        { yyrv = new Soma(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr28() { // exp : exp '-' exp
        { yyrv = new Sub(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr29() { // exp : exp '*' exp
        { yyrv = new Mult(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr30() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr31() { // exp : exp '<' exp
        { yyrv = new Menor(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr32() { // exp : exp '=' exp
        { yyrv = new Igual(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr33() { // exp : exp AND exp
        { yyrv = new ELog(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr34() { // exp : exp OR exp
        { yyrv = new OuLog(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : '-' exp
        { yyrv = new Neg(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : NOT exp
        { yyrv = new NaoLog(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : TRUE
        { yyrv = new True(); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : FALSE
        { yyrv = new False(); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : NUM
        { yyrv = new Num(((Token)yysv[yysp-1]).texto); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : ID
        { yyrv = new Var(((Token)yysv[yysp-1]).texto, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : ID '(' exps ')'
        { yyrv = new Chamada(((Token)yysv[yysp-4]).texto, ((List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr42() { // exp : ID '(' ')'
        { yyrv = new Chamada(((Token)yysv[yysp-3]).texto, new ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 87: return 89;
            case 65: return 78;
            case 59: return 74;
            case 58: return 73;
            case 56: return 71;
            case 55: return 70;
            case 54: return 69;
            case 53: return 68;
            case 52: return 67;
            case 51: return 66;
            case 42: return 62;
            case 39: return 61;
            case 34: return 47;
            case 30: return 45;
            case 29: return 44;
            case 26: return 36;
            default: return 48;
        }
    }

    private int yyr43() { // exps : exps ',' exp
        { ((List)yysv[yysp-3]).add(((Exp)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr44() { // exps : exp
        { java.util.List<Exp> l = new java.util.ArrayList<Exp>();
                        l.add(((Exp)yysv[yysp-1])); yyrv = l; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 35: return 49;
            default: return 75;
        }
    }

    private int yyr4() { // func : tipo ID '(' params ')' ':' BEGIN cmds END
        { yyrv = new Func(((String)yysv[yysp-9]), ((Token)yysv[yysp-8]).texto, ((List)yysv[yysp-6]), ((List)yysv[yysp-2]), ((Token)yysv[yysp-8]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypfunc();
    }

    private int yyr5() { // func : tipo ID '(' ')' ':' BEGIN cmds END
        { yyrv = new Func(((String)yysv[yysp-8]), ((Token)yysv[yysp-7]).texto, new ArrayList<Param>(), ((List)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=8] = yyrv;
        return yypfunc();
    }

    private int yypfunc() {
        switch (yyst[yysp-1]) {
            case 0: return 2;
            default: return 8;
        }
    }

    private int yyr2() { // funcs : funcs func
        { ((List)yysv[yysp-2]).add(((Func)yysv[yysp-1])); yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return 3;
    }

    private int yyr3() { // funcs : func
        { List<Func> fs = new ArrayList<Func>(); fs.add(((Func)yysv[yysp-1])); yyrv = fs; }
        yysv[yysp-=1] = yyrv;
        return 3;
    }

    private int yyr8() { // param : tipo ID
        { yyrv = new Param(((String)yysv[yysp-2]), ((Token)yysv[yysp-1]).texto, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=2] = yyrv;
        switch (yyst[yysp-1]) {
            case 10: return 11;
            default: return 20;
        }
    }

    private int yyr6() { // params : params ',' param
        { ((List)yysv[yysp-3]).add(((Param)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 12;
    }

    private int yyr7() { // params : param
        { List<Param> ps = new ArrayList<Param>(); ps.add(((Param)yysv[yysp-1])); yyrv = ps; }
        yysv[yysp-=1] = yyrv;
        return 12;
    }

    private int yyr14() { // cmd : IF exp ':' BEGIN cmds END elifs else
        { ((List)yysv[yysp-2]).add(0, new Teste(((Exp)yysv[yysp-7]), ((List)yysv[yysp-4]), ((Token)yysv[yysp-8]).lin)); yyrv = new If(((List)yysv[yysp-2]), ((List)yysv[yysp-1])); }
        yysv[yysp-=8] = yyrv;
        return yypcmd();
    }

    private int yyr15() { // cmd : WHILE exp ':' BEGIN cmds END
        { yyrv = new While(((Exp)yysv[yysp-5]), ((List)yysv[yysp-2]), ((Token)yysv[yysp-6]).lin); }
        yysv[yysp-=6] = yyrv;
        return yypcmd();
    }

    private int yyr16() { // cmd : ID ATRIB exp
        { yyrv = new Atrib(((Token)yysv[yysp-3]).texto, ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr17() { // cmd : ID '(' exps ')'
        { yyrv = new Chamada(((Token)yysv[yysp-4]).texto, ((List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr18() { // cmd : ID '(' ')'
        { yyrv = new Chamada(((Token)yysv[yysp-3]).texto, new ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr19() { // cmd : READ ID
        { yyrv = new Read(((Token)yysv[yysp-1]).texto, ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr20() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr21() { // cmd : PASS
        { yyrv = new Pass(); }
        yysv[yysp-=1] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 93: return 24;
            case 92: return 24;
            case 77: return 24;
            case 72: return 24;
            case 22: return 24;
            case 21: return 24;
            default: return 32;
        }
    }

    private int yyr9() { // tipo : INT
        { yyrv = "int"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr10() { // tipo : BOOL
        { yyrv = "bool"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr11() { // tipo : VOID
        { yyrv = "void"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 3: return 4;
            case 0: return 4;
            default: return 13;
        }
    }

    protected String[] yyerrmsgs = {
    };


Scanner scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Prog saida; // workaround pro bug do tipo do parse()

public Parser(java.io.Reader entrada) {
  scan = new Scanner(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.token();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException("erro de sintaxe na linha: " + token.lin);
}

}
