
public class Token implements Tokens {
	public int tipo;
	public String val;
	public int lin;
	
	public static final int EOF = 0;

	public Token(int tipo, String val, int lin) {
		this.tipo = tipo;
		this.val = val;
		this.lin = lin;
	}
		
	public String toString() {
		return "<" + tipo + "," + val + "," + lin + ">";
	}
	
	public String toToken() {
		switch(tipo) {
		case 0: return "<<EOF>>";
		case NUM: return "num";
		case ID: return "id";
		default: return val;
		}
	}

}
