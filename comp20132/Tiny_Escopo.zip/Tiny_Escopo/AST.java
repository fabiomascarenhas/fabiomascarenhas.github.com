import java.util.ArrayList;
import java.util.List;

interface Cmd {
	void run(TabSimb<Integer> vars);
	void escopo(TabSimb<Void> escopo);
}

interface Exp {
	boolean bval(TabSimb<Integer> vars);
	int ival(TabSimb<Integer> vars);
	void escopo(TabSimb<Void> escopo);
}

class Bloco {
	List<String> vars;
	List<Cmd> cmds;
	int lin;
	
	public Bloco() {
		vars = new ArrayList<String>();
		cmds = new ArrayList<Cmd>();
	}
	
	public Bloco(List<String> _vars, int _lin) {
		vars = _vars;
		lin = _lin;
		cmds = new ArrayList<Cmd>();
	}
	
	public TabSimb<Integer> run(TabSimb<Integer> escopoPai) {
		TabSimb<Integer> escopo = new TabSimb<Integer>(escopoPai);
		for(String var: vars)
			escopo.inserir(var, 0, lin);
		for(Cmd cmd: cmds)
			cmd.run(escopo);
		return escopo;
	}
	
	public TabSimb<Void> escopo(TabSimb<Void> escopoPai) {
		TabSimb<Void> escopo = new TabSimb<Void>(escopoPai);
		for(String var: vars)
			escopo.inserir(var, null, lin);
		for(Cmd cmd: cmds)
			cmd.escopo(escopo);
		return escopo;
	}
}

class Tiny {
	Bloco cmds;
	
	public Tiny(Bloco _cmds) {
		cmds = _cmds;
	}
	
	public TabSimb<Integer> run() {
		return cmds.run(null);
	}
	
	public void escopo() {
		cmds.escopo(null);
	}
}

class If implements Cmd {
	Exp cond;
	Bloco cthen;
	Bloco celse;
	int lin;
	
	public If(Exp _cond, Bloco _cthen, int _lin) {
		cond = _cond;
		cthen = _cthen;
		celse = new Bloco();
		lin = _lin;
	}
	
	public If(Exp _cond, Bloco _cthen, Bloco _celse, int _lin) {
		cond = _cond;
		cthen = _cthen;
		celse = _celse;
		lin = _lin;
	}
	
	public void run(TabSimb<Integer> vars) {
		if(cond.bval(vars))
			cthen.run(vars);
		else
			celse.run(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		cond.escopo(escopo);
		cthen.escopo(escopo);
		celse.escopo(escopo);
	}
}

class Repeat implements Cmd {
	Bloco corpo;
	Exp cond;
	int lin;
	
	public Repeat(Bloco _corpo, Exp _cond, int _lin) {
		corpo = _corpo;
		cond = _cond;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<Integer> vars) {
		TabSimb<Integer> vcond;
		do {
			vcond = corpo.run(vars);
		} while(!cond.bval(vcond));
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		TabSimb<Void> ecorpo = corpo.escopo(escopo);
		cond.escopo(ecorpo);
	}
}

class Atrib implements Cmd {
	String id;
	Exp exp;
	int lin;
	
	public Atrib(String _id, Exp _exp, int _lin) {
		id = _id;
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<Integer> vars) {
		vars.atualizar(id, exp.ival(vars), lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
		exp.escopo(escopo);
	}
}

class Read implements Cmd {
	String id;
	int lin;
	
	java.util.Scanner scan = new java.util.Scanner(System.in);
	
	public Read(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<Integer> vars) {
		vars.atualizar(id, scan.nextInt(), lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
	}
}

class Write implements Cmd {
	Exp exp;
	int lin;
	
	public Write(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<Integer> vars) {
		System.out.println(exp.ival(vars));
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		exp.escopo(escopo);
	}
}

class Menor implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Menor(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		return el.ival(vars) < er.ival(vars);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado inteiro, encontrado booleano na linha " + lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Igual implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Igual(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		return el.ival(vars) == er.ival(vars);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado inteiro, encontrado booleano na linha " + lin);
	}
	
	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Soma implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Soma(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) + er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Sub implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Sub(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) - er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Mul implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Mul(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) * er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Div implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Div(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) / er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Num implements Exp {
	int n;
	int lin;
	
	public Num(String lexeme, int _lin) {
		n = Integer.parseInt(lexeme);
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return n;
	}

	@Override
	public void escopo(TabSimb<Void> escopo) { }
}

class Id implements Exp {
	String id;
	int lin;
	
	public Id(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return vars.procurar(id, lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
	}
}
