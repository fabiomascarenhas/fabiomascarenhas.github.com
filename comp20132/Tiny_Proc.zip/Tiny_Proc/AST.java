import java.util.ArrayList;
import java.util.List;

interface Cmd {
	void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> locais);
	void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo);
}

interface Exp {
	boolean bval(TabSimb<Integer> vars);
	int ival(TabSimb<Integer> vars);
	void escopo(TabSimb<Void> escopo);
}

class Bloco {
	List<String> vars;
	List<Cmd> cmds;
	int lin;
	
	public Bloco() {
		vars = new ArrayList<String>();
		cmds = new ArrayList<Cmd>();
	}
	
	public Bloco(List<String> _vars, int _lin) {
		vars = _vars;
		lin = _lin;
		cmds = new ArrayList<Cmd>();
	}
	
	public TabSimb<Integer> run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> locais) {
		TabSimb<Integer> escopo = new TabSimb<Integer>(locais);
		for(String var: vars)
			escopo.inserir(var, 0, lin);
		for(Cmd cmd: cmds)
			cmd.run(procs, escopo);
		return escopo;
	}
	
	public TabSimb<Void> escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopoPai) {
		TabSimb<Void> escopo = new TabSimb<Void>(escopoPai);
		for(String var: vars)
			escopo.inserir(var, null, lin);
		for(Cmd cmd: cmds)
			cmd.escopo(procs, escopo);
		return escopo;
	}
}

class Tiny {
	List<Proc> procs;
	Bloco cmds;
	
	public Tiny(Bloco _cmds) {
		procs = new ArrayList<Proc>();
		cmds = _cmds;
	}
	
	public Tiny(List<Proc> _procs, Bloco _cmds) {
		procs = _procs;
		cmds = _cmds;
	}
	
	public TabSimb<Integer> run() {
		TabSimb<FechoProc<Integer>> tsprocs = new TabSimb<FechoProc<Integer>>();
		TabSimb<Integer> globais = new TabSimb<Integer>();
		for(Proc proc: procs)
			tsprocs.inserir(proc.nome, new FechoProc<Integer>(globais, proc), proc.lin);
		for(String var: cmds.vars)
			globais.inserir(var, 0, 1);
		for(Cmd cmd: cmds.cmds)
			cmd.run(tsprocs, globais);
		return globais;
	}
	
	public void escopo() {
		TabSimb<FechoProc<Void>> tsprocs = new TabSimb<FechoProc<Void>>();
		TabSimb<Void> globais = new TabSimb<Void>();
		// Fase de coleta dos nomes
		for(Proc proc: procs)
			tsprocs.inserir(proc.nome, new FechoProc<Void>(globais, proc), proc.lin);
		for(String var: cmds.vars)
			globais.inserir(var, null, 1);
		// Fase de verifica��o dos escopos
		for(Cmd cmd: cmds.cmds)
			cmd.escopo(tsprocs, globais);
		for(Proc proc: procs)
			proc.corpo.escopo(tsprocs, globais);
	}
}

class Proc {
	String nome;
	Bloco corpo;
	int lin;
	
	public Proc(String _nome, Bloco _corpo, int _lin) {
		nome = _nome;
		corpo = _corpo;
		lin = _lin;
	}
	
	void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> globais) {
		corpo.run(procs, new TabSimb<Integer>(globais));
	}
}

class FechoProc<T> {
	TabSimb<T> globais;
	Proc proc;
	
	public FechoProc(TabSimb<T> _globais, Proc _proc) {
		globais = _globais;
		proc = _proc;
	}
}

class If implements Cmd {
	Exp cond;
	Bloco cthen;
	Bloco celse;
	int lin;
	
	public If(Exp _cond, Bloco _cthen, int _lin) {
		cond = _cond;
		cthen = _cthen;
		celse = new Bloco();
		lin = _lin;
	}
	
	public If(Exp _cond, Bloco _cthen, Bloco _celse, int _lin) {
		cond = _cond;
		cthen = _cthen;
		celse = _celse;
		lin = _lin;
	}
	
	public void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> vars) {
		if(cond.bval(vars))
			cthen.run(procs, vars);
		else
			celse.run(procs, vars);
	}

	@Override
	public void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo) {
		cond.escopo(escopo);
		cthen.escopo(procs, escopo);
		celse.escopo(procs, escopo);
	}
}

class Repeat implements Cmd {
	Bloco corpo;
	Exp cond;
	int lin;
	
	public Repeat(Bloco _corpo, Exp _cond, int _lin) {
		corpo = _corpo;
		cond = _cond;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> vars) {
		TabSimb<Integer> vcond;
		do {
			vcond = corpo.run(procs, vars);
		} while(!cond.bval(vcond));
	}

	@Override
	public void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo) {
		TabSimb<Void> ecorpo = corpo.escopo(procs, escopo);
		cond.escopo(ecorpo);
	}
}

class Atrib implements Cmd {
	String id;
	Exp exp;
	int lin;
	
	public Atrib(String _id, Exp _exp, int _lin) {
		id = _id;
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> vars) {
		vars.atualizar(id, exp.ival(vars), lin);
	}

	@Override
	public void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
		exp.escopo(escopo);
	}
}

class Read implements Cmd {
	String id;
	int lin;
	
	java.util.Scanner scan = new java.util.Scanner(System.in);
	
	public Read(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> vars) {
		vars.atualizar(id, scan.nextInt(), lin);
	}

	@Override
	public void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
	}
}

class Write implements Cmd {
	Exp exp;
	int lin;
	
	public Write(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> vars) {
		System.out.println(exp.ival(vars));
	}

	@Override
	public void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo) {
		exp.escopo(escopo);
	}
}

class Menor implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Menor(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		return el.ival(vars) < er.ival(vars);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado inteiro, encontrado booleano na linha " + lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Igual implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Igual(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		return el.ival(vars) == er.ival(vars);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado inteiro, encontrado booleano na linha " + lin);
	}
	
	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Soma implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Soma(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) + er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Sub implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Sub(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) - er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Mul implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Mul(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) * er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Div implements Exp {
	Exp el;
	Exp er;
	int lin;
	
	public Div(Exp _el, Exp _er, int _lin) {
		el = _el;
		er = _er;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return el.ival(vars) / er.ival(vars);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		el.escopo(escopo);
		er.escopo(escopo);
	}
}

class Num implements Exp {
	int n;
	int lin;
	
	public Num(String lexeme, int _lin) {
		n = Integer.parseInt(lexeme);
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return n;
	}

	@Override
	public void escopo(TabSimb<Void> escopo) { }
}

class Id implements Exp {
	String id;
	int lin;
	
	public Id(String _id, int _lin) {
		id = _id;
		lin = _lin;
	}

	@Override
	public boolean bval(TabSimb<Integer> vars) {
		throw new RuntimeException("esperado booleano, encontrado inteiro na linha " + lin);
	}

	@Override
	public int ival(TabSimb<Integer> vars) {
		return vars.procurar(id, lin);
	}

	@Override
	public void escopo(TabSimb<Void> escopo) {
		escopo.procurar(id, lin);
	}
}

class Chamada implements Cmd {
	String nome;
	int lin;
	
	public Chamada(String _nome, int _lin) {
		nome = _nome;
		lin = _lin;
	}

	@Override
	public void run(TabSimb<FechoProc<Integer>> procs, TabSimb<Integer> vars) {
		FechoProc<Integer> proc = procs.procurar(nome, lin);
		proc.proc.run(procs, proc.globais);
	}

	@Override
	public void escopo(TabSimb<FechoProc<Void>> procs, TabSimb<Void> escopo) {
		procs.procurar(nome, lin);
	}
}