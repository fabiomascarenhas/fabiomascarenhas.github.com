package lex;

import java.util.List;

public interface Scanner {
	public void setInput(String input);
	public Token nextToken() throws java.io.IOException;
	public List<Token> allTokens() throws java.io.IOException;
}
