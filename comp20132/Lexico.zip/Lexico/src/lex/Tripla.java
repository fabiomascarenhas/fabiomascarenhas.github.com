package lex;

public class Tripla<A, B, C> {
	public A a;
	public B b;
	public C c;
	
	public Tripla(A a, B b, C c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}
}
