package parse;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Stack;

import parse.Grammar.Rule;

public class LRDFA {
	public State init;
	public ArrayList<State> states = new ArrayList<State>();

	private static int nextState = 0;
	
	public class Item {
		public Grammar.Rule rule;
		public int dot;
		
		public Item(Grammar.Rule rule, int dot) {
			this.rule = rule;
			this.dot = dot;
		}
		
		public String toString() {
			StringBuffer buf = new StringBuffer();
			buf.append(rule.head + "->");
			if(dot == 0) buf.append(" .");
			for(int i = 0; i < rule.body.length; i++) {
				buf.append(" ");
				buf.append(rule.body[i]);
				if(dot == i + 1)
					buf.append(" .");
			}
			return buf.toString();
		}
		
		public int hashCode() {
			return Integer.rotateLeft(rule.hashCode(), dot);
		}
		
		public boolean equals(Object o) {
			if(o instanceof Item) {
				Item i = (Item)o;
				return i.dot == dot && i.rule.equals(rule);
			}
			return false;
		}
	}
	
	public class State {
		public ArrayList<Item> items = new ArrayList<Item>();
		public HashMap<String, State> trans = 
				new HashMap<String, State>();
		public int id = nextState++;
				
		public State(Grammar g, int rule, int dot) {
			item(g, rule, dot);
		}
		
		public State(Rule rule, int dot) {
			item(rule, dot);
		}
		
		public State(Item item) {
			item(item);
		}
		
		public void item(Grammar g, int rule, int dot) {
			item(new Item(g.rules.get(rule), dot));
		}

		public void item(Rule rule, int dot) {
			item(new Item(rule, dot));
		}

		public void item(Item item) {
			items.add(item);
		}
		
		public void trans(String term, State s) {
			trans.put(term, s);
		}
		
		public String label() {
			StringBuffer buf = new StringBuffer();
			buf.append(id);
			buf.append(" [label=\"" + states.indexOf(this) +
					"\\n");
			for(Item item : items) {
				buf.append(item.toString());
				buf.append("\\n");
			}
			buf.append("\",shape=box];\n");
			return buf.toString();
		}
		
		public String transitions() {
			StringBuffer buf = new StringBuffer();
			for(Entry<String, State> pair : trans.entrySet()) {
				buf.append(" ");
				buf.append(id);
				buf.append(" -> ");
				buf.append(pair.getValue().id);
				buf.append(" [label=\"");
				buf.append(pair.getKey());
				buf.append("\"]\n");
			}
			return buf.toString();
		}
		
		public void eclosure(Grammar g) {
			Stack<Item> worklist = new Stack<Item>();
			worklist.addAll(items);
			while(!worklist.empty()) {
				Item i = worklist.pop();
				if(i.dot < i.rule.body.length){
					String term = i.rule.body[i.dot];
					if(g.variables.contains(term)) {
						for(Rule r: g.rules) {
							if(r.head.equals(term)) {
								Item next = new Item(r, 0);
								if(!items.contains(next)) {
									items.add(next);
									worklist.push(next);
								}
							}
						}
					}
				}
			}
		}
		
		public int hashCode() {
			return items.hashCode();
		}
		
		public boolean equals(Object o) {
			if(o instanceof State) {
				State s = (State)o;
				return s.items.equals(items);
			}
			return false;
		}
		
		public String toString() {
			return items.toString();
		}
	}
	
	public State fromItem(Rule r, int dot) {
		for(State s: states) {
			for(Item i: s.items) {
				if(i.rule.equals(r) && i.dot == dot)
					return s;
			}
		}
		return null;
	}
	
	public void fill(Grammar g) {
		init = new State(g, 0, 0);
		for(int i = 1; i < g.rules.size(); i++) {
			Rule r = g.rules.get(i);
			if(r.head.equals(g.rules.get(0).head)) {
				init.item(r, 0);
			}
		}
		init.eclosure(g);
		states.add(init);
		Stack<State> worklist = new Stack<State>();
		worklist.push(init);
		while(!worklist.empty()) {
			State cur = worklist.pop();
			HashMap<String, State> trans = 
					new HashMap<String, State>();
			for(Item i: cur.items) {
				if(i.dot < i.rule.body.length) {
					String term = i.rule.body[i.dot];
					if(trans.containsKey(term)) {
						trans.get(term).item(i.rule, i.dot + 1);
					} else {
						trans.put(term, new State(i.rule, i.dot + 1));
					}
				}
			}
			for(Entry<String, State> pair: trans.entrySet()) {
				State next = pair.getValue();
				next.eclosure(g);
				if(!states.contains(next)) {
					states.add(next);
					worklist.push(next);
				} else {
					next = states.get(states.indexOf(next));
				}
				cur.trans(pair.getKey(), next);
			}
		}
	}
	
	public LRDFA() { }
	
	public LRDFA(Grammar g) {
		fill(g);
	}
		
	public void printDot(String fileName) throws IOException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write("digraph DFA {\n");
		for(State s: states) {
			buf.write(s.label());
		}
		for(State s: states) {
			buf.write(s.transitions());
		}
		buf.write("}\n");
		buf.close();
	}

}
