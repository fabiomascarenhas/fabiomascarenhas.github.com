package parse;

/*
11: REXP  -> EXP {REXP'}
    REXP' -> < EXP
    REXP' -> == EXP 
14: EXP  -> TERM {EXP'}
    EXP' -> + TERM
    EXP' -> - TERM
17: TERM  -> FAT {TERM'}
    TERM' -> * FAT
    TERM' -> / FAT
20: FAT -> - FAT
21: FAT -> num
22: FAT -> id 
23: FAT -> ( EXP )
*/
public class RExpParser {
	// input[pos] � o lookahead
	public int pos;
	public String[] input;
	
	public RExpParser(String ... input) {
		this.input = input;
		this.pos = 0;
	}
	
	public String la() {
		return pos < input.length ? input[pos] : "<<EOF>>";
	}
	
	public Tree match(String token) {
		if(token.equals(la())) {
			pos++;
			return new Tree(token);
		} else
			throw new RuntimeException("erro de sintaxe em " +
					pos + ", esperado: " + token + ", achado: " +
					la());
	}
	
	public Tree parse() {
		Tree res = rexp();
		if(pos < input.length)
			throw new RuntimeException("entrada n�o foi toda analisada");
		return res;
	}

	public Tree parse(int pos) {
		this.pos = pos;
		Tree res = rexp();
		return res;
	}

	// REXP  -> EXP {REXP'}
	// REXP' -> < EXP
	// REXP' -> == EXP 
	public Tree rexp() {
		Tree res = new Tree("REXP");
		res.child(exp());
		String la = la();
		while(la.equals("<") || la.equals("==")) {
			Tree rexpp = new Tree("REXP'");
			if(la.equals("<")) {
				rexpp.child(match("<"));
				rexpp.child(exp());
			} else {
				rexpp.child(match("=="));
				rexpp.child(exp());
			}
			res.child(rexpp);
			la = la();
		}
		return res;
	}

	// EXP  -> TERM {EXP'}
	// EXP' -> + TERM
	// EXP' -> - TERM
	public Tree exp() {
		Tree res = new Tree("EXP");
		res.child(term());
		String la = la();
		while(la.equals("+") || la.equals("-")) {
			Tree expp = new Tree("EXP'");
			if(la.equals("+")) {
				expp.child(match("+"));
				expp.child(term());
			} else {
				expp.child(match("-"));
				expp.child(term());
			}
			res.child(expp);
			la = la();
		}
		return res;
	}

	// TERM  -> FAT {TERM'}
	// TERM' -> * FAT
	// TERM' -> / FAT
	public Tree term() {
		Tree res = new Tree("TERM");
		res.child(fat());
		String la = la();
		while(la.equals("*") || la.equals("/")) {
			Tree termp = new Tree("TERM'");
			if(la.equals("*")) {
				termp.child(match("*"));
				termp.child(fat());
			} else {
				termp.child(match("/"));
				termp.child(fat());
			}
			res.child(termp);
			la = la();
		}
		return res;
	}
	
	// FAT -> - FAT
	// FAT -> num
	// FAT -> id 
	// FAT -> ( EXP )
	public Tree fat() {
		Tree res = new Tree("FAT");
		switch(la()) {
		case "-":
			res.child(match("-"));
			res.child(fat());
			break;
		case "num":
			res.child(match("num"));
			break;
		case "id":
			res.child(match("id"));
			break;
		default:
			res.child(match("("));
			res.child(exp());
			res.child(match(")"));
		}
		return res;
	}
}

