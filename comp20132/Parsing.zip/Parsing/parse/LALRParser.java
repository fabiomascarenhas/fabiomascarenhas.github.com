package parse;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Stack;

import parse.Grammar.Rule;
import parse.LALRDFA.Item;

public class LALRParser {
	public Grammar g;
	public LALRDFA aut;
	public int pos;
	public String[] input;
	public Stack<Tree> stackTree;
	public Stack<Integer> stackState;
	public boolean accept;
	public HashMap<String, Integer> precedence = 
			new HashMap<String, Integer>();
	
	public HashMap<String, Action[]> ACTION;
	public HashMap<String, Integer[]> GOTO;
		
	public interface Action {
		void run(LALRParser parser);
	}
	
	public class Shift implements Action {
		public int state;
		public String term;
		
		public Shift(int state, String term) {
			this.state = state;
			this.term = term;
		}
		
		public void run(LALRParser parser) {
			parser.shift(state);
		}
		
		public String toString() {
			return "S" + state;
		}
	}
	
	public class Reduce implements Action {
		public Item item;
		
		public Reduce(Item item) {
			this.item = item;
		}
		
		public void run(LALRParser parser) {
			parser.reduce(item.rule);
		}
		
		public String toString() {
			return "R" + g.rules.indexOf(item.rule);
		}
	}
	
	public class Accept extends Reduce {
		public Accept(Item item) {
			super(item);
		}
		
		public void run(LALRParser parser) {
			super.run(parser);
			parser.accept();
		}
		
		public String toString() { 
			return "A";
		}
	}
	
	public class Error implements Action {
		public void run(LALRParser parser) {
			parser.error();
		}
		
		public String toString() {
			return "";
		}
	}
	
	public LALRParser(Grammar g) {
		g.computeSets();
		this.g = g;
		aut = new LALRDFA(g);
		fill();
	}

	public LALRParser(Grammar g, String ... prec) {
		int l = 0;
		for(String level: prec) {
			String[] ops = level.split("[ ]");
			for(String op: ops)
				precedence.put(op, l);
			l++;
		}
		g.computeSets();
		this.g = g;
		aut = new LALRDFA(g);
		fill();
	}

	public void fill() {
		ACTION = new HashMap<String, Action[]>();
		for(String term: g.terminals)
			ACTION.put(term, new Action[aut.states.size()]);
		ACTION.put("<<EOF>>", new Action[aut.states.size()]);
		GOTO = new HashMap<String, Integer[]>();
		for(String term: g.variables)
			GOTO.put(term, new Integer[aut.states.size()]);
		for(int i = 0; i < aut.states.size(); i++) {
			LALRDFA.State s = aut.states.get(i);
			for(Entry<String, LALRDFA.State> pair: s.trans.entrySet()) {
				String term = pair.getKey();
				if(g.variables.contains(term)) {
					GOTO.get(term)[i] = 
							aut.states.indexOf(pair.getValue());
				} else {
					ACTION.get(term)[i] = new Shift(aut.states.indexOf(pair.getValue()), term);
				}
			}
			for(LALRDFA.Item item: s.items) {
				if(item.dot == item.rule.body.length) {
					for(String term: item.la) {
						Action a = ACTION.get(term)[i];
						if(a == null) {
							if(item.rule.equals(g.rules.get(0)))
								ACTION.get(term)[i] = new Accept(item);
							else
								ACTION.get(term)[i] = new Reduce(item);
						} else {
							if(a instanceof Shift) {
								Shift sa = (Shift)a;
								Integer precRight = precedence.get(sa.term);
								Integer precLeft = null;
								for(int j = item.rule.body.length-1; j >= 0; j--) {
									if(g.terminals.contains(item.rule.body[j])
										&& precedence.containsKey(item.rule.body[j])) {
										precLeft = precedence.get(item.rule.body[j]);
										break;
									}
								}
								if(precRight != null && precLeft != null) {
									if(precRight <= precLeft)
										ACTION.get(term)[i] = new Reduce(item);
								} else
									System.out.println("conflito em " + term + "," + i + ": " + sa + " (" + sa.term + "), reduce " + item);
							} else {
								Reduce ra = (Reduce)a;
								int n1 = g.rules.indexOf(ra.item.rule);
								int n2 = g.rules.indexOf(item.rule);
								if(n2 < n1)  { // reduz a regra que vem primeiro
									ACTION.get(term)[i] = new Reduce(item);
									System.out.println("conflito em " + term + "," + i + ": reduce " + item + ", reduce " + ra.item);
								} else
									System.out.println("conflito em " + term + "," + i + ": reduce " + ra.item + ", reduce " + item);

							}
						}
					}
				}
			}
		}
		for(String term: ACTION.keySet()) {
			for(int i = 0; i < aut.states.size(); i++)
				if(ACTION.get(term)[i] == null)
					ACTION.get(term)[i] = new Error();
		}
		System.out.println(aut.states.size() + " estados");
	}
	
	public String la() {
		return pos < input.length ? input[pos] : "<<EOF>>";
	}

	public void setInput(String ... input) {
		this.input = input;
		this.pos = 0;
		this.accept = false;
		this.stackTree = new Stack<Tree>();
		stackTree.push(new Tree("<<EOF>>"));
		this.stackState = new Stack<Integer>();
		stackState.push(0);
		System.out.println(configuration());
	}

	public void setInput(String input) {
		setInput(input.split("[ ]+"));
	}

	public String configuration() {
		StringBuffer config = new StringBuffer();
		for(int i = 0; i < stackTree.size(); i++) {
			config.append(stackTree.get(i).term);
			config.append(",");
			config.append(stackState.get(i));
			config.append(" ");
		}
		config.append("| ");
		config.append(la());
		return config.toString();
	}
	
	public void shift(int state) {
		stackTree.push(new Tree(input[pos++]));
		stackState.push(state);
		System.out.println(configuration());
	}

	public void reduce(Rule r) {
		Tree node = new Tree(r.head);
		for(int i = r.body.length - 1; i >= 0; i--) {
			stackState.pop();
			Tree child = stackTree.pop();
			node.children.add(0, child);
		}
		stackTree.push(node);
		stackState.push(GOTO.get(node.term)[stackState.peek()]);
		System.out.println(configuration());
	}
		
	public void error() {
		throw new RuntimeException("erro de sintaxe: " + pos + ", token: " + la());
	}
	
	public void accept() {
		accept = true;
	}
	
	public Tree parse() {
		while(!accept) {
			ACTION.get(la())[stackState.peek()].run(this);
		}
		return stackTree.pop();
	}
	
	public void printTable() {
		System.out.println();
		System.out.println(">>>>> ACTION:");
		for(String term: ACTION.keySet()) {
			System.out.print("\t" + term);
		}
		System.out.println();
		for(int i = 0; i < aut.states.size(); i++) {
			System.out.print(i);
			for(String term: ACTION.keySet()) {
				System.out.print("\t" + ACTION.get(term)[i]);
			}
			System.out.println();
		}
		System.out.println();
		System.out.println(">>>>> GOTO:");
		for(String term: GOTO.keySet()) {
			System.out.print("\t" + term);
		}
		System.out.println();
		for(int i = 0; i < aut.states.size(); i++) {
			System.out.print(i);
			for(String term: GOTO.keySet()) {
				System.out.print("\t" + 
						(GOTO.get(term)[i] == null ? "" : GOTO.get(term)[i]));
			}
			System.out.println();
		}
		System.out.println();
	}
}
