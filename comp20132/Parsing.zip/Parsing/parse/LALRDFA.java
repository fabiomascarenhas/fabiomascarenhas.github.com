package parse;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Stack;

import parse.Grammar.Rule;

public class LALRDFA {
	public State init;
	public ArrayList<State> states = new ArrayList<State>();

	private static int nextState = 0;
	
	public class Item {
		public Rule rule;
		public int dot;
		public HashSet<String> la = new HashSet<String>();
		
		public Item(Grammar.Rule rule, int dot, HashSet<String> la) {
			this.rule = rule;
			this.dot = dot;
			this.la.addAll(la);
		}
		
		public String toString() {
			StringBuffer buf = new StringBuffer();
			buf.append(rule.head + " ->");
			if(dot == 0) buf.append(" .");
			for(int i = 0; i < rule.body.length; i++) {
				buf.append(" ");
				buf.append(rule.body[i]);
				if(dot == i + 1)
					buf.append(" .");
			}
			buf.append(" ");
			buf.append(la.toString());
			return buf.toString();
		}
		
		public int hashCode() {
			return Integer.rotateLeft(rule.hashCode(), dot);
		}
		
		public boolean equals(Object o) {
			if(o instanceof Item) {
				Item i = (Item)o;
				return i.dot == dot && i.rule.equals(rule);
			}
			return false;
		}
	}
	
	public class State {
		public ArrayList<Item> items = new ArrayList<Item>();
		public HashMap<String, State> trans = 
				new HashMap<String, State>();
		public int id = nextState++;
				
		public State(Grammar g, int rule, int dot, HashSet<String> la) {
			item(g, rule, dot, la);
		}
		
		public State(Rule rule, int dot, HashSet<String> la) {
			item(rule, dot, la);
		}
		
		public State(Item item) {
			item(item);
		}
		
		public void item(Grammar g, int rule, int dot, HashSet<String> la) {
			item(new Item(g.rules.get(rule), dot, la));
		}

		public void item(Rule rule, int dot, HashSet<String> la) {
			item(new Item(rule, dot, la));
		}

		public void item(Item item) {
			if(items.contains(item)) {
				items.get(items.indexOf(item)).la.addAll(item.la);
			} else {
				items.add(item);
			}
		}
		
		public void trans(String term, State s) {
			trans.put(term, s);
		}
		
		public String label() {
			StringBuffer buf = new StringBuffer();
			buf.append(id);
			buf.append(" [label=\"" + states.indexOf(this) +
					"\\n");
			for(Item item : items) {
				buf.append(item.toString());
				buf.append("\\n");
			}
			buf.append("\",shape=box];\n");
			return buf.toString();
		}
		
		public String transitions() {
			StringBuffer buf = new StringBuffer();
			for(Entry<String, State> pair : trans.entrySet()) {
				buf.append(" ");
				buf.append(id);
				buf.append(" -> ");
				buf.append(pair.getValue().id);
				buf.append(" [label=\"");
				buf.append(pair.getKey());
				buf.append("\"]\n");
			}
			return buf.toString();
		}
		
		public boolean merge(State s) {
			boolean changed = false;
			for(Item i: s.items) {
				changed = items.get(items.indexOf(i)).la.addAll(i.la) || changed;
			}
			return changed;
		}
		
		public void eclosure(final Grammar g) {
			Stack<Item> worklist = new Stack<Item>();
			worklist.addAll(items);
			while(!worklist.empty()) {
				Item i = worklist.pop();
				if(i.dot < i.rule.body.length){
					String term = i.rule.body[i.dot];
					if(g.variables.contains(term)) {
						String[] rest = 
								new String[i.rule.body.length-i.dot-1];
						for(int j = i.dot + 1, k = 0; j < i.rule.body.length; j++, k++)
							rest[k] = i.rule.body[j];
						HashSet<String> la = g.first(i.la, rest);
						for(Rule r: g.rules) {
							if(r.head.equals(term)) {
								Item next = new Item(r, 0, la);
								if(!items.contains(next)) {
									items.add(next);
									worklist.push(next);
								} else {
									Item last = items.get(items.indexOf(next));
									if(last.la.addAll(next.la))
										worklist.push(last);
								}
							}
						}
					}
				}
			}
			Collections.sort(items, new Comparator<Item>() {
				@Override
				public int compare(Item i1, Item i2) {
					int n1 = g.rules.indexOf(i1.rule);
					int n2 = g.rules.indexOf(i2.rule);
					return n1 < n2 ? -1 : (n1 > n2 ? 1 : 0);
				}
			});
		}
		
		public int hashCode() {
			return items.hashCode();
		}
		
		public boolean equals(Object o) {
			if(o instanceof State) {
				State s = (State)o;
				return s.items.equals(items);
			}
			return false;
		}
		
		public String toString() {
			return items.toString();
		}
	}
	
	public State fromItem(Rule r, int dot) {
		for(State s: states) {
			for(Item i: s.items) {
				if(i.rule.equals(r) && i.dot == dot)
					return s;
			}
		}
		return null;
	}
	
	public void fill(Grammar g) {
		HashSet<String> eof = new HashSet<String>();
		eof.add("<<EOF>>");
		init = new State(g, 0, 0, eof);
		init.eclosure(g);
		states.add(init);
		Stack<State> worklist = new Stack<State>();
		worklist.push(init);
		while(!worklist.empty()) {
			State cur = worklist.pop();
			HashMap<String, State> trans = 
					new HashMap<String, State>();
			for(Item i: cur.items) {
				if(i.dot < i.rule.body.length) {
					String term = i.rule.body[i.dot];
					if(trans.containsKey(term)) {
						trans.get(term).item(i.rule, i.dot + 1, i.la);
					} else {
						trans.put(term, new State(i.rule, i.dot + 1, i.la));
					}
				}
			}
			for(Entry<String, State> pair: trans.entrySet()) {
				State next = pair.getValue();
				next.eclosure(g);
				if(!states.contains(next)) {
					states.add(next);
					worklist.push(next);
				} else {
					State last = states.get(states.indexOf(next));
					if(last.merge(next))
						worklist.push(last);
					next = last;
				}
				cur.trans(pair.getKey(), next);
			}
		}
	}
	
	public LALRDFA() { }
	
	public LALRDFA(Grammar g) {
		fill(g);
	}
		
	public void printDot(String fileName) throws IOException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write("digraph DFA {\n");
		for(State s: states) {
			buf.write(s.label());
		}
		for(State s: states) {
			buf.write(s.transitions());
		}
		buf.write("}\n");
		buf.close();
	}
	
}
