import java.io.Writer;
import java.util.List;

public interface Exp {
	void codigo(List<String> vars, StringBuffer out);
}
