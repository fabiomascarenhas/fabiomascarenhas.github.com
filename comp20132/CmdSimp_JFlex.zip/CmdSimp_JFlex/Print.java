import java.util.List;


public class Print implements Cmd {

	public Exp exp;
	public int lin;

	public Print(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	public String toString() {
		return "print " + exp;
	}

	@Override
	public void codigo(List<String> vars, StringBuffer out) {
		out.append("getstatic java/lang/System/out Ljava/io/PrintStream;\n");
		exp.codigo(vars, out);
		out.append("invokevirtual java/io/PrintStream/println(I)V\n");
	}
}
