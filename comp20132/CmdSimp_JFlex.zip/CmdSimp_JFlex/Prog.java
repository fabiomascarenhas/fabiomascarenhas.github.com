import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Prog {
	public List<Cmd> cmds;
	
	public Prog(List<Cmd> cmds) {
		this.cmds = cmds;
	}

	public String toString() {
		String prog = "";
		for(Cmd cmd : cmds) {
			prog += cmd.toString() + ";\n";
		}
		return prog;
	}

	public void codigo(String pname) {
		StringBuffer out = new StringBuffer();
		out.append(".class public " + pname + "\n");
		out.append(".super java/lang/Object\n");
		out.append(".method public static main([Ljava/lang/String;)V\n");
		out.append(".limit stack 100\n");
		out.append(".limit locals 100\n");
		List<String> vars = new ArrayList<String>();
		for(Cmd cmd: cmds)
			cmd.codigo(vars, out);
		out.append("return\n");
		out.append(".end method\n");
		try {
			FileWriter fout = new FileWriter(pname + ".jasmin");
			fout.write(out.toString());
			fout.close();
		} catch(IOException e) {
			throw new RuntimeException(e);
		}
	}
}
