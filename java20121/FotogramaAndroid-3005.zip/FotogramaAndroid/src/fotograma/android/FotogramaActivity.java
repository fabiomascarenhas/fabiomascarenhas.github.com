package fotograma.android;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import com.parse.Parse;
import com.parse.ParseException;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

class TiqueTimer implements Runnable {

	private Handler handler;
	private Pessoa pessoa;
	
	TiqueTimer(Handler handler, Pessoa pessoa) {
		this.handler = handler;
		this.pessoa = pessoa;
	}
	
	public void run() {
		try {
			pessoa.atualiza();
		} catch(ParseException pe) {
			// espera pr�ximo tique
		}
		long agora = SystemClock.uptimeMillis();
		handler.postAtTime(this, agora + 30000);
	}

}

class ClicaSeguir implements OnClickListener {
	FotogramaActivity app;
	
	ClicaSeguir(FotogramaActivity app) {
		this.app = app;
	}

	@Override
	public void onClick(View bot) {
		AlertDialog.Builder seguir = new AlertDialog.Builder(app);
		seguir.setTitle("Seguir pessoa");
		seguir.setMessage("Entre o nome:");
		EditText entrada = new EditText(app);
		seguir.setView(entrada);
		seguir.setPositiveButton("Ok", new ClicaSeguirOk(app, entrada));
		seguir.setNegativeButton("Cancelar", new ClicaCancelar());
		seguir.show();
	}
	
}

class ClicaLogin implements OnClickListener {
	FotogramaActivity app;
	
	Dialog login;
	
	ClicaLogin(FotogramaActivity app, Dialog login) {
		this.app = app;
		this.login = login;
	}
	
	@Override
	public void onClick(View v) {
		String nome = ((EditText)login.findViewById(R.id.txtNome)).getText().toString();
	    String senha = ((EditText)login.findViewById(R.id.txtSenha)).getText().toString();
	    ProgressDialog aviso = ProgressDialog.show(app, "Login", "Aguarde...", true);
		app.login(nome, senha, aviso);
		login.dismiss();
	}
	
}

class ClicaPublica implements OnClickListener {
	FotogramaActivity app;
	
	ClicaPublica(FotogramaActivity app) {
		this.app = app;
	}
	

	@Override
	public void onClick(View arg0) {
		app.tiraFoto();
	}
}

class CallbackLogin implements LoginCallback {
	FotogramaActivity app;
	ProgressDialog aviso;
	
	CallbackLogin(FotogramaActivity app, ProgressDialog aviso) {
		this.app = app;
		this.aviso = aviso;
	}

	@Override
	public void logou(Pessoa p) {
		aviso.dismiss();
		app.init(p);
	}

	@Override
	public void naoEncontrada() {
		aviso.dismiss();
		Toast.makeText(app, "Usu�rio n�o encontrado", Toast.LENGTH_LONG).show();
		app.showDialog(FotogramaActivity.JANELA_LOGIN);
	}

	@Override
	public void senhaErrada() {
		aviso.dismiss();
		Toast.makeText(app, "Senha errada", Toast.LENGTH_LONG).show();
		app.showDialog(FotogramaActivity.JANELA_LOGIN);
	}

	@Override
	public void erroParse(ParseException pe) {
		aviso.dismiss();
		Toast.makeText(app, "Erro de comunica��o: " + pe.getMessage(), Toast.LENGTH_LONG).show();
		app.showDialog(FotogramaActivity.JANELA_LOGIN);
	}
}

class ClicaSeguirOk implements DialogInterface.OnClickListener {
	FotogramaActivity app;
	EditText entrada;
	
	ClicaSeguirOk(FotogramaActivity app, EditText entrada) {
		this.app = app;
		this.entrada = entrada;
	}

	@Override
	public void onClick(DialogInterface dialog, int which) {
		String nome = entrada.getText().toString();
	    ProgressDialog aviso = ProgressDialog.show(app, "Seguir", "Aguarde...", true);
		this.app.pessoa.seguir(nome, new FinalSeguir(app, aviso));
	}
}

class FinalSeguir implements SeguirCallback {
	FotogramaActivity app;
	ProgressDialog aviso;
	
	FinalSeguir(FotogramaActivity app, ProgressDialog aviso) {
		this.app = app;
		this.aviso = aviso;
	}

	@Override
	public void seguiu(String nome) {
		aviso.dismiss();
		Toast.makeText(app, "Voc� est� seguindo " + nome, Toast.LENGTH_LONG).show();
	}

	@Override
	public void naoExiste(String nome) {
		aviso.dismiss();
		Toast.makeText(app, nome + " n�o existe", Toast.LENGTH_LONG).show();
	}

	@Override
	public void erroParse(ParseException pe) {
		aviso.dismiss();
		Toast.makeText(app, "Erro de comunica��o: " + pe.getMessage(), Toast.LENGTH_LONG).show();
	}
	
}

class ClicaCancelar implements DialogInterface.OnClickListener {

	@Override
	public void onClick(DialogInterface dialog, int which) {
	}
	
}

public class FotogramaActivity extends Activity {
	static String SAL = "7e387tgeiugofkjbakbjg";
	static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	static String API_KEY = "j1NgkHcxTIoSlXmcOyWkp91BySLij3FzLtFWctoP";

	final static int JANELA_LOGIN = 1;
	final static int JANELA_EDITAFOTO = 2;
	final static int JANELA_SEGUIR = 3;

	Pessoa pessoa;
	Handler handler;
	File foto;

	File criaArquivo() throws IOException {
	    // Create an image file name
	    String timeStamp = 
	        new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	    String imageFileName = "Fotograma_" + timeStamp;
	    File image = File.createTempFile(
	        imageFileName, 
	        ".jpg", 
	        Environment.getExternalStorageDirectory()
	    );
	    return image;		
	}

	void tiraFoto() {
		try {
			this.foto = criaArquivo();
			Intent takePictureIntent = 
					new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, 
					Uri.fromFile(foto));
			this.startActivityForResult(takePictureIntent, 1);
		} catch(IOException e) {
			Toast.makeText(this, "Foto n�o criada: " + e.getMessage(), Toast.LENGTH_LONG).show();
		}
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		this.showDialog(JANELA_EDITAFOTO);
	}
	
	protected Dialog onCreateDialog(int id) {
		Dialog janela = null;
		switch(id) {
		case JANELA_LOGIN:
			janela = new Dialog(this);
			janela.requestWindowFeature(Window.FEATURE_NO_TITLE);
			janela.setContentView(R.layout.login);
			Button entrar = (Button)janela.findViewById(R.id.botEntrar);
			entrar.setOnClickListener(new ClicaLogin(this, janela));
			break;
		}
		return janela;
	}
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Parse.initialize(this, APP_KEY, API_KEY);
		if(pessoa == null)
			this.showDialog(JANELA_LOGIN);
    }
    
    void login(String nome, String senha, ProgressDialog aviso) {
		Pessoa.login(nome, senha, new CallbackLogin(this, aviso));
    }
    
    void init(Pessoa p) {
    		this.pessoa = p;
		LinhaTempoAdapter lta = new LinhaTempoAdapter(pessoa.getLinhaTempo());
        ListView lista = (ListView)this.findViewById(R.id.listView1);
        this.pessoa.observar(lta);
        lista.setAdapter(lta);
        Button publica = (Button)findViewById(R.id.botPublicar);
        publica.setOnClickListener(new ClicaPublica(this));
        Button seguir = (Button)findViewById(R.id.botSeguir);
        seguir.setOnClickListener(new ClicaSeguir(this));
		handler = new Handler();
		handler.postDelayed(new TiqueTimer(handler, pessoa), 30000);
    }
}