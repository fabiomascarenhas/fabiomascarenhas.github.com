package fotograma.android;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.codec.digest.DigestUtils;

interface ObservadorPessoa {
	void novaLinhaTempo(List<Foto> linhaTempo);
	void novaFoto(Foto f);
	void novoNSeg(int nseg);
}

interface LoginCallback {
	void logou(Pessoa p);
	void naoEncontrada();
	void senhaErrada();
	void erroParse(ParseException pe);
}

interface SeguirCallback {
	void seguiu(String nome);
	void naoExiste(String nome);
	void erroParse(ParseException pe);
}

class CallbackAtualiza extends FindCallback {
	private Pessoa p;
	
	CallbackAtualiza(Pessoa p) {
		this.p = p;
	}
	
	@Override
	public void done(List<ParseObject> fotos, ParseException pe) {
		if(fotos != null) {
			try {
				for(ParseObject foto : fotos) {
					Foto f = new Foto(foto.getObjectId());
					p.getLinhaTempo().add(0, f);
					for(ObservadorPessoa op : p.observadores)
						op.novaFoto(f);
				}
			} catch(ParseException e) {
				
			}
		}
	}
	
}

class CallbackBuscaLogin extends FindCallback {
	String nome;
	String senha;
	LoginCallback cb;
	
	CallbackBuscaLogin(String nome, String senha, LoginCallback cb) {
		this.senha = senha;
		this.cb = cb;
	}

	@Override
	public void done(List<ParseObject> pessoas, ParseException pe) {
		if(pessoas == null) {
			cb.erroParse(pe);
		} else {
			try {
				if(pessoas.isEmpty())
					cb.naoEncontrada();
				ParseObject pessoa = pessoas.get(0);
				if(pessoa.getString("senha").equals(
						DigestUtils.shaHex(FotogramaActivity.SAL + senha))) {
					String id = pessoa.getObjectId();
					List<String> seguidos =
							Pessoa.seguidos(nome);
					List<Foto> linhaTempo =
							Pessoa.linhaTempo(seguidos);
					cb.logou(new Pessoa(id, 
							pessoa.getString("nome"), 
							pessoa.getInt("nseg"),
							linhaTempo, seguidos));
				} else
					cb.senhaErrada();
			} catch(ParseException e) {
				cb.erroParse(e);
			}
		}
	}
}

class CallbackSeguir extends FindCallback {
	Pessoa pessoa;
	String nome;
	SeguirCallback cb;
	
	CallbackSeguir(Pessoa pessoa, String nome, SeguirCallback cb) {
		this.pessoa = pessoa;
		this.nome = nome;
		this.cb = cb;
	}
	
	@Override
	public void done(List<ParseObject> res, ParseException pe) {
		if(res == null) {
			cb.erroParse(pe);
		} else {
			if(res.isEmpty()) {
				cb.naoExiste(nome);
			} else {
				ParseObject seguido = res.get(0);
				seguido.put("nseg", seguido.getInt("nseg") + 1);
				try {
					seguido.save();
					// Cria nova liga��o com seguidor
					ParseObject rel = new ParseObject("Seguidor");
					rel.put("seguidor", this.nome);
					rel.put("seguido", nome);
					try {
						rel.save();
						// Atualiza linha do tempo
						pessoa.seguidos.add(nome);
						pessoa.novaLinhaTempo();
						cb.seguiu(nome);
					} catch(ParseException e) {
						cb.erroParse(e);
					}
				} catch (ParseException e1) {
					cb.erroParse(e1);
				}
			}
		}
	}
}

public class Pessoa {
	// Armazenados no banco de dados
	private String id; // endere�o no banco de dados
	private String nome;
	private int nSeg;
	
	// Calculados
	private List<Foto> linhaTempo;
	List<String> seguidos;
	
	Set<ObservadorPessoa> observadores;
	
	// Inicializa o objeto com dados do BD
	private void init(String id, String nome,
			int nSeg, List<Foto> linhaTempo, 
			List<String> seguidos) {
		this.id = id;
		this.nome = nome;
		this.nSeg = nSeg;
		this.linhaTempo = linhaTempo;
		this.seguidos = seguidos;
		this.observadores = new HashSet<ObservadorPessoa>();
	}
	
	public void observar(ObservadorPessoa op) {
		this.observadores.add(op);
	}
	
	public void desobservar(ObservadorPessoa op) {
		this.observadores.remove(op);
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getNSeg() {
		return this.nSeg;
	}
	
	Pessoa(String id, String nome,
			int nSeg, List<Foto> linhaTempo,
			List<String> seguidos) {
		this.init(id, nome, nSeg, linhaTempo, seguidos);
	}
	
	public List<Foto> getLinhaTempo() {
		return this.linhaTempo;
	}
	
	// Nova pessoa no BD
	public Pessoa(String nome, String senha) throws ParseException {
		ParseObject pessoa = new ParseObject("Pessoa");
		pessoa.put("nome", nome);
		pessoa.put("senha", DigestUtils.shaHex(FotogramaActivity.SAL + senha));
		pessoa.put("nseg", 0);
		pessoa.save();
		this.init(pessoa.getObjectId(), nome,
				0, new ArrayList<Foto>(), new ArrayList<String>());
	}
	
	static List<Foto> linhaTempo(List<String> seguidos) throws ParseException {
		ParseQuery qry = new ParseQuery("Foto");
		qry.whereContainedIn("autor", seguidos);
		qry.addDescendingOrder("createdAt");
		List<ParseObject> fotos = qry.find();
		List<Foto> lt = new ArrayList<Foto>();
		for(ParseObject foto : fotos) {
			lt.add(new Foto(foto));
		}
		return lt;
	}

	static List<String> seguidos(String nome) throws ParseException {
		ParseQuery qry = new ParseQuery("Seguidor");
		qry.whereEqualTo("seguidor", nome);
		List<ParseObject> poSeguidos = qry.find();
		List<String> seguidos = new ArrayList<String>();
		for(ParseObject po : poSeguidos) {
			seguidos.add(po.getString("seguido"));
		}
		return seguidos;
	}
	
	public static void login(String nome, String senha, LoginCallback cb) {
		ParseQuery busca = new ParseQuery("Pessoa");
		busca.whereEqualTo("nome", nome);
		busca.findInBackground(
				new CallbackBuscaLogin(nome, senha, cb));
	}
	
	public void seguir(String nome, SeguirCallback cb) {
		// Atualiza nseg do seguido
		ParseQuery qrySeguido = new ParseQuery("Pessoa");
		qrySeguido.whereEqualTo("nome", nome);
		qrySeguido.findInBackground(
				new CallbackSeguir(this, nome, cb)
		);
	}
	
	void novaLinhaTempo() throws ParseException {
		this.linhaTempo = Pessoa.linhaTempo(this.seguidos);
		for(ObservadorPessoa op : this.observadores) {
			op.novaLinhaTempo(this.linhaTempo);
		}
	}
	
	public void atualiza() throws ParseException {
		if(!this.linhaTempo.isEmpty()) {
			Date recente = this.linhaTempo.get(0).getData();
			ParseQuery qry = new ParseQuery("Foto");
			qry.whereContainedIn("autor", seguidos);
			qry.whereGreaterThan("createdAt", recente);
			qry.addAscendingOrder("createdAt");
			qry.findInBackground(new CallbackAtualiza(this));
		} else {
			this.novaLinhaTempo();
		}
	}
	
	public String toString() {
		String s = nome + " (" + nSeg + ")";
		for(Foto f : this.linhaTempo) {
			s += "\n" + f;
		}
		return s;
	}
}
