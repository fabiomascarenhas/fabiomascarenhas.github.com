import static org.junit.Assert.*;

import java.util.Date;

import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;


public class TesteClasses {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testeEntregaAntes() {
		ItemBib ib1 = new Livro(100, "Java B�sico",
				"Jo�o Silva", 12500);
		ItemBib ib2 = new Revista(100, "Java Magazine",
				12505, 10, 5);
		Assert.assertEquals(true, ib1.entregaAntes(ib2));
		Assert.assertEquals(false, ib2.entregaAntes(ib1));
	}
	
	@Test
	public void testeMulta() {
		ItemBib ib1 = new Livro(100, "Java B�sico",
				"Jo�o Silva", 12500);
		ItemBib ib2 = new Revista(100, "Java Magazine",
				12505, 10, 5);
		ItemBib ib3 = new CD(100, "Classic Java",
				"Java String Quartet", 12502);
		Assert.assertEquals(0.0, ib1.multa(12500));
		Assert.assertEquals(0.0, ib1.multa(12499));
		Assert.assertEquals(0.0, ib2.multa(12505));
		Assert.assertEquals(0.0, ib2.multa(12500));
		Assert.assertEquals(0.0, ib3.multa(12502));
		Assert.assertEquals(0.0, ib3.multa(12499));
		Assert.assertEquals(5.0, ib1.multa(12505));
		Assert.assertEquals(5.0, ib2.multa(12510));
		Assert.assertEquals(10.0, ib3.multa(12507));
	}

}
