import java.util.Date;

abstract class ItemBib {
	protected int categoria;
	protected String titulo;
	protected int dataEntrega; // dias desde 01/01/1970

	ItemBib(int categoria, String titulo, int dataEntrega) {
		this.categoria = categoria;
		this.titulo = titulo;
		this.dataEntrega = dataEntrega;
	}
	
	// data de entrega � antes da data de entrega de outro?
	public boolean entregaAntes(ItemBib outro) {
		return this.dataEntrega < outro.dataEntrega;
	}
	
	/* Maneira 1 - m�todo abstrato
	// dias de atraso * multa di�ria
	// 1 real para revista e livro
	// 2 reais para cds
	public abstract double multa(int data); */
	
	/* Maneira 2 - override na subclasse */
	private static double MULTA = 1.0;
	
	public double multa(int data) {
		double diasAtraso = data - this.dataEntrega;
		if(diasAtraso < 0) diasAtraso = 0;
		return diasAtraso * ItemBib.MULTA;
	} 
	
}

class Livro extends ItemBib {
	private String autor;
	
	public Livro(int categoria, String titulo,
				String autor, int dataEntrega) {
		super(categoria, titulo, dataEntrega);
		this.autor = autor;
	}

	/* Maneira 1
	private static double MULTA = 1.0;
	
	public double multa(int data) {
		double diasAtraso = data - this.dataEntrega;
		if(diasAtraso < 0) diasAtraso = 0;
		return diasAtraso * Livro.MULTA;
	} */
	
	/* Maneira 2 - n�o fa�o nada! herda de itembib */
}

class CD extends ItemBib {
	private String artista;

	public CD(int categoria, String titulo,
				String artista, int dataEntrega) {
		super(categoria, titulo, dataEntrega);
		this.artista = artista;
	}

	/* Maneira 1 e Maneira 2 - override de multa 
	private static double MULTA = 2.0;
	
	public double multa(int data) {
		double diasAtraso = data - this.dataEntrega;
		if(diasAtraso < 0) diasAtraso = 0;
		return diasAtraso * CD.MULTA;
	}*/
	
	/* Maneira 2 - com multa do CD sendo o dobro da normal */
	public double multa(int data) {
		return super.multa(data) * 2.0;
	}
}

class Revista extends ItemBib {
	private int volume;
	private int numero;
	
	public Revista(int categoria, String titulo,
			int dataEntrega, int volume, int numero) {
		super(categoria, titulo, dataEntrega);
		this.volume = volume;
		this.numero = numero;
	}

	/* Maneira 1
	private static double MULTA = 1.0;
	
	public double multa(int data) {
		double diasAtraso = data - this.dataEntrega;
		if(diasAtraso < 0) diasAtraso = 0;
		return diasAtraso * Revista.MULTA;
	} */

	/* Maneira 2 - n�o fa�o nada! herda de itembib */
}
