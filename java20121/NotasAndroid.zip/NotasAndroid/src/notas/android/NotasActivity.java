package notas.android;

import com.parse.Parse;

import android.app.Activity;
import android.os.Bundle;

public class NotasActivity extends Activity {

	static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	static String CLIENT_KEY = "j1NgkHcxTIoSlXmcOyWkp91BySLij3FzLtFWctoP";

	static String ALUNOS = "G_99_99_Alunos";
	static String TURMAS = "G_99_99_Turmas";
	static String NOTAS = "G_99_99_Notas";

	/** Called when the activity is first created. */

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Parse.initialize(this, APP_KEY, CLIENT_KEY);
        setContentView(R.layout.main);
    }
}