/** Automatically generated file. DO NOT MODIFY */
package notas.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}