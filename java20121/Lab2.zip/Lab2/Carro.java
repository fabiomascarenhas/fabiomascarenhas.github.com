
class Carro {
	String modelo;
	int ano;
	double preco;
	Dono dono;
	
	static int VELHO = 2002;
	
	Carro(String modelo, int ano,
			double preco, Dono dono) {
		this.modelo = modelo;
		this.preco = preco;
		this.ano = ano;
		this.dono = dono;
	}
	
	boolean carroVelho() {
		return this.feitoAntes(Carro.VELHO);
	}
	
	boolean feitoAntes(int ano) {
		return this.ano < ano;
	}
	
	boolean feitoDepois(int ano) {
		return this.ano > ano;
	}
	
	boolean maisVelho(Carro outro) {
		return outro.feitoDepois(this.ano);
	}
	
	boolean pertence(Dono d) {
		return this.dono.igual(d);
	}
	
	boolean mesmoDono(Carro outro) {
		return outro.pertence(this.dono);
	}
	
	Carro trocaDono(Dono dono) {
//		return new Carro(this.modelo,
//				this.ano, this.preco, dono);
		this.dono = dono;
		return this;
	}
}

class Dono {
	String nome;
	int idade;
	
	Dono(String nome, int idade) {
		this.nome = nome;
		this.idade = idade;
	}
	
	boolean igual(Dono outro) {
		return this.nome.equals(outro.nome) &&
				this.idade == outro.idade;
	}
	
}
