import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;


public class TestesCarro {
	Dono d1;
	Carro c1;
	Carro c2;
	Carro c3;
	
	@Before
	public void setUp() throws Exception {
		this.d1 = new Dono("Fulano", 30);
		this.c1 = new Carro("Fusca", 1995, 5000, new
				Dono("Beltrano", 52));
		this.c2 = new Carro("Uno", 2005,
				10000, this.d1);
		this.c3 = new Carro("Celta", 2002,
				8000, this.d1);
	}

	@Test
	public void testeCarroVelho() {
		Assert.assertEquals(false, c2.carroVelho());
		Assert.assertEquals(false, c3.carroVelho());
		Assert.assertEquals(true, c1.carroVelho());
	}
	
	@Test
	public void testeFeitoAntes() {
		Assert.assertEquals(false, c2.feitoAntes(2005));
		Assert.assertEquals(true, c2.feitoAntes(2006));
		Assert.assertEquals(false, c2.feitoAntes(2002));
		Assert.assertEquals(true, c2.feitoAntes(2010));
	}

	@Test
	public void testeMaisVelho() {
		Assert.assertEquals(true, c1.maisVelho(c2));
		Assert.assertEquals(false, c2.maisVelho(c1));
		Assert.assertEquals(false, c2.maisVelho(c2));
	}
	
	@Test
	public void testeDonoIgual() {
		Assert.assertEquals(true, d1.igual(d1));
		Assert.assertEquals(true, d1.igual(new Dono("Fulano", 30)));
		Assert.assertEquals(false, d1.igual(c1.dono));
	}
	
	@Test
	public void testeMesmoDono() {
		Assert.assertEquals(true, c1.mesmoDono(c1));
		Assert.assertEquals(true, c2.mesmoDono(c3));
		Assert.assertEquals(true, c3.mesmoDono(c2));
		Assert.assertEquals(false, c1.mesmoDono(c2));
		Assert.assertEquals(false, c2.mesmoDono(c1));
	}
	
	@Test
	public void testeTrocaDono() {
		String modelo = c1.modelo;
		int ano = c1.ano;
		double preco = c1.preco;
		Carro c = c1.trocaDono(c2.dono);
		Assert.assertEquals(true,  c == c1);
		Assert.assertEquals(modelo, c.modelo);
		Assert.assertEquals(ano, c.ano);
		Assert.assertEquals(preco, c.preco);
		Assert.assertEquals(true, c.mesmoDono(c2));
	}
}
