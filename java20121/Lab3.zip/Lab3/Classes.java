import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


interface Expressao {
	double valor();
}

interface Comando {
	void executa();
}

class Num implements Expressao {
	private double val;
	
	public Num(double val) {
		this.val = val;
	}
	
	public double valor() {
		return this.val;
	}
}

class Var implements Expressao {
	private String nome;
	private double val;
	
	public Var(String nome) {
		this.nome = nome;
		this.val = 0;
	}
	
	public double valor() {
		return this.val;
	}
	
	public void setVal(double val) {
		this.val = val;
	}
}

abstract class ExpressaoBinaria implements Expressao {
	protected Expressao esq;
	protected Expressao dir;
	
	public ExpressaoBinaria(Expressao esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	abstract double fazOp(double valEsq, double valDir);
	
	public double valor() {
		return this.fazOp(esq.valor(), dir.valor());
	}
}

class Soma extends ExpressaoBinaria {
	
	public Soma(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	double fazOp(double valEsq, double valDir) {
		return valEsq + valDir;
	}
	
}

class Sub extends ExpressaoBinaria {
	
	public Sub(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	double fazOp(double valEsq, double valDir) {
		return valEsq - valDir;
	}
	
}

class Mul extends ExpressaoBinaria {
	
	public Mul(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	double fazOp(double valEsq, double valDir) {
		return valEsq * valDir;
	}
	
}

class Div extends ExpressaoBinaria {
	
	public Div(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	double fazOp(double valEsq, double valDir) {
		return valEsq / valDir;
	}
	
}

class Igual extends ExpressaoBinaria {
	
	public Igual(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	double fazOp(double valEsq, double valDir) {
		return valEsq == valDir ? 1 : 0;
	}
	
}

class Menor extends ExpressaoBinaria {
	
	public Menor(Expressao esq, Expressao dir) {
		super(esq, dir);
	}

	double fazOp(double valEsq, double valDir) {
		return valEsq < valDir ? 1 : 0;
	}
	
}

class Vazio implements Comando {
	public void executa() { }
}

class Seq implements Comando {
	private Comando cmd1;
	private Comando cmd2;
	
	public Seq(Comando cmd1, Comando cmd2) {
		this.cmd1 = cmd1;
		this.cmd2 = cmd2;
	}
	
	public void executa() {
		cmd1.executa();
		cmd2.executa();
	}
}

class Atrib implements Comando, Expressao {
	private Var esq;
	private Expressao dir;
	
	public Atrib(Var esq, Expressao dir) {
		this.esq = esq;
		this.dir = dir;
	}
	
	public void executa() {
		esq.setVal(dir.valor());
	}
	
	public double valor() {
		double val = dir.valor();
		esq.setVal(val);
		return val;
	}
}

class If implements Comando {
	private Expressao cond;
	private Comando cmdThen;
	private Comando cmdElse;
	
	public If(Expressao cond, Comando cmdThen, Comando cmdElse) {
		this.cond = cond;
		this.cmdThen = cmdThen;
		this.cmdElse = cmdElse;
	}
	
	public void executa() {
		if(cond.valor() != 0) {
			cmdThen.executa();
		} else {
			cmdElse.executa();
		}
	}
}

class Repeat implements Comando {
	private Comando corpo;
	private Expressao cond;
	
	public Repeat(Comando corpo, Expressao cond) {
		this.corpo = corpo;
		this.cond = cond;
	}
	
	public void executa() {
		do {
			corpo.executa();
		} while(cond.valor() == 0);
	}
}

class Write implements Comando {
	private Expressao exp;
	
	public Write(Expressao exp) {
		this.exp = exp;
	}
	
	public void executa() {
		System.out.println(exp.valor());
	}
}

class Read implements Comando {
	private Var var;
	
	static BufferedReader CONSOLE =
			new BufferedReader(new InputStreamReader(System.in));
	
	static double leNumero() {
		try {
			return Double.parseDouble(CONSOLE.readLine());
		} catch(IOException e) {
			throw new RuntimeException("n�o consegui ler do console");
		} catch(NumberFormatException e) {
			throw new RuntimeException("voc� n�o passou um n�mero: " + e.getMessage());
		}
	}
	
	public Read(Var var) {
		this.var = var;
	}
	
	public void executa() {
		var.setVal(Read.leNumero());
	}
}

