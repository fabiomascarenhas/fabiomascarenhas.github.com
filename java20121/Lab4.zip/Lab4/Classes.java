import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Album implements Comparable<Album> {
	private int ano;
	private String artista;
	private String titulo;
	private double preco;
	
	public Album(int ano, String artista, String titulo,
			double preco) {
		this.ano = ano;
		this.artista = artista;
		this.titulo = titulo;
		this.preco = preco;
	}
	
	public int getAno() {
		return this.ano;
	}

	public String getArtista() {
		return this.artista;
	}

	public String getTitulo() {
		return this.titulo;
	}
	
	public double getPreco() {
		return this.preco;
	}

	public int compareTo(Album outro) {
		return this.artista.compareTo(outro.artista);
	}

	public String toString() {
		return this.artista + " - " + this.titulo + " (" +
					this.ano + ")";
	}
}

class Acervo {
	private String dono;
	private List<Album> albuns;
	
	public Acervo(String dono, Album... albuns) {
		this.dono = dono;
		this.albuns = new ArrayList<Album>();
		for(Album album : albuns) {
			this.albuns.add(album);
		}
	}
	
	public String getDono() {
		return this.dono;
	}
	
	public Album getAlbum(String titulo) {
		for(Album album : this.albuns) {
			if(titulo == album.getTitulo())
				return album;
		}
		return null;
	}
	
	public List<Album> getAlbuns(int ano) {
		return this.getAlbuns(new FiltroAno(ano));
	}

	public List<Album> getAlbuns(String artista) {
		return this.getAlbuns(new FiltroArtista(artista));
	}
	
	public List<Album> getAlbuns(FiltroAlbum filtro) {
		List<Album> albuns = new ArrayList<Album>();
		for(Album album : this.albuns) {
			if(filtro.valida(album))
				albuns.add(album);
		}
		return albuns;
	}
	
	public List<String> getArtistas() {
		List<String> artistas = new ArrayList<String>();
		for(Album album : this.albuns) {
			if(!artistas.contains(album.getArtista()))
				artistas.add(album.getArtista());
		}
		Collections.sort(artistas);
		return artistas;
	}
	
	public double valor() {
		double valor = 0.0;
		for(Album album : this.albuns) {
			valor += album.getPreco();
		}
		return valor;
	}
	
	public static void main(String[] args) {
		Album a1 = new Album(2005, "Fulano de Tal",
				"Greatest Hits", 5.25);
		Album a2 = new Album(2007, "Fulano de Tal", 
				"As M�sicas de Fulano", 7.40);
		Album a3 = new Album(2007, "Cicrano", 
				"As M�sicas de Cicrano", 8.40);
		Acervo acervo = new Acervo("Beltrano", a1, a2, a3);
		System.out.println(acervo.valor());
		List<Album> l2007 = acervo.getAlbuns(2007);
		System.out.println("===");
		for(Album album : l2007) {
			System.out.println(album);
		}
		System.out.println("===");
		List<Album> lfulano = acervo.getAlbuns("Fulano de Tal");
		System.out.println("===");
		for(Album album : lfulano) {
			System.out.println(album);
		}
		System.out.println("===");
		List<String> artistas = acervo.getArtistas();
		System.out.println("===");
		for(String artista : artistas) {
			System.out.println(artista);
		}
		System.out.println("===");
	}
}

interface FiltroAlbum {
	boolean valida(Album album);
}

class FiltroAno implements FiltroAlbum {
	private int ano;
	
	public FiltroAno(int ano) {
		this.ano = ano;
	}
	
	public boolean valida(Album album) {
		return album.getAno() == this.ano;
	}
}

class FiltroArtista implements FiltroAlbum {
	private String artista;
	
	public FiltroArtista(String artista) {
		this.artista = artista;
	}
	
	public boolean valida(Album album) {
		return album.getArtista().equals(artista);
	}
}

