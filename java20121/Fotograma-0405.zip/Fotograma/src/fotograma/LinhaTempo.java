package fotograma;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.ListSelectionModel;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

public class LinhaTempo extends JFrame {

	private JPanel contentPane;
	private JList lstLinha;
		
	
	/**
	 * Create the frame.
	 */
	public LinhaTempo(Pessoa pessoa) {
		setSize(new Dimension(320, 480));
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - getHeight()) / 2);
	    setLocation(x, y);

		DefaultListModel model = new DefaultListModel();
		
		for(Foto f : pessoa.getLinhaTempo()) {
			model.addElement(f);
		}

		setResizable(false);
		setTitle("Fotograma");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		lstLinha = new JList();
		lstLinha.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lstLinha.setModel(model);
		lstLinha.setCellRenderer(new ItemLinhaTempo());

		JScrollPane scrollPane = new JScrollPane(lstLinha);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		contentPane.add(scrollPane, BorderLayout.CENTER);
	}
}
