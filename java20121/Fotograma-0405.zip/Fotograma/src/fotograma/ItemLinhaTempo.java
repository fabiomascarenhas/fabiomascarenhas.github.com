package fotograma;

import java.awt.Component;

import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import java.awt.BorderLayout;
import javax.swing.JLabel;

public class ItemLinhaTempo implements ListCellRenderer {
	
	public ItemLinhaTempo() {
	}

	public Component getListCellRendererComponent(JList arg0, Object arg1,
			int arg2, boolean arg3, boolean arg4) {
		JPanel item = new JPanel();
		Foto foto = (Foto)arg1;
		item.setLayout(new BorderLayout(0, 0));
		
		JLabel titulo = new JLabel(foto.getTitulo());
		item.add(titulo, BorderLayout.NORTH);
		
		JLabel autorData = new JLabel(foto.getAutor() +
				" " + foto.getData().toGMTString());
		item.add(autorData, BorderLayout.SOUTH);
		
		JLabel imagem = new JLabel();
		imagem.setIcon(foto.getConteudo());
		item.add(imagem, BorderLayout.CENTER);
		return item;
	}

}
