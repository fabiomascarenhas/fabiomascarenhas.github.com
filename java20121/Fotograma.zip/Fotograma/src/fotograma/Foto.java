package fotograma;

public class Foto {

}
