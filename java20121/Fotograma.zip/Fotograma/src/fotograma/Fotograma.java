package fotograma;

import almonds.Parse;
import almonds.ParseException;

public class Fotograma {
	static String SAL = "7e387tgeiugofkjbakbjg";
	
	public static void main(String[] args) throws ParseException {
		Parse.initialize("WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ", 
				"zZkcMCjg0oybozGZJOdsq0Izik9CnQepGe8Ak4Ss");
		//Pessoa p = new Pessoa(args[0], args[1]);
		Pessoa p = Pessoa.login(args[0], args[1]);
		System.out.println(p);
	}
}
