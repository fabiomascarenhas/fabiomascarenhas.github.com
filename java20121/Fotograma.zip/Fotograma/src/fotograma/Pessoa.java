package fotograma;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;

import almonds.ParseException;
import almonds.ParseObject;
import almonds.ParseQuery;

public class Pessoa {
	// Armazenados no banco de dados
	private String id; // endere�o no banco de dados
	private String nome;
	private int nSeg;
	
	// Calculados
	private List<Foto> linhaTempo;
	private List<String> seguidores;
	
	// Inicializa o objeto com dados do BD
	private void init(String id, String nome,
			int nSeg, List<Foto> linhaTempo,
			List<String> seguidores) {
		this.id = id;
		this.nome = nome;
		this.nSeg = nSeg;
		this.linhaTempo = linhaTempo;
		this.seguidores = seguidores;
	}
	
	private Pessoa(String id, String nome,
			int nSeg, List<Foto> linhaTempo,
			List<String> seguidores) {
		this.init(id, nome, nSeg, linhaTempo, seguidores);
	}
	
	// Nova pessoa no BD
	public Pessoa(String nome, String senha) throws ParseException {
		ParseObject pessoa = new ParseObject("Pessoa");
		pessoa.put("nome", nome);
		pessoa.put("senha", DigestUtils.shaHex(Fotograma.SAL + senha));
		pessoa.put("nseg", 0);
		pessoa.save();
		this.init(pessoa.getObjectId(), nome,
				0, new ArrayList<Foto>(), 
				new ArrayList<String>());
	}
	
	private static List<Foto> linhaTempo(String id) {
		return new ArrayList<Foto>();
	}

	private static List<String> seguidores(String id) {
		return new ArrayList<String>();
	}

	public static Pessoa login(String nome, String senha) throws ParseException {
		ParseQuery busca = new ParseQuery("Pessoa");
		busca.whereEqualTo("nome", nome);
		List<ParseObject> pessoas = busca.find();
		if(pessoas.isEmpty())
			throw new RuntimeException("pessoa n�o existe");
		ParseObject pessoa = pessoas.get(0);
		if(pessoa.getString("senha").equals(
				DigestUtils.shaHex(Fotograma.SAL + senha))) {
			String id = pessoa.getObjectId();
			List<Foto> linhaTempo =
					Pessoa.linhaTempo(id);
			List<String> seguidores =
					Pessoa.seguidores(id);
			return new Pessoa(id, 
					pessoa.getString("nome"), 
					pessoa.getLong("nseg").intValue(),
					linhaTempo, seguidores);
		} else
			throw new RuntimeException("senha errada");
	}
	
	public String toString() {
		return nome + " (" + nSeg + ")";
	}
}
