package fotograma.android;

import java.util.Timer;
import java.util.TimerTask;

import com.parse.Parse;
import com.parse.ParseException;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

class TiqueTimer implements Runnable {

	private Handler handler;
	private Pessoa pessoa;
	
	TiqueTimer(Handler handler, Pessoa pessoa) {
		this.handler = handler;
		this.pessoa = pessoa;
	}
	
	public void run() {
		try {
			pessoa.atualiza();
		} catch(ParseException pe) {
			// espera pr�ximo tique
		}
		long agora = SystemClock.uptimeMillis();
		handler.postAtTime(this, agora + 30000);
	}

}

class ClicaLogin implements OnClickListener {
	FotogramaActivity app;
	
	Dialog login;
	
	ClicaLogin(FotogramaActivity app, Dialog login) {
		this.app = app;
		this.login = login;
	}
	
	@Override
	public void onClick(View v) {
		String nome = ((EditText)login.findViewById(R.id.txtNome)).getText().toString();
	    String senha = ((EditText)login.findViewById(R.id.txtSenha)).getText().toString();
		app.login(nome, senha);
		login.dismiss();
	}
	
}

public class FotogramaActivity extends Activity {
	static String SAL = "7e387tgeiugofkjbakbjg";
	static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	static String API_KEY = "j1NgkHcxTIoSlXmcOyWkp91BySLij3FzLtFWctoP";

	final static int JANELA_LOGIN = 1;
	final static int JANELA_EDITAFOTO = 2;
	final static int JANELA_SEGUIR = 3;

	Pessoa pessoa;
	Handler handler;
	
	protected Dialog onCreateDialog(int id) {
		Dialog janela = null;
		switch(id) {
		case JANELA_LOGIN:
			janela = new Dialog(this);
			janela.requestWindowFeature(Window.FEATURE_NO_TITLE);
			janela.setContentView(R.layout.login);
			Button entrar = (Button)janela.findViewById(R.id.botEntrar);
			entrar.setOnClickListener(new ClicaLogin(this, janela));
			break;
		}
		return janela;
	}
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		Parse.initialize(this, APP_KEY, API_KEY);
		this.showDialog(JANELA_LOGIN);
    }
    
    void login(String nome, String senha) {
		try {
			this.pessoa = Pessoa.login(nome, senha);
			LinhaTempoAdapter lta = new LinhaTempoAdapter(pessoa.getLinhaTempo());
	        ListView lista = (ListView)this.findViewById(R.id.listView1);
	        this.pessoa.observar(lta);
	        lista.setAdapter(lta);
			handler = new Handler();
			handler.postDelayed(new TiqueTimer(handler, pessoa), 30000);
		} catch(ParseException pe) {
			Toast.makeText(this, "Erro de comunica��o: " + pe.getMessage(), Toast.LENGTH_LONG).show();
		}
    }
}