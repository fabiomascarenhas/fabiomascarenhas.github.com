package fotograma;

import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

class EditaOk implements ActionListener {
	EditaFoto ef;
	String autor;
	String caminho;
	
	EditaOk(EditaFoto ef, String autor, String caminho) {
		this.ef = ef;
		this.autor = autor;
		this.caminho = caminho;
	}
	
	public void actionPerformed(ActionEvent ae) {
		if(ef.txtTitulo.getText().isEmpty()) {
			JOptionPane.showMessageDialog(ef, "Preencha o t�tulo!", "Erro", 
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		try {
			ef.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			Foto f = new Foto(autor, ef.txtTitulo.getText(), caminho);
			ef.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		} catch(Exception e) {
			ef.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			JOptionPane.showMessageDialog(ef, "Erro na publica��o.", "Erro", 
					JOptionPane.ERROR_MESSAGE);
		}
		ef.dispose();
	}
}

class EditaCancelar implements ActionListener {
	JDialog ef;
	
	EditaCancelar(JDialog ef) {
		this.ef = ef;
	}
	
	public void actionPerformed(ActionEvent e) {
		this.ef.dispose();
	}
}

public class EditaFoto extends JDialog {

	private final JPanel contentPanel = new JPanel();
	JTextField txtTitulo;

	/**
	 * Create the dialog.
	 */
	public EditaFoto(String dono, String caminho) {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setResizable(false);
		setTitle("Editar Foto");
		setBounds(100, 100, 371, 426);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel labTitulo = new JLabel("Titulo");
			labTitulo.setBounds(18, 6, 61, 16);
			contentPanel.add(labTitulo);
		}
		
		txtTitulo = new JTextField();
		txtTitulo.setBounds(18, 23, 290, 28);
		contentPanel.add(txtTitulo);
		txtTitulo.setColumns(10);
		
		JLabel labFoto = new JLabel("");
		labFoto.setBounds(18, 58, 300, 300);
		labFoto.setIcon(Foto.preview(caminho));
		contentPanel.add(labFoto);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new EditaOk(this, dono, caminho));
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.addActionListener(new EditaCancelar(this));
				buttonPane.add(cancelButton);
			}
		}
	}
}
