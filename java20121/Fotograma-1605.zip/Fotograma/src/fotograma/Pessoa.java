package fotograma;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.apache.commons.codec.digest.DigestUtils;

import almonds.ParseException;
import almonds.ParseObject;
import almonds.ParseQuery;

interface ObservadorPessoa {
	void novaLinhaTempo(List<Foto> linhaTempo);
	void novaFoto(Foto f);
	void novoNSeg(int nseg);
}

class PessoaNaoEncontrada extends RuntimeException {
	public PessoaNaoEncontrada() {
		super("pessoa n�o encontrada!");
	}
}

class SenhaErrada extends RuntimeException {
	public SenhaErrada() {
		super("senha errada!");
	}
}

public class Pessoa {
	// Armazenados no banco de dados
	private String id; // endere�o no banco de dados
	private String nome;
	private int nSeg;
	
	// Calculados
	private List<Foto> linhaTempo;
	private List<String> seguidos;
	
	private Set<ObservadorPessoa> observadores;
	
	// Inicializa o objeto com dados do BD
	private void init(String id, String nome,
			int nSeg, List<Foto> linhaTempo, 
			List<String> seguidos) {
		this.id = id;
		this.nome = nome;
		this.nSeg = nSeg;
		this.linhaTempo = linhaTempo;
		this.seguidos = seguidos;
		this.observadores = new HashSet<ObservadorPessoa>();
	}
	
	public void observar(ObservadorPessoa op) {
		this.observadores.add(op);
	}
	
	public void desobservar(ObservadorPessoa op) {
		this.observadores.remove(op);
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public int getNSeg() {
		return this.nSeg;
	}
	
	private Pessoa(String id, String nome,
			int nSeg, List<Foto> linhaTempo,
			List<String> seguidos) {
		this.init(id, nome, nSeg, linhaTempo, seguidos);
	}
	
	public List<Foto> getLinhaTempo() {
		return this.linhaTempo;
	}
	
	// Nova pessoa no BD
	public Pessoa(String nome, String senha) throws ParseException {
		ParseObject pessoa = new ParseObject("Pessoa");
		pessoa.put("nome", nome);
		pessoa.put("senha", DigestUtils.shaHex(Fotograma.SAL + senha));
		pessoa.put("nseg", 0);
		pessoa.save();
		this.init(pessoa.getObjectId(), nome,
				0, new ArrayList<Foto>(), new ArrayList<String>());
	}
	
	private static List<Foto> linhaTempo(List<String> seguidos) throws ParseException {
		ParseQuery qry = new ParseQuery("Foto");
		qry.whereContainedIn("autor", (List)seguidos);
		qry.addDescendingOrder("createdAt");
		List<ParseObject> fotos = qry.find();
		List<Foto> lt = new ArrayList<Foto>();
		for(ParseObject foto : fotos) {
			lt.add(new Foto(foto));
		}
		return lt;
	}

	private static List<String> seguidos(String nome) throws ParseException {
		ParseQuery qry = new ParseQuery("Seguidor");
		qry.whereEqualTo("seguidor", nome);
		List<ParseObject> poSeguidos = qry.find();
		List<String> seguidos = new ArrayList<String>();
		for(ParseObject po : poSeguidos) {
			seguidos.add(po.getString("seguido"));
		}
		return seguidos;
	}
	
	public static Pessoa login(String nome, String senha) throws ParseException {
		ParseQuery busca = new ParseQuery("Pessoa");
		busca.whereEqualTo("nome", nome);
		List<ParseObject> pessoas = busca.find();
		if(pessoas.isEmpty())
			throw new PessoaNaoEncontrada();
		ParseObject pessoa = pessoas.get(0);
		if(pessoa.getString("senha").equals(
				DigestUtils.shaHex(Fotograma.SAL + senha))) {
			String id = pessoa.getObjectId();
			List<String> seguidos =
					Pessoa.seguidos(nome);
			List<Foto> linhaTempo =
					Pessoa.linhaTempo(seguidos);
			return new Pessoa(id, 
					pessoa.getString("nome"), 
					pessoa.getLong("nseg").intValue(),
					linhaTempo, seguidos);
		} else
			throw new SenhaErrada();
	}
	
	public void seguir(String nome) throws ParseException {
		// Atualiza nseg do seguido
		ParseQuery qrySeguido = new ParseQuery("Pessoa");
		qrySeguido.whereEqualTo("nome", nome);
		List<ParseObject> res = qrySeguido.find();
		if(res.isEmpty()) {
			throw new RuntimeException("Pessoa n�o existe!");
		}
		ParseObject seguido = res.get(0);
		seguido.put("nseg", seguido.getInteger("nseg") + 1);
		seguido.save();
		// Cria nova liga��o com seguidor
		ParseObject rel = new ParseObject("Seguidor");
		rel.put("seguidor", this.nome);
		rel.put("seguido", nome);
		rel.save();
		// Atualiza linha do tempo
		this.seguidos.add(nome);
		this.novaLinhaTempo();
	}
	
	private void novaLinhaTempo() throws ParseException {
		this.linhaTempo = Pessoa.linhaTempo(this.seguidos);
		for(ObservadorPessoa op : this.observadores) {
			op.novaLinhaTempo(this.linhaTempo);
		}
	}
	
	public void atualiza() throws ParseException {
		if(!this.linhaTempo.isEmpty()) {
			Date recente = this.linhaTempo.get(0).getData();
			ParseQuery qry = new ParseQuery("Foto");
			qry.whereContainedIn("autor", (List)seguidos);
			qry.whereGreaterThan("createdAt", recente);
			qry.addAscendingOrder("createdAt");
			List<ParseObject> fotos = qry.find();
			for(ParseObject foto : fotos) {
				Foto f = new Foto(foto.getObjectId());
				this.linhaTempo.add(0, f);
				for(ObservadorPessoa op : this.observadores)
					op.novaFoto(f);
			}
		} else {
			this.novaLinhaTempo();
		}
		// Atualiza n�mero de seguidores
		ParseQuery qry = new ParseQuery("Pessoa");
		ParseObject po = qry.get(this.id);
		if(this.nSeg != po.getInteger("nseg")) {
			this.nSeg = po.getInteger("nseg");
			for(ObservadorPessoa op : this.observadores) {
				op.novoNSeg(this.nSeg);
			}
		}
	}
	
	public String toString() {
		String s = nome + " (" + nSeg + ")";
		for(Foto f : this.linhaTempo) {
			s += "\n" + f;
		}
		return s;
	}
}
