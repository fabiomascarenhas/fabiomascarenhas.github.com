package fotograma;

import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import almonds.ParseException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

class CliqueLogin implements ActionListener {
	Login login;
	JTextField nome;
	JPasswordField senha;
	
	public CliqueLogin(Login login, JTextField nome,
			JPasswordField senha) {
		this.login = login;
		this.nome = nome;
		this.senha = senha;
	}
	
	public void actionPerformed(ActionEvent e) {
		login.setCursor(new Cursor(Cursor.WAIT_CURSOR));
		try {
			Pessoa p = Pessoa.login(nome.getText(), 
					String.copyValueOf(senha.getPassword()));
			LinhaTempo lt = new LinhaTempo(p);
			login.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			login.setVisible(false);		
			lt.setVisible(true);
			lt.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		} catch(ParseException pe) {
			login.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			login.labErro.setVisible(true);
		}
	}
}

public class Login extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6755037719310614123L;
	private JPanel contentPane;
	private JTextField txtNome;
	private JPasswordField txtSenha;
	
	JLabel labErro;

	/**
	 * Create the frame.
	 */
	public Login() {
		setResizable(false);
		setTitle("Login no Fotograma");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(308, 185);
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - getHeight()) / 2);
	    setLocation(x, y);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel labNome = new JLabel("Nome");
		labNome.setBounds(35, 28, 61, 16);
		contentPane.add(labNome);
		
		JLabel labSenha = new JLabel("Senha");
		labSenha.setBounds(35, 76, 61, 16);
		contentPane.add(labSenha);
		
		txtNome = new JTextField();
		txtNome.setBounds(127, 22, 134, 28);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtSenha = new JPasswordField();
		txtSenha.setBounds(127, 70, 134, 28);
		contentPane.add(txtSenha);
		
		JButton btLogin = new JButton("Entrar");
		btLogin.addActionListener(new CliqueLogin(this, txtNome, txtSenha));
		btLogin.setBounds(84, 120, 117, 29);
		contentPane.add(btLogin);
		
		labErro = new JLabel("Erro de Comunica\u00E7\u00E3o");
		labErro.setVisible(false);
		labErro.setForeground(Color.RED);
		labErro.setBounds(84, 6, 134, 16);
		contentPane.add(labErro);
	}
}
