package fotograma;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ListModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.ListSelectionModel;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;

import almonds.ParseException;
import javax.swing.JLabel;

class CliquePublicar implements ActionListener {

	Pessoa dono;
	JFrame lt;
	
	CliquePublicar(Pessoa dono, JFrame lt) {
		this.dono = dono;
		this.lt = lt;
	}
	
	public void actionPerformed(ActionEvent e) {
		// mostrar caixa de sele��o de arquivos
		// mostrar janela para editar t�tulo
		JFileChooser abreArq = new JFileChooser();
		int resposta = abreArq.showOpenDialog(this.lt);
		if(resposta == JFileChooser.APPROVE_OPTION) {
			EditaFoto ef = new EditaFoto(
					dono.getNome(),
					abreArq.getSelectedFile().getAbsolutePath()
			);
			ef.setVisible(true);
		}
	}
	
}

class CliqueSeguir implements ActionListener {
	Pessoa pessoa;
	JFrame lt;
	
	CliqueSeguir(Pessoa pessoa, JFrame lt) {
		this.pessoa = pessoa;
		this.lt = lt;
	}
	
	public void actionPerformed(ActionEvent ae) {
		String nome = JOptionPane.showInputDialog(lt,
				"Entre o nome:", "Seguir", JOptionPane.QUESTION_MESSAGE);
		if(nome != null) {
			lt.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			try {
				pessoa.seguir(nome);
			} catch(ParseException e) {
				JOptionPane.showMessageDialog(lt, "Erro de comunica��o: " + e.getMessage(), "Erro", 
						JOptionPane.ERROR_MESSAGE);
			}
			lt.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
}

class AtualizaLinhaTempo implements ObservadorPessoa {
	private LinhaTempo lt;
	
	AtualizaLinhaTempo(LinhaTempo lt) {
		this.lt = lt;
	}
	
	public void novaLinhaTempo(Pessoa p) {
		lt.novaLista(p.getLinhaTempo());
	}
	
	public void novaFoto(Foto f) {
		lt.novaFoto(f);
	}
}

class TiqueTimer extends TimerTask {

	private Pessoa p;
	
	TiqueTimer(Pessoa p) {
		this.p = p;
	}
	
	public void run() {
		try {
			p.atualiza();
		} catch(ParseException e) {
			// espera pr�ximo tique
		}
	}

}

public class LinhaTempo extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2852630103362132796L;
	private JPanel contentPane;
	private JList lstLinha;
	private JPanel painel;
	private JButton botSeguir;
	private JButton botPublicar;
	private JLabel labSeguidores;
	private Timer timer;
	private JButton btnNewButton;
		
	
	/**
	 * Create the frame.
	 */
	public LinhaTempo(Pessoa pessoa) {
		setSize(new Dimension(320, 480));
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - getHeight()) / 2);
	    setLocation(x, y);

	    pessoa.observar(new AtualizaLinhaTempo(this));
	    
		DefaultListModel model = new DefaultListModel();
		
		for(Foto f : pessoa.getLinhaTempo()) {
			model.addElement(f);
		}
		setTitle("Fotograma - " + pessoa.getNome());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		lstLinha = new JList();
		lstLinha.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lstLinha.setModel(model);
		lstLinha.setCellRenderer(new ItemLinhaTempo());

		JScrollPane scrollPane = new JScrollPane(lstLinha);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		painel = new JPanel();
		contentPane.add(painel, BorderLayout.SOUTH);
		painel.setLayout(new GridLayout(1, 0, 0, 0));
		
		botSeguir = new JButton("Seguir...");
		botSeguir.addActionListener(new CliqueSeguir(pessoa, this));
		painel.add(botSeguir);
		
		botPublicar = new JButton("Publicar...");
		botPublicar.addActionListener(new CliquePublicar(pessoa, this));
		painel.add(botPublicar);
		
		labSeguidores = new JLabel("Voc\u00EA tem X seguidores!");
		int nseg = pessoa.getNSeg();
		if(nseg == 0)
			labSeguidores.setText("Voc� n�o tem nenhum seguidor!");
		else if(nseg == 1)
			labSeguidores.setText("Voc� tem 1 seguidor!");
		else
			labSeguidores.setText("Voc� tem " + nseg + " seguidores!");
		contentPane.add(labSeguidores, BorderLayout.NORTH);
				
		timer = new Timer();
		timer.schedule(new TiqueTimer(pessoa), 30000, 30000);
	}


	public void novaFoto(Foto f) {
		DefaultListModel model = (DefaultListModel)lstLinha.getModel();
		model.add(0, f);
	}


	public void novaLista(List<Foto> linhaTempo) {
		DefaultListModel model = (DefaultListModel)lstLinha.getModel();
		model.clear();
		for(Foto f : linhaTempo)
			model.addElement(f);
	}
}
