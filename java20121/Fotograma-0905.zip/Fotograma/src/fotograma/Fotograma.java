package fotograma;

import almonds.Parse;

public class Fotograma {
	static String SAL = "7e387tgeiugofkjbakbjg";
	static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	static String API_KEY = "zZkcMCjg0oybozGZJOdsq0Izik9CnQepGe8Ak4Ss";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Parse.initialize(APP_KEY, API_KEY);
		Login frame = new Login();
		frame.setVisible(true);
	}

}
