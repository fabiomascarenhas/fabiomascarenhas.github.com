package fotograma;

import imageUtil.Image;
import imageUtil.ImageLoader;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import org.apache.commons.codec.binary.Base64;

import almonds.ParseException;
import almonds.ParseObject;
import almonds.ParseQuery;

public class Foto {
	private String id;
	private String autor;
	private String titulo;
	private Date data;
	
	private ImageIcon conteudo;
	
	private Foto(String id, String autor,
			String titulo, Date data) {
		this.init(id, autor, titulo, data);
	}
	
	private void init(String id, String autor,
			String titulo, Date data) {
		this.id = id;
		this.autor = autor;
		this.data = data;
		this.titulo = titulo;
	}
	
	public String getTitulo() {
		return this.titulo;
	}

	public String getAutor() {
		return this.autor;
	}
	
	public Date getData() {
		return this.data;
	}
	
	public ImageIcon getConteudo() {
		return this.conteudo;
	}

	private static String codifica(String caminho) throws IOException {
		Image conteudo = ImageLoader.fromFile(caminho);
		conteudo = conteudo.getResizedToSquare(300, 0);
		File tmp = File.createTempFile("fotograma", ".jpg");
		conteudo.writeToJPG(tmp, 0.5f);
		FileInputStream arq = new FileInputStream(tmp);
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		try {
			int i = arq.read();
			while(i != -1) {
				bytes.write(i);
				i = arq.read();
			}
			bytes.close();
			String img = Base64.encodeBase64String(bytes.toByteArray());
			return img;
		} finally {
			arq.close();
		}
	}
	
	
	// Publicar foto nova
	public Foto(String autor, String titulo, String caminho) throws IOException, ParseException {
		ParseObject foto = new ParseObject("Foto");
		foto.put("autor", autor);
		foto.put("titulo", titulo);
		foto.put("conteudo", Foto.codifica(caminho));
		foto.save();
		this.init(foto.getObjectId(), autor, titulo,
				foto.getCreatedAt());
		this.conteudo = Foto.decodifica(foto.getString("conteudo"));
	}
		
	private static ImageIcon decodifica(String cont) {
		byte[] bytes = Base64.decodeBase64(cont);
		try {
			ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
			BufferedImage bi = ImageIO.read(bis);
			return new ImageIcon(bi);
		} catch(IOException e) {
			return null;
		}
	}
	
	// Buscar uma foto existente
	public Foto(String id) throws ParseException {
		ParseQuery qry = new ParseQuery("Foto");
		ParseObject foto = qry.get(id);
		this.conteudo = Foto.decodifica(foto.getString("conteudo"));
		this.init(foto.getObjectId(), foto.getString("autor"),
				foto.getString("titulo"), foto.getCreatedAt());
	}
	
	public Foto(ParseObject foto) {
		this.conteudo = Foto.decodifica(foto.getString("conteudo"));
		this.init(foto.getObjectId(), foto.getString("autor"),
				foto.getString("titulo"), foto.getCreatedAt());
	}
	
	public static ImageIcon preview(String caminho) {
		try {
			return Foto.decodifica(Foto.codifica(caminho));
		} catch(IOException e) {
			return null;
		}
	}
	
	public String toString() {
		return this.titulo + " " + this.conteudo.toString();
	}
}
