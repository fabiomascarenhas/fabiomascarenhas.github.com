package fotograma;

import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.ListSelectionModel;
import java.awt.BorderLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import almonds.ParseException;

class CliquePublicar implements ActionListener {

	Pessoa dono;
	JFrame lt;
	
	CliquePublicar(Pessoa dono, JFrame lt) {
		this.dono = dono;
		this.lt = lt;
	}
	
	public void actionPerformed(ActionEvent e) {
		// mostrar caixa de sele��o de arquivos
		// mostrar janela para editar t�tulo
		JFileChooser abreArq = new JFileChooser();
		int resposta = abreArq.showOpenDialog(this.lt);
		if(resposta == JFileChooser.APPROVE_OPTION) {
			EditaFoto ef = new EditaFoto(
					dono.getNome(),
					abreArq.getSelectedFile().getAbsolutePath()
			);
			ef.setVisible(true);
		}
	}
	
}

class CliqueSeguir implements ActionListener {
	Pessoa pessoa;
	JFrame lt;
	
	CliqueSeguir(Pessoa pessoa, JFrame lt) {
		this.pessoa = pessoa;
		this.lt = lt;
	}
	
	public void actionPerformed(ActionEvent ae) {
		String nome = JOptionPane.showInputDialog(lt,
				"Entre o nome:", "Seguir", JOptionPane.QUESTION_MESSAGE);
		if(nome != null) {
			lt.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			try {
				pessoa.seguir(nome);
			} catch(ParseException e) {
				JOptionPane.showMessageDialog(lt, "Erro de comunica��o: " + e.getMessage(), "Erro", 
						JOptionPane.ERROR_MESSAGE);
			}
			lt.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		}
	}
}

public class LinhaTempo extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2852630103362132796L;
	private JPanel contentPane;
	private JList lstLinha;
	private JPanel panel;
	private JButton botSeguir;
	private JButton botPublicar;
		
	
	/**
	 * Create the frame.
	 */
	public LinhaTempo(Pessoa pessoa) {
		setSize(new Dimension(320, 480));
	    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
	    int x = (int) ((dimension.getWidth() - getWidth()) / 2);
	    int y = (int) ((dimension.getHeight() - getHeight()) / 2);
	    setLocation(x, y);

		DefaultListModel model = new DefaultListModel();
		
		for(Foto f : pessoa.getLinhaTempo()) {
			model.addElement(f);
		}
		setTitle("Fotograma");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contentPane = new JPanel();
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		lstLinha = new JList();
		lstLinha.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lstLinha.setModel(model);
		lstLinha.setCellRenderer(new ItemLinhaTempo());

		JScrollPane scrollPane = new JScrollPane(lstLinha);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		botSeguir = new JButton("Seguir...");
		botSeguir.addActionListener(new CliqueSeguir(pessoa, this));
		panel.add(botSeguir);
		
		botPublicar = new JButton("Publicar...");
		botPublicar.addActionListener(new CliquePublicar(pessoa, this));
		panel.add(botPublicar);
	}
}
