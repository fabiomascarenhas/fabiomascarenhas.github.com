
// Coord s�o objetos imut�veis
class Coord {
	int x;
	int y;
	
	static Coord ORIGEM = new Coord(0, 0);
	
	Coord(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	double distanciaOrig() {
		return this.distancia(ORIGEM);
	}
	
	boolean igual(Coord c) {
		return c.x == this.x &&
				c.y == this.y;
	}
	
	double distancia(Coord c) {
		int x = this.x - c.x;
		int y = this.y - c.y;
		return Math.sqrt(x*x + y*y);
	}
	
	boolean noQuadrado(Coord cse, int lado) {
		int x = this.x - cse.x;
		int y = this.y - cse.y;
		return x >= 0 && x <= lado && y >= 0 && y <= lado;
	}
	
	Coord traslado(int dx, int dy) {
		return new Coord(this.x + dx, this.y + dy);
	}
}

class Caixa {
	Coord cse;
	Coord cid;
	
	Caixa(Coord cse, Coord cid) {
		this.cse = cse;
		this.cid = cid;
	}
	
	boolean igual(Caixa outro) {
		return this.cse.igual(outro.cse) &&
				this.cid.igual(outro.cid);
	}
}	

/*
 struct Forma {
    int tipo;  // 0 = quadrado, 1 = circulo, 2 = ponto, 3 = composicao
	union {
		struct {
		  struct Coord centro;
		  int raio;
		} c;
		struct {
		  struct Coord cse;
		  int lado;
		} q;
		struct {
		  struct Coord local;
		} p;
		struct {
		  struct Forma* f1;
		  struct Forma* f2;
		} cp;
	} f;
 }
 */

interface Forma {
	double area();
	double distanciaOrig();
	boolean contem(Coord c);
	Caixa caixa();
}

class Quadrado implements Forma {
	Coord cse;
	int lado;
	
	Quadrado(Coord cse, int lado) {
		this.cse = cse;
		this.lado = lado;
	}
	
	public double area() {
		return this.lado * this.lado;
	}
	
	public double distanciaOrig() {
		return this.cse.distanciaOrig();
	}
	
	public boolean contem(Coord c) {
		return c.noQuadrado(this.cse, this.lado);
	}
	
	public Caixa caixa() {
		return new Caixa(this.cse, 
				this.cse.traslado(this.lado, this.lado));
	}
}

class Circulo implements Forma {
	Coord centro;
	int raio;
	
	Circulo(Coord centro, int raio) {
		this.centro = centro;
		this.raio = raio;
	}
	
	public double area() {
		return this.raio * this.raio * Math.PI;
	}
	
	public double distanciaOrig() {
		return this.centro.distanciaOrig() - this.raio;
	}
	
	public boolean contem(Coord c) {
		return c.distancia(this.centro) <= this.raio;
	}
	
	public Caixa caixa() {
		return new Caixa(
				this.centro.traslado(-this.raio, -this.raio),
				this.centro.traslado(this.raio, this.raio)
			 );
	}
}

class Composicao implements Forma {
	Forma f1;
	Forma f2;
	
	Composicao(Forma f1, Forma f2) {
		this.f1 = f1;
		this.f2 = f2;
	}
	
	// interse��o tem area == 0!!!
	public double area() {
		return this.f1.area() + 
				this.f2.area();
	}
	
	public double distanciaOrig() {
		return Math.min(this.f1.distanciaOrig(),
					this.f2.distanciaOrig());
	}
	
	public boolean contem(Coord c) {
		return this.f1.contem(c) ||
				this.f2.contem(c);
	}
	
	public Caixa caixa() {
		Caixa c1 = this.f1.caixa();
		Caixa c2 = this.f2.caixa();
		return new Caixa(
				new Coord(Math.min(c1.cse.x, c2.cse.x),
						Math.min(c1.cse.y, c2.cse.y)),
				new Coord(Math.max(c1.cid.x, c2.cid.x),
						Math.max(c1.cid.y,c2.cid.y)));
	}
}


class Ponto implements Forma {
	Coord local;
	
	Ponto(Coord local) {
		this.local = local;
	}
	
	public double area() {
		return 0;
	}
	
	public double distanciaOrig() {
		return this.local.distanciaOrig();
	}
	
	public boolean contem(Coord c) {
		// c � igual a local?
		return c.igual(this.local);
	}
	
	public Caixa caixa() {
		return new Caixa(this.local, this.local);
	}
}
