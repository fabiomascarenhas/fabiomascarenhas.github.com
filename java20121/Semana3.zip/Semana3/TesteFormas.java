import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;


public class TesteFormas {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testeArea() {
		Forma q = new Quadrado(new Coord(10,15), 5);
		Assert.assertEquals(25.0, q.area());
		q = new Circulo(new Coord(10,10), 5);
		Assert.assertEquals(25.0 * Math.PI, q.area());
		q = new Ponto(new Coord(10, 10));
		Assert.assertEquals(0.0, q.area());
		q = new Composicao(new Quadrado(new Coord(10,15), 5),
				new Circulo(new Coord(30,30), 5));
		Assert.assertEquals(25.0 * Math.PI + 25.0, q.area());		
		Forma f = new Composicao(q,
				new Quadrado(new Coord(50,50), 3));
		Assert.assertEquals(25.0 * Math.PI + 25.0 + 9.0, f.area());		
		
	}

	@Test
	public void testeDistanciaOrig() {
		Forma q = new Quadrado(new Coord(3,4), 5);
		Assert.assertEquals(5.0, q.distanciaOrig());
		q = new Circulo(new Coord(6,8), 3);
		Assert.assertEquals(7.0, q.distanciaOrig());
		q = new Ponto(new Coord(6, 8));
		Assert.assertEquals(10.0, q.distanciaOrig());
		q = new Composicao(new Quadrado(new Coord(3,4), 5),
				new Circulo(new Coord(6,8), 5));
		Assert.assertEquals(5.0, q.distanciaOrig());		
		Forma f = new Composicao(q,
				new Quadrado(new Coord(0,0), 2));
		Assert.assertEquals(0.0, f.distanciaOrig());		
	}

	@Test
	public void testeContemQuadrado() {
		Forma q = new Quadrado(new Coord(3,4), 5);
		Assert.assertEquals(true, q.contem(new Coord(4,6)));
		Assert.assertEquals(true, q.contem(new Coord(8,9)));
		Assert.assertEquals(true, q.contem(new Coord(8,7)));
		Assert.assertEquals(true, q.contem(new Coord(5,9)));
		Assert.assertEquals(true, q.contem(new Coord(3,4)));
		Assert.assertEquals(false, q.contem(new Coord(1,2)));
		Assert.assertEquals(false, q.contem(new Coord(4,10)));
		Assert.assertEquals(false, q.contem(new Coord(9,6)));
	}

	@Test
	public void testeContemCirculo() {
		Forma q = new Circulo(new Coord(6,8), 3);
		Assert.assertEquals(true, q.contem(new Coord(6,8)));
		Assert.assertEquals(true, q.contem(new Coord(9,8)));
		Assert.assertEquals(true, q.contem(new Coord(7,8)));
		Assert.assertEquals(true, q.contem(new Coord(6,6)));
		Assert.assertEquals(false, q.contem(new Coord(10,8)));
		Assert.assertEquals(false, q.contem(new Coord(6,4)));
	}
	
	@Test
	public void testeContemPonto() {
		Forma q = new Ponto(new Coord(6, 8));
		Assert.assertEquals(true, q.contem(new Coord(6,8)));
		Assert.assertEquals(false, q.contem(new Coord(5,8)));
		Assert.assertEquals(false, q.contem(new Coord(3,4)));
	}
	
	@Test
	public void testeContemComposicao() {
		Forma q = new Composicao(new Quadrado(new Coord(3,4), 5),
				new Circulo(new Coord(6,8), 5));
		Assert.assertEquals(true, q.contem(new Coord(4,6)));
		Assert.assertEquals(true, q.contem(new Coord(8,9)));
		Assert.assertEquals(true, q.contem(new Coord(8,7)));
		Assert.assertEquals(true, q.contem(new Coord(5,9)));
		Assert.assertEquals(true, q.contem(new Coord(3,4)));
		Assert.assertEquals(true, q.contem(new Coord(6,8)));
		Assert.assertEquals(true, q.contem(new Coord(9,8)));
		Assert.assertEquals(true, q.contem(new Coord(7,8)));
		Assert.assertEquals(true, q.contem(new Coord(6,6)));
		Assert.assertEquals(false, q.contem(new Coord(1,2)));
		Assert.assertEquals(true, q.contem(new Coord(4,10)));
		Assert.assertEquals(true, q.contem(new Coord(9,6)));
		Assert.assertEquals(false, q.contem(new Coord(15,8)));
		Assert.assertEquals(false, q.contem(new Coord(1,4)));
		Forma f = new Composicao(q,
				new Quadrado(new Coord(0,0), 2));
		Assert.assertEquals(true, f.contem(new Coord(4,6)));
		Assert.assertEquals(true, f.contem(new Coord(8,9)));
		Assert.assertEquals(true, f.contem(new Coord(8,7)));
		Assert.assertEquals(true, f.contem(new Coord(5,9)));
		Assert.assertEquals(true, f.contem(new Coord(3,4)));
		Assert.assertEquals(true, f.contem(new Coord(6,8)));
		Assert.assertEquals(true, f.contem(new Coord(9,8)));
		Assert.assertEquals(true, f.contem(new Coord(7,8)));
		Assert.assertEquals(true, f.contem(new Coord(6,6)));
		Assert.assertEquals(true, f.contem(new Coord(1,2)));
		Assert.assertEquals(true, f.contem(new Coord(4,10)));
		Assert.assertEquals(true, f.contem(new Coord(9,6)));
		Assert.assertEquals(false, f.contem(new Coord(15,8)));
		Assert.assertEquals(false, f.contem(new Coord(1,4)));
	}

	@Test
	public void testeCaixa() {
		Forma q = new Quadrado(new Coord(3,4), 5);
		Assert.assertEquals(true, 
				q.caixa().igual(new Caixa(new Coord(3,4),
						new Coord(8,9))));
		Assert.assertEquals(false, 
				q.caixa().igual(new Caixa(new Coord(2,4),
						new Coord(8,9))));
		q = new Circulo(new Coord(6,8), 3);
		Assert.assertEquals(true, 
				q.caixa().igual(new Caixa(new Coord(3,5),
						new Coord(9,11))));
		Assert.assertEquals(false, 
				q.caixa().igual(new Caixa(new Coord(2,4),
						new Coord(8,9))));
		q = new Ponto(new Coord(6, 8));
		Assert.assertEquals(true, 
				q.caixa().igual(new Caixa(new Coord(6,8),
						new Coord(6,8))));
		Assert.assertEquals(false, 
				q.caixa().igual(new Caixa(new Coord(2,4),
						new Coord(8,9))));
		q = new Composicao(new Quadrado(new Coord(3,4), 5),
				new Circulo(new Coord(6,8), 5));
		Assert.assertEquals(true, 
				q.caixa().igual(new Caixa(new Coord(1,3),
						new Coord(11,13))));
		Assert.assertEquals(false, 
				q.caixa().igual(new Caixa(new Coord(2,4),
						new Coord(8,9))));
		Forma f = new Composicao(q,
				new Quadrado(new Coord(0,0), 2));
		Assert.assertEquals(true, 
				f.caixa().igual(new Caixa(new Coord(0,0),
						new Coord(11,13))));
		Assert.assertEquals(false, 
				f.caixa().igual(new Caixa(new Coord(2,4),
						new Coord(8,9))));
	}
}
