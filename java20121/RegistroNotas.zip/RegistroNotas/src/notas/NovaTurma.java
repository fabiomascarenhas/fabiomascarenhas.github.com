package notas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class NovaTurma extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2444021654444151786L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtNome;

	/**
	 * Create the dialog.
	 */
	public NovaTurma() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		setResizable(false);
		setTitle("Nova Turma");
		setBounds(100, 100, 210, 143);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel labNome = new JLabel("Nome");
		labNome.setBounds(16, 16, 61, 16);
		contentPanel.add(labNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(16, 34, 175, 28);
		contentPanel.add(txtNome);
		txtNome.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
