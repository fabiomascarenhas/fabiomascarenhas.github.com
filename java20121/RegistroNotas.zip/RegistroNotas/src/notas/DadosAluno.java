package notas;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class DadosAluno extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -484237966008668195L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtDRE;
	private JTextField txtNome;
	private JTextField txtP1;
	private JTextField txtP2;
	private JTextField txtP3;

	/**
	 * Create the dialog.
	 */
	public DadosAluno() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		setResizable(false);
		setTitle("Dados do Aluno");
		setBounds(100, 100, 329, 258);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblDre = new JLabel("DRE");
		lblDre.setBounds(16, 16, 61, 16);
		contentPanel.add(lblDre);
		
		txtDRE = new JTextField();
		txtDRE.setBounds(16, 33, 134, 28);
		contentPanel.add(txtDRE);
		txtDRE.setColumns(10);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(16, 70, 61, 16);
		contentPanel.add(lblNome);
		
		txtNome = new JTextField();
		txtNome.setBounds(16, 88, 294, 28);
		contentPanel.add(txtNome);
		txtNome.setColumns(10);
		
		JLabel lblP1 = new JLabel("P1");
		lblP1.setBounds(16, 128, 61, 16);
		contentPanel.add(lblP1);
		
		txtP1 = new JTextField();
		txtP1.setBounds(16, 145, 80, 28);
		contentPanel.add(txtP1);
		txtP1.setColumns(10);
		
		JLabel lblP2 = new JLabel("P2");
		lblP2.setBounds(120, 128, 61, 16);
		contentPanel.add(lblP2);
		
		txtP2 = new JTextField();
		txtP2.setColumns(10);
		txtP2.setBounds(120, 145, 80, 28);
		contentPanel.add(txtP2);
		
		JLabel lblP3 = new JLabel("P3");
		lblP3.setBounds(230, 128, 61, 16);
		contentPanel.add(lblP3);
		
		txtP3 = new JTextField();
		txtP3.setColumns(10);
		txtP3.setBounds(230, 145, 80, 28);
		contentPanel.add(txtP3);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
