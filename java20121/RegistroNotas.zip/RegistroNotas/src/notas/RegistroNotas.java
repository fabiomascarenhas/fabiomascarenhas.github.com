package notas;

import almonds.Parse;

public class RegistroNotas {

	public static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	public static String API_KEY = "zZkcMCjg0oybozGZJOdsq0Izik9CnQepGe8Ak4Ss";

	static String ALUNOS = "G_99_99_Alunos";
	static String TURMAS = "G_99_99_Turmas";
	static String NOTAS = "G_99_99_Notas";
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		Parse.initialize(APP_KEY, API_KEY);
		JanelaTurmas frame = new JanelaTurmas();
		frame.setVisible(true);
	}

}
