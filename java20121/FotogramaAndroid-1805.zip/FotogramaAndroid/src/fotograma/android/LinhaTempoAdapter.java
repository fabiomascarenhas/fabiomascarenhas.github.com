package fotograma.android;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class LinhaTempoAdapter extends BaseAdapter implements ObservadorPessoa {
	List<Foto> linhaTempo;
	
	public LinhaTempoAdapter(List<Foto> linhaTempo) {
		this.linhaTempo = linhaTempo;
	}
	
	@Override
	public int getCount() {
		return linhaTempo.size();
	}

	@Override
	public Object getItem(int pos) {
		return linhaTempo.get(pos);
	}

	@Override
	public long getItemId(int pos) {
		return -1;
	}

	@Override
	public View getView(int pos, View view, ViewGroup pai) {
		if(view == null) {
			LayoutInflater inf = 
					(LayoutInflater)pai.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = inf.inflate(R.layout.item_lt, null);
		}
		Foto f = linhaTempo.get(pos);
		TextView labTitulo = (TextView)view.findViewById(R.id.labTitutlo);
		labTitulo.setText(f.getTitulo());
		TextView labAutorData = (TextView)view.findViewById(R.id.labAutorData);
		labAutorData.setText(f.getAutor() + " �s " + 
				f.getData().toString());
		ImageView labImagem = (ImageView)view.findViewById(R.id.labImagem);
		labImagem.setImageBitmap(f.getConteudo());
		return view;
	}

	@Override
	public void novaLinhaTempo(List<Foto> linhaTempo) {
		this.notifyDataSetChanged();
	}

	@Override
	public void novaFoto(Foto f) {
		this.notifyDataSetChanged();
	}

	@Override
	public void novoNSeg(int nseg) {
	}

}
