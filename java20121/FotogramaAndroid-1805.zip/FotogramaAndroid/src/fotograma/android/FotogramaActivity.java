package fotograma.android;

import com.parse.Parse;
import com.parse.ParseException;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class FotogramaActivity extends Activity {
	static String SAL = "7e387tgeiugofkjbakbjg";
	static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	static String API_KEY = "j1NgkHcxTIoSlXmcOyWkp91BySLij3FzLtFWctoP";

	private Pessoa pessoa;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		Parse.initialize(this, APP_KEY, API_KEY);
		try {
			this.pessoa = Pessoa.login("fabio", "minhasenha");
		} catch(ParseException pe) {
		}
		setContentView(R.layout.main);
		LinhaTempoAdapter lta = new LinhaTempoAdapter(pessoa.getLinhaTempo());
        ListView lista = (ListView)this.findViewById(R.id.listView1);
        lista.setAdapter(lta);
    }
}