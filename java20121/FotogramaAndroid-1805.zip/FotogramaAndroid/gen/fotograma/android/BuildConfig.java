/** Automatically generated file. DO NOT MODIFY */
package fotograma.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}