
abstract class Registro {
	protected int maxima;
	protected int minima;
	protected int hoje;

	public Registro(int maxima, int minima, int hoje) {
		this.maxima = maxima;
		this.minima = minima;
		this.hoje = hoje;
	}
	
	public int dMaxima() {
		return this.maxima - this.hoje;
	}
	
	public int dMinima() {
		return this.hoje - this.minima;
	}
	
	protected abstract String unidade();

	public String toString() {
		return "" + this.hoje + " " + 
				this.unidade() + " (" +
				"maxima de " + this.maxima +
				" " + this.unidade() + 
				", minima de " + this.minima + 
				" " + this.unidade() + ")";
	}
	
	public boolean equals(Object outro) {
		if(outro instanceof Registro) {
			Registro outra = (Registro)outro;
			return this.unidade() == outra.unidade() &&
					this.maxima == outra.maxima &&
					this.minima == outra.minima &&
					this.hoje == outra.hoje;
		} else {
			return false;
		}
	}

}

class Pressao extends Registro {
	
	public Pressao(int maxima, int minima, int hoje) {
		super(maxima, minima, hoje);
	}
	
	protected String unidade() {
		return "hPa";
	}
	
}

abstract class Temperatura extends Registro {
	
	public Temperatura(int maxima, int minima, int hoje) {
		super(maxima, minima, hoje);
	}

	protected abstract String letraUnidade();

	protected abstract int paraKelvin(int val);
	
	protected String unidade() {
		return "graus " + this.letraUnidade();
	}

	public boolean equals(Object outro) {
		if(outro instanceof Temperatura) {
			Temperatura outra = (Temperatura)outro;
			return this.paraKelvin(this.maxima) == 
					outra.paraKelvin(outra.maxima) &&
					this.paraKelvin(this.minima) == 
					outra.paraKelvin(outra.minima) &&
					this.paraKelvin(this.hoje) == 
					outra.paraKelvin(outra.hoje);
		} else {
			return false;
		}
	}

}

class TemperaturaCelsius extends Temperatura {

	public TemperaturaCelsius(int maxima, int minima, int hoje) {
		super(maxima, minima, hoje);
	}
	
	protected int paraKelvin(int val) {
		return val + 273;
	}

	protected String letraUnidade() {
		return "C";
	}
}

class TemperaturaFahrenheit extends Temperatura {

	public TemperaturaFahrenheit(int maxima, int minima, int hoje) {
		super(maxima, minima, hoje);
	}

	protected int paraKelvin(int val) {
		return 5*(val-32)/9 + 273;
	}

	protected String letraUnidade() {
		return "F";
	}
}