import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Before;
import org.junit.Test;


public class Testes {
	Cafe minas;
	Cafe francisco;
	Cafe pilao;

	Rota r1, r2;
	Horario h1, h2, h3, h4;
	Onibus o1, o2, o3, o4;
	
	@Before
	public void init() {
		this.minas = new Cafe("Especial Sul de Minas",
				1300, 25.00);
		this.francisco = new Cafe(
				"Robusto do S�o Francisco",
				5258,
				10.00);
		this.pilao = new Cafe("Caf� Pil�o", 34500, 4.50);

		this.r1 = new Rota("Rio de Janeiro",
				"Petr�polis");
		this.r2 = new Rota("Petr�polis",
				"Rio de Janeiro");
		this.h1 = new Horario(17,30);
		this.h2 = new Horario(18,45);
		this.h3 = new Horario(7,0);
		this.h4 = new Horario(7,50);
		this.o1 = new Onibus(this.r1, this.h1, this.h2, false);
		this.o2 = new Onibus(this.r2, this.h3, this.h4, true);
		this.o3 = new Onibus(new Rota("Niter�i", "Cabo Frio"),
				new Horario(8,30), new Horario(11,30), false);
		this.o4 = new Onibus(null, new Horario(20,15),
				new Horario(5,30), false);
}
	
	@Test
	public void testeCafePrecoVendido() {
		Assert.assertEquals(32.5, this.minas.precoVendido());
		Assert.assertEquals(52.58, this.francisco.precoVendido());
		Assert.assertEquals(131.9625, this.pilao.precoVendido());
	}

	@Test
	public void testeDesconto() {
		Assert.assertEquals(0.0, this.minas.desconto());
		Assert.assertEquals(0.0, this.francisco.desconto());
		Assert.assertEquals(15.0, this.pilao.desconto());
	}
	
	@Test
	public void testeEmMinutos() {
		Assert.assertEquals(1050, this.h1.emMinutos());
		Assert.assertEquals(1125, this.h2.emMinutos());
		Assert.assertEquals(420, this.h3.emMinutos());
		Assert.assertEquals(470, this.h4.emMinutos());
	}
	
	@Test 
	public void testeTempoViagem() {
		Assert.assertEquals(75, this.o1.tempoViagem());
		Assert.assertEquals(50, this.o2.tempoViagem());
		Assert.assertEquals(180, this.o3.tempoViagem());
		Assert.assertEquals(555, this.o4.tempoViagem());
	}
	
	@Test
	public void testeJaSaiu() {
		Assert.assertEquals(true, this.o1.jaSaiu(new Horario(17,45)));
		Assert.assertEquals(true, this.o1.jaSaiu(new Horario(20,15)));
		Assert.assertEquals(false, this.o1.jaSaiu(new Horario(9,45)));
		Assert.assertEquals(false, this.o1.jaSaiu(new Horario(17,25)));
		Assert.assertEquals(true, this.o1.jaSaiu(new Horario(17,30)));
	}
	
	@Test
	public void testeMenor() {
		Assert.assertEquals(true, 
				new Horario(9, 34).menor(new Horario(9,50)));
		Assert.assertEquals(true, 
				new Horario(9, 34).menor(new Horario(12,50)));
		Assert.assertEquals(false, 
				new Horario(9, 34).menor(new Horario(9,34)));
		Assert.assertEquals(false, 
				new Horario(9, 34).menor(new Horario(8,50)));
		Assert.assertEquals(false, 
				new Horario(9, 34).menor(new Horario(9,20)));
	}
	
	@Test
	public void testeAreaQuadrado() {
		Forma q = new Quadrado(new Coord(10,15), 5);
		Assert.assertEquals(25.0, q.area());
	}
}
