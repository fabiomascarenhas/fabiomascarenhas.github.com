import java.util.List;


// M�todos

// Linha do recibo de venda
class Cafe {
	String nome;
	int peso;       // gramas vendidas
	double preco;   // pre�o/kg (R$)

	static int PESO_DESCONTO = 10000;
	static int VALOR_DESCONTO = 15;
	
	Cafe(String nome, 
			int peso,
			double preco) {
		this.nome = nome;
		this.peso = peso;
		this.preco = preco;
	}
	
	// Pre�o total de venda
	double precoVendido() {
		double desconto = 1 - (this.desconto() / 100);
		return desconto * (
				((double)this.peso / 1000) * this.preco
				);
	}
	
	// Desconto aplic�vel a essa venda (em %)
	double desconto() {
		if(this.peso > PESO_DESCONTO)
			return VALOR_DESCONTO;
		else
			return 0;
	}
	
}

class Rota {
	String origem;
	String destino;
	
	Rota(String origem, String destino) {
		this.origem = origem;
		this.destino = destino;
	}
}

class Horario {
	int hora;
	int minuto;
	
	Horario(int hora, int minuto) {
		this.hora = hora;
		this.minuto = minuto;
	}
	
	int emMinutos() {
		return this.hora * 60 + this.minuto;
	}
	
	boolean menor(Horario outro) {
		return (this.hora < outro.hora) ||
				(this.hora == outro.hora &&
				this.minuto < outro.minuto);
	}
}

class Onibus {
	Rota rota;
	Horario saida;
	Horario chegada;
	boolean executivo;
	
	Onibus(Rota rota, Horario saida,
			Horario chegada,
			boolean executivo) {
		this.rota = rota;
		this.saida = saida;
		this.chegada = chegada;
		this.executivo = executivo;
	}
		
	// Tempo de viagem em minutos
	int tempoViagem() {
		int chegada = this.chegada.emMinutos();
		int saida = this.saida.emMinutos();
		if(chegada < saida) {
			// cruza a meia-noite
			chegada = chegada + 24 * 60;
		}
		return chegada - saida;
	}
	
	boolean jaSaiu(Horario agora) {
		return !agora.menor(this.saida);
	}
}

class Coord {
	int x;
	int y;
	
	Coord(int x, int y) {
		this.x = x;
		this.y = y;
	}
}

interface Forma {
	double area();
}

class Quadrado implements Forma {
	Coord cse;
	int lado;
	
	Quadrado(Coord cse, int lado) {
		this.cse = cse;
		this.lado = lado;
	}
	
	public double area() {
		return this.lado * this.lado;
	}
}

class Circulo implements Forma {
	Coord centro;
	int raio;
	
	Circulo(Coord centro, int raio) {
		this.centro = centro;
		this.raio = raio;
	}
	
	public double area() {
		return this.raio * this.raio * Math.PI;
	}
}

/*class Composicao implements Forma {
	List<Forma> formas;
	
	Composicao(List<Forma> formas) {
		this.formas = formas;
	}
}
*/
class Ponto implements Forma {
	Coord local;
	
	Ponto(Coord local) {
		this.local = local;
	}
	
	public double area() {
		return 0;
	}
}



