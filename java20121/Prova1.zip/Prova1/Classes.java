import java.util.ArrayList;
import java.util.List;


class Lancamento {
	private String data;
	private String descricao;
	private double valor;
	
	public Lancamento(String data, String descricao,
			double valor) {
		this.data = data;
		this.descricao = descricao;
		this.valor = valor;
	}
	
	public String getData() {
		return this.data;
	}
	
	public String toString() {
		return this.data + " - " + this.descricao + " (" +
				this.valor + ")";
	}

	public double getValor() {
		return this.valor;
	}
}

abstract class Conta {
	protected int numero;
	protected String correntista;
	public double saldo;
	protected List<Lancamento> lancamentos;
	
	protected Conta(int numero, String correntista,
			double saldo) {
		this.numero = numero;
		this.correntista = correntista;
		this.saldo = saldo;
		this.lancamentos = new ArrayList<Lancamento>();
	}
	
	public String toString() {
		String s = "" + this.numero + " - " + this.correntista + "\n";
		for(Lancamento l : this.lancamentos) {
			s = s + l.toString() + "\n";
		}
		s = s + "Saldo: " + this.saldo;
		return s;
	}
	
	public static String HOJE;
	
	public void deposita(double valor) {
		this.saldo += valor;
		this.lancamentos.add(new Lancamento(
				HOJE, "DEP�SITO", valor));
	}
	
	protected abstract boolean checaSaldo(double valor);
	
	public void retira(double valor) {
		if(this.checaSaldo(valor)) { 
			this.saldo -= valor;
			this.lancamentos.add(new Lancamento(
					HOJE, "RETIRADA", -valor));
		} else {
			throw new RuntimeException("saldo insuficiente");
		}
	}
	
	public List<Lancamento> extrato(String dataInicio,
			String dataFim) {
		List<Lancamento> lancs = new ArrayList<Lancamento>();
		for(Lancamento l : this.lancamentos) {
			if(l.getData().compareTo(dataInicio) >= 0 &&
					l.getData().compareTo(dataFim) <= 0) {
				lancs.add(l);
			}
		}
		return lancs;
	}
	
	public double movimento(String dataInicio,
			String dataFim) {
		double mov = 0;
		List<Lancamento> ext = this.extrato(dataInicio, dataFim);
		for(Lancamento l : ext) {
			mov += l.getValor();
		}
		return mov;
	}
}

abstract class Investimento extends Conta {
	protected double taxaJuros;
	
	protected Investimento(int numero, String correntista,
			double saldo, double taxaJuros) {
		super(numero, correntista, saldo);
		this.taxaJuros = taxaJuros;
	}
	
	public void corrige() {
		double taxaDia = this.taxaJuros / 365;
		double correcao = this.saldo * (taxaDia / 100);
		this.lancamentos.add(new Lancamento(
				HOJE, "CORRE��O MONET�RIA", correcao));
		this.saldo += correcao;
	}
}

class ContaCorrente extends Conta {
	private double limite;
	
	public ContaCorrente(int numero, String correntista,
			double saldo, double limite) {
		super(numero, correntista, saldo);
		this.limite = limite;
	}
	
	protected boolean checaSaldo(double valor) {
		return valor <= this.saldo + this.limite;
	}
}

class Poupanca extends Investimento {
	public Poupanca(int numero, String correntista,
			double saldo, double taxaJuros) {
		super(numero, correntista, saldo, taxaJuros);
	}

	protected boolean checaSaldo(double valor) {
		return valor <= this.saldo;
	}
}

class CD extends Investimento {
	private String dataVencimento; // AAAA-MM-DD
	
	public CD(int numero, String correntista,
			double saldo, double taxaJuros, String dataVencimento) {
		super(numero, correntista, saldo, taxaJuros);
		this.dataVencimento = dataVencimento;
	}
	
	public void deposita(double valor) {
		throw new RuntimeException("tipo de conta n�o aceita dep�sito");
	}

	public void retira(double valor) {
		throw new RuntimeException("tipo de conta n�o aceita retirada");
	}
	
	public void corrige() {
		if(HOJE.compareTo(this.dataVencimento) < -0) {
			super.corrige();
		}
	}

	protected boolean checaSaldo(double valor) {
		return false;
	}
}

