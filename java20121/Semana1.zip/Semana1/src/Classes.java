import java.util.List;

// Tipos primitivos ou at�micos

// int
// double
// boolean (true e false)
// String ("Ol� Java!\n")

// Classes
//struct {
//  char *nome;
//  int peso;
//  double preco;
//} Cafe;

class Cafe {
	String nome;
	int peso;
	double preco;
	
	Cafe(String nome, 
			int peso,
			double preco) {
		this.nome = nome;
		this.peso = peso;
		this.preco = preco;
	}
}

class Rota {
	String origem;
	String destino;
	
	Rota(String origem, String destino) {
		this.origem = origem;
		this.destino = destino;
	}
}

class Horario {
	int hora;
	int minuto;
	
	Horario(int hora, int minuto) {
		this.hora = hora;
		this.minuto = minuto;
	}
}

class Onibus {
	Rota rota;
	Horario saida;
	Horario chegada;
	boolean executivo;
	List<String> paradas;
	
	Onibus(Rota rota, Horario saida,
			Horario chegada,
			boolean executivo,
			List<String> paradas) {
		this.rota = rota;
		this.saida = saida;
		this.chegada = chegada;
		this.executivo = executivo;
		this.paradas = paradas;
	}
}

class Data {
	int dia;
	int mes;
	int ano;
	
	Data(int dia, int mes, int ano) {
		this.dia = dia;
		this.mes = mes;
		this.ano = ano;
	}
}

class IntervaloTemp {
	int minima;
	int maxima;
	
	IntervaloTemp(int minima, int maxima) {
		this.minima = minima;
		this.maxima = maxima;
	}
}

class RegistroTemp {
	Data dia;
	IntervaloTemp hoje;
	IntervaloTemp normal;
	IntervaloTemp recorde;
	
	RegistroTemp(Data dia, IntervaloTemp hoje,
			IntervaloTemp normal, IntervaloTemp recorde) {
		this.dia = dia;
		this.hoje = hoje;
		this.normal = normal;
		this.recorde = recorde;
	}
}

class Temperaturas {
	String cidade;
	List<RegistroTemp> registros;
	
	Temperaturas(String cidade, List<RegistroTemp> registros) {
		this.cidade = cidade;
		this.registros = registros;
	}
}

class Coord {
	double x;
	double y;
	
	Coord(double x, double y) {
		this.x = x;
		this.y = y;
	}
}

interface Forma {}

class Quadrado implements Forma {
	Coord cse;
	double lado;
	
	Quadrado(Coord cse, double lado) {
		this.cse = cse;
		this.lado = lado;
	}
}

class Circulo implements Forma {
	Coord centro;
	double raio;
	
	Circulo(Coord centro, double raio) {
		this.centro = centro;
		this.raio = raio;
	}
}

class Composicao implements Forma {
	List<Forma> formas;
	
	Composicao(List<Forma> formas) {
		this.formas = formas;
	}
}

class Ponto implements Forma {
	Coord local;
	
	Ponto(Coord local) {
		this.local = local;
	}
}
