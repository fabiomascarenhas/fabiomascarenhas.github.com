package fotograma;

import imageUtil.Image;
import imageUtil.ImageLoader;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;

import almonds.ParseException;
import almonds.ParseObject;
import almonds.ParseQuery;

public class Foto {
	private String id;
	private String autor;
	private String titulo;
	private Date data;
	
	private Image conteudo;
	
	private Foto(String id, String autor,
			String titulo, Date data, Image conteudo) {
		this.init(id, autor, titulo, data, conteudo);
	}
	
	private void init(String id, String autor,
			String titulo, Date data, Image conteudo) {
		this.id = id;
		this.autor = autor;
		this.data = data;
		this.titulo = titulo;
		this.conteudo = conteudo;
	}
	
	// Publicar foto nova
	public Foto(String autor, String titulo, String caminho) throws IOException, ParseException {
		ParseObject foto = new ParseObject("Foto");
		foto.put("autor", autor);
		foto.put("titulo", titulo);
		Image conteudo = ImageLoader.fromFile(caminho);
		conteudo = conteudo.getResizedToSquare(400, 0);
		File tmp = File.createTempFile("fotograma", "foto");
		conteudo.writeToJPG(tmp, 0.5f);
		FileReader arq = new FileReader(tmp);
		ByteArrayOutputStream bytes = new ByteArrayOutputStream();
		try {
			int i = arq.read();
			while(i != -1) {
				bytes.write(i);
				i = arq.read();
			}
			foto.put("conteudo", Base64.encodeBase64String(bytes.toByteArray()));
			foto.save();
			this.init(foto.getObjectId(), autor, titulo,
					foto.getCreatedAt(), conteudo);
			this.publicar();
		} finally {
			arq.close();
			bytes.close();
		}
	}
	
	private void publicar() throws ParseException {
		ParseQuery qry = new ParseQuery("Seguidor");
		qry.whereEqualTo("seguido", this.autor);
		List<ParseObject> objs = qry.find();
		Set<String> seguidores = new HashSet<String>();
		for(ParseObject obj : objs) {
			seguidores.add(obj.getString("seguidor"));
		}
		for(String seguidor : seguidores) {
			ParseObject obj = new ParseObject("LinhaTempo");
			obj.put("dono", seguidor);
			obj.put("foto", this.id);
			obj.saveInBackground();
		}
	}
	
	// Buscar uma foto existente
	public Foto(String id) {
	}
}
