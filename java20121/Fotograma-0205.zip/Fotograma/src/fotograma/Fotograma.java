package fotograma;

import java.io.IOException;

import almonds.Parse;
import almonds.ParseException;

public class Fotograma {
	static String SAL = "7e387tgeiugofkjbakbjg";
	static String APP_KEY = "WcOrVgrzFkh8X4Bxa93ta6DEveLl7NJJMaWvx9rQ";
	static String API_KEY = "zZkcMCjg0oybozGZJOdsq0Izik9CnQepGe8Ak4Ss";
	
	public static void main(String[] args) throws IOException, ParseException {
		Parse.initialize(APP_KEY, API_KEY);
		if(args[0].equals("novo")) {
			Pessoa p = new Pessoa(args[1], args[2]);
			System.out.println(p);
		} else if(args[0].equals("publicar")) {
			System.out.println(args[3]);
			Foto f = new Foto(args[1], args[2], args[3]);
			System.out.println(f);
		} else {
			Pessoa p = Pessoa.login(args[0], args[1]);
			p.seguir(args[2]);
			System.out.println(p);
		}
	}
}
