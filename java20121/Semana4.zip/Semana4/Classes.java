import java.util.ArrayList;
import java.util.List;


// Coord s�o objetos imut�veis
class Coord {
	public int x;
	public int y;
	
	public static Coord ORIGEM = new Coord(0, 0);
	
	public Coord(int x, int y) {
		this.x = x;
		this.y = y;
	}
		
	public double distanciaOrig() {
		return this.distancia(ORIGEM);
	}
	
	public boolean igual(Coord c) {
		return c.x == this.x &&
				c.y == this.y;
	}
	
	public double distancia(Coord c) {
		int x = this.x - c.x;
		int y = this.y - c.y;
		return Math.sqrt(x*x + y*y);
	}
	
	public boolean noQuadrado(Coord cse, int lado) {
		int x = this.x - cse.x;
		int y = this.y - cse.y;
		return x >= 0 && x <= lado && y >= 0 && y <= lado;
	}
	
	public Coord traslado(int dx, int dy) {
		return new Coord(this.x + dx, this.y + dy);
	}
}

class Caixa {
	public Coord cse;
	public Coord cid;
	
	public Caixa(Coord cse, Coord cid) {
		this.cse = cse;
		this.cid = cid;
	}
	
	public boolean igual(Caixa outro) {
		return this.cse.igual(outro.cse) &&
				this.cid.igual(outro.cid);
	}
}	

/*
 struct Forma {
    int tipo;  // 0 = quadrado, 1 = circulo, 2 = ponto, 3 = composicao
	union {
		struct {
		  struct Coord centro;
		  int raio;
		} c;
		struct {
		  struct Coord cse;
		  int lado;
		} q;
		struct {
		  struct Coord local;
		} p;
		struct {
		  struct Forma* f1;
		  struct Forma* f2;
		} cp;
	} f;
 }
 */

interface Forma {
	double area();
	double distanciaOrig();
	boolean contem(Coord c);
	Caixa caixa();
}

class Quadrado implements Forma {
	private Coord cse;
	private int lado;
	
	public Quadrado(int x, int y, int lado) {
		this.cse = new Coord(x, y);
		this.lado = lado;
	}
	
	public Quadrado(Coord cse, int lado) {
		this.cse = cse;
		this.lado = lado;
	}
	
	public double area() {
		return this.lado * this.lado;
	}
	
	public double distanciaOrig() {
		return this.cse.distanciaOrig();
	}
	
	public boolean contem(Coord c) {
		return c.noQuadrado(this.cse, this.lado);
	}
	
	public Caixa caixa() {
		return new Caixa(this.cse, 
				this.cse.traslado(this.lado, this.lado));
	}
}

class Circulo implements Forma {
	private Coord centro;
	private int raio;
	
	public Circulo(Coord centro, int raio) {
		this.centro = centro;
		this.raio = raio;
	}
	
	public double area() {
		return this.raio * this.raio * Math.PI;
	}
	
	public double distanciaOrig() {
		return this.centro.distanciaOrig() - this.raio;
	}
	
	public boolean contem(Coord c) {
		return c.distancia(this.centro) <= this.raio;
	}
	
	public Caixa caixa() {
		return new Caixa(
				this.centro.traslado(-this.raio, -this.raio),
				this.centro.traslado(this.raio, this.raio)
			 );
	}
}

class Composicao implements Forma {
	private List<Forma> formas;
	
	public Composicao(List<Forma> formas) {
		this.formas = formas;
	}
	
	public Composicao(Forma[] formas) {
		this.formas = new ArrayList<Forma>();
		for(Forma f: formas) {
			this.formas.add(f);
		}
	}
	
	public Composicao(Forma f1, Forma... formas) {
		this.formas = new ArrayList<Forma>();
		this.formas.add(f1);
		for(Forma f : formas) {
			this.formas.add(f);
		}
	}
	
	// interse��o tem area == 0!!!
	// Padr�o: acumulador
	public double area() {
		double area = 0;
		for(Forma f : this.formas) {
			area += f.area();
		}
		return area;
	}
	
	// Padr�o: acumulador do m�nimo
	public double distanciaOrig() {
		double minDist = Double.MAX_VALUE;
		for(Forma f : this.formas) {
			double distF = f.distanciaOrig();
			if(distF < minDist) {
				minDist = distF;
			}
		}
		return minDist;
	}
	
	// Acumulador do ou l�gico c/ curto-circuito
	public boolean contem(Coord c) {
		for(Forma f : this.formas) {
			if(f.contem(c)) {
				return true;
			}
		}
		return false;
	}

	// Padr�o: filtro
	public List<Forma> container(Coord c) {
		List<Forma> formas = new ArrayList<Forma>();
		for(Forma f : this.formas) {
			if(f.contem(c))
				formas.add(f);
		}
		return formas;		
	}

	// Padr�o: mapeamento
	public List<Double> areas() {
		List<Double> areas = new ArrayList<Double>();
		for(Forma f : this.formas) {
			areas.add(f.area());
		}
		return areas;		
	}
	
	public Caixa caixa() {
		int menorX = Integer.MAX_VALUE;
		int menorY = Integer.MAX_VALUE;
		int maiorX = Integer.MIN_VALUE;
		int maiorY = Integer.MIN_VALUE;
		for(Forma f : this.formas) {
			Caixa c = f.caixa();
			if(c.cse.x < menorX)
				menorX = c.cse.x;
			if(c.cse.y < menorY)
				menorY = c.cse.y;
			if(c.cid.x > maiorX)
				maiorX = c.cid.x;
			if(c.cid.y > maiorY)
				maiorY = c.cid.y;
		}
		return new Caixa(new Coord(menorX, menorY),
				new Coord(maiorX, maiorY));
	}
}

class Ponto implements Forma {
	private Coord local;
	
	public Ponto(Coord local) {
		this.local = local;
	}
	
	public double area() {
		return 0;
	}
	
	public double distanciaOrig() {
		return this.local.distanciaOrig();
	}
	
	public boolean contem(Coord c) {
		// c � igual a local?
		return c.igual(this.local);
	}
	
	public Caixa caixa() {
		return new Caixa(this.local, this.local);
	}
}
