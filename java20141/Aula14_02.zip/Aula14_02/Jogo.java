public class Jogo {
    String titulo;
    int altura;
    int largura;
    
    Bola bola;
    Raquete raquete;
    Tijolo[] tijolos;
    int score, vidas;
    
    public Jogo() {
        this.titulo = "Breakout";
        this.largura = 800;
        this.altura = 600;
        score = 0;
        vidas = 3;
        bola = new Bola(800, 300);
        raquete = new Raquete(400, 600);
    }
    
    void desenhar(Tela t) {
        t.texto("" + score, 100, 30, 32, new Cor("branco"));
        t.texto("" + vidas, 300, 30, 32, new Cor("branco"));
        bola.desenhar(t);
        raquete.desenhar(t);
    }
    
    void tique(double dt) {
        bola.tique(dt);
    }
}