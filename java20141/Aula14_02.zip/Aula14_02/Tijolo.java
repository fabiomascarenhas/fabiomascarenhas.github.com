public class Tijolo {
    int x;
    int y;
    int largura;
    int altura;
    Cor cor;
    boolean vivo;
    
    Tijolo(int x, int y, Cor cor) {
        this.x = x;
        this.y = y;
        largura = 50;
        altura = 10;
        this.cor = cor;
        vivo = true;
    }
}