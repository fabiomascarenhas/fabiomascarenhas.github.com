public class Raquete {
    // Coordenadas do canto superior esquerdo
    double x;
    double y;
    double vx;
    Cor cor;
    int largura;
    int altura;
    
    Raquete(double x_centro, double y_inferior) {
        x = x_centro - 25;
        y = y_inferior - 10;
        vx = 300;
        cor = new Cor("azul");
        largura = 50;
        altura = 10;
    }
    
    void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
}