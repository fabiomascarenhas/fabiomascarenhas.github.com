public class Bola {
    // Coordenadas do centro
    double x;
    double y;
    // Pixels por segundo
    double vx;
    double vy;
    Cor cor;
    int raio;
    
    Bola(double x, double y) {
        this.x = x;
        this.y = y;
        vx = -200;
        vy = 150;
        cor = new Cor("branco");
        raio = 5;
    }
    
    void desenhar(Tela t) {
        t.circulo(x, y, raio, cor);
    }
    
    void tique(double dt) {
        x = x + vx * dt;
        y = y + vy * dt;
    }
}
