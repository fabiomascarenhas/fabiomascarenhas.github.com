public class Carro {
    String modelo;
    double preco;
    double consumo;
    boolean novo;
    
    Carro(String modelo, double preco, double consumo, boolean novo) {
        this.modelo = modelo;
        this.preco = preco;
        this.consumo = consumo;
        this.novo = novo;
    }
}