public class RetanguloInvertido extends Retangulo {
    public RetanguloInvertido(int x, int y, int largura, int altura) {
        super(largura, altura, x, y);
    }
    
    public void mover(int dx, int dy) {
        this.largura += dx;
        this.altura += dy;
    }
    
    public boolean dentro(int x, int y) {
        return (x >= largura) && (x <= largura + this.x) &&
          (y >= altura) && (y <= altura + this.y);
    }

    public void escala(double f) {
        x *= f;
        y *= f;
    }
    
    public void desenhar(Canvas c) {
        c.retangulo(largura, altura, x, y, 1, 1, 1);
    }
}