import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public abstract class App extends Jogo {
    public App() {
        super();  // opcional
        canvas.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent arg0) {
                arrasto(arg0.getX(), arg0.getY());
            }
            @Override
            public void mouseMoved(MouseEvent arg0) {
                movimento(arg0.getX(), arg0.getY());
            }
            
        });
        canvas.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
                clique(arg0.getX(), arg0.getY());
            }
            @Override
            public void mouseEntered(MouseEvent arg0) {}
            @Override
            public void mouseExited(MouseEvent arg0) {}
            @Override
            public void mousePressed(MouseEvent arg0) {
                aperto(arg0.getX(), arg0.getY());
            }
            @Override
            public void mouseReleased(MouseEvent arg0) {
                solta(arg0.getX(), arg0.getY());
            }
        });
    }

    public abstract void movimento(int x, int y);
    public abstract void arrasto(int x, int y);
    public abstract void clique(int x, int y);
    public abstract void aperto(int x, int y);
    public abstract void solta(int x, int y);
}