import java.util.Scanner;

public class IniVetor {
	static Scanner scan = new Scanner(System.in);
	
	public static void geraConjunto(double[] vetor, int tamanho, double inicial) {
	    for (int i = 0 ; i < tamanho; i++) {
	        vetor[i] = inicial;
	        inicial *= 2;
	    }
	}

	public static void main(String[] args)
	{
	    double[] vetor = new double[5];
	    double num;
	    int i;

	    System.out.println("Este programa gera um vetor de numeros inteiros.");
	    System.out.println("Entre com o numero inicial do conjunto. ");
	    num = scan.nextInt();

	    /* Geracao do conjunto */
	    geraConjunto(vetor, 5, num);
	    
	    /* Impressao do conjunto */
	    for (i = 0; i < 5; i++)
	        System.out.println("Elemento " + i + " = " + vetor[i]);
	}

}
