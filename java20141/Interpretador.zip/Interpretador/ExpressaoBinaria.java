public abstract class ExpressaoBinaria implements Expressao {
    Expressao esq;
    Expressao dir;
    
    public ExpressaoBinaria(Expressao esq, Expressao dir) {
        this.esq = esq;
        this.dir = dir;
    }
    
    public double valor(java.util.HashMap<String, Double> vars) {
        // delegando para as subclasses
        System.out.println("valor em ExpressaoBinaria");
        return op(esq.valor(vars), dir.valor(vars));
    }
    
    public abstract double op(double x, double y);
}
