public class Mult extends ExpressaoBinaria {
    public Mult(Expressao esq, Expressao dir) {
        super(esq, dir);
    }
    
    public double op(double x, double y) {
        System.out.println("op em Mult");
        return x * y;
    }
}
