public interface Expressao {
    double valor(java.util.HashMap<String, Double> vars);
}