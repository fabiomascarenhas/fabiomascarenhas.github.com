public class Num implements Expressao {
    double n;
    
    public Num(double n) {
        this.n = n;
    }
    
    public double valor(java.util.HashMap<String, Double> vars) {
        return n;
    }
}