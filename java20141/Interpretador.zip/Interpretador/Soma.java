public class Soma extends ExpressaoBinaria {
    public Soma(Expressao esq, Expressao dir) {
        super(esq, dir);
    }
    
    public double op(double x, double y) {
        System.out.println("op em Soma");
        return x + y;
    }
}
