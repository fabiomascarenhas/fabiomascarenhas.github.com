public class Calculo
{
    public static double dx = 0.000001;
    
    // Integral definida da função f no intervalo [a, b]
    public static double integral(Funcao f, double a, double b) {
        if(a > b) {
            double temp = b;
            b = a;
            a = temp;
        }
        double s = 0;
        while(a < b) {
            s = s + Math.abs(f.valor(a)) * dx;
            a = a + dx;
        }
        return s;
    }
}
