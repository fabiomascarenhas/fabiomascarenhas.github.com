// f(x) = c * g(x)
public class Escala implements Funcao {
    double c;
    Funcao g;
    
    public Escala(double c, Funcao g) {
        this.c = c;
        this.g = g;
    }
    
    public double valor(double x) {
        return c * g.valor(x);
    }
    
    public String formula() {
        return "" + c + g.formula();
    }
}