// Funções da família x^n
public class Potencia implements Funcao {
    int n;
    
    public Potencia(int n) {
        this.n = n;
    }
    
    public double valor(double x) {
        return Math.pow(x, n);
    }
    
    public String formula() {
        return "x^" + n;
    }
}