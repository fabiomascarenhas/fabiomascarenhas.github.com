// f(x) = g0(x) + ... + gi(x)
public class Soma implements Funcao {
    Funcao[] gs;

    public Soma(Funcao... gs) {
        this.gs = gs;
    }
    
    public double valor(double x) {
        double s = 0;
        for(Funcao g: gs) {
            s += g.valor(x);
        }
        return s;
    }
    
    public String formula() {
        String s = "(" + gs[0].formula();
        for(int i = 1; i < gs.length; i++) {
           s += "+" + gs[i].formula();
        }
        return s + ")";
    }
}