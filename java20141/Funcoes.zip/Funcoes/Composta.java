public class Composta {
    Funcao f;
    Funcao g;
    
    public Composta(Funcao f, Funcao g) {
        this.f = f;
        this.g = g;
    }
    
    public double valor(double x) {
        return f.valor(g.valor(x));
    }
    
    public String formula() {
        return "Comp[" + f.formula() + 
            "," + g.formula() + "]";
    }
}