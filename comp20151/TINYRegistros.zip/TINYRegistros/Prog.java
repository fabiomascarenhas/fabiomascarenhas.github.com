import java.util.ArrayList;
import java.util.List;

public class Prog extends Node {
	public List<Proc> procs;
	public Bloco cmds;
	
	public Prog(List<Proc> _procs, Bloco _cmds, int _lin) {
		super(_lin);
		procs = _procs;
		cmds = _cmds;
	}
	
	void checaEscopo() {
		// Primeira passada - coleta de nomes globais
		TabSimb<Boolean> escProcs = new TabSimb<Boolean>();
		for(Proc proc: procs) {
			escProcs.inserir(proc.id, true, proc.lin);
		}
		TabSimb<Boolean> globais = new TabSimb<Boolean>();
		for(Decl decl: cmds.vars) {
			for(String id: decl.vars) {
				globais.inserir(id, true, cmds.lin);
			}
		}
		// Segunda passada - verificação de escopo
		for(Proc proc: procs) {
			proc.checaEscopo(globais, escProcs);
		}
		cmds.checaEscopo(null, escProcs);
	}
	
	void checaTipo() {
		// Primeira passada - coleta de nomes globais
		TabSimb<Proc> escProcs = new TabSimb<Proc>();
		for(Proc proc: procs) {
			escProcs.inserir(proc.id, proc, proc.lin);
		}
		TabSimb<Tipo> globais = new TabSimb<Tipo>();
		for(Decl decl: cmds.vars) {
			for(String id: decl.vars) {
				globais.inserir(id, decl.tipo, cmds.lin);
			}
		}
		for(Proc proc: procs) {
			proc.tipo(globais, escProcs);
		}
		cmds.tipo(null, escProcs);
	}
	
	String codigo() {
		ArrayList<String> cprocs = new ArrayList<String>();
		ArrayList<String> nprocs = new ArrayList<String>();
		ArrayList<String> nglobais = new ArrayList<String>();
		TabSimb<Endereco> globais = new TabSimb<Endereco>();
		for(Decl decl: cmds.vars) {
			for(String id: decl.vars) {
				nglobais.add(id);
				globais.inserir(id, new Global(id), cmds.lin);
			}
		}
		for(Proc proc: procs) {
			nprocs.add(proc.id);
			cprocs.add(proc.codigo(globais));
		}
		Contexto cmain = new Contexto("main", 0);
		for(Cmd cmd: cmds.cmds) {
			cmd.codigo(cmain, globais);
		}
		cmain.icload(0);
		nprocs.add("main");
		cprocs.add(cmain.codigo());
		return Contexto.programa(nglobais, nprocs, cprocs);
	}
}
 