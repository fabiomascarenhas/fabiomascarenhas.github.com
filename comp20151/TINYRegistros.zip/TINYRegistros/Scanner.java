
public interface Scanner {
	Token token() throws java.io.IOException;
}
