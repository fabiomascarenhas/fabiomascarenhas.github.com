
public class Nil extends Node implements Exp, Tipo {
	static Tipo tipo = new Nil(0);

	public Nil(int _lin) {
		super(_lin);
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) { }

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		return Nil.tipo;
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(0);
	}

	@Override
	public void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label) {
		ctx.jmp(label);
	}

	@Override
	public boolean subtipo(Tipo t) {
		return t instanceof Reg;
	}
}
