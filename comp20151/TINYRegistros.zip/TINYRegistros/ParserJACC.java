// Output created by jacc on Wed Jun 24 11:39:24 BRT 2015


class ParserJACC implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 244;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    switch (yytok) {
                        case ';':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    switch (yytok) {
                        case ';':
                            yyn = 13;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    yyn = yys7();
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    switch (yytok) {
                        case ID:
                            yyn = 22;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case ID:
                            yyn = 23;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    yyn = yys11();
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    yyn = yys12();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    yyn = yys13();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    switch (yytok) {
                        case '.':
                            yyn = 34;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 35;
                            continue;
                        case '(':
                            yyn = 36;
                            continue;
                        case '.':
                            yyn = yyr53();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    yyn = yys17();
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case ID:
                            yyn = 45;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    yyn = yys20();
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    yyn = yys21();
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    switch (yytok) {
                        case '(':
                            yyn = 49;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case ';':
                        case END:
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ',':
                            yyn = 51;
                            continue;
                        case ';':
                            yyn = 52;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case ',':
                            yyn = 53;
                            continue;
                        case ':':
                            yyn = 54;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr26();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    switch (yytok) {
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    switch (yytok) {
                        case ';':
                            yyn = 55;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ID:
                            yyn = 56;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case '.':
                            yyn = 68;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    switch (yytok) {
                        case ID:
                            yyn = 70;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr32();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case UNTIL:
                            yyn = 71;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys48();
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case ')':
                            yyn = 74;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    switch (yytok) {
                        case ',':
                            yyn = 51;
                            continue;
                        case END:
                            yyn = 75;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    switch (yytok) {
                        case ID:
                            yyn = 77;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case BOOL:
                            yyn = 79;
                            continue;
                        case ID:
                            yyn = 80;
                            continue;
                        case INT:
                            yyn = 81;
                            continue;
                        case REAL:
                            yyn = 82;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 84;
                            continue;
                        case '.':
                            yyn = yyr52();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    yyn = yys57();
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    switch (yytok) {
                        case ')':
                            yyn = 85;
                            continue;
                        case ',':
                            yyn = 86;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr33();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    yyn = yys61();
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    yyn = yys62();
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys63();
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    switch (yytok) {
                        case ID:
                            yyn = 94;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    switch (yytok) {
                        case '(':
                            yyn = 97;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    switch (yytok) {
                        case '.':
                            yyn = yyr54();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    switch (yytok) {
                        case ',':
                            yyn = 51;
                            continue;
                        case ')':
                            yyn = 99;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    switch (yytok) {
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case ';':
                        case END:
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr25();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case ';':
                        case END:
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    yyn = yys79();
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    yyn = yys80();
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    yyn = yys81();
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 204:
                    yyn = yys82();
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 205:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 206:
                    yyn = yys84();
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 207:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr34();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 208:
                    yyn = yys86();
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 209:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ELSE:
                            yyn = 104;
                            continue;
                        case END:
                            yyn = 105;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 210:
                    yyn = yys88();
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 211:
                    yyn = yys89();
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 212:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 213:
                    yyn = yys91();
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 214:
                    yyn = yys92();
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 215:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 216:
                    yyn = yys94();
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 217:
                    switch (yytok) {
                        case ',':
                            yyn = 86;
                            continue;
                        case ')':
                            yyn = 106;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 218:
                    yyn = yys96();
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 219:
                    yyn = yys97();
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 220:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 221:
                    yyn = yys99();
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 222:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 111;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 223:
                    switch (yytok) {
                        case BOOL:
                            yyn = 79;
                            continue;
                        case ID:
                            yyn = 80;
                            continue;
                        case INT:
                            yyn = 81;
                            continue;
                        case REAL:
                            yyn = 82;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 102:
                    yyst[yysp] = 102;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 224:
                    yyn = yys102();
                    continue;

                case 103:
                    yyst[yysp] = 103;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 225:
                    yyn = yys103();
                    continue;

                case 104:
                    yyst[yysp] = 104;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 226:
                    yyn = yys104();
                    continue;

                case 105:
                    yyst[yysp] = 105;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 227:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 106:
                    yyst[yysp] = 106;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 228:
                    yyn = yys106();
                    continue;

                case 107:
                    yyst[yysp] = 107;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 229:
                    switch (yytok) {
                        case ',':
                            yyn = 86;
                            continue;
                        case ')':
                            yyn = 114;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 108:
                    yyst[yysp] = 108;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 230:
                    yyn = yys108();
                    continue;

                case 109:
                    yyst[yysp] = 109;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 231:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 115;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 110:
                    yyst[yysp] = 110;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 232:
                    switch (yytok) {
                        case BOOL:
                            yyn = 79;
                            continue;
                        case ID:
                            yyn = 80;
                            continue;
                        case INT:
                            yyn = 81;
                            continue;
                        case REAL:
                            yyn = 82;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 111:
                    yyst[yysp] = 111;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 233:
                    switch (yytok) {
                        case ';':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 112:
                    yyst[yysp] = 112;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 234:
                    yyn = yys112();
                    continue;

                case 113:
                    yyst[yysp] = 113;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 235:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 118;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 114:
                    yyst[yysp] = 114;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 236:
                    yyn = yys114();
                    continue;

                case 115:
                    yyst[yysp] = 115;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 237:
                    switch (yytok) {
                        case ';':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 116:
                    yyst[yysp] = 116;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 238:
                    yyn = yys116();
                    continue;

                case 117:
                    yyst[yysp] = 117;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 239:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 120;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 118:
                    yyst[yysp] = 118;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 240:
                    switch (yytok) {
                        case ELSE:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case END:
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 119:
                    yyst[yysp] = 119;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 241:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 121;
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 120:
                    yyst[yysp] = 120;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 242:
                    switch (yytok) {
                        case ';':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 121:
                    yyst[yysp] = 121;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 243:
                    switch (yytok) {
                        case ';':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 247;
                    continue;

                case 244:
                    return true;
                case 245:
                    yyerror("stack overflow");
                case 246:
                    return false;
                case 247:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case RECORD:
                return 9;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys7() {
        switch (yytok) {
            case ID:
                return 16;
            case IF:
                return 17;
            case READ:
                return 18;
            case REPEAT:
                return 19;
            case WRITE:
                return 20;
            case '(':
                return 21;
        }
        return 247;
    }

    private int yys11() {
        switch (yytok) {
            case ID:
                return 16;
            case IF:
                return 17;
            case READ:
                return 18;
            case REPEAT:
                return 19;
            case WRITE:
                return 20;
            case '(':
                return 21;
        }
        return 247;
    }

    private int yys12() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys13() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case RECORD:
                return 9;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys17() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys19() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys20() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys21() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys35() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys36() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
            case ')':
                return 60;
        }
        return 247;
    }

    private int yys37() {
        switch (yytok) {
            case THEN:
                return 61;
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
        }
        return 247;
    }

    private int yys39() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr45();
        }
        return 247;
    }

    private int yys40() {
        switch (yytok) {
            case '(':
                return 69;
            case '/':
            case '-':
            case ELSE:
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case THEN:
            case '<':
            case ';':
            case END:
            case '=':
            case ENDINPUT:
                return yyr43();
            case '.':
                return yyr53();
        }
        return 247;
    }

    private int yys42() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr46();
        }
        return 247;
    }

    private int yys43() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr42();
        }
        return 247;
    }

    private int yys44() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr44();
        }
        return 247;
    }

    private int yys47() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case END:
                return yyr31();
        }
        return 247;
    }

    private int yys48() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ')':
                return 72;
        }
        return 247;
    }

    private int yys52() {
        switch (yytok) {
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr16();
        }
        return 247;
    }

    private int yys55() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys57() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case END:
                return yyr30();
        }
        return 247;
    }

    private int yys58() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ',':
            case ')':
                return yyr56();
        }
        return 247;
    }

    private int yys61() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys62() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys63() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys64() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys65() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys66() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys67() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys69() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
            case ')':
                return 96;
        }
        return 247;
    }

    private int yys71() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys74() {
        switch (yytok) {
            case VAR:
                return 10;
            case ':':
                return 101;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys79() {
        switch (yytok) {
            case IF:
            case ',':
            case READ:
            case ')':
            case ID:
            case '(':
            case WRITE:
            case VAR:
            case ';':
            case REPEAT:
            case END:
                return yyr23();
        }
        return 247;
    }

    private int yys80() {
        switch (yytok) {
            case IF:
            case ',':
            case READ:
            case ')':
            case ID:
            case '(':
            case WRITE:
            case VAR:
            case ';':
            case REPEAT:
            case END:
                return yyr24();
        }
        return 247;
    }

    private int yys81() {
        switch (yytok) {
            case IF:
            case ',':
            case READ:
            case ')':
            case ID:
            case '(':
            case WRITE:
            case VAR:
            case ';':
            case REPEAT:
            case END:
                return yyr22();
        }
        return 247;
    }

    private int yys82() {
        switch (yytok) {
            case IF:
            case ',':
            case READ:
            case ')':
            case ID:
            case '(':
            case WRITE:
            case VAR:
            case ';':
            case REPEAT:
            case END:
                return yyr21();
        }
        return 247;
    }

    private int yys84() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys86() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
        }
        return 247;
    }

    private int yys88() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr39();
        }
        return 247;
    }

    private int yys89() {
        switch (yytok) {
            case '*':
                return 62;
            case '/':
                return 65;
            case '-':
            case ',':
            case '+':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr38();
        }
        return 247;
    }

    private int yys90() {
        switch (yytok) {
            case '*':
                return 62;
            case '/':
                return 65;
            case '-':
            case ',':
            case '+':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr40();
        }
        return 247;
    }

    private int yys91() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr41();
        }
        return 247;
    }

    private int yys92() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case ',':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr36();
        }
        return 247;
    }

    private int yys93() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case ',':
            case ')':
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case THEN:
            case ';':
            case END:
                return yyr37();
        }
        return 247;
    }

    private int yys94() {
        switch (yytok) {
            case '/':
            case '-':
            case ELSE:
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case THEN:
            case '<':
            case ';':
            case END:
            case '=':
            case ENDINPUT:
                return yyr51();
            case '.':
                return yyr52();
        }
        return 247;
    }

    private int yys96() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr47();
        }
        return 247;
    }

    private int yys97() {
        switch (yytok) {
            case '(':
                return 21;
            case FALSE:
                return 39;
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case TRUE:
                return 44;
            case ')':
                return 108;
        }
        return 247;
    }

    private int yys98() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case END:
                return yyr29();
        }
        return 247;
    }

    private int yys99() {
        switch (yytok) {
            case VAR:
                return 10;
            case ':':
                return 110;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys102() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ELSE:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case END:
                return yyr35();
        }
        return 247;
    }

    private int yys103() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ',':
            case ')':
                return yyr55();
        }
        return 247;
    }

    private int yys104() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys106() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr48();
        }
        return 247;
    }

    private int yys108() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr49();
        }
        return 247;
    }

    private int yys112() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yys114() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case ELSE:
            case UNTIL:
            case '=':
            case THEN:
            case '<':
            case ';':
            case ENDINPUT:
            case END:
                return yyr50();
        }
        return 247;
    }

    private int yys116() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case REPEAT:
                return yyr17();
        }
        return 247;
    }

    private int yyr1() { // s : regs ';' procs ';' cmds
        { saida = new Prog(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=5] = yyrv;
        return 1;
    }

    private int yyr2() { // s : regs ';' cmds
        { saida = new Prog(new java.util.ArrayList<Proc>(), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr3() { // s : procs ';' cmds
        { saida = new Prog(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr4() { // s : cmds
        { saida = new Prog(new java.util.ArrayList<Proc>(), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr14() { // cmds : cmds ';' cmd
        { ((Bloco)yysv[yysp-3]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr15() { // cmds : var cmd
        { ((Bloco)yysv[yysp-2]).add(((Cmd)yysv[yysp-1])); yyrv = ((Bloco)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 112: return 117;
            case 104: return 113;
            case 99: return 109;
            case 74: return 100;
            case 61: return 87;
            case 55: return 83;
            case 19: return 46;
            case 13: return 31;
            case 12: return 29;
            case 0: return 2;
            default: return 119;
        }
    }

    private int yyr20() { // decl : ids ':' tipo
        { yyrv = new Decl(((java.util.List)yysv[yysp-3]), ((Tipo)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        switch (yyst[yysp-1]) {
            case 51: return 76;
            default: return 24;
        }
    }

    private int yyr18() { // decls : decls ',' decl
        { ((java.util.List)yysv[yysp-3]).add(((Decl)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypdecls();
    }

    private int yyr19() { // decls : decl
        { java.util.List<Decl> res = new java.util.ArrayList<Decl>();
                         res.add(((Decl)yysv[yysp-1]));
                         yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypdecls();
    }

    private int yypdecls() {
        switch (yyst[yysp-1]) {
            case 23: return 50;
            case 10: return 25;
            default: return 73;
        }
    }

    private int yyr36() { // exp : exp '<' exp
        { yyrv = new Lt(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : exp '=' exp
        { yyrv = new Eq(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : exp '+' exp
        { yyrv = new Plus(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : exp '*' exp
        { yyrv = new Mul(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : exp '-' exp
        { yyrv = new Minus(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr42() { // exp : NUM
        { yyrv = new Num(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr43() { // exp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr44() { // exp : TRUE
        { yyrv = new True(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr45() { // exp : FALSE
        { yyrv = new False(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : NIL
        { yyrv = new Nil(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : ID '(' ')'
        { yyrv = new ExpChamada(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : ID '(' exps ')'
        { yyrv = new ExpChamada(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr49() { // exp : NEW ID '(' ')'
        { yyrv = new Cons(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr50() { // exp : NEW ID '(' exps ')'
        { yyrv = new Cons(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypexp();
    }

    private int yyr51() { // exp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), ((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 86: return 103;
            case 84: return 102;
            case 71: return 98;
            case 67: return 93;
            case 66: return 92;
            case 65: return 91;
            case 64: return 90;
            case 63: return 89;
            case 62: return 88;
            case 35: return 57;
            case 21: return 48;
            case 20: return 47;
            case 17: return 37;
            default: return 58;
        }
    }

    private int yyr55() { // exps : exps ',' exp
        { ((java.util.List)yysv[yysp-3]).add(((Exp)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr56() { // exps : exp
        { java.util.List<Exp> res = new java.util.ArrayList<Exp>();
                       res.add(((Exp)yysv[yysp-1]));
                       yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 69: return 95;
            case 36: return 59;
            default: return 107;
        }
    }

    private int yyr25() { // ids : ids ',' ID
        { ((java.util.List)yysv[yysp-3]).add(((Token)yysv[yysp-1]).lexeme); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 26;
    }

    private int yyr26() { // ids : ID
        { java.util.List<String> res = new java.util.ArrayList<String>();
                     res.add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return 26;
    }

    private int yyr10() { // proc : PROCEDURE ID '(' ')' cmds END
        { yyrv = new Proc(((Token)yysv[yysp-5]).lexeme, new java.util.ArrayList<Decl>(), new Void(((Token)yysv[yysp-6]).lin), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-6]).lin); }
        yysv[yysp-=6] = yyrv;
        return yypproc();
    }

    private int yyr11() { // proc : PROCEDURE ID '(' decls ')' cmds END
        { yyrv = new Proc(((Token)yysv[yysp-6]).lexeme, ((java.util.List)yysv[yysp-4]), new Void(((Token)yysv[yysp-7]).lin), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypproc();
    }

    private int yyr12() { // proc : PROCEDURE ID '(' decls ')' ':' tipo cmds END
        { yyrv = new Proc(((Token)yysv[yysp-8]).lexeme, ((java.util.List)yysv[yysp-6]), ((Tipo)yysv[yysp-3]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-9]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypproc();
    }

    private int yyr13() { // proc : PROCEDURE ID '(' ')' ':' tipo cmds END
        { yyrv = new Proc(((Token)yysv[yysp-7]).lexeme, new java.util.ArrayList<Decl>(), ((Tipo)yysv[yysp-3]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-8]).lin); }
        yysv[yysp-=8] = yyrv;
        return yypproc();
    }

    private int yypproc() {
        switch (yyst[yysp-1]) {
            case 13: return 3;
            case 0: return 3;
            default: return 30;
        }
    }

    private int yyr8() { // procs : procs ';' proc
        { ((java.util.List)yysv[yysp-3]).add(((Proc)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypprocs();
    }

    private int yyr9() { // procs : proc
        { java.util.List<Proc> res = new java.util.ArrayList<Proc>();
                         res.add(((Proc)yysv[yysp-1]));
                         yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypprocs();
    }

    private int yypprocs() {
        switch (yyst[yysp-1]) {
            case 0: return 4;
            default: return 32;
        }
    }

    private int yyr7() { // reg : RECORD ID decls END
        { Registro.registros.put(((Token)yysv[yysp-3]).lexeme,
                                       new Registro(((java.util.List)yysv[yysp-2]))); }
        yysv[yysp-=4] = yyrv;
        switch (yyst[yysp-1]) {
            case 0: return 5;
            default: return 33;
        }
    }

    private int yyr5() { // regs : regs ';' reg
        yysp -= 3;
        return 6;
    }

    private int yyr6() { // regs : reg
        yysp -= 1;
        return 6;
    }

    private int yyr52() { // rexp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), ((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr53() { // rexp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyprexp();
    }

    private int yyr54() { // rexp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyprexp() {
        switch (yyst[yysp-1]) {
            case 11: return 14;
            case 7: return 14;
            default: return 38;
        }
    }

    private int yyr27() { // cmd : IF exp THEN cmds END
        { yyrv = new IfThen(((Exp)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr28() { // cmd : IF exp THEN cmds ELSE cmds END
        { yyrv = new IfThenElse(((Exp)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr29() { // cmd : REPEAT cmds UNTIL exp
        { yyrv = new Repeat(((Exp)yysv[yysp-1]), ((Bloco)yysv[yysp-3]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr30() { // cmd : ID ATTRIB exp
        { yyrv = new Assign(((Token)yysv[yysp-3]).lexeme, ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr31() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr32() { // cmd : READ ID
        { yyrv = new Read(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr33() { // cmd : ID '(' ')'
        { yyrv = new Chamada(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr34() { // cmd : ID '(' exps ')'
        { yyrv = new Chamada(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr35() { // cmd : rexp '.' ID ATTRIB exp
        { yyrv = new AssignCampo(((Exp)yysv[yysp-5]), ((Token)yysv[yysp-3]).lexeme, ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 7: return 15;
            default: return 28;
        }
    }

    private int yyr21() { // tipo : REAL
        { yyrv = new Real(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr22() { // tipo : INT
        { yyrv = new Int(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr23() { // tipo : BOOL
        { yyrv = new Bool(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr24() { // tipo : ID
        { yyrv = new Reg(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 101: return 112;
            case 54: return 78;
            default: return 116;
        }
    }

    private int yyr16() { // var : VAR decls ';'
        { yyrv = new Bloco(((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return 7;
    }

    private int yyr17() { // var : /* empty */
        { yyrv = new Bloco(new java.util.ArrayList<Decl>(), ((Token)token).lin); }
        yysv[yysp-=0] = yyrv;
        return 7;
    }

    protected String[] yyerrmsgs = {
    };


Scanner scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Prog saida; // workaround pro bug do tipo do parse()

public ParserJACC(java.io.Reader entrada) {
  scan = new ScannerJF(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.token();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException("erro de sintaxe:" + token);
}

}
