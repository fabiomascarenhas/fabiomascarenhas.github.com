public class IfThenElse extends Node implements Cmd {
	public Exp cond;
	public Bloco cthen;
	public Bloco celse;
	
	public IfThenElse(Exp _cond, Bloco _cthen, Bloco _celse, int _lin) {
		super(_lin);
		cond = _cond;
		cthen = _cthen;
		celse = _celse;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		cond.checaEscopo(escopo, escopoProcs);
		cthen.checaEscopo(escopo, escopoProcs);
		celse.checaEscopo(escopo, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo tcond = cond.tipo(vars, procs);
		if(!tcond.subtipo(Bool.tipo) && !Nil.tipo.subtipo(tcond)) {
			throw new RuntimeException("condição do if na linha " + lin + " não é booleana ou registro, mas " + tcond);
		}
		cthen.tipo(vars, procs);
		celse.tipo(vars, procs);
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		int lelse = ctx.label();
		int lfim = ctx.label();
		cond.codigoSaltoF(ctx, vars, lelse);
		cthen.codigo(ctx, vars);
		ctx.jmp(lfim);
		ctx.label(lelse);
		celse.codigo(ctx, vars);
		ctx.label(lfim);
	}
}
