import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Registro {
	public List<Tipo> campos;
	public List<String> ncampos;
	public Set<Registro> supers;
	
	public static Map<String, Registro> registros = new
			HashMap<String, Registro>();
	
	public Registro(List<Decl> decls) {
		campos = new ArrayList<Tipo>();
		ncampos = new ArrayList<String>();
		supers = new HashSet<Registro>();
		for(Decl decl: decls) {
			for(String var: decl.vars) {
				ncampos.add(var);
				campos.add(decl.tipo);
			}
		}
	}
	
	public boolean subtipo(Registro r) {
		if(campos.size() < r.campos.size()) {
			return false;
		}
		if(supers.contains(r)) {
			return true;
		}
		supers.add(r);
		for(int i = 0; i < r.campos.size(); i++) {
			if(!campos.get(i).subtipo(r.campos.get(i)) ||
				!r.campos.get(i).subtipo(campos.get(i))) {
				supers.remove(r);
				return false;
			}
		}
		return true;
	}
}
