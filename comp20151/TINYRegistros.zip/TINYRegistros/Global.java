
public class Global implements Endereco {
	String id;
	
	public Global(String _id) {
		this.id = _id;
	}

	@Override
	public void store(Contexto ctx) {
		ctx.putglobal(id);
	}

	@Override
	public void load(Contexto ctx) {
		ctx.getglobal(id);
	}
	
}
