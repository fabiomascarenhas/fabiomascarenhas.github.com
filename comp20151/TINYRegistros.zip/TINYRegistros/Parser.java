/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | id | num

*/

public class Parser {
	Grammar g;
	SLRParser parser;
	
	public Parser(Scanner scan) {
		g = new Grammar();
		g.rules("S", "CMDS");
		g.rules("CMDS", "CMDS ; CMD");
		g.rules("CMDS", "CMD");
		g.rules("CMD", "if EXP then CMDS end");
		g.rules("CMD", "if EXP then CMDS else CMDS end");
		g.rules("CMD", "repeat CMDS until EXP");
		g.rules("CMD", "id := EXP");
		g.rules("CMD", "read id");
		g.rules("CMD", "write EXP");
		g.rules("EXP", "EXP < EXP");
		g.rules("EXP", "EXP = EXP");
		g.rules("EXP", "EXP + EXP");
		g.rules("EXP", "EXP - EXP");
		g.rules("EXP", "EXP * EXP");
		g.rules("EXP", "EXP / EXP");
		g.rules("EXP", "( EXP )");
		g.rules("EXP", "num");
		g.rules("EXP", "id");
		this.parser = new SLRParser(g, new String[] { "< =", "+ -", "* /" });
		this.parser.setInput(scan);
	}
		
	public Tree parse() {
		return parser.parse();
	}
	
}
