
public class Reg extends Node implements Tipo {
	public String nome;
	
	public Reg(String _nome, int _lin) {
		super(_lin);
		nome = _nome;
	}
	
	public boolean subtipo(Tipo t) {
		if(t instanceof Reg) {
			Registro r1 = Registro.registros.get(nome);
			if(r1 == null) {
				throw new RuntimeException("registro " + nome + " na linha " + lin + " não existe");
			}
			Registro r2 = Registro.registros.get(((Reg)t).nome);
			if(r2 == null) {
				throw new RuntimeException("registro " + ((Reg)t).nome + " na linha " + ((Reg)t).lin + " não existe");
			}
			return r1.subtipo(r2);
		}
		return false;
	}
}
