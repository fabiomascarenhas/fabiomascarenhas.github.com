
public class Questao14 extends ParserRL {

	public Questao14(String[] input) {
		super(input);
	}

	@Override
	public Tree S() {
		return A();
	}

	Tree A() {
		Tree arvore = new Tree("A");
		int atual = pos;
		try {
			Tree rascunho = new Tree("");
			// ( A ) A
			// (
			arvore.child(terminal("("));
			// A
			arvore.child(A());
			// )
			arvore.child(terminal(")"));
			// A
			arvore.child(A());
			arvore.children.addAll(rascunho.children);
		} catch(Falha f) {
			pos = atual;
			// *vazio*
		}
		return arvore;
	}

}
