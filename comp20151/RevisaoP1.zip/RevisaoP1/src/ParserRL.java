import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;


class Falha extends RuntimeException { }

public abstract class ParserRL {
	ArrayList<String> tokens = new ArrayList<String>();
	int pos = 0;
	int erro = 0;
	HashSet<String> esperados = new HashSet<String>();
	
	public ParserRL(String[] input) {
		for(String s: input) {
			tokens.add(s);
		}
	}
	
	public String terminal(String tok) {
		if(pos < tokens.size() && tokens.get(pos).equals(tok)) {
			pos++;
			return tok;
		} else {
			if(pos > erro) {
				erro = pos;
				esperados = new HashSet<String>();
				esperados.add(tok);
			} else if(pos == erro) {
				esperados.add(tok);
			}
			throw new Falha();
		}
	}
	
	public Tree parse() {
		Tree res = S();
		if(pos == tokens.size()) {
			return res;
		} else {
			String s = "an�lise falhou no token " + erro + 
					   " (" + tokens.get(erro) + "), esperados:";
			for(String token: esperados) {
				s += "    " + token;
			}
			throw new RuntimeException(s);
		}
	}

	public abstract Tree S();
	
}
