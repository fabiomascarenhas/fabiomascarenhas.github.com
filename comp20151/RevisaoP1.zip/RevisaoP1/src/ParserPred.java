import java.util.ArrayList;

public abstract class ParserPred {
	String la;
	ArrayList<String> input = new ArrayList<String>();
	
	public ParserPred(String[] input) {
		for(String s: input) {
			this.input.add(s);
		}
		this.input.add("<<EOF>>");
		this.input.add("$");
		la = this.input.remove(0);
	}
	
	public String terminal(String tok) {
		if(la.equals(tok)) {
			la = this.input.remove(0);
			return tok;
		} else {
			throw new RuntimeException("analise falhou no token "+
					la+ ", esperado:" + tok);
		}
	}
	
	public Tree parse() {
		Tree res = S();
		terminal("<<EOF>>");
		return res;
	}
	
	public abstract Tree S();
	
}
