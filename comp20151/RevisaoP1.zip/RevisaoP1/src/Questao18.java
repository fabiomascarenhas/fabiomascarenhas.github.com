/*
	CMD     -> id (ATRIB | CHAMADA) | outro
    ATRIB   -> := exp
    CHAMADA -> ( exp )
 */
public class Questao18 extends ParserPred {

	public Questao18(String[] input) {
		super(input);
	}
	
	@Override
	public Tree S() {
		return CMD();
	}

	public Tree CMD() {
		Tree arvore = new Tree("CMD");
		if(la.equals("id")) {
			terminal("id");
			if(la.equals(":=")) {
				// ATRIB
				arvore.child(ATRIB());
			} else {
				// CHAMADA
				arvore.child(CHAMADA());
			}
		} else {
			arvore.child(terminal("outro"));
		}
		return arvore;
	}
	
	public Tree ATRIB() {
		Tree arvore = new Tree("ATRIB");
		arvore.child("id");
		arvore.child(terminal(":="));
		arvore.child(terminal("exp"));
		return arvore;
	}
	
	public Tree CHAMADA() {
		Tree arvore = new Tree("CHAMADA");
		arvore.child("id");
		arvore.child(terminal("("));
		arvore.child(terminal("exp"));
		arvore.child(terminal(")"));
		return arvore;
	}
}
