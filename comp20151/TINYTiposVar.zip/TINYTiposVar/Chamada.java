
public class Chamada extends Node implements Cmd {
	public String id;
	
	public Chamada(String _id, int _lin) {
		super(_lin);
		id = _id;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		escopoProcs.procurar(id, lin);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars) {}
}
