import java.util.HashMap;
import java.util.Map;

public class TabSimb<T> {
  TabSimb<T> pai;
  Map<String, T> nomes =
		  new HashMap<String, T>();
  
  public TabSimb(TabSimb<T> _pai) {
	  pai = _pai;
  }
  
  public TabSimb() { pai = null; }
  
  void inserir(String nome, T atrib, int lin) {
	  if(nomes.containsKey(nome))
		  throw new RuntimeException(nome + " redeclarado na linha " + lin);
	  nomes.put(nome,  atrib);
  }
  
  T procurar(String nome, int lin) {
	  if(nomes.containsKey(nome))
		  return nomes.get(nome);
	  else if(pai != null)
		  return pai.procurar(nome, lin);
	  else
		  throw new RuntimeException(nome + " fora de escopo na linha " + lin);
  }
  
  void atualizar(String nome, T atrib, int lin) {
	  if(nomes.containsKey(nome))
		  nomes.put(nome,  atrib);
	  else if(pai != null)
		  pai.atualizar(nome, atrib, lin);
	  else
		  throw new RuntimeException(nome + " fora de escopo na linha " + lin);
  }
}
