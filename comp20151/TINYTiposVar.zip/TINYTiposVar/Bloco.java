import java.util.ArrayList;
import java.util.List;

public class Bloco extends Node {
	public List<Decl> vars;
	public List<Cmd> cmds;
	
	public Bloco(List<Decl> _vars, int _lin) {
		super(_lin);
		vars = _vars;
		cmds = new ArrayList<Cmd>();
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}
	
	TabSimb<Boolean> checaEscopo(TabSimb<Boolean> pai, TabSimb<Boolean> escopoProcs) {
		TabSimb<Boolean> escopo = new TabSimb<Boolean>(pai);
		for(Decl decl: vars) {
			for(String var: decl.vars) {
				escopo.inserir(var, true, lin);
			}
		}
		for(Cmd cmd: cmds) {
			cmd.checaEscopo(escopo, escopoProcs);
		}
		return escopo;
	}
	
	public TabSimb<Tipo> tipo(TabSimb<Tipo> vars) {
		TabSimb<Tipo> escopo = new TabSimb<Tipo>(vars);
		for(Decl decl: this.vars) {
			for(String var: decl.vars) {
				escopo.inserir(var, decl.tipo, lin);
			}
		}
		for(Cmd cmd: cmds) {
			cmd.tipo(escopo);
		}
		return escopo;
	}
}
