
public class Bool extends Node implements Tipo {
	static Tipo tipo = new Bool(0);
	
	public Bool(int lin) {
		super(lin);
	}

	public boolean subtipo(Tipo t) {
		return t instanceof Bool;
	}

	public String toString() {
		return "bool";
	}
}
