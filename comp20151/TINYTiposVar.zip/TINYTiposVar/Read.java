
public class Read extends Node implements Cmd {
	public String id;
	
	public Read(String _id, int _lin) {
		super(_lin);
		id = _id;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		escopo.procurar(id, lin);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars) {
		vars.procurar(id, lin);
	}
}
