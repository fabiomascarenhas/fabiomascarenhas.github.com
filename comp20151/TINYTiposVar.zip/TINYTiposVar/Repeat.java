public class Repeat extends Node implements Cmd {
	public Exp cond;
	public Bloco cmds;
	
	public Repeat(Exp _cond, Bloco _cmds, int _lin) {
		super(_lin);
		cond = _cond;
		cmds = _cmds;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		TabSimb<Boolean> escopoBloco = cmds.checaEscopo(escopo, escopoProcs);
		cond.checaEscopo(escopoBloco, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars) {
		TabSimb<Tipo> escopo = cmds.tipo(vars);
		Tipo tcond = cond.tipo(escopo);
		if(!tcond.subtipo(Bool.tipo)) {
			throw new RuntimeException("condição do repeat na linha " + lin + " não é booleano, mas " + tcond);
		}
	}
}
