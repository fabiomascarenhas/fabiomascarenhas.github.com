
public class Id extends Node implements Exp {
	public String id;
	
	public Id(String _id, int _lin) {
		super(_lin);
		id = _id;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		escopo.procurar(id, lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars) {
		return vars.procurar(id, lin);
	}
}
