import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | id | num

SEXP  -> SEXP + TERMO | SEXP - TERMO | TERMO

*/

public class Parser {
	Token la;
	Scanner scan;
	
	public Parser(Scanner scan) {
		try {
			this.scan = scan;
			la = scan.token();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public String terminal(int tipo) {
		if(la.tipo == tipo) {
			try {
				String lexeme = la.lexeme;
				la = scan.token();
				return lexeme;
			} catch(IOException e) {
				throw new RuntimeException(e);
			}
		} else {
			throw new RuntimeException("análise falhou no token "+
					la.toString() + ", esperado:" + tipo);
		}
	}
	
	public Tree parse() {
		Tree res = cmds();
		terminal(Token.EOF);
		return res;
	}
	
	Tree cmds() {
		Tree res = new Tree("CMDS");
		// CMD { ; CMD }
		res.child(cmd());
		while(la.tipo == ';') {
			res.child(terminal(';'));
			res.child(cmd());
		}
		return res;
	}
	
	Tree cmd() {
		Tree res = new Tree("CMD");
		switch(la.tipo) {
		case Token.IF: {
			// if EXP then CMDS [ else CMDS ] end
			res.child(terminal(Token.IF));
			res.child(exp());
			res.child(terminal(Token.THEN));
			res.child(cmds());
			if(la.tipo == Token.ELSE) {
				// ELSE cmds
				res.child(terminal(Token.ELSE));
				res.child(cmds());
			}
			res.child(terminal(Token.END));
			break;
		}
		case Token.REPEAT: {
			// repeat CMDS until EXP
			res.child(terminal(Token.REPEAT));
			res.child(cmds());
			res.child(terminal(Token.UNTIL));
			res.child(exp());
			break;
		}
		case Token.ID: {
			// id := EXP
			res.child(terminal(Token.ID));
			res.child(terminal(Token.ATTRIB));
			res.child(exp());
			break;
		}
		case Token.WRITE: {
			// write EXP
			res.child(terminal(Token.WRITE));
			res.child(exp());
			break;
		}
		case Token.READ: {
			// read id
			res.child(terminal(Token.READ));
			res.child(terminal(Token.ID));
			break;
		}
		default:
			throw new RuntimeException("comando esperado na linha " +
					la.lin + ", encontrado " + la.toString());
		}
		return res;
	}
	
	Tree exp() {
		Tree res = new Tree("EXP");
		// SEXP { < SEXP | = SEXP }
		res.child(sexp());
		while(la.tipo == '<' || la.tipo == '=') {
			if(la.tipo == '<') {
				// < SEXP
				res.child(terminal('<'));
				res.child(sexp());
			} else {
				// = SEXP
				res.child(terminal('='));
				res.child(sexp());
			}
		}
		return res;
	}
	
	Tree sexp() {
		Tree res = new Tree("SEXP");
		// TERMO { + TERMO | - TERMO }
		res.child(termo());
		while(la.tipo == '+' || la.tipo == '-') {
			if(la.tipo == '+') {
				// + TERMO
				res.child(terminal('+'));
				res.child(termo());
			} else {
				// - TERMO
				res.child(terminal('-'));
				res.child(termo());
			}
		}
		return res;
	}
	
	Tree termo() {
		Tree res = new Tree("TERMO");
		// FATOR { * FATOR | / FATOR }
		res.child(fator());
		while(la.tipo == '*' || la.tipo == '/') {
			if(la.tipo == '*') {
				// * FATOR
				res.child(terminal('*'));
				res.child(fator());
			} else {
				// / FATOR 
				res.child(terminal('/'));
				res.child(fator());
			}
		}
		return res;
	}
	
	Tree fator() {
		Tree res = new Tree("FATOR");
		// "(" EXP ")" | id | num
		switch(la.tipo) {
		case '(': {
			// "(" EXP ")"
			res.child(terminal('('));
			res.child(exp());
			res.child(terminal(')'));
			break;
		}
		case Token.ID: {
			// id
			res.child(terminal(Token.ID));
			break;
		}
		case Token.NUM: {
			// num
			res.child(terminal(Token.NUM));
			break;
		}
		default:
			throw new RuntimeException("expressão esperada na linha " +
					la.lin + ", encontrado " + la.toString());
		}
		return res;
	}
}
