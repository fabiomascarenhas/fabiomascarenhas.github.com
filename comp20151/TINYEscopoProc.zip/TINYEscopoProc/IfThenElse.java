public class IfThenElse extends Node implements Cmd {
	public Exp cond;
	public Bloco cthen;
	public Bloco celse;
	
	public IfThenElse(Exp _cond, Bloco _cthen, Bloco _celse, int _lin) {
		super(_lin);
		cond = _cond;
		cthen = _cthen;
		celse = _celse;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		cond.checaEscopo(escopo, escopoProcs);
		cthen.checaEscopo(escopo, escopoProcs);
		celse.checaEscopo(escopo, escopoProcs);
	}
}
