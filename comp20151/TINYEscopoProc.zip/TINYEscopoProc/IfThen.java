public class IfThen extends Node implements Cmd {
	public Exp cond;
	public Bloco cthen;
	
	public IfThen(Exp _cond, Bloco _cthen, int _lin) {
		super(_lin);
		cond = _cond;
		cthen = _cthen;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		cond.checaEscopo(escopo, escopoProcs);
		cthen.checaEscopo(escopo, escopoProcs);
	}
}
