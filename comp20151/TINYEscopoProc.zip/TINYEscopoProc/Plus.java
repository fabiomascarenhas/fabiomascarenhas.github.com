
public class Plus extends BinExp {
	public Plus(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}
}
