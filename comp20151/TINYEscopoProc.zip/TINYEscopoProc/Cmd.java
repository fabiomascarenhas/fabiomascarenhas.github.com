
public interface Cmd {
	void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs);
}
