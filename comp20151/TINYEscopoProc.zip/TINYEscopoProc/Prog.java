import java.util.List;

public class Prog extends Node {
	public List<Proc> procs;
	public Bloco cmds;
	
	public Prog(List<Proc> _procs, Bloco _cmds, int _lin) {
		super(_lin);
		procs = _procs;
		cmds = _cmds;
	}
	
	void checaEscopo() {
		// Primeira passada - coleta de nomes globais
		TabSimb<Boolean> escProcs = new TabSimb<Boolean>();
		for(Proc proc: procs) {
			escProcs.inserir(proc.id, true, proc.lin);
		}
		TabSimb<Boolean> globais = new TabSimb<Boolean>();
		for(String id: cmds.vars) {
			globais.inserir(id, true, cmds.lin);
		}
		// Segunda passada - verificação de escopo
		for(Proc proc: procs) {
			proc.cmds.checaEscopo(globais, escProcs);
		}
		cmds.checaEscopo(null, escProcs);
	}
}
