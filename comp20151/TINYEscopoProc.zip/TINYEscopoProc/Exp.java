
public interface Exp {
	void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs);
}
