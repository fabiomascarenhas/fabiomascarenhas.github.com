
public class Proc extends Node {
	public String id;
	public Bloco cmds;
	
	public Proc(String _id, Bloco _cmds, int _lin) {
		super(_lin);
		id = _id;
		cmds = _cmds;
	}
}
