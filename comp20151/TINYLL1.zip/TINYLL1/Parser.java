import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | id | num

*/

public class Parser {
	Grammar g;
	Scanner scan;
	
	public Parser(Scanner scan) {
		g = new Grammar();
		g.rules("S", "CMDS");
		g.rules("CMDS", "CMD RESTO");
		g.rules("RESTO", "");
		g.rules("RESTO", "; CMD RESTO");
		g.rules("CMD", "if EXP then CMDS ELSE end");
		g.rules("CMD", "repeat CMDS until EXP");
		g.rules("CMD", "id := EXP");
		g.rules("CMD", "read id");
		g.rules("CMD", "write EXP");
		g.rules("ELSE", "");
		g.rules("ELSE", "else CMDS");
		g.rules("EXP", "SEXP REXP");
		g.rules("REXP", "");
		g.rules("REXP", "< SEXP REXP");
		g.rules("REXP", "= SEXP REXP");
		g.rules("SEXP", "TERMO RSEXP");
		g.rules("RSEXP", "");
		g.rules("RSEXP", "+ TERMO RSEXP");
		g.rules("RSEXP", "- TERMO RSEXP");
		g.rules("TERMO", "FATOR RTERMO");
		g.rules("RTERMO", "");
		g.rules("RTERMO", "* FATOR RTERMO");
		g.rules("RTERMO", "/ FATOR RTERMO");
		g.rules("FATOR", "( EXP )");
		g.rules("FATOR", "id");
		g.rules("FATOR", "num");
		g.computeSets();
		this.scan = scan;
	}
		
	public Tree parse() {
		return g.parse(scan);
	}
	
}
