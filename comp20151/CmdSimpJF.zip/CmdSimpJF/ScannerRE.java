import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class ScannerRE implements Scanner {
	public class Rule {
		public String regex;
		public int type;
		
		public Rule(String regex, int type) {
			this.regex = regex;
			this.type = type;
		}
	}
	
	public List<Rule> rules = new ArrayList<Rule>();
	public String regexSpace;
	public String input;

	public void space(String regex) {
		regexSpace = regex;
	}
	
	public void rule(String regex, int type) {
		rules.add(new Rule(regex, type));
	}
	
	public ScannerRE(Reader in) {
		input = "";
		try {
			int c = in.read();
			while(c > 0) {
				input = input + Character.toString((char)c);
				c = in.read();
			}
		} catch(IOException ioe) {
		}
	}

	public Token token() {
		do {
			String[] result = RE.findAtStart(regexSpace, input);
			if(result[0].length() == 0) break;
			input = result[1];
		} while(true);
		if(input.equals(""))
			return new Token(Token.EOF, "", 0);
		String maxMatch = "";
		String nextInput = input;
		int type = -1;
		for(Rule rule : rules) {
			String[] result = RE.findAtStart(rule.regex, input);
			String match = result[0];
			if(match.length() > maxMatch.length()) {
				maxMatch = match;
				type = rule.type;
				nextInput = result[1];
			}
		}
		if(maxMatch.length() > 0) {
			input = nextInput;
			return new Token(type, maxMatch, 0);
		} else throw new RuntimeException("lexical error at: " +
			input);
	}

}
