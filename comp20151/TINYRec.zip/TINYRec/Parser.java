import java.io.IOException;
import java.util.ArrayList;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id
*/

class Falha extends RuntimeException { }

public class Parser {
	ArrayList<Token> tokens;
	int atual = 0;
	
	public Parser(Scanner scan) {
		tokens = new ArrayList<Token>();
		try {
			Token tok;
			do {
				tok = scan.token();
				tokens.add(tok);
			} while(tok.tipo != Token.EOF);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void terminal(int tipo) {
		if(tokens.get(atual).tipo == tipo) {
			atual++;
		} else {
			throw new Falha();
		}
	}
	
	public void parse() {
		cmds();
		terminal(Token.EOF);
	}
	
	void cmds() {
		cmd();
		while(true) {
			int salvo = atual;
			try {
				terminal(';');
				cmd();
			} catch(Falha f) {
				atual = salvo;
				break;
			}
		}
	}
	
	void cmd() {
		int salvo = atual;
		try {
			terminal(Token.REPEAT);
			cmds();
			terminal(Token.UNTIL);
			exp();
		} catch(Falha f1) {
			atual = salvo;
			salvo = atual;
			try {
				terminal(Token.ID);
				terminal(Token.ATTRIB);
				exp();
			} catch(Falha f2) {
				atual = salvo;
				salvo = atual;
				try {
					terminal(Token.READ);
					terminal(Token.ID);
				} catch(Falha f3) {
					atual = salvo;
					salvo = atual;
					try {
						terminal(Token.WRITE);
						exp();
					} catch(Falha f4) {
						atual = salvo;
						terminal(Token.IF);
						exp();
						terminal(Token.THEN);
						cmds();
						salvo = atual;
						try {
							terminal(Token.ELSE);
							cmds();
						} catch(Falha f5) {
							atual = salvo;
						}
						terminal(Token.END);
					}
				}
			}
		}
	}
	
	void exp() {
		sexp();
		while(true) {
			int salvo = atual;
			try {
				int salvo_ = atual;
				try {
					terminal('<');
					sexp();
				} catch(Falha f1) {
					atual = salvo_;
					terminal('=');
					sexp();
				}
			} catch(Falha f2) {
				atual = salvo;
				break;
			}
		}
	}
	
	void sexp() {
		termo();
		while(true) {
			int salvo = atual;
			try {
				int salvo_ = atual;
				try {
					terminal('+');
					termo();
				} catch(Falha f1) {
					atual = salvo_;
					terminal('-');
					termo();
				}
			} catch(Falha f2) {
				atual = salvo;
				break;
			}
		}
		
	}
	
	void termo() {
		fator();
		while(true) {
			int salvo = atual;
			try {
				int salvo_ = atual;
				try {
					terminal('*');
					fator();
				} catch(Falha f1) {
					atual = salvo_;
					terminal('/');
					fator();
				}
			} catch(Falha f2) {
				atual = salvo;
				break;
			}
		}
	}
	
	void fator() {
		int salvo = atual;
		try {
			terminal('(');
			exp();
			terminal(')');
		} catch(Falha f1) {
			atual = salvo;
			salvo = atual;
			try {
				terminal(Token.ID);
			} catch(Falha f2) {
				atual = salvo;
				terminal(Token.NUM);
			}
		}
	}
}
