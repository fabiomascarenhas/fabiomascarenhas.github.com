
public class Token {
	public int tipo;
	public String lexeme;
	public int lin; // para mensagens de erro
	
	public final static int EOF = 0;
	public final static int NUM = 1;
	public final static int ID = 2;
	public final static int WRITE = 3;
	public final static int ATTRIB = 4;
	public final static int READ = 5;
	public final static int IF = 6;
	public final static int END = 7;
	public final static int THEN = 8;
	public final static int ELSE = 9;
	public final static int REPEAT = 10;
	public final static int UNTIL = 11;
	
	// outros: '(', ')', '+', ...
	
	public Token(int _tipo, String _lexeme, int _lin) {
		tipo = _tipo;
		lexeme = _lexeme;
		lin = _lin;
	}
	
	public String toString() {
		return "<" + tipo + "," + lexeme + "," + lin + ">";
	}
}
