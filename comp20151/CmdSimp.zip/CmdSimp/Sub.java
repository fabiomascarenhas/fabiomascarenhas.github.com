import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;


public class Sub implements Exp {
	public Exp exp1;
	public Exp exp2;
	public int lin;
	
	public Sub(Exp _exp1, Exp _exp2, int _lin) {
		exp1 = _exp1;
		exp2 = _exp2;
		lin = _lin;
	}

	public String toString() {
		return "(" + exp1 + "-" + exp2 + ")";
	}

	@Override
	public void codigo(List<String> vars, StringBuffer out) {
		exp1.codigo(vars, out);
		exp2.codigo(vars, out);
		out.append("isub\n");
	}

	@Override
	public BigInteger eval(HashMap<String, BigInteger> vars) {
		return exp1.eval(vars).subtract(exp2.eval(vars));
	}

}
