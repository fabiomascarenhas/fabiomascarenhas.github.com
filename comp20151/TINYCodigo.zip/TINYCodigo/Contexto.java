import java.util.List;
import java.util.Stack;

public class Contexto {
	StringBuffer buf;
	int proxLabel;
	int proxLoc;
	int marca;
	int nparams;
		
	String func;
	Stack<Integer> escopos;
	
	// Código para o programa completo
	public static String programa(List<String> globais, List<String> fnames, List<String> funcs) {
		StringBuffer buf = new StringBuffer();
		buf.append("extern _printf\n");
		buf.append("extern _scanf\n");
		buf.append("segment .data\n");
		buf.append("$fmt_printf db \"%d\",10,0\n");
		buf.append("$fmt_scanf db \"%d\",0\n");
		buf.append("segment .bss\n");
		for(String var: globais)
			buf.append(var + " resb 4\n"); 
		buf.append("segment .text\n");
		for(String fname: fnames)
			buf.append("global _" + fname + "\n");
		for(String func: funcs)
			buf.append(func);
		return buf.toString();
	}
	
	public Contexto(String _func, int _nparams) {
		buf = new StringBuffer();
		func = _func;
		proxLabel = 1;
		nparams = _nparams;
		marca = _nparams;
		proxLoc = 1;
		escopos = new Stack<Integer>();
	}
	
	public String codigo() {
		int slocs = (marca - nparams)*4;
		String codigo = buf.toString();
		codigo = "_" + func + ":\n" +
		         "  push ebp\n" +
				 "  mov ebp,esp\n" +
		         (slocs > 0 ? "  sub esp," + slocs + "\n" : "") +
		         codigo;
		codigo += "  mov esp, ebp\n" +
				  "  pop ebp\n" +
		          "  ret\n";
		return codigo;
	}

	public int label() {
		return proxLabel++;
	}

	public Local local() {
		return new Local(proxLoc++);
	}
	
	public void entraEscopo() {
		escopos.push(proxLoc);
	}
	
	public void saiEscopo() {
		if(proxLoc > marca)
			marca = proxLoc - 1;
		proxLoc = escopos.pop();
	}
	
	private void op(String inst) {
		buf.append("  " + inst + "\n");
	}

	private void op(String inst, String arg) {
		buf.append("  " + inst + " " + arg + "\n");
	}

	private void op(String inst, String arg1, String arg2) {
		buf.append("  " + inst + " " + arg1 + "," + arg2 + "\n");
	}

	public void icload(int i) {
		op("push", "eax");
		op("mov", "eax", "" + i);
	}
	
	public void getglobal(String nome) {
		op("push", "eax");
		op("mov", "eax", "[" + nome + "]");
	}
	
	public void putglobal(String nome) {
		op("mov", "[" + nome + "]", "eax");
		op("pop", "eax");
	}
	
	public void iload(int loc) {
		op("push", "eax");
		if(loc > nparams) {
			op("mov", "eax", "[ebp-" + (loc-nparams)*4 + "]");
		} else {
			op("mov", "eax", "[ebp+" + (loc+1)*4 + "]");
		}
	}

	public void istore(int loc) {
		if(loc > nparams) {
			op("mov", "[ebp-" + (loc-nparams)*4 + "]", "eax");
		} else {
			op("mov", "[ebp+" + (loc+1)*4 + "]", "eax");
		}
		op("pop", "eax");
	}
	
	public void iadd() {
		op("pop", "ebx");
		op("add", "eax", "ebx");
	}
	
	public void isub() {
		op("mov", "ebx", "eax");
		op("pop", "eax");
		op("sub", "eax", "ebx");
	}

	public void imul() {
		op("pop", "ebx");
		op("imul", "eax", "ebx");
	}

	public void idiv() {
		op("mov", "ebx", "eax");
		op("pop", "eax");
		op("cdq");
		op("idiv dword", "ebx");
	}
	
	public void pop() {
		op("pop", "eax");
	}
	
	public void invoke(String func, int nargs) {
		op("push", "eax");
		op("call", "_" + func);
		op("add", "esp", ""+(nargs*4));
	}
		
	public void if_icmpneq(int label) {
		op("mov", "edx", "eax");
		op("pop", "ebx");
		op("pop", "eax");
		op("cmp", "ebx", "edx");
		op("jne", "$" + func + label);
	}
	
	public void if_icmpge(int label) {
		op("mov", "edx", "eax");
		op("pop", "ebx");
		op("pop", "eax");
		op("cmp", "ebx", "edx");
		op("jge", "$" + func + label);
	}
	
	public void jmp(int label) {
		op("jmp", "$" + func + label);
	}
	
	public void read() {
		op("push", "eax");
		op("sub", "esp", "4");
		op("lea", "ebx", "[esp]");
		op("push", "ebx");
		op("push dword $fmt_scanf");
		op("call", "_scanf");
		op("add", "esp", "8");
		op("pop", "eax");
	}
	
	public void write() {
		op("push", "eax");
		op("push dword $fmt_printf");
		op("call", "_printf");
		op("add", "esp", "8");
		op("pop", "eax");
	}
	
	public void label(int label) {
		buf.append("$" + func + label + ":\n");
	}
		
}

