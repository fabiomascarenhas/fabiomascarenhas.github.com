
public class Write extends Node implements Cmd {
	public Exp exp;
	
	public Write(Exp _exp, int _lin) {
		super(_lin);
		exp = _exp;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		exp.checaEscopo(escopo, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		exp.tipo(vars, procs);
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		exp.codigo(ctx, vars); // empilha valor(exp)
		ctx.write();		   // desempilha e imprime
	}
}
