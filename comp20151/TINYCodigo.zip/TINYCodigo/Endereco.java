
public interface Endereco {
	void store(Contexto ctx);
	void load(Contexto ctx);
}
