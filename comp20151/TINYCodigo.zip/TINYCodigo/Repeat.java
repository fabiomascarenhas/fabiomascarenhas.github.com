public class Repeat extends Node implements Cmd {
	public Exp cond;
	public Bloco cmds;
	
	public Repeat(Exp _cond, Bloco _cmds, int _lin) {
		super(_lin);
		cond = _cond;
		cmds = _cmds;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		TabSimb<Boolean> escopoBloco = cmds.checaEscopo(escopo, escopoProcs);
		cond.checaEscopo(escopoBloco, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		TabSimb<Tipo> escopo = cmds.tipo(vars, procs);
		Tipo tcond = cond.tipo(escopo, procs);
		if(!tcond.subtipo(Bool.tipo)) {
			throw new RuntimeException("condição do repeat na linha " + lin + " não é booleano, mas " + tcond);
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		int linicio = ctx.label();
		ctx.label(linicio);
		TabSimb<Endereco> escopo = cmds.codigo(ctx, vars);
		cond.codigoSaltoF(ctx, escopo, linicio);
	}
}
