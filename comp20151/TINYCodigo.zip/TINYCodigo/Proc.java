import java.util.List;

public class Proc extends Node {
	public String id;
	public Bloco cmds;
	public List<String> params = new java.util.ArrayList<String>();
	public List<Tipo> tparams = new java.util.ArrayList<Tipo>();
	public Tipo tret;
	
	public Proc(String _id, List<Decl> _params, Tipo _tret, Bloco _cmds, int _lin) {
		super(_lin);
		id = _id;
		cmds = _cmds;
		for(Decl decl: _params) {
			for(String nome: decl.vars) {
				params.add(nome);
				tparams.add(decl.tipo);
			}
		}
		tret = _tret;
	}
	
	public void checaEscopo(TabSimb<Boolean> globais, TabSimb<Boolean> procs) {
		TabSimb<Boolean> escopo = new TabSimb<Boolean>(globais);
		if(!(tret instanceof Void)) {
			escopo.inserir(id, true, lin);
		}
		for(int i = 0; i < params.size(); i++) {
			escopo.inserir(params.get(i), true, lin);
		}
		cmds.checaEscopo(escopo, procs);
	}
	
	public void tipo(TabSimb<Tipo> globais, TabSimb<Proc> procs) {
		TabSimb<Tipo> escopo = new TabSimb<Tipo>(globais);
		if(!(tret instanceof Void)) {
			escopo.inserir(id, tret, lin);
		}
		for(int i = 0; i < params.size(); i++) {
			escopo.inserir(params.get(i), tparams.get(i), lin);
		}
		cmds.tipo(escopo, procs);
	}

	public String codigo(TabSimb<Endereco> globais) {
		Contexto ctx = new Contexto(id, params.size());
		TabSimb<Endereco> escopo = new TabSimb<Endereco>(globais);
		for(int i = 0; i < params.size(); i++) {
			escopo.inserir(params.get(i), ctx.local(), lin);
		}
		Endereco eret = ctx.local();
		if(!(tret instanceof Void)) {
			escopo.inserir(id, eret, lin);
		}
		cmds.codigo(ctx, escopo);
		if(!(tret instanceof Void)) {
			eret.load(ctx);
		} else {
			ctx.icload(0);
		}
		return ctx.codigo();
	}
}
