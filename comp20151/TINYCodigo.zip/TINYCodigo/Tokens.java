// Output created by jacc on Mon Jun 08 11:43:07 BRT 2015

interface Tokens {
    int ENDINPUT = 0;
    int ATTRIB = 1;
    int BOOL = 2;
    int ELSE = 3;
    int END = 4;
    int FALSE = 5;
    int ID = 6;
    int IF = 7;
    int INT = 8;
    int NUM = 9;
    int PROCEDURE = 10;
    int READ = 11;
    int REAL = 12;
    int REPEAT = 13;
    int THEN = 14;
    int TRUE = 15;
    int UNTIL = 16;
    int VAR = 17;
    int WRITE = 18;
    int error = 19;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
