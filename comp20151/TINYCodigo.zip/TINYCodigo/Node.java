import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.List;

public abstract class Node {
	int lin;
	
	public Node(int _lin) {
		lin = _lin;
	}
	
	public int printDot(BufferedWriter buf, int count) throws IOException, IllegalArgumentException, IllegalAccessException {
		int me = count;
		buf.write(String.valueOf(me));
		buf.write(" [label=\"");
		buf.write(this.getClass().toString());
		buf.write("\",shape=box];");
		for(Field f: this.getClass().getFields()) {
			Object o = f.get(this);
			if(o instanceof Node) {
				Node n = (Node)o;
				count++;
				buf.write(String.valueOf(me));
				buf.write("->");
				buf.write(String.valueOf(count));
				buf.write(";\n");
				count = n.printDot(buf, count);
			} else if(o instanceof List) {
				List<Object> ln = (List<Object>)o;
				for(Object oo: ln) {
					if(oo instanceof Node) {
						Node n = (Node)oo;
						count++;
						buf.write(String.valueOf(me));
						buf.write("->");
						buf.write(String.valueOf(count));
						buf.write(";\n");
						count = n.printDot(buf, count);
					} else {
						count++;
						buf.write(String.valueOf(me));
						buf.write("->");
						buf.write(String.valueOf(count));
						buf.write(";\n");
						buf.write(String.valueOf(count));
						buf.write(" [label=\"");
						buf.write(oo.toString());
						buf.write("\",shape=box];");
					}
				}
			} else {
				count++;
				buf.write(String.valueOf(me));
				buf.write("->");
				buf.write(String.valueOf(count));
				buf.write(";\n");
				buf.write(String.valueOf(count));
				buf.write(" [label=\"");
				buf.write(o.toString());
				buf.write("\",shape=box];");
			}
		}
		return count;
	}
	
	public void printDot(String fileName) throws IOException, IllegalArgumentException, IllegalAccessException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write("digraph tree {\n");
		printDot(buf, 0);
		buf.write("}");
		buf.close();
	}
}
