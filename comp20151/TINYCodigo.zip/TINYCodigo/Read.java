
public class Read extends Node implements Cmd {
	public String id;
	
	public Read(String _id, int _lin) {
		super(_lin);
		id = _id;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		escopo.procurar(id, lin);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo tid = vars.procurar(id, lin);
		if(!(tid instanceof Int)) {
			throw new RuntimeException("variável do read não é inteira na linha " + lin);
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.read(); // empilha um número inteiro lido do console
		Endereco var = vars.procurar(id, lin);
		var.store(ctx); // desempilha e escreve
	}
}
