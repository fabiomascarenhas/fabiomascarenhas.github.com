
public interface Exp {
	void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs);
	Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs);
	void codigo(Contexto ctx, TabSimb<Endereco> vars);
	void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label);
}
