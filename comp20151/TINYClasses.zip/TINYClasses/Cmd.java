
public interface Cmd {
	void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs);
	void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs);
	void codigo(Contexto ctx, TabSimb<Endereco> vars);
}
