
public class Skip extends Node implements Cmd {

	public Skip(int _lin) {
		super(_lin);
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
	}

}
