
public class Eq extends BinExp {
	public Eq(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo t1 = e1.tipo(vars, procs);
		Tipo t2 = e2.tipo(vars, procs);
		if(t1.subtipo(t2)) {
			return Bool.tipo;
		}
		if(t2.subtipo(t1)) {
			return Bool.tipo;
		}
		throw new RuntimeException("tipos inválidos na igualdade na linha " + lin +
				": " + t1 + " e " + t2);
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		int lfim = ctx.label();
		int lfalso = ctx.label();
		e1.codigo(ctx, vars);
		e2.codigo(ctx, vars);
		ctx.if_icmpneq(lfalso);
		ctx.icload(1);
		ctx.jmp(lfim);
		ctx.label(lfalso); // lfalso:
		ctx.icload(0);
		ctx.label(lfim);
	}

	@Override
	public void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label) {
		e1.codigo(ctx, vars);
		e2.codigo(ctx, vars);
		ctx.if_icmpneq(label);
	}
}
