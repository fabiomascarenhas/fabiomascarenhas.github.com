// Output created by jacc on Wed Jul 01 20:52:47 BRT 2015

interface Tokens {
    int ENDINPUT = 0;
    int ATTRIB = 1;
    int BOOL = 2;
    int CLASS = 3;
    int ELSE = 4;
    int END = 5;
    int FALSE = 6;
    int ID = 7;
    int IF = 8;
    int INT = 9;
    int IS = 10;
    int NEW = 11;
    int NUM = 12;
    int PROCEDURE = 13;
    int READ = 14;
    int REAL = 15;
    int REPEAT = 16;
    int SKIP = 17;
    int THEN = 18;
    int THIS = 19;
    int TRUE = 20;
    int UNTIL = 21;
    int VAR = 22;
    int WRITE = 23;
    int error = 24;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '.' (code=46)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
