
public class Token implements Tokens {
	public int tipo;
	public String lexeme;
	public int lin; // para mensagens de erro
	
	public final static int EOF = 0;
	
	// outros: '(', ')', '+', ...
	
	public Token(int _tipo, String _lexeme, int _lin) {
		tipo = _tipo;
		lexeme = _lexeme;
		lin = _lin;
	}
	
	public String toString() {
		return "<" + tipo + "," + lexeme + "," + lin + ">";
	}
	
	public String nomeTipo() {
		if(tipo == ID) {
			return "id";
		}
		if(tipo == NUM) {
			return "num";
		}
		return lexeme;
	}
}
