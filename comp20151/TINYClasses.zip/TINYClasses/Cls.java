
public class Cls extends Node implements Tipo {
	public String nome;
	
	public Cls(String _nome, int _lin) {
		super(_lin);
		nome = _nome;
	}
	
	public boolean subtipo(Tipo t) {
		if(t instanceof Cls) {
			Classe c1 = Classe.classes.get(nome);
			if(c1 == null) {
				throw new RuntimeException("tipo " + nome + " na linha " + lin + " não existe");
			}
			Classe c2 = Classe.classes.get(((Cls)t).nome);
			if(c2 == null) {
				throw new RuntimeException("tipo " + ((Cls)t).nome + " na linha " + ((Cls)t).lin + " não existe");
			}
			return c1.subclasse(c2);
		}
		return false;
	}
	
	public String toString() {
		return nome;
	}
}
