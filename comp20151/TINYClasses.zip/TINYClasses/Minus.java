
public class Minus extends ArithExp {
	public Minus(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}

	@Override
	void op(Contexto ctx) {
		ctx.isub();
	}
}
