
public class This extends Node implements Exp {

	public This(int lin) {
		super(lin);
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		escopoVars.procurar("this", lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		return vars.procurar("this", lin);
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.iload(1);
	}

	@Override
	public void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label) {
	}

}
