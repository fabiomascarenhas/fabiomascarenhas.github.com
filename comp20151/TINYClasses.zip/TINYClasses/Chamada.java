import java.util.List;

public class Chamada extends Node implements Cmd {
	public String id;
	public List<Exp> args;
	
	public Chamada(String _id, List<Exp> _args, int _lin) {
		super(_lin);
		id = _id;
		args = _args;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		escopoProcs.procurar(id, lin);
		for(Exp arg: args) {
			arg.checaEscopo(escopoVars, escopoProcs);
		}
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Proc proc = procs.procurar(id, lin);
		if(args.size() != proc.params.size()) {
			throw new RuntimeException("erro de aridade na linha " + lin +
					", esperados " + proc.params.size() + 
					", passados " + args.size());
			
		}
		for(int i = 0; i < args.size(); i++) {
			Tipo targ = args.get(i).tipo(vars, procs);
			Tipo tparam = proc.tparams.get(i);
			if(!targ.subtipo(tparam)) {
				throw new RuntimeException("tipo do parâmetro " + i + 
						" inválido na linha " + lin + ", esperado "
						+ tparam + ", passado " + targ);
			}
		}
		if(!(proc.tret instanceof Void)) {
			throw new RuntimeException("chamada de procedimento ignorando valor de retorno na linha " + lin);
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		for(int i = args.size()-1; i >= 0; i--) {
			args.get(i).codigo(ctx, vars); // empilha arg(i)
		}
		ctx.invoke(id, args.size()); // desempilha os argumentos,
		                             // chama id(args), 
						             // empilhar valor de retorno
		ctx.pop();                   // joga fora valor de retorno
	}
}
