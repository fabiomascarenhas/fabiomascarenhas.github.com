import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Classe {
	public String nome;
	public String sup;
	public List<Tipo> campos;
	public List<String> ncampos;
	public List<Proc> metodos;
	
	boolean fechada = false;

	public Endereco vtable;
	
	public static Map<String, Classe> classes = new
			HashMap<String, Classe>();
	
	public Classe(String _nome, String _sup, Bloco _campos, List<Proc> _metodos) {
		nome = _nome;
		sup = _sup;
		campos = new ArrayList<Tipo>();
		ncampos = new ArrayList<String>();
		for(Decl decl: _campos.vars) {
			for(String var: decl.vars) {
				ncampos.add(var);
				campos.add(decl.tipo);
			}
		}
		metodos = _metodos;
	}
	
	public void fecho() {
		if(fechada) return;
		if(sup != null) {
			Classe csup = Classe.classes.get(sup);
			csup.fecho();
			List<String> fncampos = new ArrayList<String>();
			fncampos.addAll(csup.ncampos);
			for(String campo: ncampos) {
				if(fncampos.contains(campo)) {
					throw new RuntimeException("campo " + campo + " redeclarado na classe " + nome);
				} else {
					fncampos.add(campo);
				}
			}
			ncampos = fncampos;
			List<Tipo> fcampos = new ArrayList<Tipo>();
			fcampos.addAll(csup.campos);
			fcampos.addAll(campos);
			campos = fcampos;
			List<Proc> fmetodos = new ArrayList<Proc>();
			fmetodos.addAll(csup.metodos);
			for(Proc metodo: metodos) {
				Proc redefinido = null;
				for(Proc m: fmetodos) {
					if(m.id.equals(metodo.id)) {
						redefinido = m;
						if(m.params.size() == metodo.params.size()) {
							for(int i = 0; i < m.params.size(); i++) {
								if(!m.tparams.get(i).subtipo(metodo.tparams.get(i))) {
									throw new RuntimeException("parâmetro " + i + " na redefinição do método " + m.id + " na classe " + nome + " tem tipos incompatíveis");
								}
							}
						} else {
							throw new RuntimeException("método " + m.id + " redeclarado na classe " + nome + " tem aridade diferente");
						}
						if(!metodo.tret.subtipo(m.tret)) {
							throw new RuntimeException("tipo de retorno incompatível na redefinição do método " + m.id + " na classe " + nome);						}
					}
				}
				if(redefinido != null) {
					// Toma o lugar do método original
					int i = fmetodos.indexOf(redefinido);
					fmetodos.set(i, metodo);
				} else {
					fmetodos.add(metodo);
				}
			}
			metodos = fmetodos;
		}
		fechada = true;
	}
	
	public boolean subclasse(Classe c) {
		if(this == c)
			return true;
		if(sup != null) {
			if(sup.equals(c.nome))
				return true;
			Classe csup = Classe.classes.get(sup);
			return csup.subclasse(c);
		} else {
			return false;
		}
	}

	public Proc metodo(String id) {
		for(Proc metodo: metodos) {
			if(id.equals(metodo.id))
				return metodo;
		}
		return null;
	}
}
