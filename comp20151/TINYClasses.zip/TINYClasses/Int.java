
public class Int extends Node implements Tipo {
	static Tipo tipo = new Int(0);
	
	public Int(int lin) {
		super(lin);
	}

	public boolean subtipo(Tipo t) {
		return t instanceof Int || t instanceof Real;
	}

	public String toString() {
		return "int";
	}
}
