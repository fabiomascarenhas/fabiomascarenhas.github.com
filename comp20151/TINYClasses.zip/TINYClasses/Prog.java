import java.util.ArrayList;
import java.util.List;

public class Prog extends Node {
	public List<Proc> procs;
	public Bloco cmds;
	
	public Prog(List<Proc> _procs, Bloco _cmds, int _lin) {
		super(_lin);
		procs = _procs;
		cmds = _cmds;
	}
	
	void checaEscopo() {
		// Fechar as classes
		for(Classe classe: Classe.classes.values()) {
			classe.fecho();
		}
		// Primeira passada - coleta de nomes globais
		TabSimb<Boolean> escProcs = new TabSimb<Boolean>();
		for(Proc proc: procs) {
			escProcs.inserir(proc.id, true, proc.lin);
		}
		TabSimb<Boolean> globais = new TabSimb<Boolean>();
		for(Decl decl: cmds.vars) {
			for(String id: decl.vars) {
				globais.inserir(id, true, cmds.lin);
			}
		}
		// Segunda passada - verificação de escopo
		for(Proc proc: procs) {
			proc.checaEscopo(globais, escProcs);
		}
		cmds.checaEscopo(null, escProcs);
		for(Classe classe: Classe.classes.values()) {
			for(Proc metodo: classe.metodos) {
				TabSimb<Boolean> escopo = new TabSimb<Boolean>(globais);
				escopo.inserir("this", true, 0);
				metodo.checaEscopo(escopo, escProcs);
			}
		}
	}
	
	void checaTipo() {
		// Primeira passada - coleta de nomes globais
		TabSimb<Proc> escProcs = new TabSimb<Proc>();
		for(Proc proc: procs) {
			escProcs.inserir(proc.id, proc, proc.lin);
		}
		TabSimb<Tipo> globais = new TabSimb<Tipo>();
		for(Decl decl: cmds.vars) {
			for(String id: decl.vars) {
				globais.inserir(id, decl.tipo, cmds.lin);
			}
		}
		for(Proc proc: procs) {
			proc.tipo(globais, escProcs);
		}
		cmds.tipo(null, escProcs);
		for(Classe classe: Classe.classes.values()) {
			for(Proc metodo: classe.metodos) {
				TabSimb<Tipo> escopo = new TabSimb<Tipo>(globais);
				escopo.inserir("this", new Cls(classe.nome, 0), 0);
				metodo.tipo(escopo, escProcs);
			}
		}
	}
	
	String codigo() {
		ArrayList<String> cprocs = new ArrayList<String>();
		ArrayList<String> nprocs = new ArrayList<String>();
		ArrayList<String> nglobais = new ArrayList<String>();
		TabSimb<Endereco> globais = new TabSimb<Endereco>();
		for(Decl decl: cmds.vars) {
			for(String id: decl.vars) {
				nglobais.add(id);
				globais.inserir(id, new Global(id), cmds.lin);
			}
		}
		for(Proc proc: procs) {
			nprocs.add(proc.id);
			cprocs.add(proc.codigo(globais));
		}
		for(Classe classe: Classe.classes.values()) {
			String vtable = "_$_" + classe.nome + "_$vtable";
			classe.vtable = new Global(vtable);
			nglobais.add(vtable);
			globais.inserir(vtable, classe.vtable, 0);
		}
		for(Classe classe: Classe.classes.values()) {
			for(Proc metodo: classe.metodos) {
				if(!nprocs.contains("_$m_" + metodo.toString())) {
					Contexto cmetodo = new Contexto("_$m_" + metodo.toString(), metodo.params.size() + 1);
					cmetodo.local(); // reserva espaço para o this
					nprocs.add("_$m_" + metodo.toString());
					cprocs.add(metodo.codigo(cmetodo, globais));
				}
			}
		}
		Contexto cmain = new Contexto("main", 0);
		for(Classe classe: Classe.classes.values()) {
			cmain.newrec(classe.metodos.size());
			int i = 1;
			for(Proc metodo: classe.metodos) {
				cmain.getglobaladdr("__$m_" + metodo.toString());
				cmain.stfld(i++);
			}
			classe.vtable.store(cmain);
		}
		for(Cmd cmd: cmds.cmds) {
			cmd.codigo(cmain, globais);
		}
		cmain.icload(0);
		nprocs.add("main");
		cprocs.add(cmain.codigo());
		return Contexto.programa(nglobais, nprocs, cprocs);
	}
}
 