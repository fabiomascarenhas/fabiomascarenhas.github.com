
public interface Scanner {
	Token token();
}
