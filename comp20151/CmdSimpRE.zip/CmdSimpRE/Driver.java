import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Driver {
	public static void main(String[] args) throws IOException {
		File f = new File(args[0]);
		FileReader fr = new FileReader(f);
		ScannerRE scan = new ScannerRE(fr);
		scan.space("[\t\n\r ]+");
		scan.rule("[pP][rR][iI][nN][tT]", 3);
		scan.rule("[a-zA-Z_][a-zA-Z0-9_]*", 2);
		scan.rule("[0-9]+", 1);
		scan.rule("[+]", '+');
		scan.rule("[-]", '-');
		scan.rule("[(]", '(');
		scan.rule("[)]", ')');
		scan.rule("[=]", '=');
		scan.rule("[;]", ';');
		Parser parser = new Parser(scan);
		Prog prog = parser.prog();
		System.out.println(prog.toString());
		String fname = f.getName();
		prog.run();
		prog.codigo(fname.substring(0, fname.lastIndexOf('.')));
	}
}
