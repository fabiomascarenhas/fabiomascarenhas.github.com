
public abstract class ArithExp extends BinExp {
	public ArithExp(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo t1 = e1.tipo(vars, procs);
		Tipo t2 = e2.tipo(vars, procs);
		if(t1.subtipo(Int.tipo) && t2.subtipo(Int.tipo)) {
			return Int.tipo;
		}
		if(t1.subtipo(Real.tipo) && t2.subtipo(Real.tipo)) {
			return Real.tipo;
		}
		throw new RuntimeException("tipos inválidos em expressão aritmética na linha " + lin +
				": " + t1 + " e " + t2);
	}
	
	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		e1.codigo(ctx, vars); // empilhou valor(e1)
		e2.codigo(ctx, vars); // empilhou valor(e2)
		op(ctx);              // desempilhar valor(e2) e valor(e1),
						      //   empilhar (valor(e1) op valor(e2))
		// efeito final: empilhar (valor(e1) op valor(e2)) =
		//                              valor(e1 op e2)
	}
	
	@Override
	public void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label) {
		throw new RuntimeException("bug na análise de tipos na expressão da linha " + lin);
	}
	
	abstract void op(Contexto ctx);
}
