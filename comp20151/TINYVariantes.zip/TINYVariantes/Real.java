
public class Real extends Node implements Tipo {
	static Tipo tipo = new Real(0);
	
	public Real(int lin) {
		super(lin);
	}

	public boolean subtipo(Tipo t) {
		return t instanceof Real;
	}
	
	public String toString() {
		return "real";
	}
}
