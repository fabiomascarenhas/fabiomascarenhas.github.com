
public class RamoCase extends Node {
	String reg;
	Bloco bloco;
	
	public RamoCase(String _reg, Bloco _bloco, int lin) {
		super(lin);
		reg = _reg;
		bloco = _bloco;
	}

}
