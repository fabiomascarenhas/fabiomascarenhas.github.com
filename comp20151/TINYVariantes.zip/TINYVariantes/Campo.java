
public class Campo extends Node implements Exp {
	Exp reg;
	String campo;
	
	int ncampo;
	
	public Campo(Exp _reg, String _campo, int _lin) {
		super(_lin);
		reg = _reg;
		campo = _campo;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		reg.checaEscopo(escopoVars, escopoProcs);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo treg = reg.tipo(vars, procs);
		if(treg instanceof Reg) {
			Registro r = Registro.registros.get(((Reg)treg).nome);
			if(r == null) {
				throw new RuntimeException("registro " + ((Reg)treg).nome + " não existe na linha " + lin);
			}
			int i = r.ncampos.indexOf(campo);
			ncampo = i;
			if(i == -1) {
				throw new RuntimeException("campo " + campo + " não existe em " + ((Reg)treg).nome + " não existe na linha " + lin);
			}
			return r.campos.get(i);
		} else {
			throw new RuntimeException("" + treg + " não é um registro na linha " + lin);
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		reg.codigo(ctx, vars);
		ctx.ldfld(ncampo+2);
	}

	@Override
	public void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label) {
		ctx.icload(0);
		this.codigo(ctx, vars);
		ctx.if_icmpge(label);
	}

}
