
public class Void extends Node implements Tipo {
	public Void(int lin) {
		super(lin);
	}
	
	public String toString() {
		return "void";
	}

	@Override
	public boolean subtipo(Tipo t) {
		return t instanceof Void;
	}
}
