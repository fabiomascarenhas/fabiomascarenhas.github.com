// Output created by jacc on Mon Jun 29 11:06:34 BRT 2015

interface Tokens {
    int ENDINPUT = 0;
    int ATTRIB = 1;
    int BOOL = 2;
    int CASE = 3;
    int ELSE = 4;
    int END = 5;
    int FALSE = 6;
    int ID = 7;
    int IF = 8;
    int INT = 9;
    int IS = 10;
    int NEW = 11;
    int NUM = 12;
    int PROCEDURE = 13;
    int READ = 14;
    int REAL = 15;
    int RECORD = 16;
    int REPEAT = 17;
    int SKIP = 18;
    int THEN = 19;
    int TRUE = 20;
    int UNTIL = 21;
    int VAR = 22;
    int VARIANT = 23;
    int WRITE = 24;
    int error = 25;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '.' (code=46)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
