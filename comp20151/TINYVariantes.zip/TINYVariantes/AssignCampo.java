
public class AssignCampo extends Node implements Cmd {
	Exp reg;
	String campo;
	Exp rval;
	
	int ncampo;
	
	public AssignCampo(Exp _reg, String _campo, Exp _rval, int _lin) {
		super(_lin);
		reg = _reg;
		campo = _campo;
		rval = _rval;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		reg.checaEscopo(escopoVars, escopoProcs);
		rval.checaEscopo(escopoVars, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo treg = reg.tipo(vars, procs);
		if(treg instanceof Reg) {
			Registro r = Registro.registros.get(((Reg)treg).nome);
			if(r == null) {
				throw new RuntimeException("registro " + ((Reg)treg).nome + " não existe na linha " + lin);
			}
			int i = r.ncampos.indexOf(campo);
			if(i == -1) {
				throw new RuntimeException("campo " + campo + " não existe em " + ((Reg)treg).nome + " não existe na linha " + lin);
			}
			ncampo = i;
			Tipo tcampo = r.campos.get(i);
			Tipo trval = rval.tipo(vars, procs); 
			if(!trval.subtipo(tcampo)) {
				throw new RuntimeException("" + trval + " incompatível com " + tcampo + " na linha " + lin);
			}
		} else {
			throw new RuntimeException("" + treg + " não é um registro na linha " + lin);
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		reg.codigo(ctx, vars); // empilha endereço do registro
		rval.codigo(ctx, vars); // empilha valor
		ctx.stfld(ncampo+2);
		ctx.pop();
	}

}
