import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Registro {
	public String nome;
	public List<Tipo> campos;
	public List<String> ncampos;
	
	public static Map<String, Registro> registros = new
			HashMap<String, Registro>();
	
	public Registro(String _nome, List<Decl> decls) {
		nome = _nome;
		campos = new ArrayList<Tipo>();
		ncampos = new ArrayList<String>();
		for(Decl decl: decls) {
			for(String var: decl.vars) {
				ncampos.add(var);
				campos.add(decl.tipo);
			}
		}
	}
	
	public boolean subtipo(Variante v) {
		return v.membros.contains(this.nome);
	}
}
