import java.util.List;

public class Cons extends Node implements Exp {
	public String id;
	public List<Exp> args;
	
	public Cons(String _id, List<Exp> _args, int _lin) {
		super(_lin);
		id = _id;
		args = _args;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		for(Exp arg: args) {
			arg.checaEscopo(escopoVars, escopoProcs);
		}
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Registro r = Registro.registros.get(id);
		if(r == null) {
			throw new RuntimeException("registro " + id + " não existe na linha " + lin);
		}
		if(args.size() != r.campos.size()) {
			throw new RuntimeException("erro de aridade na linha " + lin +
					", esperados " + r.campos.size() + 
					", passados " + args.size());
			
		}
		for(int i = 0; i < args.size(); i++) {
			Tipo targ = args.get(i).tipo(vars, procs);
			Tipo tparam = r.campos.get(i);
			if(!targ.subtipo(tparam)) {
				throw new RuntimeException("tipo do parâmetro " + i + 
						" inválido na linha " + lin + ", esperado "
						+ tparam + ", passado " + targ);
			}
		}
		return new Reg(id, lin);
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		Registro r = Registro.registros.get(id);
		ctx.newrec(r.campos.size()+1);
		ctx.icload(r.hashCode()); // trocar depois para algo garantidamente único
		ctx.stfld(1);
		for(int i = 0; i < args.size(); i++) {
			args.get(i).codigo(ctx, vars); // empilha arg(i)
			ctx.stfld(i+2);
		}
	}

	@Override
	public void codigoSaltoF(Contexto ctx, TabSimb<Endereco> vars, int label) {	}
}
