import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Variante {
	public String nome;
	public List<String> membros;

	public static Map<String, Variante> variantes = new
			HashMap<String, Variante>();

	public Variante(String _nome, List<String> _membros) {
		nome = _nome;
		membros = _membros;
	}
	
	public boolean subtipo(Variante v) {
		for(String reg: membros) {
			if(!Registro.registros.get(reg).subtipo(v))
				return false;
		}
		return true;
	}
}
