import java.util.List;

public class Decl extends Node {
	public List<String> vars;
	public Tipo tipo;
	
	public Decl(List<String> _vars, Tipo _tipo, int lin) {
		super(lin);
		vars = _vars;
		tipo = _tipo;
	}
}
