// Output created by jacc on Mon Jun 29 11:06:33 BRT 2015


class ParserJACC implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 276;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    switch (yytok) {
                        case ';':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    switch (yytok) {
                        case ';':
                            yyn = 13;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    switch (yytok) {
                        case ';':
                            yyn = 14;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    yyn = yys7();
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ID:
                            yyn = 25;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case ID:
                            yyn = 31;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    yyn = yys12();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys13();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    yyn = yys14();
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    yyn = yys15();
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    switch (yytok) {
                        case '.':
                            yyn = 38;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case ID:
                            yyn = 39;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 40;
                            continue;
                        case '(':
                            yyn = 41;
                            continue;
                        case '.':
                            yyn = yyr58();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case ID:
                            yyn = 49;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    yyn = yys21();
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    yyn = yys22();
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    yyn = yys23();
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys24();
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    switch (yytok) {
                        case '(':
                            yyn = 53;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    switch (yytok) {
                        case IS:
                            yyn = 54;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    switch (yytok) {
                        case ',':
                            yyn = 55;
                            continue;
                        case ';':
                            yyn = 56;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    switch (yytok) {
                        case ',':
                            yyn = 57;
                            continue;
                        case ':':
                            yyn = 58;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    switch (yytok) {
                        case ',':
                        case END:
                        case ':':
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    switch (yytok) {
                        case IS:
                            yyn = 59;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    switch (yytok) {
                        case ';':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    switch (yytok) {
                        case ';':
                            yyn = 60;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case ID:
                            yyn = 61;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    switch (yytok) {
                        case IF:
                            yyn = 64;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    switch (yytok) {
                        case '.':
                            yyn = 76;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    yyn = yys45();
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    switch (yytok) {
                        case ID:
                            yyn = 78;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    yyn = yys48();
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    yyn = yys49();
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case UNTIL:
                            yyn = 79;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    yyn = yys51();
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                        case ')':
                            yyn = 82;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    switch (yytok) {
                        case ID:
                            yyn = 85;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    switch (yytok) {
                        case BOOL:
                            yyn = 87;
                            continue;
                        case ID:
                            yyn = 88;
                            continue;
                        case INT:
                            yyn = 89;
                            continue;
                        case REAL:
                            yyn = 90;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 93;
                            continue;
                        case '.':
                            yyn = yyr57();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    switch (yytok) {
                        case IF:
                            yyn = 64;
                            continue;
                        case END:
                            yyn = 95;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    switch (yytok) {
                        case END:
                        case IF:
                            yyn = yyr40();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    switch (yytok) {
                        case ID:
                            yyn = 96;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 204:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 205:
                    switch (yytok) {
                        case ')':
                            yyn = 97;
                            continue;
                        case ',':
                            yyn = 98;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 206:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 207:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 208:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 209:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 210:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 211:
                    yyn = yys73();
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 212:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 213:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 214:
                    switch (yytok) {
                        case ID:
                            yyn = 106;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 215:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 216:
                    switch (yytok) {
                        case '(':
                            yyn = 109;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 217:
                    yyn = yys79();
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 218:
                    switch (yytok) {
                        case '.':
                            yyn = yyr59();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 219:
                    switch (yytok) {
                        case ',':
                            yyn = 55;
                            continue;
                        case ')':
                            yyn = 111;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 220:
                    yyn = yys82();
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 221:
                    switch (yytok) {
                        case ',':
                            yyn = 55;
                            continue;
                        case END:
                            yyn = 114;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 222:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 223:
                    switch (yytok) {
                        case ',':
                        case END:
                        case ':':
                            yyn = yyr26();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 224:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr21();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 225:
                    yyn = yys87();
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 226:
                    yyn = yys88();
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 227:
                    yyn = yys89();
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 228:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 229:
                    switch (yytok) {
                        case ',':
                            yyn = 57;
                            continue;
                        case END:
                            yyn = 115;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 230:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 231:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 232:
                    switch (yytok) {
                        case END:
                        case IF:
                            yyn = yyr39();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 233:
                    yyn = yys95();
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 234:
                    switch (yytok) {
                        case THEN:
                            yyn = 117;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 235:
                    yyn = yys97();
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 236:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 237:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ELSE:
                            yyn = 119;
                            continue;
                        case END:
                            yyn = 120;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 238:
                    yyn = yys100();
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 239:
                    yyn = yys101();
                    continue;

                case 102:
                    yyst[yysp] = 102;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 240:
                    yyn = yys102();
                    continue;

                case 103:
                    yyst[yysp] = 103;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 241:
                    yyn = yys103();
                    continue;

                case 104:
                    yyst[yysp] = 104;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 242:
                    yyn = yys104();
                    continue;

                case 105:
                    yyst[yysp] = 105;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 243:
                    yyn = yys105();
                    continue;

                case 106:
                    yyst[yysp] = 106;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 244:
                    yyn = yys106();
                    continue;

                case 107:
                    yyst[yysp] = 107;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 245:
                    switch (yytok) {
                        case ',':
                            yyn = 98;
                            continue;
                        case ')':
                            yyn = 121;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 108:
                    yyst[yysp] = 108;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 246:
                    yyn = yys108();
                    continue;

                case 109:
                    yyst[yysp] = 109;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 247:
                    yyn = yys109();
                    continue;

                case 110:
                    yyst[yysp] = 110;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 248:
                    yyn = yys110();
                    continue;

                case 111:
                    yyst[yysp] = 111;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 249:
                    yyn = yys111();
                    continue;

                case 112:
                    yyst[yysp] = 112;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 250:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 126;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 113:
                    yyst[yysp] = 113;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 251:
                    switch (yytok) {
                        case BOOL:
                            yyn = 87;
                            continue;
                        case ID:
                            yyn = 88;
                            continue;
                        case INT:
                            yyn = 89;
                            continue;
                        case REAL:
                            yyn = 90;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 114:
                    yyst[yysp] = 114;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 252:
                    switch (yytok) {
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 115:
                    yyst[yysp] = 115;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 253:
                    switch (yytok) {
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 116:
                    yyst[yysp] = 116;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 254:
                    yyn = yys116();
                    continue;

                case 117:
                    yyst[yysp] = 117;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 255:
                    yyn = yys117();
                    continue;

                case 118:
                    yyst[yysp] = 118;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 256:
                    yyn = yys118();
                    continue;

                case 119:
                    yyst[yysp] = 119;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 257:
                    yyn = yys119();
                    continue;

                case 120:
                    yyst[yysp] = 120;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 258:
                    yyn = yys120();
                    continue;

                case 121:
                    yyst[yysp] = 121;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 259:
                    yyn = yys121();
                    continue;

                case 122:
                    yyst[yysp] = 122;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 260:
                    switch (yytok) {
                        case ',':
                            yyn = 98;
                            continue;
                        case ')':
                            yyn = 130;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 123:
                    yyst[yysp] = 123;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 261:
                    yyn = yys123();
                    continue;

                case 124:
                    yyst[yysp] = 124;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 262:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 131;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 125:
                    yyst[yysp] = 125;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 263:
                    switch (yytok) {
                        case BOOL:
                            yyn = 87;
                            continue;
                        case ID:
                            yyn = 88;
                            continue;
                        case INT:
                            yyn = 89;
                            continue;
                        case REAL:
                            yyn = 90;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 126:
                    yyst[yysp] = 126;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 264:
                    switch (yytok) {
                        case ';':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 127:
                    yyst[yysp] = 127;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 265:
                    yyn = yys127();
                    continue;

                case 128:
                    yyst[yysp] = 128;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 266:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                        case IF:
                            yyn = yyr41();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 129:
                    yyst[yysp] = 129;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 267:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 134;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 130:
                    yyst[yysp] = 130;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 268:
                    yyn = yys130();
                    continue;

                case 131:
                    yyst[yysp] = 131;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 269:
                    switch (yytok) {
                        case ';':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 132:
                    yyst[yysp] = 132;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 270:
                    yyn = yys132();
                    continue;

                case 133:
                    yyst[yysp] = 133;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 271:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 136;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 134:
                    yyst[yysp] = 134;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 272:
                    yyn = yys134();
                    continue;

                case 135:
                    yyst[yysp] = 135;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 273:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 137;
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 136:
                    yyst[yysp] = 136;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 274:
                    switch (yytok) {
                        case ';':
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 137:
                    yyst[yysp] = 137;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 275:
                    switch (yytok) {
                        case ';':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 279;
                    continue;

                case 276:
                    return true;
                case 277:
                    yyerror("stack overflow");
                case 278:
                    return false;
                case 279:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case RECORD:
                return 9;
            case VAR:
                return 10;
            case VARIANT:
                return 11;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys7() {
        switch (yytok) {
            case CASE:
                return 17;
            case ID:
                return 18;
            case IF:
                return 19;
            case READ:
                return 20;
            case REPEAT:
                return 21;
            case SKIP:
                return 22;
            case WRITE:
                return 23;
            case '(':
                return 24;
        }
        return 279;
    }

    private int yys12() {
        switch (yytok) {
            case CASE:
                return 17;
            case ID:
                return 18;
            case IF:
                return 19;
            case READ:
                return 20;
            case REPEAT:
                return 21;
            case SKIP:
                return 22;
            case WRITE:
                return 23;
            case '(':
                return 24;
        }
        return 279;
    }

    private int yys13() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys14() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case RECORD:
                return 9;
            case VAR:
                return 10;
            case VARIANT:
                return 11;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys15() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr16();
        }
        return 279;
    }

    private int yys19() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys21() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys22() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr37();
        }
        return 279;
    }

    private int yys23() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys24() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys32() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr15();
        }
        return 279;
    }

    private int yys40() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys41() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
            case ')':
                return 68;
        }
        return 279;
    }

    private int yys42() {
        switch (yytok) {
            case THEN:
                return 69;
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
        }
        return 279;
    }

    private int yys44() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr51();
        }
        return 279;
    }

    private int yys45() {
        switch (yytok) {
            case '(':
                return 77;
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case THEN:
            case '-':
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ELSE:
            case ENDINPUT:
                return yyr49();
            case '.':
                return yyr58();
        }
        return 279;
    }

    private int yys47() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr48();
        }
        return 279;
    }

    private int yys48() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr50();
        }
        return 279;
    }

    private int yys49() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr33();
        }
        return 279;
    }

    private int yys51() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr32();
        }
        return 279;
    }

    private int yys52() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case ')':
                return 80;
        }
        return 279;
    }

    private int yys56() {
        switch (yytok) {
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr17();
        }
        return 279;
    }

    private int yys60() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys65() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr31();
        }
        return 279;
    }

    private int yys66() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case ',':
            case ')':
                return yyr61();
        }
        return 279;
    }

    private int yys68() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr34();
        }
        return 279;
    }

    private int yys69() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys70() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys71() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys72() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys73() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys74() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys75() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys77() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
            case ')':
                return 108;
        }
        return 279;
    }

    private int yys79() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys82() {
        switch (yytok) {
            case VAR:
                return 10;
            case ':':
                return 113;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys87() {
        switch (yytok) {
            case ',':
            case READ:
            case ID:
            case ')':
            case '(':
            case WRITE:
            case CASE:
            case VAR:
            case END:
            case SKIP:
            case ';':
            case REPEAT:
            case IF:
                return yyr24();
        }
        return 279;
    }

    private int yys88() {
        switch (yytok) {
            case ',':
            case READ:
            case ID:
            case ')':
            case '(':
            case WRITE:
            case CASE:
            case VAR:
            case END:
            case SKIP:
            case ';':
            case REPEAT:
            case IF:
                return yyr25();
        }
        return 279;
    }

    private int yys89() {
        switch (yytok) {
            case ',':
            case READ:
            case ID:
            case ')':
            case '(':
            case WRITE:
            case CASE:
            case VAR:
            case END:
            case SKIP:
            case ';':
            case REPEAT:
            case IF:
                return yyr23();
        }
        return 279;
    }

    private int yys90() {
        switch (yytok) {
            case ',':
            case READ:
            case ID:
            case ')':
            case '(':
            case WRITE:
            case CASE:
            case VAR:
            case END:
            case SKIP:
            case ';':
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 279;
    }

    private int yys93() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys95() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr38();
        }
        return 279;
    }

    private int yys97() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr35();
        }
        return 279;
    }

    private int yys98() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
        }
        return 279;
    }

    private int yys100() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr45();
        }
        return 279;
    }

    private int yys101() {
        switch (yytok) {
            case '*':
                return 70;
            case '/':
                return 73;
            case ',':
            case '+':
            case ')':
            case UNTIL:
            case '-':
            case END:
            case THEN:
            case '=':
            case '<':
            case ';':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr44();
        }
        return 279;
    }

    private int yys102() {
        switch (yytok) {
            case '*':
                return 70;
            case '/':
                return 73;
            case ',':
            case '+':
            case ')':
            case UNTIL:
            case '-':
            case END:
            case THEN:
            case '=':
            case '<':
            case ';':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr46();
        }
        return 279;
    }

    private int yys103() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr47();
        }
        return 279;
    }

    private int yys104() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case ',':
            case ')':
            case UNTIL:
            case END:
            case THEN:
            case '=':
            case '<':
            case ';':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr42();
        }
        return 279;
    }

    private int yys105() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case ',':
            case ')':
            case UNTIL:
            case END:
            case THEN:
            case '=':
            case ';':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr43();
        }
        return 279;
    }

    private int yys106() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case THEN:
            case '-':
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ELSE:
            case ENDINPUT:
                return yyr56();
            case '.':
                return yyr57();
        }
        return 279;
    }

    private int yys108() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr52();
        }
        return 279;
    }

    private int yys109() {
        switch (yytok) {
            case '(':
                return 24;
            case FALSE:
                return 44;
            case ID:
                return 45;
            case NEW:
                return 46;
            case NUM:
                return 47;
            case TRUE:
                return 48;
            case ')':
                return 123;
        }
        return 279;
    }

    private int yys110() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr30();
        }
        return 279;
    }

    private int yys111() {
        switch (yytok) {
            case VAR:
                return 10;
            case ':':
                return 125;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys116() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr36();
        }
        return 279;
    }

    private int yys117() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys118() {
        switch (yytok) {
            case '*':
                return 70;
            case '+':
                return 71;
            case '-':
                return 72;
            case '/':
                return 73;
            case '<':
                return 74;
            case '=':
                return 75;
            case ',':
            case ')':
                return yyr60();
        }
        return 279;
    }

    private int yys119() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys120() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr28();
        }
        return 279;
    }

    private int yys121() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr53();
        }
        return 279;
    }

    private int yys123() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr54();
        }
        return 279;
    }

    private int yys127() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys130() {
        switch (yytok) {
            case ',':
            case '+':
            case '*':
            case ')':
            case UNTIL:
            case END:
            case '-':
            case THEN:
            case '=':
            case '<':
            case ';':
            case '/':
            case IF:
            case ENDINPUT:
            case ELSE:
                return yyr55();
        }
        return 279;
    }

    private int yys132() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case CASE:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr18();
        }
        return 279;
    }

    private int yys134() {
        switch (yytok) {
            case UNTIL:
            case END:
            case ENDINPUT:
            case ';':
            case IF:
            case ELSE:
                return yyr29();
        }
        return 279;
    }

    private int yyr1() { // s : regs ';' procs ';' cmds
        { saida = new Prog(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=5] = yyrv;
        return 1;
    }

    private int yyr2() { // s : regs ';' cmds
        { saida = new Prog(new java.util.ArrayList<Proc>(), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr3() { // s : procs ';' cmds
        { saida = new Prog(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr4() { // s : cmds
        { saida = new Prog(new java.util.ArrayList<Proc>(), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr39() { // cases : cases case
        { ((java.util.List)yysv[yysp-2]).add(((RamoCase)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return 62;
    }

    private int yyr40() { // cases : case
        { java.util.List<RamoCase> res = new java.util.ArrayList<RamoCase>();
                      res.add(((RamoCase)yysv[yysp-1]));
                      yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return 62;
    }

    private int yyr28() { // cmd : IF exp THEN cmds END
        { yyrv = new IfThen(((Exp)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr29() { // cmd : IF exp THEN cmds ELSE cmds END
        { yyrv = new IfThenElse(((Exp)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr30() { // cmd : REPEAT cmds UNTIL exp
        { yyrv = new Repeat(((Exp)yysv[yysp-1]), ((Bloco)yysv[yysp-3]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr31() { // cmd : ID ATTRIB exp
        { yyrv = new Assign(((Token)yysv[yysp-3]).lexeme, ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr32() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr33() { // cmd : READ ID
        { yyrv = new Read(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr34() { // cmd : ID '(' ')'
        { yyrv = new Chamada(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr35() { // cmd : ID '(' exps ')'
        { yyrv = new Chamada(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr36() { // cmd : rexp '.' ID ATTRIB exp
        { yyrv = new AssignCampo(((Exp)yysv[yysp-5]), ((Token)yysv[yysp-3]).lexeme, ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr37() { // cmd : SKIP
        { yyrv = new Skip(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypcmd();
    }

    private int yyr38() { // cmd : CASE ID cases END
        { yyrv = new Case(((Token)yysv[yysp-3]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 7: return 15;
            default: return 32;
        }
    }

    private int yyr15() { // cmds : cmds ';' cmd
        { ((Bloco)yysv[yysp-3]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr16() { // cmds : var cmd
        { ((Bloco)yysv[yysp-2]).add(((Cmd)yysv[yysp-1])); yyrv = ((Bloco)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 127: return 133;
            case 119: return 129;
            case 117: return 128;
            case 111: return 124;
            case 82: return 112;
            case 69: return 99;
            case 60: return 92;
            case 21: return 50;
            case 14: return 35;
            case 13: return 33;
            case 0: return 2;
            default: return 135;
        }
    }

    private int yyr21() { // decl : ids ':' tipo
        { yyrv = new Decl(((java.util.List)yysv[yysp-3]), ((Tipo)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        switch (yyst[yysp-1]) {
            case 55: return 84;
            default: return 27;
        }
    }

    private int yyr19() { // decls : decls ',' decl
        { ((java.util.List)yysv[yysp-3]).add(((Decl)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypdecls();
    }

    private int yyr20() { // decls : decl
        { java.util.List<Decl> res = new java.util.ArrayList<Decl>();
                         res.add(((Decl)yysv[yysp-1]));
                         yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypdecls();
    }

    private int yypdecls() {
        switch (yyst[yysp-1]) {
            case 53: return 81;
            case 10: return 28;
            default: return 83;
        }
    }

    private int yyr42() { // exp : exp '<' exp
        { yyrv = new Lt(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr43() { // exp : exp '=' exp
        { yyrv = new Eq(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr44() { // exp : exp '+' exp
        { yyrv = new Plus(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr45() { // exp : exp '*' exp
        { yyrv = new Mul(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : exp '-' exp
        { yyrv = new Minus(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : NUM
        { yyrv = new Num(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr49() { // exp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr50() { // exp : TRUE
        { yyrv = new True(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr51() { // exp : FALSE
        { yyrv = new False(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr52() { // exp : ID '(' ')'
        { yyrv = new ExpChamada(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr53() { // exp : ID '(' exps ')'
        { yyrv = new ExpChamada(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr54() { // exp : NEW ID '(' ')'
        { yyrv = new Cons(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr55() { // exp : NEW ID '(' exps ')'
        { yyrv = new Cons(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypexp();
    }

    private int yyr56() { // exp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), ((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 98: return 118;
            case 93: return 116;
            case 79: return 110;
            case 75: return 105;
            case 74: return 104;
            case 73: return 103;
            case 72: return 102;
            case 71: return 101;
            case 70: return 100;
            case 40: return 65;
            case 24: return 52;
            case 23: return 51;
            case 19: return 42;
            default: return 66;
        }
    }

    private int yyr60() { // exps : exps ',' exp
        { ((java.util.List)yysv[yysp-3]).add(((Exp)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr61() { // exps : exp
        { java.util.List<Exp> res = new java.util.ArrayList<Exp>();
                       res.add(((Exp)yysv[yysp-1]));
                       yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 77: return 107;
            case 41: return 67;
            default: return 122;
        }
    }

    private int yyr26() { // ids : ids ',' ID
        { ((java.util.List)yysv[yysp-3]).add(((Token)yysv[yysp-1]).lexeme); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypids();
    }

    private int yyr27() { // ids : ID
        { java.util.List<String> res = new java.util.ArrayList<String>();
                     res.add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypids();
    }

    private int yypids() {
        switch (yyst[yysp-1]) {
            case 59: return 91;
            default: return 29;
        }
    }

    private int yyr11() { // proc : PROCEDURE ID '(' ')' cmds END
        { yyrv = new Proc(((Token)yysv[yysp-5]).lexeme, new java.util.ArrayList<Decl>(), new Void(((Token)yysv[yysp-6]).lin), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-6]).lin); }
        yysv[yysp-=6] = yyrv;
        return yypproc();
    }

    private int yyr12() { // proc : PROCEDURE ID '(' decls ')' cmds END
        { yyrv = new Proc(((Token)yysv[yysp-6]).lexeme, ((java.util.List)yysv[yysp-4]), new Void(((Token)yysv[yysp-7]).lin), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypproc();
    }

    private int yyr13() { // proc : PROCEDURE ID '(' decls ')' ':' tipo cmds END
        { yyrv = new Proc(((Token)yysv[yysp-8]).lexeme, ((java.util.List)yysv[yysp-6]), ((Tipo)yysv[yysp-3]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-9]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypproc();
    }

    private int yyr14() { // proc : PROCEDURE ID '(' ')' ':' tipo cmds END
        { yyrv = new Proc(((Token)yysv[yysp-7]).lexeme, new java.util.ArrayList<Decl>(), ((Tipo)yysv[yysp-3]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-8]).lin); }
        yysv[yysp-=8] = yyrv;
        return yypproc();
    }

    private int yypproc() {
        switch (yyst[yysp-1]) {
            case 14: return 3;
            case 0: return 3;
            default: return 34;
        }
    }

    private int yyr9() { // procs : procs ';' proc
        { ((java.util.List)yysv[yysp-3]).add(((Proc)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypprocs();
    }

    private int yyr10() { // procs : proc
        { java.util.List<Proc> res = new java.util.ArrayList<Proc>();
                         res.add(((Proc)yysv[yysp-1]));
                         yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypprocs();
    }

    private int yypprocs() {
        switch (yyst[yysp-1]) {
            case 0: return 4;
            default: return 36;
        }
    }

    private int yyr7() { // reg : RECORD ID IS decls END
        { Registro.registros.put(((Token)yysv[yysp-4]).lexeme,
                                       new Registro(((Token)yysv[yysp-4]).lexeme,((java.util.List)yysv[yysp-2]))); }
        yysv[yysp-=5] = yyrv;
        return yypreg();
    }

    private int yyr8() { // reg : VARIANT ID IS ids END
        { Variante.variantes.put(((Token)yysv[yysp-4]).lexeme,
                                       new Variante(((Token)yysv[yysp-4]).lexeme,((java.util.List)yysv[yysp-2]))); }
        yysv[yysp-=5] = yyrv;
        return yypreg();
    }

    private int yypreg() {
        switch (yyst[yysp-1]) {
            case 0: return 5;
            default: return 37;
        }
    }

    private int yyr5() { // regs : regs ';' reg
        yysp -= 3;
        return 6;
    }

    private int yyr6() { // regs : reg
        yysp -= 1;
        return 6;
    }

    private int yyr57() { // rexp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), ((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr58() { // rexp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyprexp();
    }

    private int yyr59() { // rexp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyprexp() {
        switch (yyst[yysp-1]) {
            case 12: return 16;
            case 7: return 16;
            default: return 43;
        }
    }

    private int yyr41() { // case : IF ID THEN cmds
        { yyrv = new RamoCase(((Token)yysv[yysp-3]).lexeme, ((Bloco)yysv[yysp-1]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        switch (yyst[yysp-1]) {
            case 39: return 63;
            default: return 94;
        }
    }

    private int yyr22() { // tipo : REAL
        { yyrv = new Real(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr23() { // tipo : INT
        { yyrv = new Int(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr24() { // tipo : BOOL
        { yyrv = new Bool(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr25() { // tipo : ID
        { yyrv = new Reg(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 113: return 127;
            case 58: return 86;
            default: return 132;
        }
    }

    private int yyr17() { // var : VAR decls ';'
        { yyrv = new Bloco(((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return 7;
    }

    private int yyr18() { // var : /* empty */
        { yyrv = new Bloco(new java.util.ArrayList<Decl>(), ((Token)token).lin); }
        yysv[yysp-=0] = yyrv;
        return 7;
    }

    protected String[] yyerrmsgs = {
    };


Scanner scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Prog saida; // workaround pro bug do tipo do parse()

public ParserJACC(java.io.Reader entrada) {
  scan = new ScannerJF(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.token();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException("erro de sintaxe:" + token);
}

}
