import java.util.List;

public class Case extends Node implements Cmd {
	String var;
	List<RamoCase> casos;
	
	public Case(String _var, List<RamoCase> _casos, int lin) {
		super(lin);
		var = _var;
		casos = _casos;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs) {
		escopoVars.procurar(var, lin);
		for(RamoCase caso: casos) {
			caso.bloco.checaEscopo(escopoVars, escopoProcs);
		}
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo tvar = vars.procurar(var, lin);
		if(tvar instanceof Reg) {
			String nome = ((Reg)tvar).nome;
			Variante v = Variante.variantes.get(nome);
			if(v != null) {
				for(String membro: v.membros) {
					boolean existe = false;
					for(RamoCase caso: casos) {
						if(caso.reg.equals(membro)) {
							existe = true;
							TabSimb<Tipo> escopo = new TabSimb<Tipo>(vars);
							escopo.inserir(var, new Reg(membro, caso.lin), caso.lin);
							caso.bloco.tipo(escopo, procs);
						}
					}
					if(!existe) {
						throw new RuntimeException("comando case ignorando registro " + membro + " do variante " + v.nome + " na linha " + lin);
					}
				}
				for(RamoCase caso: casos) {
					if(!v.membros.contains(caso.reg)) {
						throw new RuntimeException("caso " + caso.reg + " não existe na variante " + v.nome + " na linha " + caso.lin);
					}
				}
			}
		}
	}

	@Override
	public void codigo(Contexto ctx, TabSimb<Endereco> vars) {
		Endereco evar = vars.procurar(var, lin);
		int lfim = ctx.label();
		int lprox = ctx.label();
		for(RamoCase caso: casos) {
			ctx.label(lprox);
			lprox = ctx.label();
			Registro reg = Registro.registros.get(caso.reg);
			evar.load(ctx); // empilhou var
			ctx.ldfld(1);
			ctx.icload(reg.hashCode());
			ctx.if_icmpneq(lprox);
			caso.bloco.codigo(ctx, vars);
			ctx.jmp(lfim);
		}
		ctx.label(lprox);
		ctx.label(lfim);
	}

}
