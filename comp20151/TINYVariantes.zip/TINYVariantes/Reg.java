
public class Reg extends Node implements Tipo {
	public String nome;
	
	public Reg(String _nome, int _lin) {
		super(_lin);
		nome = _nome;
	}
	
	public boolean subtipo(Tipo t) {
		if(t instanceof Reg) {
			Registro r1 = Registro.registros.get(nome);
			if(r1 == null) {
				Variante v1 = Variante.variantes.get(nome);
				if(v1 == null) {
					throw new RuntimeException("tipo " + nome + " na linha " + lin + " não existe");
				}
				Variante v2 = Variante.variantes.get(((Reg)t).nome);
				if(v2 == null) {
					throw new RuntimeException("tipo " + ((Reg)t).nome + " na linha " + ((Reg)t).lin + " não existe");
				}
				return v1.subtipo(v2);
			}
			Registro r2 = Registro.registros.get(((Reg)t).nome);
			if(r2 == null) {
				Variante v2 = Variante.variantes.get(((Reg)t).nome);
				if(v2 == null) {
					throw new RuntimeException("tipo " + ((Reg)t).nome + " na linha " + ((Reg)t).lin + " não existe");
				}
				return r1.subtipo(v2);
			}
			return r1 == r2;
		}
		return false;
	}
}
