import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | id | num

S     <- CMDS
CMDS  <- CMD (; CMD)*
CMD   <- if EXP then CMDS (else CMDS)? end
       / repeat CMDS until EXP
       / id := EXP
       / read id
       / write EXP
EXP   <- SEXP (< SEXP / = SEXP)*
SEXP  <- TERMO (+ TERMO / - TERMO)*
TERMO <- FATOR ("*" FATOR / "/" FATOR)*
FATOR <- "(" EXP ")" / id / num

*/

class Falha extends RuntimeException { }

public class Parser {
	ArrayList<Token> tokens;
	int atual = 0;
	int erro = 0;
	HashSet<String> esperados = new HashSet<String>();
	
	public Parser(Scanner scan) {
		tokens = new ArrayList<Token>();
		try {
			Token tok;
			do {
				tok = scan.token();
				tokens.add(tok);
			} while(tok.tipo != Token.EOF);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String terminal(int tipo) {
		if(tokens.get(atual).tipo == tipo) {
			String lexeme = tokens.get(atual).lexeme;
			atual++;
			return lexeme;
		} else {
			if(atual > erro) {
				erro = atual;
				esperados = new HashSet<String>();
				esperados.add("" + tipo);
			} else if(atual == erro) {
				esperados.add("" + tipo);
			}
			throw new Falha();
		}
	}
	
	public Tree parse() {
		Tree res = cmds();
		terminal(Token.EOF);
		return res;
	}
	
	Tree cmds() {
		Tree res = new Tree("CMDS");
		// CMD { ; CMD }
		res.child(cmd());
		while(true) {
			int salvo = atual;
			try {
				Tree rascunho = new Tree("");
				rascunho.child(terminal(';'));
				rascunho.child(cmd());
				res.children.addAll(rascunho.children);
			} catch(Falha f) {
				atual = salvo;
				break;
			}
		}
		return res;
	}
	
	Tree cmd() {
		Tree res = new Tree("CMD");
		int salvo = atual;
		try {
			Tree rascunho = new Tree("");
			// repeat CMDS until EXP
			rascunho.child(terminal(Token.REPEAT));
			rascunho.child(cmds());
			rascunho.child(terminal(Token.UNTIL));
			rascunho.child(exp());
			res.children.addAll(rascunho.children);
		} catch(Falha f1) {
			atual = salvo;
			salvo = atual;
			try {
				Tree rascunho = new Tree("");
				// id := EXP
				rascunho.child(terminal(Token.ID));
				rascunho.child(terminal(Token.ATTRIB));
				rascunho.child(exp());
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				atual = salvo;
				salvo = atual;
				try {
					Tree rascunho = new Tree("");
					// read id
					rascunho.child(terminal(Token.READ));
					rascunho.child(terminal(Token.ID));
					res.children.addAll(rascunho.children);
				} catch(Falha f3) {
					atual = salvo;
					salvo = atual;
					try {
						Tree rascunho = new Tree("");
						// write EXP
						rascunho.child(terminal(Token.WRITE));
						rascunho.child(exp());
						res.children.addAll(rascunho.children);
					} catch(Falha f4) {
						atual = salvo;
						// if EXP then CMDS [ else CMDS ] end
						res.child(terminal(Token.IF));
						res.child(exp());
						res.child(terminal(Token.THEN));
						res.child(cmds());
						salvo = atual;
						try {
							Tree rascunho = new Tree("");
							// else CMDS
							rascunho.child(terminal(Token.ELSE));
							rascunho.child(cmds());
							res.children.addAll(rascunho.children);
						} catch(Falha f5) {
							atual = salvo;
						}
						res.child(terminal(Token.END));
					}
				}
			}
		}
		return res;
	}
	
	Tree exp() {
		Tree res = new Tree("EXP");
		// SEXP { < SEXP | = SEXP }
		res.child(sexp());
		while(true) {
			int salvo = atual;
			try {
				Tree rascunho = new Tree("");
				int salvo_ = atual;
				try {
					Tree rascunho_ = new Tree("");
					// < SEXP
					rascunho_.child(terminal('<'));
					rascunho_.child(sexp());
					rascunho.children.addAll(rascunho_.children);
				} catch(Falha f1) {
					atual = salvo_;
					// = SEXP
					rascunho.child(terminal('='));
					rascunho.child(sexp());
				}
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				atual = salvo;
				break;
			}
		}
		return res;
	}
	
	Tree sexp() {
		Tree res = new Tree("SEXP");
		// TERMO { + TERMO | - TERMO }
		res.child(termo());
		while(true) {
			int salvo = atual;
			try {
				Tree rascunho = new Tree("");
				int salvo_ = atual;
				try {
					Tree rascunho_ = new Tree("");
					// + TERMO
					rascunho_.child(terminal('+'));
					rascunho_.child(termo());
					rascunho.children.addAll(rascunho_.children);
				} catch(Falha f1) {
					atual = salvo_;
					// - TERMO
					rascunho.child(terminal('-'));
					rascunho.child(termo());
				}
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				atual = salvo;
				break;
			}
		}
		return res;
	}
	
	Tree termo() {
		Tree res = new Tree("TERMO");
		// FATOR { * FATOR | / FATOR }
		res.child(fator());
		while(true) {
			int salvo = atual;
			try {
				Tree rascunho = new Tree("");
				int salvo_ = atual;
				try {
					Tree rascunho_ = new Tree("");
					// * FATOR
					rascunho_.child(terminal('*'));
					rascunho_.child(fator());
					rascunho.children.addAll(rascunho_.children);
				} catch(Falha f1) {
					atual = salvo_;
					// / FATOR 
					rascunho.child(terminal('/'));
					rascunho.child(fator());
				}
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				atual = salvo;
				break;
			}
		}
		return res;
	}
	
	Tree fator() {
		Tree res = new Tree("FATOR");
		// "(" EXP ")" | id | num
		int salvo = atual;
		try {
			Tree rascunho = new Tree("");
			// "(" EXP ")"
			rascunho.child(terminal('('));
			rascunho.child(exp());
			rascunho.child(terminal(')'));
			res.children.addAll(rascunho.children);
		} catch(Falha f1) {
			atual = salvo;
			salvo = atual;
			try {
				Tree rascunho = new Tree("");
				// id
				rascunho.child(terminal(Token.ID));
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				atual = salvo;
				// num
				res.child(terminal(Token.NUM));
			}
		}
		return res;
	}
}
