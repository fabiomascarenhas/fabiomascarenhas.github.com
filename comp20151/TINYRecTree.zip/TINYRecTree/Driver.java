import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Driver {
	public static void main(String[] args) throws IOException {
		File f = new File(args[0]);
		FileReader fr = new FileReader(f);
		Scanner scan = new ScannerJF(fr);
		Parser parser = new Parser(scan);
		try {
			Tree arvore = parser.parse();
			arvore.printDot(f.getPath() + ".gv");
			System.out.println(arvore.toString());
		} catch(Falha falha) {
			System.out.println("análise falhou no token " + parser.erro + 
					" (" + parser.tokens.get(parser.erro).toString() + "), esperados:");
			for(String token: parser.esperados) {
				System.out.println("    " + token);
			}
		}
	}
}
