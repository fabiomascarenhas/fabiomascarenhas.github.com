
public abstract class ArithExp extends BinExp {
	public ArithExp(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo t1 = e1.tipo(vars, procs);
		Tipo t2 = e2.tipo(vars, procs);
		if(t1.subtipo(Int.tipo) && t2.subtipo(Int.tipo)) {
			return Int.tipo;
		}
		if(t1.subtipo(Real.tipo) && t2.subtipo(Real.tipo)) {
			return Real.tipo;
		}
		throw new RuntimeException("tipos inválidos em expressão aritmética na linha " + lin +
				": " + t1 + " e " + t2);
	}
}
