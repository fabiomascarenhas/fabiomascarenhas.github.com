
public interface Tipo {
	boolean subtipo(Tipo t);
}
