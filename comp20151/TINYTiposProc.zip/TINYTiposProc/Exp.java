
public interface Exp {
	void checaEscopo(TabSimb<Boolean> escopoVars, TabSimb<Boolean> escopoProcs);
	Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs);
}
