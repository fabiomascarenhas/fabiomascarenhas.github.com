
public class Eq extends BinExp {
	public Eq(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo t1 = e1.tipo(vars, procs);
		Tipo t2 = e2.tipo(vars, procs);
		if(t1.subtipo(t2)) {
			return Bool.tipo;
		}
		if(t2.subtipo(t1)) {
			return Bool.tipo;
		}
		throw new RuntimeException("tipos inválidos na igualdade na linha " + lin +
				": " + t1 + " e " + t2);
	}
}
