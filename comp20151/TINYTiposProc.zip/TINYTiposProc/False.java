public class False extends Node implements Exp {
	public False(int _lin) {
		super(_lin);
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) { }

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		return Bool.tipo;
	}
}
