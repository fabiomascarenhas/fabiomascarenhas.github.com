
public class Lt extends BinExp {
	public Lt(Exp _e1, Exp _e2, int _lin) {
		super(_e1, _e2, _lin);
	}

	@Override
	public Tipo tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo t1 = e1.tipo(vars, procs);
		Tipo t2 = e2.tipo(vars, procs);
		if(t1.subtipo(Real.tipo) && t2.subtipo(Real.tipo)) {
			return Bool.tipo;
		}
		throw new RuntimeException("tipos inválidos no menor que na linha " + lin +
				": " + t1 + " e " + t2);
	}
}
