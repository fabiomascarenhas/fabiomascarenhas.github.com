// Output created by jacc on Mon Jun 08 11:43:07 BRT 2015


class ParserJACC implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 94:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 95:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 188;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 96:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 97:
                    switch (yytok) {
                        case ';':
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    switch (yytok) {
                        case ID:
                            yyn = 11;
                            continue;
                        case IF:
                            yyn = 12;
                            continue;
                        case READ:
                            yyn = 13;
                            continue;
                        case REPEAT:
                            yyn = 14;
                            continue;
                        case WRITE:
                            yyn = 15;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 100:
                    switch (yytok) {
                        case ID:
                            yyn = 16;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    switch (yytok) {
                        case ID:
                            yyn = 11;
                            continue;
                        case IF:
                            yyn = 12;
                            continue;
                        case READ:
                            yyn = 13;
                            continue;
                        case REPEAT:
                            yyn = 14;
                            continue;
                        case WRITE:
                            yyn = 15;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    yyn = yys9();
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 24;
                            continue;
                        case '(':
                            yyn = 25;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    switch (yytok) {
                        case ID:
                            yyn = 32;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    yyn = yys14();
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    switch (yytok) {
                        case '(':
                            yyn = 35;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    switch (yytok) {
                        case ',':
                            yyn = 36;
                            continue;
                        case ';':
                            yyn = 37;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    switch (yytok) {
                        case ',':
                            yyn = 38;
                            continue;
                        case ':':
                            yyn = 39;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    switch (yytok) {
                        case ';':
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    yyn = yys25();
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    yyn = yys27();
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    yyn = yys28();
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    yyn = yys29();
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    yyn = yys30();
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr26();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case UNTIL:
                            yyn = 53;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    yyn = yys34();
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                        case ')':
                            yyn = 55;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case IF:
                        case REPEAT:
                        case ID:
                        case READ:
                        case WRITE:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    switch (yytok) {
                        case ID:
                            yyn = 57;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    switch (yytok) {
                        case BOOL:
                            yyn = 59;
                            continue;
                        case INT:
                            yyn = 60;
                            continue;
                        case REAL:
                            yyn = 61;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    switch (yytok) {
                        case ')':
                            yyn = 62;
                            continue;
                        case ',':
                            yyn = 63;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    yyn = yys51();
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case ',':
                            yyn = 36;
                            continue;
                        case ')':
                            yyn = 75;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    yyn = yys59();
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    yyn = yys61();
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case FALSE:
                            yyn = 27;
                            continue;
                        case ID:
                            yyn = 28;
                            continue;
                        case NUM:
                            yyn = 29;
                            continue;
                        case TRUE:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ELSE:
                            yyn = 79;
                            continue;
                        case END:
                            yyn = 80;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    switch (yytok) {
                        case ',':
                            yyn = 63;
                            continue;
                        case ')':
                            yyn = 81;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys73();
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 84;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case BOOL:
                            yyn = 59;
                            continue;
                        case INT:
                            yyn = 60;
                            continue;
                        case REAL:
                            yyn = 61;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    yyn = yys78();
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    yyn = yys79();
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr21();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    yyn = yys81();
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 87;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    switch (yytok) {
                        case BOOL:
                            yyn = 59;
                            continue;
                        case INT:
                            yyn = 60;
                            continue;
                        case REAL:
                            yyn = 61;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    yyn = yys85();
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 90;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    yyn = yys88();
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 92;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr22();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 93;
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    switch (yytok) {
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 191;
                    continue;

                case 188:
                    return true;
                case 189:
                    yyerror("stack overflow");
                case 190:
                    return false;
                case 191:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case PROCEDURE:
                return 6;
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys9() {
        switch (yytok) {
            case PROCEDURE:
                return 6;
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys14() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys25() {
        switch (yytok) {
            case FALSE:
                return 27;
            case ID:
                return 28;
            case NUM:
                return 29;
            case TRUE:
                return 30;
            case '(':
                return 31;
            case ')':
                return 43;
        }
        return 191;
    }

    private int yys26() {
        switch (yytok) {
            case THEN:
                return 44;
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
        }
        return 191;
    }

    private int yys27() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr39();
        }
        return 191;
    }

    private int yys28() {
        switch (yytok) {
            case '(':
                return 51;
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr37();
        }
        return 191;
    }

    private int yys29() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr36();
        }
        return 191;
    }

    private int yys30() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr38();
        }
        return 191;
    }

    private int yys34() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr25();
        }
        return 191;
    }

    private int yys40() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr24();
        }
        return 191;
    }

    private int yys41() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
            case ',':
            case ')':
                return yyr43();
        }
        return 191;
    }

    private int yys44() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys51() {
        switch (yytok) {
            case FALSE:
                return 27;
            case ID:
                return 28;
            case NUM:
                return 29;
            case TRUE:
                return 30;
            case '(':
                return 31;
            case ')':
                return 72;
        }
        return 191;
    }

    private int yys52() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
            case ')':
                return 73;
        }
        return 191;
    }

    private int yys55() {
        switch (yytok) {
            case VAR:
                return 7;
            case ':':
                return 77;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys59() {
        switch (yytok) {
            case ';':
            case IF:
            case REPEAT:
            case ',':
            case ID:
            case READ:
            case ')':
            case WRITE:
            case VAR:
                return yyr18();
        }
        return 191;
    }

    private int yys60() {
        switch (yytok) {
            case ';':
            case IF:
            case REPEAT:
            case ',':
            case ID:
            case READ:
            case ')':
            case WRITE:
            case VAR:
                return yyr17();
        }
        return 191;
    }

    private int yys61() {
        switch (yytok) {
            case ';':
            case IF:
            case REPEAT:
            case ',':
            case ID:
            case READ:
            case ')':
            case WRITE:
            case VAR:
                return yyr16();
        }
        return 191;
    }

    private int yys65() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr32();
        }
        return 191;
    }

    private int yys66() {
        switch (yytok) {
            case '*':
                return 45;
            case '/':
                return 48;
            case '=':
            case ';':
            case THEN:
            case '-':
            case ',':
            case ELSE:
            case '+':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr31();
        }
        return 191;
    }

    private int yys67() {
        switch (yytok) {
            case '*':
                return 45;
            case '/':
                return 48;
            case '=':
            case ';':
            case THEN:
            case '-':
            case ',':
            case ELSE:
            case '+':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr33();
        }
        return 191;
    }

    private int yys68() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr34();
        }
        return 191;
    }

    private int yys69() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '=':
            case ';':
            case THEN:
            case ',':
            case ELSE:
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr29();
        }
        return 191;
    }

    private int yys70() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
            case ';':
            case THEN:
            case ',':
            case ELSE:
            case ')':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr30();
        }
        return 191;
    }

    private int yys72() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr40();
        }
        return 191;
    }

    private int yys73() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr35();
        }
        return 191;
    }

    private int yys74() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr23();
        }
        return 191;
    }

    private int yys75() {
        switch (yytok) {
            case VAR:
                return 7;
            case ':':
                return 83;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys78() {
        switch (yytok) {
            case '*':
                return 45;
            case '+':
                return 46;
            case '-':
                return 47;
            case '/':
                return 48;
            case '<':
                return 49;
            case '=':
                return 50;
            case ',':
            case ')':
                return yyr42();
        }
        return 191;
    }

    private int yys79() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys81() {
        switch (yytok) {
            case '=':
            case ';':
            case THEN:
            case '/':
            case '-':
            case ',':
            case ELSE:
            case '+':
            case '*':
            case ')':
            case '<':
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr41();
        }
        return 191;
    }

    private int yys85() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yys88() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 191;
    }

    private int yyr1() { // s : procs ';' cmds
        { saida = new Prog(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr2() { // s : cmds
        { saida = new Prog(new java.util.ArrayList<Proc>(), ((Bloco)yysv[yysp-1]), 1); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr9() { // cmds : cmds ';' cmd
        { ((Bloco)yysv[yysp-3]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr10() { // cmds : var cmd
        { ((Bloco)yysv[yysp-2]).add(((Cmd)yysv[yysp-1])); yyrv = ((Bloco)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 85: return 89;
            case 79: return 86;
            case 75: return 82;
            case 55: return 76;
            case 44: return 64;
            case 14: return 33;
            case 9: return 22;
            case 0: return 2;
            default: return 91;
        }
    }

    private int yyr15() { // decl : ids ':' tipo
        { yyrv = new Decl(((java.util.List)yysv[yysp-3]), ((Tipo)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        switch (yyst[yysp-1]) {
            case 36: return 56;
            default: return 17;
        }
    }

    private int yyr13() { // decls : decls ',' decl
        { ((java.util.List)yysv[yysp-3]).add(((Decl)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypdecls();
    }

    private int yyr14() { // decls : decl
        { java.util.List<Decl> res = new java.util.ArrayList<Decl>();
                         res.add(((Decl)yysv[yysp-1]));
                         yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypdecls();
    }

    private int yypdecls() {
        switch (yyst[yysp-1]) {
            case 7: return 18;
            default: return 54;
        }
    }

    private int yyr29() { // exp : exp '<' exp
        { yyrv = new Lt(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr30() { // exp : exp '=' exp
        { yyrv = new Eq(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr31() { // exp : exp '+' exp
        { yyrv = new Plus(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr32() { // exp : exp '*' exp
        { yyrv = new Mul(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr33() { // exp : exp '-' exp
        { yyrv = new Minus(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr34() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : NUM
        { yyrv = new Num(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : TRUE
        { yyrv = new True(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : FALSE
        { yyrv = new False(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : ID '(' ')'
        { yyrv = new ExpChamada(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : ID '(' exps ')'
        { yyrv = new ExpChamada(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 63: return 78;
            case 53: return 74;
            case 50: return 70;
            case 49: return 69;
            case 48: return 68;
            case 47: return 67;
            case 46: return 66;
            case 45: return 65;
            case 31: return 52;
            case 24: return 40;
            case 15: return 34;
            case 12: return 26;
            default: return 41;
        }
    }

    private int yyr42() { // exps : exps ',' exp
        { ((java.util.List)yysv[yysp-3]).add(((Exp)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr43() { // exps : exp
        { java.util.List<Exp> res = new java.util.ArrayList<Exp>();
                       res.add(((Exp)yysv[yysp-1]));
                       yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 25: return 42;
            default: return 71;
        }
    }

    private int yyr19() { // ids : ids ',' ID
        { ((java.util.List)yysv[yysp-3]).add(((Token)yysv[yysp-1]).lexeme); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 19;
    }

    private int yyr20() { // ids : ID
        { java.util.List<String> res = new java.util.ArrayList<String>();
                     res.add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return 19;
    }

    private int yyr5() { // proc : PROCEDURE ID '(' ')' cmds END
        { yyrv = new Proc(((Token)yysv[yysp-5]).lexeme, new java.util.ArrayList<Decl>(), new Void(((Token)yysv[yysp-6]).lin), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-6]).lin); }
        yysv[yysp-=6] = yyrv;
        return yypproc();
    }

    private int yyr6() { // proc : PROCEDURE ID '(' decls ')' cmds END
        { yyrv = new Proc(((Token)yysv[yysp-6]).lexeme, ((java.util.List)yysv[yysp-4]), new Void(((Token)yysv[yysp-7]).lin), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypproc();
    }

    private int yyr7() { // proc : PROCEDURE ID '(' decls ')' ':' tipo cmds END
        { yyrv = new Proc(((Token)yysv[yysp-8]).lexeme, ((java.util.List)yysv[yysp-6]), ((Tipo)yysv[yysp-3]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-9]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypproc();
    }

    private int yyr8() { // proc : PROCEDURE ID '(' ')' ':' tipo cmds END
        { yyrv = new Proc(((Token)yysv[yysp-7]).lexeme, new java.util.ArrayList<Decl>(), ((Tipo)yysv[yysp-3]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-8]).lin); }
        yysv[yysp-=8] = yyrv;
        return yypproc();
    }

    private int yypproc() {
        switch (yyst[yysp-1]) {
            case 0: return 3;
            default: return 23;
        }
    }

    private int yyr3() { // procs : procs ';' proc
        { ((java.util.List)yysv[yysp-3]).add(((Proc)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 4;
    }

    private int yyr4() { // procs : proc
        { java.util.List<Proc> res = new java.util.ArrayList<Proc>();
                         res.add(((Proc)yysv[yysp-1]));
                         yyrv = res; }
        yysv[yysp-=1] = yyrv;
        return 4;
    }

    private int yyr21() { // cmd : IF exp THEN cmds END
        { yyrv = new IfThen(((Exp)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr22() { // cmd : IF exp THEN cmds ELSE cmds END
        { yyrv = new IfThenElse(((Exp)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr23() { // cmd : REPEAT cmds UNTIL exp
        { yyrv = new Repeat(((Exp)yysv[yysp-1]), ((Bloco)yysv[yysp-3]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr24() { // cmd : ID ATTRIB exp
        { yyrv = new Assign(((Token)yysv[yysp-3]).lexeme, ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr25() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr26() { // cmd : READ ID
        { yyrv = new Read(((Token)yysv[yysp-1]).lexeme, ((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr27() { // cmd : ID '(' ')'
        { yyrv = new Chamada(((Token)yysv[yysp-3]).lexeme, new java.util.ArrayList<Exp>(), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr28() { // cmd : ID '(' exps ')'
        { yyrv = new Chamada(((Token)yysv[yysp-4]).lexeme, ((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 5: return 10;
            default: return 21;
        }
    }

    private int yyr16() { // tipo : REAL
        { yyrv = new Real(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr17() { // tipo : INT
        { yyrv = new Int(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr18() { // tipo : BOOL
        { yyrv = new Bool(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 77: return 85;
            case 39: return 58;
            default: return 88;
        }
    }

    private int yyr11() { // var : VAR decls ';'
        { yyrv = new Bloco(((java.util.List)yysv[yysp-2]), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return 5;
    }

    private int yyr12() { // var : /* empty */
        { yyrv = new Bloco(new java.util.ArrayList<Decl>(), ((Token)token).lin); }
        yysv[yysp-=0] = yyrv;
        return 5;
    }

    protected String[] yyerrmsgs = {
    };


Scanner scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Prog saida; // workaround pro bug do tipo do parse()

public ParserJACC(java.io.Reader entrada) {
  scan = new ScannerJF(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.token();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException("erro de sintaxe:" + token);
}

}
