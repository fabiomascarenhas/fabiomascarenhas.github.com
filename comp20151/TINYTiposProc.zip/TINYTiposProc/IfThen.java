public class IfThen extends Node implements Cmd {
	public Exp cond;
	public Bloco cthen;
	
	public IfThen(Exp _cond, Bloco _cthen, int _lin) {
		super(_lin);
		cond = _cond;
		cthen = _cthen;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		cond.checaEscopo(escopo, escopoProcs);
		cthen.checaEscopo(escopo, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo tcond = cond.tipo(vars, procs);
		if(!tcond.subtipo(Bool.tipo)) {
			throw new RuntimeException("condição do if na linha " + lin + " não é booleano, mas " + tcond);
		}
		cthen.tipo(vars, procs);
	}
}
