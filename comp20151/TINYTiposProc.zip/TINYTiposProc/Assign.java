
public class Assign extends Node implements Cmd {
	public String id;
	public Exp exp;
	
	public Assign(String _id, Exp _exp, int _lin) {
		super(_lin);
		id = _id;
		exp = _exp;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo, TabSimb<Boolean> escopoProcs) {
		escopo.procurar(id, lin);
		exp.checaEscopo(escopo, escopoProcs);
	}

	@Override
	public void tipo(TabSimb<Tipo> vars, TabSimb<Proc> procs) {
		Tipo t1 = exp.tipo(vars, procs);
		Tipo t2 = vars.procurar(id, lin);
		if(!t1.subtipo(t2)) {
			throw new RuntimeException("atribuição inválida na linha " + lin + 
					", lado esquerdo é " + t2 + " e lado direito é " + t1);
			   
		}
	}
}
