
public class Write extends Node implements Cmd {
	public Exp exp;
	
	public Write(Exp _exp, int _lin) {
		super(_lin);
		exp = _exp;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo) {
		exp.checaEscopo(escopo);
	}
}
