
public class Assign extends Node implements Cmd {
	public String id;
	public Exp exp;
	
	public Assign(String _id, Exp _exp, int _lin) {
		super(_lin);
		id = _id;
		exp = _exp;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo) {
		escopo.procurar(id, lin);
		exp.checaEscopo(escopo);
	}
}
