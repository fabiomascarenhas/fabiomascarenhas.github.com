import java.util.ArrayList;
import java.util.List;

public class Bloco extends Node {
	public List<String> vars;
	public List<Cmd> cmds;
	
	public Bloco(List<String> _vars, int _lin) {
		super(_lin);
		vars = _vars;
		cmds = new ArrayList<Cmd>();
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}
	
	TabSimb<Boolean> checaEscopo(TabSimb<Boolean> pai) {
		TabSimb<Boolean> escopo = new TabSimb<Boolean>(pai);
		for(String var: vars) {
			escopo.inserir(var, true, lin);
		}
		for(Cmd cmd: cmds) {
			cmd.checaEscopo(escopo);
		}
		return escopo;
	}
}
