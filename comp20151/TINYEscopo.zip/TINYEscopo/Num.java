
public class Num extends Node implements Exp {
	public String lexeme;
	int val;
	
	public Num(String _lexeme, int _lin) {
		super(_lin);
		lexeme = _lexeme;
		val = Integer.parseInt(lexeme);
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo) { }
}
