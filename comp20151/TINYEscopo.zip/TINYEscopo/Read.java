
public class Read extends Node implements Cmd {
	public String id;
	
	public Read(String _id, int _lin) {
		super(_lin);
		id = _id;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo) {
		escopo.procurar(id, lin);
	}
}
