
public class Id extends Node implements Exp {
	public String id;
	
	public Id(String _id, int _lin) {
		super(_lin);
		id = _id;
	}

	@Override
	public void checaEscopo(TabSimb<Boolean> escopo) {
		escopo.procurar(id, lin);
	}
}
