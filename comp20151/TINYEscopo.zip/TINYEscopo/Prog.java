public class Prog extends Node {
	public Bloco cmds;
	
	public Prog(Bloco _cmds, int _lin) {
		super(_lin);
		cmds = _cmds;
	}
	
	void checaEscopo() {
		cmds.checaEscopo(null);
	}
}
