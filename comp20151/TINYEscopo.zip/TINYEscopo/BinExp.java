
public abstract class BinExp extends Node implements Exp {
	public Exp e1;
	public Exp e2;
	
	public BinExp(Exp _e1, Exp _e2, int _lin) {
		super(_lin);
		e1 = _e1;
		e2 = _e2;
	}
	
	@Override
	public void checaEscopo(TabSimb<Boolean> escopo) {
		e1.checaEscopo(escopo);
		e2.checaEscopo(escopo);
	}
}
