
public interface Cmd {
	void checaEscopo(TabSimb<Boolean> escopo);
}
