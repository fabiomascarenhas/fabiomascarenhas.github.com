
public interface Exp {
	void checaEscopo(TabSimb<Boolean> escopo);
}
