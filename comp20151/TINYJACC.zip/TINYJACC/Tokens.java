// Output created by jacc on Wed May 20 11:53:34 BRT 2015

interface Tokens {
    int ENDINPUT = 0;
    int ATTRIB = 1;
    int ELSE = 2;
    int END = 3;
    int ID = 4;
    int IF = 5;
    int NUM = 6;
    int READ = 7;
    int REPEAT = 8;
    int THEN = 9;
    int UNTIL = 10;
    int WRITE = 11;
    int error = 12;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // '-' (code=45)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
