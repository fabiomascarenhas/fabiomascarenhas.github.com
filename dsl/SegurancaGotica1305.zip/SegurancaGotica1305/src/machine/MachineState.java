package machine;

import java.util.List;

public class MachineState implements Node {
	public final String name;
	public final List<String> actions;
	public final List<Transition> transitions;
	
	public MachineState(String _name,
			            List<String> _actions,
			            List<Transition> _transitions) {
		name = _name;
		actions = _actions;
		transitions = _transitions;
	}
	
	public String toString() {
		String acs = actions.isEmpty() ? "" :
			" { " + String.join(", ", actions) + " }";
		String[] trs = new String[transitions.size()];
		for(int i = 0; i < trs.length; i++) {
			trs[i] = transitions.get(i).toString(); // visita
		}
		return "state " + name + acs + "\n" +
					String.join("\n", trs) + "\nend";
	}

	public void run(Visitor v) {
		v.visit(this);
	}
}
