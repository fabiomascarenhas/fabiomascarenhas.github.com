package machine;

import java.util.List;

import bloco.Node;

public class Machine implements Node {
	public final List<Event> events;
	public final List<Command> commands;
	public final List<MachineState> states;

	public Machine(List<Event> _events,
				   List<Command> _commands,
				   List<MachineState> _states) {
		events = _events;
		commands = _commands;
		states = _states;
	}
	
	public String toString() {
		String[] evs = new String[events.size()];
		String[] cmds = new String[commands.size()];
		String[] sts = new String[states.size()];
		for(int i = 0; i < evs.length; i++)
			evs[i] = events.get(i).toString();
		for(int i = 0; i < cmds.length; i++)
			cmds[i] = commands.get(i).toString();
		for(int i = 0; i < sts.length; i++)
			sts[i] = states.get(i).toString();
		return "events\n" + String.join("\n", evs) + "\nend\n" +
			   "commands\n" + String.join("\n", evs) + "\nend\n" +
		       String.join("\n", sts);
	}
	
	public void run(Visitor v) {
		v.visit(this);
	}
}
