package machine;

import scope.Symbol;

public class EventSymbol extends Symbol {
	public final String code;
	
	public EventSymbol(String _name, String _code) {
		super(_name);
		code = _code;
	}
}
