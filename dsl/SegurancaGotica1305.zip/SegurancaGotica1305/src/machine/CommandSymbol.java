package machine;

import scope.Symbol;

public class CommandSymbol extends Symbol {
	public final String code;
	
	public CommandSymbol(String _name, String _code) {
		super(_name);
		code = _code;
	}
}
