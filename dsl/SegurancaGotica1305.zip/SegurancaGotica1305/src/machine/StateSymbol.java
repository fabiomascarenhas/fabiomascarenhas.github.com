package machine;

import scope.Symbol;

public class StateSymbol extends Symbol {
	public final MachineState state;
	
	public StateSymbol(String _name, MachineState _state) {
		super(_name);
		state = _state;
	}
}
