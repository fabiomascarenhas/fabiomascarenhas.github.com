package machine;

import static pegast.Parser.choice;
import static pegast.Parser.star;
import static pegast.Parser.plus;
import static pegast.Parser.listof;
import static pegast.Parser.seq;
import static pegast.Parser.opt;
import static pegast.Parser.cls;
import static pegast.Parser.str;
import static pegast.Parser.named;
import static pegast.Parser.not;
import static pegast.Parser.lazy;
import static pegast.Parser.eps;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import pegast.Parser;
import pegast.Token;

/*
machine := events commands state+
events := "events" event+ "end"
event := name code
commands := "commands" command+ "end"
command := name code
state := "state" name actions? transition* "end"
actions := "actions" '{' name+ '}'
transition := name '=>' name

-- terminais
reserved := "events" | "state" | "end" | "action"
name := !reserved [a-zA-Z]+ ![a-zA-Z0-9] 
code := !reserved [A-Z0-9][A-Z0-9][A-Z0-9][A-Z0-9] ![a-zA-Z0-9]
comment := '--'[^\n]*
 */
public class MachineParser {
	// Regras léxicas
	static Parser<Void> notalphanum = not(cls((char c) -> Character.isJavaIdentifierPart(c)));
	static Parser<Void> alphanum = cls((char c) -> Character.isJavaIdentifierPart(c));
	static Parser<Void> alpha = cls((char c) -> Character.isJavaIdentifierStart(c));
	static Parser<Void> digit = cls((char c) -> Character.isDigit(c));
	static Parser<Void> comment = seq(str("--"), star(cls((char c) -> c != '\n')));
	static Parser<Void> space = star(choice(cls((char c) -> Character.isWhitespace(c)),
								            comment)).seqr(eps);
	static Parser<Void> upalphanum = cls((char c) -> Character.isDigit(c) || Character.isUpperCase(c));
	static Parser<Void> eof = seq(space, not(cls((char c) -> true)));
	static Parser<Void> kw(String s) {
		return space.seql(named(seq(str(s), notalphanum), s));
	}
	static Map<String, Parser<Void>> kws = new HashMap<String, Parser<Void>>();
	static {
		kws.put("events", kw("events"));
		kws.put("commands", kw("commands"));
		kws.put("state", kw("state"));
		kws.put("end", kw("end"));
		kws.put("actions", kw("actions"));
	}
	@SuppressWarnings("unchecked")
	static Parser<Void> notkw = not(choice((Parser<Void>[])(kws.values().toArray(new Parser[0]))));
	static Parser<Token> name = space.seqr(named(seq(notkw, alpha, star(alpha), not(alphanum)), "name"));
	static Parser<Token> code = space.seqr(named(
			seq(upalphanum,upalphanum,upalphanum,upalphanum,
					not(alphanum)),"code"));
	static Parser<Token> op(String s) {
		return space.seqr(named(str(s), s));
	}

	static Parser<Machine> machine() {
		return seq(lazy(MachineParser::events), lazy(MachineParser::commands), plus(lazy(MachineParser::state)),
				(List<Event> evs, List<Command> cmds, List<MachineState> sts) -> new Machine(evs, cmds, sts));
	}

	static Parser<List<Event>> events() {
		return seq(kws.get("events"), plus(lazy(MachineParser::event)), kws.get("end"),
				(Void _1, List<Event> evs, Void _2) -> evs);
	}
	
	static Parser<Event> event() {
		return seq(name, code, 
				(Token name, Token code) -> new Event(name.lexema, code.lexema, name.pos));
	}

	static Parser<List<Command>> commands() {
		return seq(kws.get("commands"), plus(lazy(MachineParser::command)), kws.get("end"),
				(Void _1, List<Command> cmds, Void _2) -> cmds);
	}

	static Parser<Command> command() {
		return seq(name, code, 
				(Token name, Token code) -> new Command(name.lexema, code.lexema, name.pos));
	}
	
	static Parser<MachineState> state() {
		return seq(kws.get("state"), name, opt(lazy(MachineParser::actions)), 
				       star(lazy(MachineParser::transition)), kws.get("end"),
				(Void _1, Token name, List<String> acs, List<Transition> trans, Void _2) ->
					new MachineState(name.lexema, acs, trans));
	}
	
	static Parser<List<String>> actions() {
		return seq(kws.get("actions"), op("{"), listof(name, choice(op(","), eps)), op("}"),
				(Void _1, Object _2, List<Token> names, Object _3) -> {
					List<String> res = new ArrayList<String>();
					for(Token tok: names) res.add(tok.lexema);
					return res;
				});
	}
	
	static Parser<Transition> transition() {
		return seq(name, op("=>"), name,
				(Token from, Token arrow, Token to) ->
					new Transition(from.lexema, to.lexema, arrow.pos));
	}
	
	public static Parser<Machine> parser = 
			machine().seql(eof);
}
