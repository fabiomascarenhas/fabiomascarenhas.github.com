package machine;

public interface Visitor {
	void visit(Command c);
	void visit(Event e);
	void visit(Machine m);
	void visit(MachineState s);
	void visit(Transition t);
}
