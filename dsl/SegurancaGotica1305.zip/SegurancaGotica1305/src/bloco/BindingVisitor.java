package bloco;

import java.util.ArrayList;
import java.util.List;

import scope.GlobalScope;
import scope.NestedScope;
import scope.Scope;
import scope.Symbol;

public class BindingVisitor implements Visitor {
	Scope current = new GlobalScope();
	public List<String> errors = new ArrayList<>();
	
	@Override
	public void visit(Assign a) {
		a.rval.run(this);
		if(current.resolve(a.lval) == null)
			current.define(new VarSymbol(a.lval, current));
	}

	@Override
	public void visit(Div d) {
		d.left.run(this);
		d.right.run(this);
	}

	@Override
	public void visit(Maior m) {
		m.left.run(this);
		m.right.run(this);
	}

	@Override
	public void visit(Soma s) {
		s.left.run(this);
		s.right.run(this);
	}

	@Override
	public void visit(Sub s) {
		s.left.run(this);
		s.right.run(this);
	}

	@Override
	public void visit(Mult m) {
		m.left.run(this);
		m.right.run(this);
	}

	@Override
	public void visit(While w) {
		w.cond.run(this);
		Scope save = current;
		current = new NestedScope("while", save);
		for(Statement s: w.corpo) {
			s.run(this);
		}
		w.scope = current;
		current = save;
	}

	@Override
	public void visit(Name n) {
		Symbol s = current.resolve(n.var);
		if(s == null) {
			errors.add("nome " + n.var + " não encontrado na posição " + n.pos);
			n.symbol = new Symbol("ERRO");
		} else {
			n.symbol = s;
		}
	}

	@Override
	public void visit(Num n) {}

}
