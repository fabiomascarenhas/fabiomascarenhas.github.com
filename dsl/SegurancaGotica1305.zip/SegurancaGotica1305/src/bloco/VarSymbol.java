package bloco;

import scope.Scope;
import scope.Symbol;

public class VarSymbol extends Symbol {
	public final Scope scope;
	
	public VarSymbol(String _name, Scope _scope) {
		super(_name);
		scope = _scope;
	}
	
	public String toString() {
		return name + " in " + scope;
	}
}
