package bloco;

public interface Visitor {
	void visit(Assign a);
	void visit(Div d);
	void visit(Maior m);
	void visit(Soma s);
	void visit(Sub s);
	void visit(Mult m);
	void visit(While w);
	void visit(Name n);
	void visit(Num n);
}
