package bloco;

import java.util.Map;

public interface Exp extends Node {
	int getPos();
	int eval(Map<String, Integer> vars);
	void run(Visitor v);
}
