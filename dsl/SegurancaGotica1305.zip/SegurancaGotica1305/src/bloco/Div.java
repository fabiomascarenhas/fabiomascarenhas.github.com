package bloco;

import java.util.Map;

public class Div implements Exp {
	public final Exp left;
	public final Exp right;
	
	public final int pos;
	
	public Div(Exp _left, Exp _right, int _pos) {
		left = _left;
		right = _right;
		pos = _pos;
	}
	
	@Override
	public int getPos() {
		return pos;
	}

	@Override
	public int eval(Map<String, Integer> vars) {
		return left.eval(vars) / right.eval(vars);
	}

	public void run(Visitor v) {
		v.visit(this);
	}

}
