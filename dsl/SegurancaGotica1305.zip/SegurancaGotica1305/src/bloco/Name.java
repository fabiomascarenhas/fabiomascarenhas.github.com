package bloco;

import java.util.Map;

import scope.Symbol;

public class Name implements Exp {
	public final String var;
	public final int pos;
	
	public Symbol symbol;
	
	public Name(String _var, int _pos) {
		var = _var;
		pos = _pos;
	}
	
	@Override
	public int getPos() {
		return pos;
	}

	@Override
	public int eval(Map<String, Integer> vars) {
		return vars.getOrDefault(var, 0);
	}
	
	public void run(Visitor v) {
		v.visit(this);
	}

}
