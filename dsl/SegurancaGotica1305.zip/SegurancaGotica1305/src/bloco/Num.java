package bloco;

import java.util.Map;

public class Num implements Exp {
	public final String val;
	public final int pos;
	
	public Num(String _val, int _pos) {
		val = _val;
		pos = _pos;
	}
	
	@Override
	public int getPos() {
		return pos;
	}

	@Override
	public int eval(Map<String, Integer> vars) {
		return Integer.parseInt(val);
	}

	public void run(Visitor v) {
		v.visit(this);
	}

}
