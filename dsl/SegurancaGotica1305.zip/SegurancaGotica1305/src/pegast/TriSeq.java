package pegast;

public class TriSeq<A,B,C,T> implements Parser<T> {
	public final Parser<A> p1;
	public final Parser<B> p2;
	public final Parser<C> p3;
	public TriFunction<? super A,? super B,? super C, ? extends T> comb;
	
	public TriSeq(Parser<A> _p1, Parser<B> _p2, Parser<C> _p3, TriFunction<? super A,? super B, ? super C, ? extends T> _comb) {
		p1 = _p1;
		p2 = _p2;
		p3 = _p3;
		comb = _comb;
	}
		
	@Override
	public Result<? extends T> parse(State<Character> st) {
		Result<? extends A> res1 = p1.parse(st);
		Result<? extends B> res2 = p2.parse(res1.out);
		Result<? extends C> res3 = p3.parse(res2.out);
		return new Result<>(comb.apply(res1.res, res2.res, res3.res),
				            res3.out);
	}

}

