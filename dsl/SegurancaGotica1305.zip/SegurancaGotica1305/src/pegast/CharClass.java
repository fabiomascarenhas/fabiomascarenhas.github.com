package pegast;

public interface CharClass {
	boolean test(char x);
}
