package scope;

import java.util.HashMap;
import java.util.Map;

public class NestedScope implements Scope {
	public final String name;
	public final Scope enclosing;

	public final Map<String, Symbol> table =
			new HashMap<>();

	public NestedScope(String _name, Scope _enclosing) {
		name = _name;
		enclosing = _enclosing;
	}
	
	@Override
	public String getScopeName() {
		return name;
	}

	@Override
	public Scope getEnclosing() {
		return enclosing;
	}

	@Override
	public void define(Symbol sym) {
		table.put(sym.name, sym);
	}

	@Override
	public Symbol resolve(String name) {
		if(table.containsKey(name)) {
			return table.get(name);
		} else {
			return enclosing.resolve(name);
		}
	}
	
	public String toString() {
		return name + " in " + enclosing;
	}
}
