package scope;

public interface Scope {
	public String getScopeName();
	public Scope getEnclosing();
	public void define(Symbol sym);
	public Symbol resolve(String name);
}
