package scope;

import java.util.HashMap;
import java.util.Map;

public class GlobalScope implements Scope {
	public final Map<String, Symbol> table =
			new HashMap<>();
	
	@Override
	public String getScopeName() {
		return "global";
	}

	@Override
	public Scope getEnclosing() {
		return null;
	}

	@Override
	public void define(Symbol sym) {
		table.put(sym.name, sym);
	}

	@Override
	public Symbol resolve(String name) {
		return table.get(name);
	}

	public String toString() {
		return getScopeName();
	}
	
}
