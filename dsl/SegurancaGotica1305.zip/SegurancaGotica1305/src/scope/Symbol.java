package scope;

public class Symbol {
	public final String name;
	
	public Symbol(String _name) {
		name = _name;
	}
	
	public String toString() {
		return name;
	}
}
