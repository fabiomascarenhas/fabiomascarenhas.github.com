
public class AbstractEvent {
	public final String name;
	public final String code;
	
	public AbstractEvent(String _name, String _code) {
		name = _name;
		code = _code;
	}
}

