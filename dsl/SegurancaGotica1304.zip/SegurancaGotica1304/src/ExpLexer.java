import java.io.Reader;

public class ExpLexer extends Lexer {
	public static int NAME = 2;
	public static int NUM = 3;

	public ExpLexer(Reader _input) {
		super(_input);
	}

	public boolean isLetra(char x) {
		return (x >= 'a' && x <= 'z') ||
				(x >= 'A' && x <= 'Z');
	}
	
	// [a-zA-Z]
	public void matchLetra() {
		if(isLetra(c)) consume();
		else throw new RuntimeException("esperado letra, encontrado " + c + " em " + lin);
	}

	public boolean isAlphaNum(char x) {
		return (x >= 'a' && x <= 'z') ||
			   (x >= 'A' && x <= 'Z') ||
			   (x >= '0' && x <= '9');
	}
	
	public void testNotAlphaNum() {
		if(isAlphaNum(c)) 
			throw new RuntimeException("esperado não alfanumérico, encontrado " + c + " em " + lin);
	}

	// [a-zA-Z]+[^a-zA-Z0-9]
	public Token name() {
		int lin = this.lin;
		StringBuffer sb = new StringBuffer();
		do {
			sb.append(c);
			matchLetra();
		} while(isLetra(c));
		testNotAlphaNum();
		String texto = sb.toString();
		return new Token(NAME, texto, lin);
	}

	// [0-9]+[^a-zA-Z0-9]
	public Token num() {
		int lin = this.lin;
		StringBuffer sb = new StringBuffer();
		do {
			sb.append(c);
			matchDigito();
		} while(isDigito(c));
		testNotAlphaNum();
		String texto = sb.toString();
		return new Token(NUM, texto, lin);
	}

	public boolean isDigito(char x) {
		return (x >= '0' && x <= '9');
	}
	
	// [0-9]
	public void matchDigito() {
		if(isDigito(c)) consume();
		else throw new RuntimeException("esperado dígito, encontrado " + c + " em " + lin);
	}

	@Override
	public Token nextToken() {
		while(c != EOF) {
			if(Character.isWhitespace(c)) {
				consume();
				continue;
			}
			if(isLetra(c)) return name();
			if(isDigito(c)) return num();
			if(c == '+' || c == '-' || c == '(' 
					|| c == ')' || c == '*' || c == '/')
				return single(c);
			throw new RuntimeException("caractere " + c + " não esperado na posição " + lin);
		}
		return new Token(EOF_TYPE, "<<EOF>>", lin);
	}

	@Override
	public String getTokenName(int type) {
		if(type > 3) return "" + (char)type;
		else if(type == 2) return "name";
		else if(type == 3) return "num";
		else if(type == 1) return "EOF";
		else return "null";
	}

}
