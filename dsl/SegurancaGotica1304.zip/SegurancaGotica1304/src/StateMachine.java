import java.util.ArrayList;
import java.util.List;

public class StateMachine {
	public final State start;
	public final List<Event> resetEvents = new ArrayList<Event>();
	
	public StateMachine(State _start) {
		start = _start;
	}
	
	public void addResetEvents(Event... evts) {
		for(Event e: evts) {
			resetEvents.add(e);
			start.addResetEvent(e, start);
		}
	}
	
}
