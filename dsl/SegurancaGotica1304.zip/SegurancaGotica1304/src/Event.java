
public class Event extends AbstractEvent {

	public Event(String _name, String _code) {
		super(_name, _code);
	}
	
}
