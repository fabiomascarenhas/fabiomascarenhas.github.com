package pegtree;

import java.util.ArrayList;
import java.util.Map;

public interface Parser {
	Result<Character> parse(State<Character> st);
	
	static Parser cls(CharClass cls) {
		return new CharClassParser(cls);
	}
	static Parser named(Parser p, String name) {
		return new NamedParser(p, name);
	}
	static Parser str(String s) {
		return new StringParser(s);
	}
	static Parser not(Parser p) {
		return new Not(p);
	}
	static Parser eps = new Empty();
	static Parser seq(Parser p1, Parser p2) {
		return new Seq(p1, p2);
	}
	static Parser seq(Parser p1, Parser p2, Parser p3) {
		return new Seq(p1, p2, p3);
	}
	static Parser seq(Parser p1, Parser p2, Parser p3, Parser p4) {
		return new Seq(p1, p2, p3, p4);
	}
	static Parser seq(Parser p1, Parser p2, Parser p3, Parser p4, Parser p5) {
		return new Seq(p1, p2, p3, p4, p5);
	}
	static Parser seq(Parser[] ps) {
		if(ps.length > 1)
			return new Seq(ps);
		else
			return ps[0];
	}
	static Parser choice(Parser p1, Parser p2) {
		return new OrdChoice(p1, p2);
	}
	static Parser choice(Parser p1, Parser p2, Parser p3) {
		return new OrdChoice(p1, p2, p3);
	}
	static Parser choice(Parser p1, Parser p2, Parser p3, Parser p4) {
		return new OrdChoice(p1, p2, p3, p4);
	}
	static Parser choice(Parser p1, Parser p2, Parser p3, Parser p4, Parser p5) {
		return new OrdChoice(p1, p2, p3, p4, p5);
	}
	static Parser choice(Parser[] ps) {
		if(ps.length > 1)
			return new OrdChoice(ps);
		else
			return ps[0];
	}
	static Parser star(Parser p) {
		return new Many(p);
	}
	static Parser plus(Parser p) {
		return seq(p, star(p));
	}
	static Parser var(Map<String, Parser> g, String name) {
		return new Variable(g, name);
	}
	
	default ParseTree parse(String input) {
		char[] inp = input.toCharArray();
		ArrayList<Character> chars = new ArrayList<>();
		for(char c: inp) chars.add(c);
		try {
			Result<Character> res = parse(new State<>(chars));
			assert(res.nodes.size() == 1);
			return res.nodes.get(0);
		} catch (Fail f) {
			int pos = chars.size() - f.error;
			int lin = 1;
			int col = 1;
			for(char c: chars.subList(0,  pos)) {
				if(c == '\n') { lin++; col = 1; } else col++;
			}
			String[] esps = f.expected.toArray(new String[0]);
			throw new RuntimeException("erro no na linha " + lin + " coluna " + col +
					", esperado " +	String.join(", ", esps));
		}
	}
}
