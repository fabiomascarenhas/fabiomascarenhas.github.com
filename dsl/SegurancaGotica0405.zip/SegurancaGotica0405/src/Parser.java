
import java.util.List;
import java.util.Map;

public interface Parser {
	List<List<Token>> parse(List<Token> input);
	
	static Parser tok(int tipo) {
		return new TokenParser(tipo);
	}
	static Parser eps = new Empty();
	static Parser seq(Parser p1, Parser p2) {
		return new Seq(p1, p2);
	}
	static Parser seq(Parser p1, Parser p2, Parser p3) {
		return new Seq(p1, p2, p3);
	}
	static Parser seq(Parser p1, Parser p2, Parser p3, Parser p4) {
		return new Seq(p1, p2, p3, p4);
	}
	static Parser seq(Parser p1, Parser p2, Parser p3, Parser p4, Parser p5) {
		return new Seq(p1, p2, p3, p4, p5);
	}
	static Parser choice(Parser p1, Parser p2) {
		return new OrdChoice(p1, p2);
	}
	static Parser choice(Parser p1, Parser p2, Parser p3) {
		return new OrdChoice(p1, p2, p3);
	}
	static Parser choice(Parser p1, Parser p2, Parser p3, Parser p4) {
		return new OrdChoice(p1, p2, p3, p4);
	}
	static Parser choice(Parser p1, Parser p2, Parser p3, Parser p4, Parser p5) {
		return new OrdChoice(p1, p2, p3, p4, p5);
	}
	static Parser star(Parser p) {
		return new Many(p);
	}
	static Parser plus(Parser p) {
		return seq(p, star(p));
	}
	static Parser var(Map<String, Parser> g, String name) {
		return new Variable(g, name);
	}
}
