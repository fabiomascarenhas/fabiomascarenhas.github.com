import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class State {
	public final String name;
	public final List<Command> actions =
			new ArrayList<Command>();
	public final Map<String, State> transitions =
			new HashMap<String, State>();
	
	public State(String _name) {
		name = _name;
	}
	
	public void addTransition(Event evt, State target) {
		transitions.put(evt.code, target);
	}
	
	public void addAction(Command cmd) {
		actions.add(cmd);
	}

	public void addResetEvent(Event e, State start) {
		if(transitions.containsKey(e.code)) return;
		addTransition(e, start);
		for(State s: transitions.values()) {
			s.addResetEvent(e, start);
		}
	}

	public boolean hasTransition(String eventCode) {
		return transitions.containsKey(eventCode);
	}

	public State targetState(String eventCode) {
		return transitions.get(eventCode);
	}

	public void executeActions() {
		for(Command c: actions) {
			System.out.println(c.name + ": " + c.code);
		}
	}
}
