package peg;

public class StringParser implements Parser {
	public final char[] s;
	
	public StringParser(String _s) {
		s = _s.toCharArray();
	}

	@Override
	public State<Character> parse(State<Character> st) {
		if(s.length > st.input.size()) return st.fail();
		for(int i = 0; i < s.length; i++) {
			if(s[i] != st.input.get(i))
				return st.fail();
		}
		return st.success(st.input.subList(s.length, st.input.size()));
	}
}
