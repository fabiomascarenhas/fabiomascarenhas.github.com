package peg;

import static peg.Parser.seq;
import static peg.Parser.choice;
import static peg.Parser.star;
import static peg.Parser.var;
import static peg.Parser.cls;
import static peg.Parser.str;
import static peg.Parser.named;
import static peg.Parser.not;
import java.util.HashMap;
import java.util.Map;

public class BlocoParser {
	// Regras léxicas
	static Parser notalphanum = not(cls((char c) -> Character.isJavaIdentifierPart(c)));
	static Parser alphanum = cls((char c) -> Character.isJavaIdentifierPart(c));
	static Parser alpha = cls((char c) -> Character.isJavaIdentifierStart(c));
	static Parser digit = cls((char c) -> Character.isDigit(c));
	static Parser comment = seq(str("--"), star(cls((char c) -> c != '\n')));
	static Parser space = star(choice(cls((char c) -> Character.isWhitespace(c)),
								      comment));
	static Parser eof = seq(space, not(cls((char c) -> true)));
	static Parser kw(String s) {
		return seq(space, named(seq(str(s), notalphanum), s));
	}
	static Map<String, Parser> kws = new HashMap<String, Parser>();
	static {
		kws.put("while", kw("while"));
		kws.put("do", kw("do"));
		kws.put("end", kw("end"));
	}
	static Parser notkw = not(choice(kws.values().toArray(new Parser[0])));
	static Parser name = seq(space, named(seq(notkw, alpha, star(alphanum)), "name"));
	static Parser num = seq(space, named(seq(digit, star(digit)), "num"));
	static Parser op(String s) {
		return seq(space, named(str(s), s));
	}

	// Gramática
	static Map<String, Parser> g = new HashMap<>();
	static {
		g.put("bloco", star(var(g, "stat")));
		g.put("stat", choice(seq(kws.get("while"),
				                 var(g, "exp"),
				                 kws.get("do"),
				                 var(g, "bloco"),
				                 kws.get("end")),
				             seq(name,
				                 op("="),
				                 var(g, "exp"))));
		g.put("exp", choice(seq(var(g, "aexp"),
				                op(">"),
				                var(g, "aexp")),
				            var(g, "aexp")));
		g.put("aexp", seq(var(g, "termo"), 
			             star(choice(seq(op("+"), var(g, "termo")),
					                 seq(op("-"), var(g, "termo")))))); 
		g.put("termo", seq(var(g, "fator"), 
	                       star(choice(seq(op("*"), var(g, "fator")),
			                           seq(op("/"), var(g, "fator")))))); 
		g.put("fator", choice(seq(op("("), var(g, "exp"), op(")")),
				              num, name));
	}

	public static Parser parser = seq(var(g, "bloco"), eof);
}

