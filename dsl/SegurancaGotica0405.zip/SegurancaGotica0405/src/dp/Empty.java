package dp;

public class Empty implements Parser {

	@Override
	public State<Token> parse(State<Token> st) {
		return st;
	}

}
