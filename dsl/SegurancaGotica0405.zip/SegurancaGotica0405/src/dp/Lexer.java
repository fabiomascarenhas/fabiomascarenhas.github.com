package dp;
import java.io.IOException;
import java.io.PushbackReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public abstract class Lexer {
	public static final char EOF = (char)-1;
	public static final int EOF_TYPE = 1;
	
	public PushbackReader input;
	public char c; // lookahead
	int lin = 1; // no. da linha
	
	public Lexer(Reader _input) {
		input = new PushbackReader(_input);
		consume();
	}
	
	public void consume() {
		try {
			c = (char)input.read();
			if(c == '\n') lin++;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void match(char x) {
		if(c == x) consume();
		else throw new RuntimeException("esperado " + x + " achado " + c + " em " + lin);
	}
	
	public void match(CharClass cc) {
		if(cc.test(c)) consume();
		else throw new RuntimeException("esperado " + cc.name() + " achado " + c + " em " + lin);
	}
	
	public void testNot(CharClass cc) {
		if(cc.test(c))
			throw new RuntimeException("não esperado " + cc.name() + " mas achado " + c + " em " + lin);
	}
	
	public Token single(char x) {
		match(x);
		return new Token(x, "" + x, lin);
	}
	
	public char peek(int n) {
		char[] cs = new char[n];
		int eof = 0;
		try {
			eof = input.read(cs);
			input.unread(cs);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(eof == -1)
			return EOF;
		else
			return cs[n-1];
	}
	
	public List<Token> allTokens() {
		ArrayList<Token> toks = new ArrayList<>();
		Token tok;
		do {
			tok = nextToken();
			toks.add(tok);
		} while(tok.tipo != EOF_TYPE);
		return toks;
	}
	
	public abstract Token nextToken();
	public abstract String getTokenName(int type);
}
