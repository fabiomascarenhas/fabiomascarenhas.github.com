
public class Command extends AbstractEvent {

	public Command(String _name, String _code) {
		super(_name, _code);
	}
	
}
