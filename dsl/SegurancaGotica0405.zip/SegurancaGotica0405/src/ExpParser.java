
public class ExpParser extends ParserRec {

	public ExpParser(Lexer _input) {
		super(_input);
	}

	// exp: termo ('+' termo | '-' termo)*
	public void exp() {
		termo();
		while(la.tipo == '+' || la.tipo == '-') {
			if(la.tipo == '+') {
				match('+');
				termo();
			} else {
				match('-');
				termo();
			}
		}
	}
	
	// termo: fator ('*' fator | '/' fator)*
	public void termo() {
		fator();
		while(la.tipo == '*' || la.tipo == '/') {
			if(la.tipo == '*') {
				match('*');
				fator();
			} else {
				match('/');
				fator();
			}
		}
	}
	
	// fator: '(' exp ')' | NUM | NAME
	public void fator() {
		if(la.tipo == '(') {
			match('(');
			exp();
			match(')');
		} else if(la.tipo == ExpLexer.NUM) {
			match(ExpLexer.NUM);
		} else {
			match(ExpLexer.NAME);
		}
	}
	
	@Override
	public void parse() {
		exp();
		match(Lexer.EOF_TYPE);
	}

}
