import java.util.ArrayList;
import java.util.List;

public class ParseTree {
	public final String rot;
	public final List<ParseTree> children;
	
	public ParseTree(String _rot) {
		rot = _rot;
		children = new ArrayList<>();
	}
	
	public void addChild(ParseTree child) {
		children.add(child);
	}
	
	public void addChild(String child) {
		children.add(new ParseTree(child));
	}
	
	public String toString() {
		if(children.isEmpty()) return "'"+rot+"'";
		String[] cs = new String[children.size()];
		for(int i = 0; i < children.size(); i++) {
			cs[i] = children.get(i).toString();
		}
		return rot + "(" + String.join(", ", cs) + ")";
	}
}
