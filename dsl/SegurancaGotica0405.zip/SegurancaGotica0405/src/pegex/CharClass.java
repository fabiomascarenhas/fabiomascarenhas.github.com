package pegex;

public interface CharClass {
	boolean test(char x);
}
