package pegex;

public class Empty implements Parser {

	@Override
	public State<Character> parse(State<Character> st) {
		return st;
	}

}
