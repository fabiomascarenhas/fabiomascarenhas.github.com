package pegex;

public class Many implements Parser {
	public Parser p;
	
	public Many(Parser _p) {
		p = new OrdChoice(new Seq(_p, this), new Empty());
		//p = new Choice(new Empty(), new Seq(_p, this));
	}

	public Many(Parser _p, Parser base) {
		p = new OrdChoice(new Seq(_p, this), base);
	}

	@Override
	public State<Character> parse(State<Character> st) {
		return p.parse(st);
	}
	
}
