package pegast;

import java.util.function.BiFunction;

public class BiSeq<A,B,T> implements Parser<T> {
	public Parser<A> p1;
	public Parser<B> p2;
	public BiFunction<? super A,? super B,? extends T> comb;
	
	public BiSeq(Parser<A> _p1, Parser<B> _p2, BiFunction<? super A,? super B,? extends T> _comb) {
		p1 = _p1;
		p2 = _p2;
		comb = _comb;
	}
		
	@Override
	public Result<? extends T> parse(State<Character> st) {
		Result<? extends A> res1 = p1.parse(st);
		Result<? extends B> res2 = p2.parse(res1.out);
		return new Result<>(comb.apply(res1.res, res2.res),
				            res2.out);
	}

}

