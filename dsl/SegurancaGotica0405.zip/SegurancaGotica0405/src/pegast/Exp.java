package pegast;

public interface Exp {
	int getPos();
}
