package pegast;

import java.util.List;

public class Machine implements Node {
	public final List<Event> events;
	public final List<Command> commands;
	public final List<MachineState> states;

	public Machine(List<Event> _events,
				   List<Command> _commands,
				   List<MachineState> _states) {
		events = _events;
		commands = _commands;
		states = _states;
	}
}
