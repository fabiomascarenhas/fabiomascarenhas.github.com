package pegast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;

public interface Parser<T> {
	Result<? extends T> parse(State<Character> st);
	
	static Parser<Void> cls(CharClass cls) {
		return new CharClassParser(cls);
	}
	static Parser<Token> named(Parser<?> p, String name) {
		return new NamedParser(p, name);
	}
	static Parser<Void> str(String s) {
		return new StringParser(s);
	}
	static Parser<Void> not(Parser<?> p) {
		return new Not(p);
	}
	static Parser<Void> eps = new Empty();
	default Parser<T> seql(Parser<?> r) {
		return new SeqL<>(this, r);
	}
	default <B> Parser<B> seqr(Parser<? extends B> r) {
		return new SeqR<>(this, r);
	}
	static <A,B,T> Parser<T> seq(Parser<A> p1, Parser <B> p2, BiFunction<? super A, ? super B, ? extends T> comb) {
		return new BiSeq<>(p1, p2, comb);
	}
	static <A,B,C,T> Parser<T> seq(Parser<A> p1, Parser <B> p2, Parser <C> p3, TriFunction<? super A, ? super B, ? super C, ? extends T> comb) {
		return new TriSeq<>(p1, p2, p3, comb);
	}
	static <A,B,C,D,T> Parser<T> seq(Parser<A> p1, Parser <B> p2, Parser <C> p3, Parser<D> p4,
			TetraFunction<? super A, ? super B, ? super C, ? super D, ? extends T> comb) {
		return new TetraSeq<>(p1, p2, p3, p4, comb);
	}
	static <A,B,C,D,E,T> Parser<T> seq(Parser<A> p1, Parser <B> p2, Parser <C> p3, Parser<D> p4, Parser<E> p5,
			PentaFunction<? super A, ? super B, ? super C, ? super D, ? super E, ? extends T> comb) {
		return new PentaSeq<>(p1, p2, p3, p4, p5, comb);
	}
	static <T> Parser<T> choice(Parser<? extends T> p1, Parser<? extends T> p2) {
		return new OrdChoice<>(p1, p2);
	}
	static <T> Parser<T> choice(Parser<? extends T> p1, Parser<? extends T> p2, Parser<? extends T> p3) {
		return new OrdChoice<>(p1, p2, p3);
	}
	static <T> Parser<T> choice(Parser<? extends T> p1, Parser<? extends T> p2, Parser<? extends T> p3, Parser<? extends T> p4) {
		return new OrdChoice<>(p1, p2, p3, p4);
	}
	static <T> Parser<T> choice(Parser<? extends T> p1, Parser<? extends T> p2, Parser<? extends T> p3, Parser<? extends T> p4, Parser<? extends T> p5) {
		return new OrdChoice<>(p1, p2, p3, p4, p5);
	}
	static <T> Parser<? extends T> choice(Parser<? extends T>[] ps) {
		if(ps.length > 1)
			return new OrdChoice<>(ps);
		else
			return ps[0];
	}
	static <T> Parser<List<T>> star(Parser<? extends T> p) {
		return new Many<>(p);
	}
	static <T> Parser<List<T>> plus(Parser<? extends T> p) {
		return seq(p, star(p), (T t, List<T> ts) -> {
			List<T> nts = new ArrayList<>();
			nts.add(t);
			nts.addAll(ts);
			return nts;
		});
	}
	static <T> Parser<T> var(Map<String, Parser<?>> g, String name) {
		return new Variable<T>(g, name);
	}
	static <A,B> Parser<B> fun(Parser<A> p, Function<? super A,? extends B> f) {
		return new Func<>(p, f);
	}
	
	default T parse(String input) {
		char[] inp = input.toCharArray();
		ArrayList<Character> chars = new ArrayList<>();
		for(char c: inp) chars.add(c);
		try {
			Result<? extends T> res = parse(new State<>(chars));
			return res.res;
		} catch (Fail f) {
			int pos = chars.size() - f.error;
			int lin = 1;
			int col = 1;
			for(char c: chars.subList(0,  pos)) {
				if(c == '\n') { lin++; col = 1; } else col++;
			}
			String[] esps = f.expected.toArray(new String[0]);
			throw new RuntimeException("erro no na linha " + lin + " coluna " + col +
					", esperado " +	String.join(", ", esps));
		}
	}
}
