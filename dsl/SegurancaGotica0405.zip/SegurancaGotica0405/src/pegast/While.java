package pegast;

import java.util.List;

public class While implements Statement {
	public final Exp cond;
	public final List<Statement> corpo;
	
	public While(Exp _cond, List<Statement> _corpo) {
		cond = _cond;
		corpo = _corpo;
	}
}
