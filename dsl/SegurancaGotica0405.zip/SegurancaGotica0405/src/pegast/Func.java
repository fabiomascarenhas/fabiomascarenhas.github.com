package pegast;

import java.util.function.Function;

public class Func<A,B> implements Parser<B> {
	public Parser<A> p;
	public Function<? super A, ? extends B> f;
	
	public Func(Parser<A> _p, Function<? super A, ? extends B> _f) {
		p = _p;
		f = _f;
	}

	@Override
	public Result<? extends B> parse(State<Character> st) {
		Result<? extends A> rp = p.parse(st);
		return new Result<>(f.apply(rp.res), rp.out);
	}
	
	
}
