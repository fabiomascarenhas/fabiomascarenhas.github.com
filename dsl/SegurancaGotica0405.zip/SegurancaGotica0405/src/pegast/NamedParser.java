package pegast;

import java.util.List;

public class NamedParser implements Parser<Token> {
	public final Parser<?> p;
	public final String name;
	
	public NamedParser(Parser<?> _p, String _name) {
		p = _p;
		name = _name;
	}
	
	@Override
	public Result<Token> parse(State<Character> st) {
		try {
			int pos = st.input.size();
			List<Character> input = st.input;
			Result<?> res = p.parse(st);
			List<Character> lexema = input.subList(0, pos - res.out.input.size());
			char[] cs = new char[lexema.size()];
			for(int i = 0; i < cs.length; i++) cs[i] = lexema.get(i);
			return new Result<>(new Token(new String(cs), pos), res.out);
		} catch(Fail f) {
			throw st.fail(st.input.size(), name);
		}
	}
	
	
}
