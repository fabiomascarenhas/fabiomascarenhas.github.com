package pegast;

public class Result<T> {
	public final T res;
	public final State<Character> out;
	
	public Result(T _res, State<Character> _out) {
		res = _res;
		out = _out;
	}
}
