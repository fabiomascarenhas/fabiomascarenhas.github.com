package pegast;

import java.util.Map;

public class Variable<T> implements Parser<T> {
	public Map<String, Parser<?>> g;
	public String name;
	
	public Variable(Map<String, Parser<?>> _g, String _name) {
		g = _g;
		name = _name;
	}
	
	@Override
	public Result<? extends T> parse(State<Character> st) {
		return (Result<? extends T>)g.get(name).parse(st);
	}

}
