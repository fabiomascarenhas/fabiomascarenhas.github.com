package pegast;

import java.util.HashSet;
import java.util.Set;

public class Fail extends RuntimeException {
	private static final long serialVersionUID = 5546168256043052907L;

	public final int error;
	public final Set<String> expected;
	
	public Fail(int _error, Set<String> _expected) {
		error = _error;
		expected = _expected;
	}

	public Fail(int _error, String _expected) {
		error = _error;
		expected = new HashSet<String>();
		expected.add(_expected);
	}
}
