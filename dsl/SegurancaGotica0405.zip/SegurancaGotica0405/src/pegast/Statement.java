package pegast;

public interface Statement extends Node { }
