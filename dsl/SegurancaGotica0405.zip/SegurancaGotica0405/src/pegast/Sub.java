package pegast;

public class Sub implements Exp {
	public final Exp left;
	public final Exp right;
	
	public final int pos;
	
	public Sub(Exp _left, Exp _right, int _pos) {
		left = _left;
		right = _right;
		pos = _pos;
	}
	
	@Override
	public int getPos() {
		return pos;
	}

}
