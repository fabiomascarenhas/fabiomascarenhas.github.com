package pegast;

import java.util.List;

public class MachineState implements Node {
	public final String name;
	public final List<String> actions;
	public final List<Transition> transitions;
	
	public MachineState(String _name,
			            List<String> _actions,
			            List<Transition> _transitions) {
		name = _name;
		actions = _actions;
		transitions = _transitions;
	}
}
