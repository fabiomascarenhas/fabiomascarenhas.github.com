package pegast;

import static pegast.Parser.choice;
import static pegast.Parser.star;
import static pegast.Parser.seq;
import static pegast.Parser.var;
import static pegast.Parser.cls;
import static pegast.Parser.str;
import static pegast.Parser.named;
import static pegast.Parser.not;
import static pegast.Parser.eps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
bloco  -> stat*
stat   -> "while" exp "do" bloco "end" | NAME "=" exp
exp    -> aexp ">" aexp | aexp
aexp   -> termo (aop termo)*
termo  -> fator (mop fator)*
fator  -> NUM | NAME | "(" exp ")"
aop    -> "+" | "-"
mop    -> "*" | "/"
 */
public class BlocoParser {
	// Regras léxicas
	static Parser<Void> notalphanum = not(cls((char c) -> Character.isJavaIdentifierPart(c)));
	static Parser<Void> alphanum = cls((char c) -> Character.isJavaIdentifierPart(c));
	static Parser<Void> alpha = cls((char c) -> Character.isJavaIdentifierStart(c));
	static Parser<Void> digit = cls((char c) -> Character.isDigit(c));
	static Parser<Void> comment = str("--").seql(star(cls((char c) -> c != '\n')));
	static Parser<Void> space = star(choice(cls((char c) -> Character.isWhitespace(c)),
								            comment)).seqr(eps);
	static Parser<Void> eof = space.seqr(not(cls((char c) -> true)));
	static Parser<Void> kw(String s) {
		return space.seql(named(str(s).seql(notalphanum), s));
	}
	static Map<String, Parser<Void>> kws = new HashMap<String, Parser<Void>>();
	static {
		kws.put("while", kw("while"));
		kws.put("do", kw("do"));
		kws.put("end", kw("end"));
	}
	@SuppressWarnings("unchecked")
	static Parser<Void> notkw = not(choice((Parser<Void>[])(kws.values().toArray(new Parser[0]))));
	static Parser<Token> name = space.seqr(named(notkw.seql(alpha.seql(star(alphanum))), "name"));
	static Parser<Token> num = space.seqr(named(digit.seql(star(digit)), "num"));
	static Parser<Token> op(String s) {
		return space.seqr(named(str(s), s));
	}

	// Gramática
	static Map<String, Parser<?>> g = new HashMap<>();
	static {
		g.put("bloco", star(var(g, "stat")));
		g.put("stat", choice(seq(kws.get("while"),
				                 var(g, "exp"),
				                 kws.get("do"),
				                 var(g, "bloco"),
				                 kws.get("end"), 
				                   (Void _1, Exp cond, Void _2, List<Statement> corpo, Void _3) -> new While(cond, corpo)),
				             seq(name, op("="), var(g, "exp"), 
				               (Token lval, Object _1, Exp rval) -> new Assign(lval.lexema, rval))));
		g.put("exp", choice(seq(var(g, "aexp"),
				                op(">"),
				                var(g, "aexp"),
				                  (Exp left, Token op, Exp right) -> new Maior(left, right, op.pos)),
				            var(g, "aexp")));
		g.put("aexp", seq(var(g, "termo"), 
			             star(choice(seq(op("+"), var(g, "termo")),
					                 seq(op("-"), var(g, "termo")))))); 
		g.put("termo", seq(var(g, "fator"), 
	                       star(choice(seq(op("*"), var(g, "fator")),
			                           seq(op("/"), var(g, "fator")))))); 
		g.put("fator", choice(seq(op("("), var(g, "exp"), op(")")),
				              num, name));
	}

	public static Parser<List<Statement>> parser = 
			Parser.<List<Statement>>var(g, "bloco").seql(eof);
}

