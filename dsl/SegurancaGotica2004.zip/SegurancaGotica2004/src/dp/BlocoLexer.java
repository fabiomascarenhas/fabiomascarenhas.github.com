package dp;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;


public class BlocoLexer extends Lexer {
	public static int NAME = 2;
	public static int NUM = 3;
	public static int WHILE = 4;
	public static int DO = 5;
	public static int END = 6;
	
	public static final Map<String, Integer> reserved =
			new HashMap<String, Integer>();
	
	static {
		reserved.put("while", WHILE);
		reserved.put("do", DO);
		reserved.put("end", END);
	}

	public BlocoLexer(Reader _input) {
		super(_input);
	}

	public boolean isLetra(char x) {
		return (x >= 'a' && x <= 'z') ||
				(x >= 'A' && x <= 'Z');
	}
	
	// [a-zA-Z]
	public void matchLetra() {
		if(isLetra(c)) consume();
		else throw new RuntimeException("esperado letra, encontrado " + c + " em " + lin);
	}

	public boolean isAlphaNum(char x) {
		return (x >= 'a' && x <= 'z') ||
			   (x >= 'A' && x <= 'Z') ||
			   (x >= '0' && x <= '9');
	}
	
	public void testNotAlphaNum() {
		if(isAlphaNum(c)) 
			throw new RuntimeException("esperado não alfanumérico, encontrado " + c + " em " + lin);
	}

	// [a-zA-Z]+[^a-zA-Z0-9]
	public Token name() {
		int lin = this.lin;
		StringBuffer sb = new StringBuffer();
		do {
			sb.append(c);
			matchLetra();
		} while(isLetra(c));
		testNotAlphaNum();
		String texto = sb.toString();
		if(reserved.containsKey(texto)) 
			return new Token(reserved.get(texto), texto, lin);
		else
			return new Token(NAME, texto, lin);
	}

	// [0-9]+[^a-zA-Z0-9]
	public Token num() {
		int lin = this.lin;
		StringBuffer sb = new StringBuffer();
		do {
			sb.append(c);
			matchDigito();
		} while(isDigito(c));
		testNotAlphaNum();
		String texto = sb.toString();
		return new Token(NUM, texto, lin);
	}

	public boolean isDigito(char x) {
		return (x >= '0' && x <= '9');
	}
	
	// [0-9]
	public void matchDigito() {
		if(isDigito(c)) consume();
		else throw new RuntimeException("esperado dígito, encontrado " + c + " em " + lin);
	}

	// '--'[^\n]*
	public void comment() {
		match('-');
		match('-');
		while(c != EOF && c != '\n') {
			consume();
		}
	}

	@Override
	public Token nextToken() {
		while(c != EOF) {
			if(c == '-' && peek(1) == '-') {
				comment(); continue;
			}
			if(Character.isWhitespace(c)) {
				consume();
				continue;
			}
			if(isLetra(c)) return name();
			if(isDigito(c)) return num();
			return single(c);
		}
		return new Token(EOF_TYPE, "<<EOF>>", lin);
	}

	@Override
	public String getTokenName(int type) {
		if(type > 3) return "" + (char)type;
		else if(type == 2) return "name";
		else if(type == 3) return "num";
		else if(type == 1) return "EOF";
		else return "null";
	}

}
