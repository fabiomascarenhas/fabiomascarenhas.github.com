package dp;

import static dp.Parser.seq;
import static dp.Parser.choice;
import static dp.Parser.star;
import static dp.Parser.var;
import static dp.Parser.tok;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlocoParser {
	public static List<Token> parse(String input) {
		Map<String,Parser> g = new HashMap<>();
		g.put("bloco", star(var(g, "stat")));
		g.put("stat", choice(seq(tok(BlocoLexer.WHILE),
				                 var(g, "exp"),
				                 tok(BlocoLexer.DO),
				                 var(g, "bloco"),
				                 tok(BlocoLexer.END)),
				             seq(tok(BlocoLexer.NAME),
				                 tok('='),
				                 var(g, "exp"))));
		g.put("exp", choice(seq(var(g, "aexp"),
				                tok('>'),
				                var(g, "aexp")),
				            var(g, "aexp")));
		g.put("aexp", seq(var(g, "termo"), 
			             star(choice(seq(tok('+'), var(g, "termo")),
					                 seq(tok('-'), var(g, "termo")))))); 
		g.put("termo", seq(var(g, "fator"), 
	                       star(choice(seq(tok('*'), var(g, "fator")),
			                           seq(tok('/'), var(g, "fator")))))); 
		g.put("fator", choice(seq(tok('('), var(g, "exp"), tok(')')),
				              tok(ExpLexer.NUM),
				              tok(ExpLexer.NAME)));
		Parser p = seq(var(g, "bloco"), tok(Lexer.EOF_TYPE));
		//Parser p = var(g, "bloco");
		Lexer l = new BlocoLexer(new java.io.StringReader(input));
		return p.parse(l.allTokens());
	}
}

