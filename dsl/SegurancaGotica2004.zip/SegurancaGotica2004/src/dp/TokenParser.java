package dp;

import java.util.ArrayList;
import java.util.List;

public class TokenParser implements Parser {
	public int tipo;
	
	public TokenParser(int _tipo) {
		tipo = _tipo;
	}
	
	@Override
	public List<Token> parse(List<Token> input) {
		Token tok = input.get(0);
		if(tok.tipo == tipo) {
			return input.subList(1, input.size());
		}
		return null;
	}
}
