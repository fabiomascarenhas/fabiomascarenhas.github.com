package dp;

import java.util.List;

public class OrdChoice implements Parser {
	public Parser p1;
	public Parser p2;
	
	public OrdChoice(Parser _p1, Parser _p2) {
		p1 = _p1;
		p2 = _p2;
	}

	public OrdChoice(Parser... ps) {
		if(ps.length < 2)
			throw new RuntimeException("ordchoice precisa de pelo menos dois elementos");
		p1 = ps[0];
		if(ps.length == 2) {
			p2 = ps[1];
		} else {
			Parser[] nps = new Parser[ps.length-1];
			for(int i = 1; i < ps.length; i++) {
				nps[i-1] = ps[i];
			}
			p2 = new OrdChoice(nps);
		}
	}
	
	@Override
	public List<Token> parse(List<Token> input) {
		List<Token> res = p1.parse(input);
		if(res == null) {
			return p2.parse(input);
		} else {
			return res;
		}
	}

}
