package dp;

import java.util.List;

public class Empty implements Parser {

	@Override
	public List<Token> parse(List<Token> input) {
		return input;
	}

}
