import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

public class StateMachineLexer extends Lexer {
	public static int NAME = 2;
	public static int CODE = 3;
	public static int ARROW = 4; // =>
	public static int EVENTS = 5;
	public static int COMMANDS = 6;
	public static int END = 7;
	public static int ACTIONS = 8;
	public static int STATE = 9;
	// o tipo de '{' é o código do caractere '{'
	// o tipo de '}' é o código do caractere '}'
	
	public static final String[] tokenNames = new String[] {
			"NULL", "EOF", "NAME", "CODE", "=>",
			"EVENTS", "COMMANDS", "END", "ACTIONS", "STATE"
	};
	
	public static final Map<String, Integer> reserved =
			new HashMap<String, Integer>();
	
	static {
		reserved.put("events", EVENTS);
		reserved.put("state", STATE);
		reserved.put("end", END);
		reserved.put("commands", COMMANDS);
		reserved.put("actions", ACTIONS);
	}
	
	public static CharClass letraMin = new CharClass() {
		@Override
		public boolean test(char x) {
			return (x >= 'a' && x <= 'z');
		}

		@Override
		public String name() {
			return "letra minúscula";
		}
	};
	
	public StateMachineLexer(Reader _input) {
		super(_input);
	}

	public Token arrow() {
		int lin = this.lin;
		match('=');
		match('>');
		return new Token(ARROW, "=>", lin);
	}

	public boolean isAlphaNum(char x) {
		return (x >= 'a' && x <= 'z') ||
			   (x >= 'A' && x <= 'Z') ||
			   (x >= '0' && x <= '9');
	}
	
	public void testNotAlphaNum() {
		if(isAlphaNum(c)) 
			throw new RuntimeException("esperado não alfanumérico, encontrado " + c + " em " + lin);
	}

	public boolean isLetra(char x) {
		return (x >= 'a' && x <= 'z') ||
				(x >= 'A' && x <= 'Z');
	}
	
	// [a-zA-Z]
	public void matchLetra() {
		if(isLetra(c)) consume();
		else throw new RuntimeException("esperado letra, encontrado " + c + " em " + lin);
	}
	
	// [A-Z0-9]
	public boolean isCharCodigo(char x) {
		return (x >= 'A' && x <= 'Z') ||
				(x >= '0' && x <= '9');
	}

	public void matchCharCodigo() {
		if(isCharCodigo(c)) consume();
		else throw new RuntimeException("esperado parte de código, encontrado " + c + " em " + lin);
	}
	
	// [a-z]
	public boolean isLetraMin(char x) {
		return (x >= 'a' && x <= 'z');
	}
	
	public void matchLetraMin() {
		match(letraMin);
	}
	
	// [a-z][a-zA-Z]*[^a-zA-Z0-9]
	public Token name() {
		int lin = this.lin;
		StringBuffer sb = new StringBuffer();
		sb.append(c);
		matchLetraMin();
		while(isLetra(c)) {
			sb.append(c);
			matchLetra();
		}
		testNotAlphaNum();
		String texto = sb.toString();
		if(reserved.containsKey(texto)) 
			return new Token(reserved.get(texto), texto, lin);
		else
			return new Token(NAME, texto, lin);
	}
	
	// [A-Z0-9][A-Z0-9][A-Z0-9][A-Z0-9][^a-zA-Z0-9]
	public Token code() {
		int lin = this.lin;
		StringBuffer sb = new StringBuffer();
		sb.append(c);
		matchCharCodigo();
		sb.append(c);
		matchCharCodigo();
		sb.append(c);
		matchCharCodigo();
		sb.append(c);
		matchCharCodigo();
		testNotAlphaNum();
		return new Token(CODE, sb.toString(), lin);
	}
	
	// '--'[^\n]*
	public void comment() {
		match('-');
		match('-');
		while(c != EOF && c != '\n') {
			consume();
		}
	}
	
	@Override
	public Token nextToken() {
		while(c != EOF) {
			if(c == '-' && peek(1) == '-') {
				comment(); continue;
			}
			if(Character.isWhitespace(c)) {
				consume();
				continue;
			}
			if(isLetraMin(c)) return name();
			if(isCharCodigo(c)) return code();
			if(c == '=') return arrow();
			if(c == '{' || c == '}') return single(c);
			throw new RuntimeException("caractere " + c + " não esperado na posição " + lin);
		}
		return new Token(EOF_TYPE, "<<EOF>>", lin);
	}
	
	@Override
	public String getTokenName(int type) {
		if(type > 9) return "" + (char)type;
		else return tokenNames[type];
	}

}
