
public class StateMachineParser extends Parser {

	public StateMachineParser(Lexer _input) {
		super(_input);
	}

	// machine := events commands state+
	public void machine() {
		events();
		commands();
		do {
			state();
		} while(la.tipo == StateMachineLexer.STATE);
	}
	
	// events := "events" event+ "end"
	public void events() {
		match(StateMachineLexer.EVENTS);
		do {
			event();
		} while(la.tipo == StateMachineLexer.NAME);
		match(StateMachineLexer.END);
	}
	
	// event := name code
	public void event() {
		match(StateMachineLexer.NAME);
		match(StateMachineLexer.CODE);
	}

	// commands := "commands" command+ "end"
	public void commands() {
		match(StateMachineLexer.COMMANDS);
		do {
			command();
		} while(la.tipo == StateMachineLexer.NAME);
		match(StateMachineLexer.END);
	}

	// command := name code
	public void command() {
		match(StateMachineLexer.NAME);
		match(StateMachineLexer.CODE);
	}

	// state := "state" name actions? transition* "end"
	public void state() {
		match(StateMachineLexer.STATE);
		match(StateMachineLexer.NAME);
		if(la.tipo == StateMachineLexer.ACTIONS) actions();
		while(la.tipo == StateMachineLexer.NAME) {
			transition();
		}
		match(StateMachineLexer.END);
	}
	
	// actions := "actions" '{' name+ '}'
	public void actions() {
		match(StateMachineLexer.ACTIONS);
		match('{');
		do {
			match(StateMachineLexer.NAME);
		} while(la.tipo == StateMachineLexer.NAME);
		match('}');
	}
	
	// transition := name '=>' name
	public void transition() {
		match(StateMachineLexer.NAME);
		match(StateMachineLexer.ARROW);
		match(StateMachineLexer.NAME);
	}
	
	@Override
	public void parse() {
		machine();
		match(Lexer.EOF_TYPE);
	}

}
