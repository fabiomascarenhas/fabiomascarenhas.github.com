import java.io.IOException;

public abstract class Parser {
	Lexer input;
	Token la; // lookahead
	
	public Parser(Lexer _input) {
		input = _input;
		consume();
	}
	
	public void consume() {
		la = input.nextToken();
	}
	
	public void match(int tipo) {
		if(la.tipo == tipo) consume();
		else throw new RuntimeException("esperado " + input.getTokenName(tipo) + " mas encontrado " + la.texto + " na linha " + la.pos);
	}
	
	public abstract void parse();
}
