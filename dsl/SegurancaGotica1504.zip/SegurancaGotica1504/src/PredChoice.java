import java.util.List;

public class PredChoice implements Parser {
	public Predicate<Token> pred;
	public Parser p1;
	public Parser p2;
	
	public PredChoice(Predicate<Token> _pred, Parser _p1, Parser _p2) {
		pred = _pred;
		p1 = _p1;
		p2 = _p2;
	}
	
	public PredChoice(int _tipo, Parser _p1, Parser _p2) {
		pred = (tok) -> tok.tipo == _tipo;
		p1 = _p1;
		p2 = _p2;
	}

	public PredChoice(int[] _tipos, Parser _p1, Parser _p2) {
		pred = (tok) -> {
			for(int tipo: _tipos) {
				if(tok.tipo == tipo) return true;
			}
			return false;
		};
		p1 = _p1;
		p2 = _p2;
	}

	@Override
	public List<List<Token>> parse(List<Token> input) {
		Token fst = input.get(0);
		if(pred.test(fst)) {
			return p1.parse(input);
		} else {
			return p2.parse(input);
		}
	}

}
