import java.util.List;

public interface Parser {
	List<List<Token>> parse(List<Token> input);
}
