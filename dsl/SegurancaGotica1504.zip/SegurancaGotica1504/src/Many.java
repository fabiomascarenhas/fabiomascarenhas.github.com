import java.util.List;

public class Many implements Parser {
	public Parser p;
	
	public Many(Parser _p) {
		p = new OrdChoice(new Seq(_p, this), new Empty());
		//p = new OrdChoice(new Empty(), new Seq(_p, this));
	}

	public Many(Parser _p, Parser base) {
		p = new OrdChoice(new Seq(_p, this), base);
	}

	@Override
	public List<List<Token>> parse(List<Token> input) {
		return p.parse(input);
	}
	
}
