import java.util.List;

public class PredMany implements Parser {
	public Parser p;
	
	public PredMany(Predicate<Token> _pred, Parser _p) {
		p = new PredChoice(_pred, new Seq(_p, this), new Empty());
	}

	@Override
	public List<List<Token>> parse(List<Token> input) {
		return p.parse(input);
	}

}
