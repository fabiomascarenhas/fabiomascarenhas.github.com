
public class Controller {
	public final StateMachine machine;
	public State currentState;
	
	public Controller(StateMachine _machine) {
		machine = _machine;
		currentState = machine.start;
	}
	
	public void handle(String eventCode) {
		if(currentState.hasTransition(eventCode)) {
			currentState = currentState.targetState(eventCode);
			currentState.executeActions();
		}
	}
}
