package peg;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class State<T> {
	public final List<T> input;
	public final int error;
	public final Set<String> expected;

	public State(List<T> _input) {
		input = _input;
		error = _input.size();
		expected = new HashSet<>();
	}

	public State(List<T> _input, int _error) {
		input = _input;
		error = _error;
		expected = new HashSet<>();
	}

	public State<T> fail(int pos, String exp) {
		if(pos < error) {
			State<T> res = new State<>(null, pos);
			res.expected.add(exp);
			return res;
		} else if(pos == error) {
			State<T> res = new State<>(null, pos);
			res.expected.addAll(expected);
			res.expected.add(exp);
			return res;
		} else {
			State<T> res = new State<>(null, error);
			res.expected.addAll(expected);
			return res;
		}
	}
	
	public State<T> success(List<T> input) {
		State<T> res = new State<T>(input, error);
		res.expected.addAll(expected);
		return res;
	}
	
	public State<T> fail() {
		State<T> res = new State<>(null, error);
		res.expected.addAll(expected);
		return res;
	}
}
