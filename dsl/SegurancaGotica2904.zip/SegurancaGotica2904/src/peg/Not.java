package peg;

public class Not implements Parser {
	public Parser p;
	
	public Not(Parser _p) {
		p = _p;
	}
	
	@Override
	public State<Character> parse(State<Character> st) {
		State<Character> res = p.parse(st);
		if(res.input == null) {
			return st;
		} else {
			return st.fail();
		}
	}

}
