package dp;

import java.util.List;

public class PredMany implements Parser {
	public Parser p;
	
	public PredMany(Predicate<Token> _pred, Parser _p) {
		p = new PredChoice(_pred, new Seq(_p, this), new Empty());
	}

	@Override
	public State<Token> parse(State<Token> st) {
		return p.parse(st);
	}

}
