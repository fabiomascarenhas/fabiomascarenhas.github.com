package pegtree;

import java.util.ArrayList;
import java.util.List;

public class Result<T> {
	public final List<ParseTree> nodes;
	public final State<T> out;
	
	public Result(List<ParseTree> _nodes, State<T> _out) {
		nodes = _nodes;
		out = _out;
	}

	public Result(String _rot, List<ParseTree> _nodes, State<T> _out) {
		nodes = new ArrayList<>();
		nodes.add(new ParseTree(_rot));
		for(ParseTree child: _nodes) {
			nodes.get(0).addChild(child);
		}
		out = _out;
	}

	public Result(ParseTree _node, State<T> _out) {
		nodes = new ArrayList<>();
		nodes.add(_node);
		out = _out;
	}

	public Result(List<ParseTree> _nodes1, List<ParseTree> _nodes2, State<T> _out) {
		nodes = new ArrayList<>();
		nodes.addAll(_nodes1);
		nodes.addAll(_nodes2);
		out = _out;
	}

	public Result(State<T> _out) {
		nodes = new ArrayList<>();
		out = _out;
	}
}
