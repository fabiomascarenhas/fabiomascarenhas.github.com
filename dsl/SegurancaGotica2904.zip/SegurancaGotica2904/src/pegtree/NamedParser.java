package pegtree;

public class NamedParser implements Parser {
	public final Parser p;
	public final String name;
	
	public NamedParser(Parser _p, String _name) {
		p = _p;
		name = _name;
	}
	
	@Override
	public Result<Character> parse(State<Character> st) {
		try {
			Result<Character> res = p.parse(st);
			return new Result<>(new ParseTree(name), res.out);
		} catch(Fail f) {
			throw st.fail(st.input.size(), name);
		}
	}
	
	
}
