package peg;

public class NamedParser implements Parser {
	public final Parser p;
	public final String name;
	
	public NamedParser(Parser _p, String _name) {
		p = _p;
		name = _name;
	}
	
	@Override
	public State<Character> parse(State<Character> st) {
		State<Character> res = p.parse(st);
		if(res.input == null) {
			return st.fail(st.input.size(), name);
		} else {
			return res;
		}
	}
	
	
}
