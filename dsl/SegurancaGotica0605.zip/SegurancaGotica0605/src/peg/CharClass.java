package peg;

public interface CharClass {
	boolean test(char x);
}
