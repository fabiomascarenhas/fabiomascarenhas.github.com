package pegex;

public class CharClassParser implements Parser {
	public final CharClass cls;
	
	public CharClassParser(CharClass _cls) {
		cls = _cls;
	}
	
	@Override
	public State<Character> parse(State<Character> st) {
		if(st.input.isEmpty()) throw st.fail();
		char tok = st.input.get(0);
		if(cls.test(tok)) {
			return st.success(st.input.subList(1, st.input.size()));
		} else {
			throw st.fail();
		}
	}
}
