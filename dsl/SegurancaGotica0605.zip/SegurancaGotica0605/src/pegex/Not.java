package pegex;

public class Not implements Parser {
	public Parser p;
	
	public Not(Parser _p) {
		p = _p;
	}
	
	@Override
	public State<Character> parse(State<Character> st) {
		try {
			p.parse(st);
		} catch (Fail f) {
			return st;
		}
		throw st.fail();
	}

}
