package pegex;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class State<T> {
	public final List<T> input;
	public final int error;
	public final Set<String> expected;

	public State(List<T> _input) {
		input = _input;
		error = _input.size();
		expected = new HashSet<>();
	}

	public State(List<T> _input, int _error) {
		input = _input;
		error = _error;
		expected = new HashSet<>();
	}

	public State(List<T> _input, int _error, Set<String> _expected) {
		input = _input;
		error = _error;
		expected = _expected;
	}

	public Fail fail(int pos, String exp) {
	  if(pos < error) {
	    return new Fail(pos, exp);
	  }
	  if(pos == error) {
		Set<String> _expected = new HashSet<>();
		_expected.addAll(expected);
	    _expected.add(exp);
	    return new Fail(error, _expected);
	  }
	  return new Fail(error, expected);
	}
	
	public State<T> success(List<T> input) {
		State<T> res = new State<T>(input, error);
		res.expected.addAll(expected);
		return res;
	}
	
	public Fail fail() {
		return new Fail(error, expected);
	}
}
