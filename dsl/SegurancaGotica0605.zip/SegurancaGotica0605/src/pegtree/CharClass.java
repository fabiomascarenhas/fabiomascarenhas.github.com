package pegtree;

public interface CharClass {
	boolean test(char x);
}
