package pegtree;

public class Empty implements Parser {

	@Override
	public Result<Character> parse(State<Character> st) {
		return new Result<>(st);
	}

}
