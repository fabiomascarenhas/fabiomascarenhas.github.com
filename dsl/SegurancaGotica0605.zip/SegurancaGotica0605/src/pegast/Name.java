package pegast;

public class Name implements Exp {
	public final String var;
	public final int pos;
	
	public Name(String _var, int _pos) {
		var = _var;
		pos = _pos;
	}
	
	@Override
	public int getPos() {
		return pos;
	}
	
}
