package pegast;

public class Token {
	public final String lexema;
	public final int pos;
	
	public Token(String _lexema, int _pos) {
		lexema = _lexema;
		pos = _pos;
	}
}
