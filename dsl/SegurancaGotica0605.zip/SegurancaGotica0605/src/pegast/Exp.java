package pegast;

public interface Exp extends Node {
	int getPos();
}
