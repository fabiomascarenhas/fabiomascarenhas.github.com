package pegast;

public class Assign implements Statement {
	public final String lval;
	public final Exp rval;
	
	public Assign(String _lval, Exp _rval) {
		lval = _lval;
		rval = _rval;
	}
}
