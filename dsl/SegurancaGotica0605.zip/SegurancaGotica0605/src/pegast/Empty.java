package pegast;

public class Empty implements Parser<Void> {

	@Override
	public Result<Void> parse(State<Character> st) {
		return new Result<>(null, st);
	}

}
