package pegast;

public class Transition implements Node {
	public final String from;
	public final String to;
	
	public final int pos;
	
	public Transition(String _from, String _to, int _pos) {
		from = _from;
		to = _to;
		pos = _pos;
	}
}
