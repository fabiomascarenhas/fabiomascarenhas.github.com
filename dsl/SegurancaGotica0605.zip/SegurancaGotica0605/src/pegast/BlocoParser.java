package pegast;

import static pegast.Parser.choice;
import static pegast.Parser.star;
import static pegast.Parser.seq;
import static pegast.Parser.var;
import static pegast.Parser.cls;
import static pegast.Parser.str;
import static pegast.Parser.fun;
import static pegast.Parser.named;
import static pegast.Parser.not;
import static pegast.Parser.eps;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;

/*
bloco  -> stat*
stat   -> "while" exp "do" bloco "end" | NAME "=" exp
exp    -> aexp ">" aexp | aexp
aexp   -> termo (aop termo)*
termo  -> fator (mop fator)*
fator  -> NUM | NAME | "(" exp ")"
aop    -> "+" | "-"
mop    -> "*" | "/"
 */
public class BlocoParser {
	// Regras léxicas
	static Parser<Void> notalphanum = not(cls((char c) -> Character.isJavaIdentifierPart(c)));
	static Parser<Void> alphanum = cls((char c) -> Character.isJavaIdentifierPart(c));
	static Parser<Void> alpha = cls((char c) -> Character.isJavaIdentifierStart(c));
	static Parser<Void> digit = cls((char c) -> Character.isDigit(c));
	static Parser<Void> comment = seq(str("--"), star(cls((char c) -> c != '\n')));
	static Parser<Void> space = star(choice(cls((char c) -> Character.isWhitespace(c)),
								            comment)).seqr(eps);
	static Parser<Void> eof = seq(space, not(cls((char c) -> true)));
	static Parser<Void> kw(String s) {
		return space.seql(named(seq(str(s), notalphanum), s));
	}
	static Map<String, Parser<Void>> kws = new HashMap<String, Parser<Void>>();
	static {
		kws.put("while", kw("while"));
		kws.put("do", kw("do"));
		kws.put("end", kw("end"));
	}
	@SuppressWarnings("unchecked")
	static Parser<Void> notkw = not(choice((Parser<Void>[])(kws.values().toArray(new Parser[0]))));
	static Parser<Token> name = space.seqr(named(seq(notkw, alpha, star(alphanum)), "name"));
	static Parser<Token> num = space.seqr(named(seq(digit, star(digit)), "num"));
	static Parser<Token> op(String s) {
		return space.seqr(named(str(s), s));
	}

	// Gramática
	static Map<String, Parser<?>> g = new HashMap<>();
	static {
		g.put("bloco", star(var(g, "stat")));
		g.put("stat", choice(seq(kws.get("while"),
				                 var(g, "exp"),
				                 kws.get("do"),
				                 var(g, "bloco"),
				                 kws.get("end"), 
				                   (Void _1, Exp cond, Void _2, List<Statement> corpo, Void _3) -> new While(cond, corpo)),
				             seq(name, op("="), var(g, "exp"), 
				               (Token lval, Object _1, Exp rval) -> new Assign(lval.lexema, rval))));
		g.put("exp", choice(seq(var(g, "aexp"),
				                op(">"),
				                var(g, "aexp"),
				                  (Exp left, Token op, Exp right) -> new Maior(left, right, op.pos)),
				            var(g, "aexp")));
		g.put("aexp", Parser.<Exp>chainl(var(g, "termo"), var(g, "aop"))); 
		g.put("termo", Parser.<Exp>chainl(var(g, "fator"), var(g, "mop"))); 
		g.put("fator", choice(seq(op("("), var(g, "exp"), op(")"), 
					                (Object _1, Exp exp, Object _2) -> exp), 
				fun(num, (Token num) -> new Num(num.lexema, num.pos)), 
				fun(name, (Token name) -> new Name(name.lexema, name.pos))));
		g.put("aop", choice(Parser.<Token,BiFunction<Exp,Exp,Exp>>fun(op("+"), (Token op) ->
		                          (Exp left, Exp right) -> new Soma(left, right, op.pos)),
				            Parser.<Token,BiFunction<Exp,Exp,Exp>>fun(op("-"), (Token op) ->
                                  (Exp left, Exp right) -> new Sub(left, right, op.pos))));	                         			
		g.put("mop", choice(Parser.<Token,BiFunction<Exp,Exp,Exp>>fun(op("*"), (Token op) ->
                                  (Exp left, Exp right) -> new Mult(left, right, op.pos)),
                            Parser.<Token,BiFunction<Exp,Exp,Exp>>fun(op("/"), (Token op) ->
                                  (Exp left, Exp right) -> new Div(left, right, op.pos))));	                         			
	}

	public static Parser<Node> parser = 
			Parser.<List<Statement>,Node>fun(Parser.<List<Statement>>var(g, "bloco").seql(eof),
					(List<Statement> stats) -> new Node() {
						public List<Statement> sts = stats;
					});
}

