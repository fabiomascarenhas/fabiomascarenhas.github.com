package pegast;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Fail extends RuntimeException {
	private static final long serialVersionUID = 5546168256043052907L;

	public final int error;
	public final Set<String> expected;
	
	public Fail(int _error, Set<String> _expected) {
		error = _error;
		expected = _expected;
	}

	public Fail(int _error, String _expected) {
		error = _error;
		expected = new HashSet<String>();
		expected.add(_expected);
	}

	public State<Character> success(List<Character> input) {
		return new State<>(input, error, expected);
	}
}
