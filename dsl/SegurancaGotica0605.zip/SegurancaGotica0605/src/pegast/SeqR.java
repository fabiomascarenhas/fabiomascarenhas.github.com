package pegast;

public class SeqR<T> implements Parser<T> {
	public Parser<?> p1;
	public Parser<? extends T> p2;
	
	public SeqR(Parser<?> _p1, Parser<? extends T> _p2) {
		p1 = _p1;
		p2 = _p2;
	}
		
	@Override
	public Result<? extends T> parse(State<Character> st) {
		Result<?> res1 = p1.parse(st);
		return p2.parse(res1.out);
	}

}

