package pegast;

import java.util.function.BiFunction;

public class ChainL<T> implements Parser<T> {
	public final Parser<? extends T> term;
	public final Parser<BiFunction<? super T, ? super T, ? extends T>> op;
	
	public ChainL(Parser<? extends T> _term, Parser<BiFunction<? super T, ? super T, ? extends T>> _op) {
		term = _term;
		op = _op;
	}
 	
	@Override
	public Result<? extends T> parse(State<Character> st) {
		Result<? extends T> resl = term.parse(st);
		T left = resl.res;
		while(true) {
			try {
				Result<? extends BiFunction<? super T, ? super T, ? extends T>>
					resop = op.parse(resl.out);
				BiFunction<? super T, ? super T, ? extends T> fop = resop.res;
				Result<? extends T> resr = term.parse(resop.out);
				T right = resr.res;
				left = fop.apply(left, right);
				resl = resr;
			} catch(Fail f) {
				return new Result<>(left, f.success(resl.out.input));
			}
		}
	}
	
}
