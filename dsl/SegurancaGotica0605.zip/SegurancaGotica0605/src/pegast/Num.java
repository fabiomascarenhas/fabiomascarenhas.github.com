package pegast;

public class Num implements Exp {
	public final String val;
	public final int pos;
	
	public Num(String _val, int _pos) {
		val = _val;
		pos = _pos;
	}
	
	@Override
	public int getPos() {
		return pos;
	}
	
}
