package dp;


public class Token {
	public final int tipo;
	public final String texto;
	public final int pos;
		
	public Token(int _tipo, String _texto, int _pos) {
		tipo = _tipo;
		texto = _texto;
		pos = _pos;
	}
	
	public String toString() {
		return "<" + tipo + "," + texto + "," + pos + ">";
	}
}
