package dp;

import static dp.Parser.seq;
import static dp.Parser.choice;
import static dp.Parser.star;
import static dp.Parser.var;
import static dp.Parser.tok;

import java.util.HashMap;
import java.util.Map;

public class ExpParser {
	public static State<Token> parse(String input) {
		Map<String,Parser> g = new HashMap<>();
		g.put("exp", seq(var(g, "termo"), 
			             star(choice(seq(tok('+'), var(g, "termo")),
					                 seq(tok('-'), var(g, "termo")))))); 
		g.put("termo", seq(var(g, "fator"), 
	                       star(choice(seq(tok('*'), var(g, "fator")),
			                           seq(tok('/'), var(g, "fator")))))); 
		g.put("fator", choice(seq(tok('('), var(g, "exp"), tok(')')),
				              tok(ExpLexer.NUM),
				              tok(ExpLexer.NAME)));
		//Parser p = seq(var(g, "exp"), tok(Lexer.EOF_TYPE));
		Parser p = var(g, "exp");
		Lexer l = new ExpLexer(new java.io.StringReader(input));
		return p.parse(new State<>(l.allTokens()));
	}
}

