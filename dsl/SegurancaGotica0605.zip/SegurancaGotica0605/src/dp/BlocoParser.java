package dp;

import static dp.Parser.seq;
import static dp.Parser.choice;
import static dp.Parser.star;
import static dp.Parser.var;
import static dp.Parser.tok;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlocoParser {
	public static void parse(String input) {
		Map<String,Parser> g = new HashMap<>();
		g.put("bloco", star(var(g, "stat")));
		g.put("stat", choice(seq(tok(BlocoLexer.WHILE),
				                 var(g, "exp"),
				                 tok(BlocoLexer.DO),
				                 var(g, "bloco"),
				                 tok(BlocoLexer.END)),
				             seq(tok(BlocoLexer.NAME),
				                 tok('='),
				                 var(g, "exp"))));
		g.put("exp", choice(seq(var(g, "aexp"),
				                tok('>'),
				                var(g, "aexp")),
				            var(g, "aexp")));
		g.put("aexp", seq(var(g, "termo"), 
			             star(choice(seq(tok('+'), var(g, "termo")),
					                 seq(tok('-'), var(g, "termo")))))); 
		g.put("termo", seq(var(g, "fator"), 
	                       star(choice(seq(tok('*'), var(g, "fator")),
			                           seq(tok('/'), var(g, "fator")))))); 
		g.put("fator", choice(seq(tok('('), var(g, "exp"), tok(')')),
				              tok(ExpLexer.NUM),
				              tok(ExpLexer.NAME)));
		Parser p = seq(var(g, "bloco"), tok(Lexer.EOF_TYPE));
		//arser p = var(g, "bloco");
		Lexer l = new BlocoLexer(new java.io.StringReader(input));
		List<Token> toks = l.allTokens();
		State<Token> res = p.parse(new State<>(toks));
		if(res.input == null) {
			Token tokerr = toks.get(toks.size() - res.error);
			Integer[] expected = new Integer[res.expected.size()];
			res.expected.toArray(expected);
			String[] esps = new String[res.expected.size()];
			for(int i = 0; i < expected.length; i++) {
				esps[i] = l.getTokenName(expected[i]);
			}
			throw new RuntimeException("erro no token " + tokerr.texto + " na linha " + tokerr.pos + ", esperado " +
					String.join(", ", esps));
		}
	}
}

