package dp;

import java.util.Map;

public class Variable implements Parser {
	public Map<String, Parser> g;
	public String name;
	
	public Variable(Map<String, Parser> _g, String _name) {
		g = _g;
		name = _name;
	}
	
	@Override
	public State<Token> parse(State<Token> st) {
		return g.get(name).parse(st);
	}

}
