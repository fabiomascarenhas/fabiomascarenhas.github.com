
public class ExpParserTree extends ExpParser {
	ParseTree root;
	ParseTree current;
	
	public ExpParserTree(Lexer _input) {
		super(_input);
	}

	@Override
	public void match(int tipo) {
		if(tipo != Lexer.EOF_TYPE) current.addChild(la.texto);
		super.match(tipo);
	}
	
	@Override
	public void exp() {
		ParseTree node = new ParseTree("exp");
		if(root == null) root = node;
		else current.addChild(node);
		ParseTree save = current;
		current = node;
		super.exp();
		current = save;
	}

	@Override
	public void termo() {
		ParseTree node = new ParseTree("termo");
		if(root == null) root = node;
		else current.addChild(node);
		ParseTree save = current;
		current = node;
		super.termo();
		current = save;
	}

	@Override
	public void fator() {
		ParseTree node = new ParseTree("fator");
		if(root == null) root = node;
		else current.addChild(node);
		ParseTree save = current;
		current = node;
		super.fator();
		current = save;
	}
}
