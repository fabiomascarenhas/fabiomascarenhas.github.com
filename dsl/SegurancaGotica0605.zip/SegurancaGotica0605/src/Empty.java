
import java.util.ArrayList;
import java.util.List;

public class Empty implements Parser {

	@Override
	public List<List<Token>> parse(List<Token> input) {
		ArrayList<List<Token>> res = new ArrayList<>();
		res.add(input);
		return res;
	}

}
