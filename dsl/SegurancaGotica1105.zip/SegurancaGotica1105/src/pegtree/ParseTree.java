package pegtree;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ParseTree {
	public final String rot;
	public final List<ParseTree> children;
	
	public ParseTree(String _rot) {
		rot = _rot;
		children = new ArrayList<>();
	}
	
	public void addChild(ParseTree child) {
		children.add(child);
	}
	
	public void addChild(String child) {
		children.add(new ParseTree(child));
	}

	public int printDot(BufferedWriter buf, int count) throws IOException {
		int me = count;
		buf.write(String.valueOf(me));
		buf.write(" [label=\"");
		buf.write(rot);
		buf.write("\",shape=box];");
		for(ParseTree child: children) {
			count++;
			buf.write(String.valueOf(me));
			buf.write("->");
			buf.write(String.valueOf(count));
			buf.write(";\n");
			count = child.printDot(buf, count);
		}
		return count;
	}
	
	public void printDot(String fileName) throws IOException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write("digraph tree {\n");
		printDot(buf, 0);
		buf.write("}");
		buf.close();
	}

	public String toString() {
		if(children.isEmpty()) return "'"+rot+"'";
		String[] cs = new String[children.size()];
		for(int i = 0; i < children.size(); i++) {
			cs[i] = children.get(i).toString();
		}
		return rot + "(" + String.join(", ", cs) + ")";
	}
}
