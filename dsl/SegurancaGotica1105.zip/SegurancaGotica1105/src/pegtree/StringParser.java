package pegtree;

public class StringParser implements Parser {
	public final char[] s;
	
	public StringParser(String _s) {
		s = _s.toCharArray();
	}

	@Override
	public Result<Character> parse(State<Character> st) {
		if(s.length > st.input.size()) throw st.fail();
		for(int i = 0; i < s.length; i++) {
			if(s[i] != st.input.get(i))
				throw st.fail();
		}
		return new Result<>(st.success(st.input.subList(s.length, st.input.size())));
	}
}
