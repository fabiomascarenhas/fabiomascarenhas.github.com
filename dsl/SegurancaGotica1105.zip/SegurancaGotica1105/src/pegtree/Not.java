package pegtree;

public class Not implements Parser {
	public Parser p;
	
	public Not(Parser _p) {
		p = _p;
	}
	
	@Override
	public Result<Character> parse(State<Character> st) {
		try {
			p.parse(st);
		} catch (Fail f) {
			return new Result<>(st);
		}
		throw st.fail();
	}

}
