package machine;

public class Event implements Node {
	public final String name;
	public final String code;
	
	public final int pos;
	
	public Event(String _name, String _code, int _pos) {
		name = _name;
		code = _code;
		pos = _pos;
	}
	
	public String toString() {
		return "    " + name + " " + code;
	}
	
	public void run(Visitor v) {
		v.visit(this);
	}
}
