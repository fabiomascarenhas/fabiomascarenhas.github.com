package machine;

public class PrintVisitor implements Visitor {

	@Override
	public void visit(Command c) {
		System.out.println("    " + c.name + " " + c.code);
	}

	@Override
	public void visit(Event e) {
		System.out.println("    " + e.name + " " + e.code);
	}

	@Override
	public void visit(Machine m) {
		System.out.println("events");
		for(Event e: m.events) {
			e.run(this); // visitar os filhos
		}
		System.out.println("end");
		System.out.println("commands");
		for(Command c: m.commands) {
			c.run(this); // visitar os filhos
		}
		System.out.println("end");
		for(MachineState s: m.states) {
			s.run(this);
		}
	}

	@Override
	public void visit(MachineState s) {
		System.out.println("state " + s.name);
		if(!s.actions.isEmpty()) {
			System.out.println("     { " + String.join(", ", s.actions) + " }");
		}
		for(Transition t: s.transitions) {
			t.run(this);
		}
		System.out.println("end");
	}

	@Override
	public void visit(Transition t) {
		System.out.println("    " + t.from + " => " + t.to);
	}

}
