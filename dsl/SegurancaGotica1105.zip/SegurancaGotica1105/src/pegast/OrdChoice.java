package pegast;

public class OrdChoice<T> implements Parser<T> {
	public Parser<? extends T> p1;
	public Parser<? extends T> p2;
	
	public OrdChoice(Parser<? extends T> _p1, Parser<? extends T> _p2) {
		p1 = _p1;
		p2 = _p2;
	}

	@SafeVarargs
	@SuppressWarnings("unchecked")
	public OrdChoice(Parser<? extends T>... ps) {
		if(ps.length < 2)
			throw new RuntimeException("ordchoice precisa de pelo menos dois elementos");
		p1 = ps[0];
		if(ps.length == 2) {
			p2 = ps[1];
		} else {
			Parser<? extends T>[] nps = new Parser[ps.length-1];
			for(int i = 1; i < ps.length; i++) {
				nps[i-1] = ps[i];
			}
			p2 = new OrdChoice<T>(nps);
		}
	}
	
	@Override
	public Result<? extends T> parse(State<Character> st) {
		try {
			return p1.parse(st);
		} catch(Fail f) {
			return p2.parse(new State<>(st.input, f.error, f.expected));
		}
	}
}
