package pegast;

public class SeqL<T> implements Parser<T> {
	public Parser<? extends T> p1;
	public Parser<?> p2;
	
	public SeqL(Parser<? extends T> _p1, Parser<?> _p2) {
		p1 = _p1;
		p2 = _p2;
	}
		
	@Override
	public Result<? extends T> parse(State<Character> st) {
		Result<? extends T> res1 = p1.parse(st);
		Result<?> res2 = p2.parse(res1.out);
		return new Result<>(res1.res, res2.out);
	}

}

