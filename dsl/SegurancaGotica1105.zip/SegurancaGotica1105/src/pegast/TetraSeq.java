package pegast;

public class TetraSeq<A,B,C,D,T> implements Parser<T> {
	public final Parser<A> p1;
	public final Parser<B> p2;
	public final Parser<C> p3;
	public final Parser<D> p4;
	public TetraFunction<? super A,? super B,? super C, ? super D, ? extends T> comb;
	
	public TetraSeq(Parser<A> _p1, Parser<B> _p2, Parser<C> _p3, Parser<D> _p4, 
			        TetraFunction<? super A,? super B, ? super C, ? super D, ? extends T> _comb) {
		p1 = _p1;
		p2 = _p2;
		p3 = _p3;
		p4 = _p4;
		comb = _comb;
	}
		
	@Override
	public Result<? extends T> parse(State<Character> st) {
		Result<? extends A> res1 = p1.parse(st);
		Result<? extends B> res2 = p2.parse(res1.out);
		Result<? extends C> res3 = p3.parse(res2.out);
		Result<? extends D> res4 = p4.parse(res3.out);
		return new Result<>(comb.apply(res1.res, res2.res, res3.res, res4.res),
				            res4.out);
	}

}

