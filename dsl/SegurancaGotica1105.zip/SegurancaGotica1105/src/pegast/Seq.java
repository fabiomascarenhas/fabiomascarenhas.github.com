package pegast;

public class Seq implements Parser<Void> {
	public Parser<?> p1;
	public Parser<?> p2;
	
	public Seq(Parser<?> _p1, Parser<?> _p2) {
		p1 = _p1;
		p2 = _p2;
	}
	
	public Seq(Parser<?>... ps) {
		if(ps.length < 2)
			throw new RuntimeException("seq precisa de pelo menos dois elementos");
		p1 = ps[0];
		if(ps.length == 2) {
			p2 = ps[1];
		} else {
			Parser<?>[] nps = new Parser[ps.length-1];
			for(int i = 1; i < ps.length; i++) {
				nps[i-1] = ps[i];
			}
			p2 = new Seq(nps);
		}
	}
	
	@Override
	public Result<? extends Void> parse(State<Character> st) {
		Result<?> res1 = p1.parse(st);
		Result<?> res2 = p2.parse(res1.out);
		return new Result<>(null, res2.out);
	}

}

