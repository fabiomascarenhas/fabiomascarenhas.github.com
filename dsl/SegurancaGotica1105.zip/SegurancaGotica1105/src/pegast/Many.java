package pegast;

import java.util.ArrayList;
import java.util.List;

public class Many<T> implements Parser<List<T>> {
	public Parser<List<T>> p;
	
	public Many(Parser<? extends T> _p) {
		p = Parser.choice(Parser.seq(_p, this,(T t, List<T> ts) -> {
			List<T> nts = new ArrayList<>();
			nts.add(t);
			nts.addAll(ts);
			return nts;
		}), Parser.fun(eps, (Void _v) -> new ArrayList<T>()));
	}

	@Override
	public Result<? extends List<T>> parse(State<Character> st) {
		return p.parse(st);
	}
	
}
