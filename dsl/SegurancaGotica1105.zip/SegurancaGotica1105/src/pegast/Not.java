package pegast;

public class Not implements Parser<Void> {
	public Parser<?> p;
	
	public Not(Parser<?> _p) {
		p = _p;
	}
	
	@Override
	public Result<Void> parse(State<Character> st) {
		try {
			p.parse(st);
		} catch (Fail f) {
			return new Result<>(null, st);
		}
		throw st.fail();
	}

}
