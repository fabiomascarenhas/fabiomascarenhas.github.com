package pegast;

import java.util.function.Supplier;

public class Lazy<T> implements Parser<T> {
	public final Supplier<Parser<? extends T>> f;
	public Parser<? extends T> p;
	
	public Lazy(Supplier<Parser<? extends T>> _f) {
		f = _f;
	}
	
	@Override
	public Result<? extends T> parse(State<Character> st) {
		if(p == null)
			p = f.get();
		return p.parse(st);
	}
}
