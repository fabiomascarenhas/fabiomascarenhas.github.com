package bloco;

import java.util.Map;

public class EvalVisitor implements Visitor {
	Map<String, Integer> vars;
	int value; // valor da última expressão avaliada
	
	public EvalVisitor(Map<String, Integer> _vars) {
		vars = _vars;
	}
	
	@Override
	public void visit(Assign a) {
		a.rval.run(this);
		vars.put(a.lval, value);
	}

	@Override
	public void visit(Div d) {
		d.left.run(this);
		int vl = value;
		d.right.run(this);
		value = vl / value;
	}

	@Override
	public void visit(Maior m) {
		m.left.run(this);
		int vl = value;
		m.right.run(this);
		value = vl > value ? 1 : 0;
	}

	@Override
	public void visit(Soma s) {
		s.left.run(this);
		int vl = value;
		s.right.run(this);
		value = vl + value;
	}

	@Override
	public void visit(Sub s) {
		s.left.run(this);
		int vl = value;
		s.right.run(this);
		value = vl - value;
	}

	@Override
	public void visit(Mult m) {
		m.left.run(this);
		int vl = value;
		m.right.run(this);
		value = vl * value;
	}

	@Override
	public void visit(While w) {
		while(true) {
			w.cond.run(this);
			if(value == 0) break;
			for(Statement s: w.corpo)
				s.run(this);
		}
	}

	@Override
	public void visit(Name n) {
		value = vars.getOrDefault(n.var, 0);
	}

	@Override
	public void visit(Num n) {
		value = Integer.parseInt(n.val);
	}
	
}
