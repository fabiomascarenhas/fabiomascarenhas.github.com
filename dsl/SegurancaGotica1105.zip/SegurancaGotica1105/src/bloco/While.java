package bloco;

import java.util.List;
import java.util.Map;

public class While implements Statement {
	public final Exp cond;
	public final List<Statement> corpo;
	
	public While(Exp _cond, List<Statement> _corpo) {
		cond = _cond;
		corpo = _corpo;
	}

	@Override
	public void eval(Map<String, Integer> vars) {
		while(cond.eval(vars) != 0) {
			for(Statement s: corpo)
				s.eval(vars);
		}
	}

	public void run(Visitor v) {
		v.visit(this);
	}
}
