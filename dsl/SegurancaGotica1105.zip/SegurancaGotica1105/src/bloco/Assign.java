package bloco;

import java.util.Map;

public class Assign implements Statement {
	public final String lval;
	public final Exp rval;
	
	public Assign(String _lval, Exp _rval) {
		lval = _lval;
		rval = _rval;
	}

	@Override
	public void eval(Map<String, Integer> vars) {
		vars.put(lval, rval.eval(vars));
	}

	public void run(Visitor v) {
		v.visit(this);
	}
}
