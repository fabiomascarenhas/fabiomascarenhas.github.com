package bloco;

import java.util.Map;

public interface Statement extends Node { 
	void eval(Map<String, Integer> vars);
	void run(Visitor v);
}
