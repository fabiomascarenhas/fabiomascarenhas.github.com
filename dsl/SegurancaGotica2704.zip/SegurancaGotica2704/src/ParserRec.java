public abstract class ParserRec {
	Lexer input;
	Token la; // lookahead
	
	public ParserRec(Lexer _input) {
		input = _input;
		consume();
	}
	
	public void consume() {
		la = input.nextToken();
	}
	
	public void match(int tipo) {
		if(la.tipo == tipo) consume();
		else throw new RuntimeException("esperado " + input.getTokenName(tipo) + " mas encontrado " + la.texto + " na linha " + la.pos);
	}
	
	public abstract void parse();
}
