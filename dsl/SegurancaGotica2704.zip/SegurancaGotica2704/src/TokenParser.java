
import java.util.ArrayList;
import java.util.List;

public class TokenParser implements Parser {
	public int tipo;
	
	public TokenParser(int _tipo) {
		tipo = _tipo;
	}
	
	@Override
	public List<List<Token>> parse(List<Token> input) {
		Token tok = input.get(0);
		ArrayList<List<Token>> res = new ArrayList<>();
		if(tok.tipo == tipo) {
			res.add(input.subList(1, input.size()));
		}
		return res;
	}
}
