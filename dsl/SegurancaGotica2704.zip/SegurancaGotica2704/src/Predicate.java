

public interface Predicate<T> {
	boolean test(T x);
}
