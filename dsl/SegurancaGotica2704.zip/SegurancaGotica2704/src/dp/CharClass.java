package dp;

public interface CharClass {
	boolean test(char x);
	String name();
}
