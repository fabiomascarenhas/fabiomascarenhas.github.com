package dp;

import java.util.ArrayList;
import java.util.List;

public class TokenParser implements Parser {
	public final int tipo;
	
	public TokenParser(int _tipo) {
		tipo = _tipo;
	}
	
	@Override
	public State<Token> parse(State<Token> st) {
		Token tok = st.input.get(0);
		if(tok.tipo == tipo) {
			return st.success(st.input.subList(1, st.input.size()));
		} else {
			return st.fail(st.input.size(), tipo);
		}
	}
}
