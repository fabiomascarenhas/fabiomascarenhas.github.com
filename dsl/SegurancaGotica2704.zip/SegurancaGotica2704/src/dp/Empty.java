package dp;

import java.util.List;

public class Empty implements Parser {

	@Override
	public State<Token> parse(State<Token> st) {
		return st;
	}

}
