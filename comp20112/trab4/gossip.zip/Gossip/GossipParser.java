// Output created by jacc on Wed Nov 30 14:40:17 BRST 2011


import java.io.*;
import java.util.*;

class GossipParser implements GossipTokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case CLASS:
                        case ENDINPUT:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 252;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    switch (yytok) {
                        case CLASS:
                            yyn = 4;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    switch (yytok) {
                        case CLASS:
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    switch (yytok) {
                        case ID:
                            yyn = 5;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case '{':
                            yyn = 6;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    switch (yytok) {
                        case VAR:
                        case DEF:
                        case '}':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    switch (yytok) {
                        case DEF:
                            yyn = 11;
                            continue;
                        case VAR:
                            yyn = 12;
                            continue;
                        case '}':
                            yyn = 13;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    switch (yytok) {
                        case VAR:
                        case DEF:
                        case '}':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    switch (yytok) {
                        case VAR:
                        case DEF:
                        case '}':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    switch (yytok) {
                        case VAR:
                        case DEF:
                        case '}':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    switch (yytok) {
                        case ID:
                            yyn = 14;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    switch (yytok) {
                        case ID:
                            yyn = 15;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case CLASS:
                        case ENDINPUT:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case '(':
                            yyn = 16;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    switch (yytok) {
                        case ';':
                            yyn = 17;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                        case ')':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    switch (yytok) {
                        case VAR:
                        case DEF:
                        case '}':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    switch (yytok) {
                        case ',':
                            yyn = 21;
                            continue;
                        case ')':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case ')':
                            yyn = 22;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ID:
                            yyn = 23;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case '{':
                            yyn = 24;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    yyn = yys24();
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys25();
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case '=':
                            yyn = 47;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    switch (yytok) {
                        case ';':
                            yyn = 48;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case '.':
                            yyn = 50;
                            continue;
                        case '[':
                            yyn = 51;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    yyn = yys30();
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case ';':
                            yyn = 52;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case '=':
                            yyn = yyr29();
                            continue;
                        case '.':
                        case '[':
                            yyn = yyr39();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case '(':
                            yyn = 53;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    switch (yytok) {
                        case ID:
                            yyn = 60;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    switch (yytok) {
                        case '(':
                            yyn = 61;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    yyn = yys45();
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    switch (yytok) {
                        case VAR:
                        case DEF:
                        case '}':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    yyn = yys48();
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    yyn = yys49();
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case ID:
                            yyn = 65;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys51();
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    yyn = yys53();
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys54();
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    switch (yytok) {
                        case ID:
                            yyn = 81;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys59();
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ';':
                            yyn = 84;
                            continue;
                        case '=':
                            yyn = 85;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    yyn = yys61();
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    yyn = yys62();
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    yyn = yys63();
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    switch (yytok) {
                        case '(':
                            yyn = 90;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    yyn = yys73();
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    yyn = yys76();
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 204:
                    yyn = yys78();
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 205:
                    switch (yytok) {
                        case ID:
                            yyn = 103;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 206:
                    yyn = yys80();
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 207:
                    switch (yytok) {
                        case '(':
                            yyn = 105;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 208:
                    yyn = yys82();
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 209:
                    yyn = yys83();
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 210:
                    yyn = yys84();
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 211:
                    yyn = yys85();
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 212:
                    yyn = yys86();
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 213:
                    yyn = yys87();
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 214:
                    yyn = yys88();
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 215:
                    yyn = yys89();
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 216:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 217:
                    switch (yytok) {
                        case '=':
                            yyn = yyr30();
                            continue;
                        case '.':
                        case '[':
                            yyn = yyr42();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 218:
                    yyn = yys92();
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 219:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 220:
                    yyn = yys94();
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 221:
                    yyn = yys95();
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 222:
                    yyn = yys96();
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 223:
                    yyn = yys97();
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 224:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 225:
                    yyn = yys99();
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 226:
                    yyn = yys100();
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 227:
                    yyn = yys101();
                    continue;

                case 102:
                    yyst[yysp] = 102;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 228:
                    yyn = yys102();
                    continue;

                case 103:
                    yyst[yysp] = 103;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 229:
                    switch (yytok) {
                        case '(':
                            yyn = 112;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 104:
                    yyst[yysp] = 104;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 230:
                    yyn = yys104();
                    continue;

                case 105:
                    yyst[yysp] = 105;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 231:
                    yyn = yys105();
                    continue;

                case 106:
                    yyst[yysp] = 106;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 232:
                    yyn = yys106();
                    continue;

                case 107:
                    yyst[yysp] = 107;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 233:
                    yyn = yys107();
                    continue;

                case 108:
                    yyst[yysp] = 108;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 234:
                    yyn = yys108();
                    continue;

                case 109:
                    yyst[yysp] = 109;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 235:
                    switch (yytok) {
                        case ')':
                            yyn = 117;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 110:
                    yyst[yysp] = 110;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 236:
                    switch (yytok) {
                        case ',':
                            yyn = 118;
                            continue;
                        case ')':
                            yyn = yyr58();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 111:
                    yyst[yysp] = 111;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 237:
                    yyn = yys111();
                    continue;

                case 112:
                    yyst[yysp] = 112;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 238:
                    yyn = yys112();
                    continue;

                case 113:
                    yyst[yysp] = 113;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 239:
                    yyn = yys113();
                    continue;

                case 114:
                    yyst[yysp] = 114;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 240:
                    switch (yytok) {
                        case ')':
                            yyn = 122;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 115:
                    yyst[yysp] = 115;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 241:
                    yyn = yys115();
                    continue;

                case 116:
                    yyst[yysp] = 116;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 242:
                    yyn = yys116();
                    continue;

                case 117:
                    yyst[yysp] = 117;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 243:
                    switch (yytok) {
                        case ';':
                            yyn = yyr43();
                            continue;
                        case '.':
                        case '[':
                            yyn = yyr41();
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 118:
                    yyst[yysp] = 118;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 244:
                    yyn = yys118();
                    continue;

                case 119:
                    yyst[yysp] = 119;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 245:
                    yyn = yys119();
                    continue;

                case 120:
                    yyst[yysp] = 120;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 246:
                    yyn = yys120();
                    continue;

                case 121:
                    yyst[yysp] = 121;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 247:
                    switch (yytok) {
                        case ')':
                            yyn = 125;
                            continue;
                    }
                    yyn = 255;
                    continue;

                case 122:
                    yyst[yysp] = 122;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 248:
                    yyn = yys122();
                    continue;

                case 123:
                    yyst[yysp] = 123;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 249:
                    yyn = yys123();
                    continue;

                case 124:
                    yyst[yysp] = 124;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 250:
                    yyn = yys124();
                    continue;

                case 125:
                    yyst[yysp] = 125;
                    yysv[yysp] = (token
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 251:
                    yyn = yys125();
                    continue;

                case 252:
                    return true;
                case 253:
                    yyerror("stack overflow");
                case 254:
                    return false;
                case 255:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys24() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr16();
        }
        return 255;
    }

    private int yys25() {
        switch (yytok) {
            case BREAK:
                return 31;
            case FALSE:
                return 32;
            case ID:
                return 33;
            case IF:
                return 34;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case RETURN:
                return 37;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case VAR:
                return 41;
            case WHILE:
                return 42;
            case '(':
                return 43;
            case ';':
                return 44;
            case '{':
                return 45;
            case '}':
                return 46;
        }
        return 255;
    }

    private int yys26() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr15();
        }
        return 255;
    }

    private int yys30() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr32();
        }
        return 255;
    }

    private int yys32() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr35();
        }
        return 255;
    }

    private int yys35() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr34();
        }
        return 255;
    }

    private int yys36() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr37();
        }
        return 255;
    }

    private int yys37() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys38() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr38();
        }
        return 255;
    }

    private int yys39() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr33();
        }
        return 255;
    }

    private int yys40() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr36();
        }
        return 255;
    }

    private int yys43() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys44() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr26();
        }
        return 255;
    }

    private int yys45() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr16();
        }
        return 255;
    }

    private int yys47() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys48() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr23();
        }
        return 255;
    }

    private int yys49() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr31();
        }
        return 255;
    }

    private int yys51() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys52() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr20();
        }
        return 255;
    }

    private int yys53() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys54() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case ';':
                return 77;
            case '<':
                return 78;
        }
        return 255;
    }

    private int yys55() {
        switch (yytok) {
            case '.':
                return 79;
            case '[':
                return 80;
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr44();
        }
        return 255;
    }

    private int yys56() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr39();
        }
        return 255;
    }

    private int yys58() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys59() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys61() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys62() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ')':
                return 87;
        }
        return 255;
    }

    private int yys63() {
        switch (yytok) {
            case BREAK:
                return 31;
            case FALSE:
                return 32;
            case ID:
                return 33;
            case IF:
                return 34;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case RETURN:
                return 37;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case VAR:
                return 41;
            case WHILE:
                return 42;
            case '(':
                return 43;
            case ';':
                return 44;
            case '{':
                return 45;
            case '}':
                return 88;
        }
        return 255;
    }

    private int yys64() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ';':
                return 89;
        }
        return 255;
    }

    private int yys66() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ']':
                return 91;
        }
        return 255;
    }

    private int yys67() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ')':
                return 92;
        }
        return 255;
    }

    private int yys68() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys69() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys70() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys71() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys72() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys73() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys74() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys75() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys76() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys77() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr21();
        }
        return 255;
    }

    private int yys78() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys80() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys82() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ',':
            case ')':
            case ']':
            case ';':
                return yyr57();
        }
        return 255;
    }

    private int yys83() {
        switch (yytok) {
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr56();
        }
        return 255;
    }

    private int yys84() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr24();
        }
        return 255;
    }

    private int yys85() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys86() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ')':
                return 107;
        }
        return 255;
    }

    private int yys87() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr40();
        }
        return 255;
    }

    private int yys88() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr17();
        }
        return 255;
    }

    private int yys89() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr22();
        }
        return 255;
    }

    private int yys90() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
            case ')':
                return yyr59();
        }
        return 255;
    }

    private int yys92() {
        switch (yytok) {
            case BREAK:
                return 31;
            case FALSE:
                return 32;
            case ID:
                return 33;
            case IF:
                return 34;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case RETURN:
                return 37;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case VAR:
                return 41;
            case WHILE:
                return 42;
            case '(':
                return 43;
            case ';':
                return 44;
            case '{':
                return 45;
        }
        return 255;
    }

    private int yys93() {
        switch (yytok) {
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case OR:
            case ',':
            case ')':
            case ']':
            case ';':
            case AND:
                return yyr50();
        }
        return 255;
    }

    private int yys94() {
        switch (yytok) {
            case '*':
                return 73;
            case '/':
                return 76;
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case CONCAT:
            case AND:
                return yyr55();
        }
        return 255;
    }

    private int yys95() {
        switch (yytok) {
            case CONCAT:
                return 69;
            case LEQ:
                return 71;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case OR:
            case ',':
            case EQ:
            case ')':
            case ']':
            case ';':
            case AND:
                return yyr54();
        }
        return 255;
    }

    private int yys96() {
        switch (yytok) {
            case CONCAT:
                return 69;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case OR:
            case ',':
            case EQ:
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case AND:
                return yyr53();
        }
        return 255;
    }

    private int yys97() {
        switch (yytok) {
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case OR:
            case ',':
            case ')':
            case ']':
            case ';':
            case AND:
                return yyr51();
        }
        return 255;
    }

    private int yys98() {
        switch (yytok) {
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr49();
        }
        return 255;
    }

    private int yys99() {
        switch (yytok) {
            case '*':
                return 73;
            case '/':
                return 76;
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case CONCAT:
            case AND:
                return yyr46();
        }
        return 255;
    }

    private int yys100() {
        switch (yytok) {
            case '*':
                return 73;
            case '/':
                return 76;
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case CONCAT:
            case AND:
                return yyr47();
        }
        return 255;
    }

    private int yys101() {
        switch (yytok) {
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr48();
        }
        return 255;
    }

    private int yys102() {
        switch (yytok) {
            case CONCAT:
                return 69;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case OR:
            case ',':
            case EQ:
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case AND:
                return yyr52();
        }
        return 255;
    }

    private int yys104() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ']':
                return 113;
        }
        return 255;
    }

    private int yys105() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
            case ')':
                return yyr59();
        }
        return 255;
    }

    private int yys106() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ';':
                return 115;
        }
        return 255;
    }

    private int yys107() {
        switch (yytok) {
            case BREAK:
                return 31;
            case FALSE:
                return 32;
            case ID:
                return 33;
            case IF:
                return 34;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case RETURN:
                return 37;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case VAR:
                return 41;
            case WHILE:
                return 42;
            case '(':
                return 43;
            case ';':
                return 44;
            case '{':
                return 45;
        }
        return 255;
    }

    private int yys108() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ',':
            case ')':
                return yyr61();
        }
        return 255;
    }

    private int yys111() {
        switch (yytok) {
            case ELSE:
                return 120;
            case NUMBER:
            case NULL:
            case '(':
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr28();
        }
        return 255;
    }

    private int yys112() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
            case ')':
                return yyr59();
        }
        return 255;
    }

    private int yys113() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr42();
        }
        return 255;
    }

    private int yys115() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr25();
        }
        return 255;
    }

    private int yys116() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr19();
        }
        return 255;
    }

    private int yys118() {
        switch (yytok) {
            case FALSE:
                return 32;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case '(':
                return 43;
            case ID:
                return 56;
            case NEW:
                return 57;
            case '!':
                return 58;
            case '-':
                return 59;
        }
        return 255;
    }

    private int yys119() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr18();
        }
        return 255;
    }

    private int yys120() {
        switch (yytok) {
            case BREAK:
                return 31;
            case FALSE:
                return 32;
            case ID:
                return 33;
            case IF:
                return 34;
            case NULL:
                return 35;
            case NUMBER:
                return 36;
            case RETURN:
                return 37;
            case STRING:
                return 38;
            case THIS:
                return 39;
            case TRUE:
                return 40;
            case VAR:
                return 41;
            case WHILE:
                return 42;
            case '(':
                return 43;
            case ';':
                return 44;
            case '{':
                return 45;
        }
        return 255;
    }

    private int yys122() {
        switch (yytok) {
            case '-':
            case OR:
            case ',':
            case '+':
            case EQ:
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr45();
        }
        return 255;
    }

    private int yys123() {
        switch (yytok) {
            case AND:
                return 68;
            case CONCAT:
                return 69;
            case EQ:
                return 70;
            case LEQ:
                return 71;
            case OR:
                return 72;
            case '*':
                return 73;
            case '+':
                return 74;
            case '-':
                return 75;
            case '/':
                return 76;
            case '<':
                return 78;
            case ',':
            case ')':
                return yyr60();
        }
        return 255;
    }

    private int yys124() {
        switch (yytok) {
            case NUMBER:
            case NULL:
            case '(':
            case ELSE:
            case WHILE:
            case VAR:
            case IF:
            case TRUE:
            case THIS:
            case ID:
            case STRING:
            case ';':
            case RETURN:
            case '{':
            case '}':
            case FALSE:
            case BREAK:
                return yyr27();
        }
        return 255;
    }

    private int yys125() {
        switch (yytok) {
            case OR:
            case ',':
            case '+':
            case EQ:
            case '-':
            case '.':
            case '*':
            case ')':
            case LEQ:
            case ']':
            case '[':
            case '<':
            case ';':
            case '/':
            case CONCAT:
            case AND:
                return yyr41();
        }
        return 255;
    }

    private int yyr1() { // start : gossip
        { output = new GossipProgram(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr4() { // class_decl : CLASS ID '{' members '}'
        { yyrv = new GossipClass(((GossipToken)yysv[yysp-4]).toVal(), ((List)yysv[yysp-2]), ((GossipToken)yysv[yysp-5]).line, ((GossipToken)yysv[yysp-5]).col); }
        yysv[yysp-=5] = yyrv;
        return 3;
    }

    private int yyr17() { // cmd : '{' cmds '}'
        { yyrv = new GossipBlock(((List)yysv[yysp-2])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr18() { // cmd : IF '(' exp ')' cmd else_part
        { yyrv = new GossipIf(((GossipExpression)yysv[yysp-4]), ((GossipCmd)yysv[yysp-2]), ((GossipCmd)yysv[yysp-1])); }
        yysv[yysp-=6] = yyrv;
        return yypcmd();
    }

    private int yyr19() { // cmd : WHILE '(' exp ')' cmd
        { yyrv = new GossipWhile(((GossipExpression)yysv[yysp-3]), ((GossipCmd)yysv[yysp-1])); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr20() { // cmd : BREAK ';'
        { yyrv = new GossipBreak(); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr21() { // cmd : RETURN exp ';'
        { yyrv = new GossipReturn(((GossipExpression)yysv[yysp-2])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr22() { // cmd : lvalue '=' exp ';'
        { yyrv = new GossipAssign(((GossipExpression)yysv[yysp-4]), ((GossipExpression)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr23() { // cmd : methodcall ';'
        { yyrv = ((GossipCmd)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr24() { // cmd : VAR ID ';'
        { yyrv = new GossipVar(((GossipToken)yysv[yysp-2]).toVal(), new GossipNull(), ((GossipToken)yysv[yysp-3]).line, ((GossipToken)yysv[yysp-3]).col); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr25() { // cmd : VAR ID '=' exp ';'
        { yyrv = new GossipVar(((GossipToken)yysv[yysp-4]).toVal(), ((GossipExpression)yysv[yysp-2]), ((GossipToken)yysv[yysp-5]).line, ((GossipToken)yysv[yysp-5]).col); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr26() { // cmd : ';'
        { yyrv = new GossipEmpty(); }
        yysv[yysp-=1] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 120: return 124;
            case 107: return 116;
            case 92: return 111;
            default: return 26;
        }
    }

    private int yyr15() { // cmds : cmds cmd
        { ((List)yysv[yysp-2]).add(((GossipCmd)yysv[yysp-1])); yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yyr16() { // cmds : /* empty */
        { yyrv = new ArrayList<GossipCmd>(); }
        yysv[yysp-=0] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 24: return 25;
            default: return 63;
        }
    }

    private int yyr27() { // else_part : ELSE cmd
        { yyrv = ((GossipCmd)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return 119;
    }

    private int yyr28() { // else_part : /* empty */
        { yyrv = null; }
        yysv[yysp-=0] = yyrv;
        return 119;
    }

    private int yyr44() { // exp : simple
        yysp -= 1;
        return yypexp();
    }

    private int yyr45() { // exp : NEW ID '(' exp_list ')'
        { yyrv = new GossipNew(((GossipToken)yysv[yysp-4]).toVal(), ((List)yysv[yysp-2]), ((GossipToken)yysv[yysp-5]).line, ((GossipToken)yysv[yysp-5]).col); }
        yysv[yysp-=5] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : exp '+' exp
        { yyrv = new GossipArith("ADD", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : exp '-' exp
        { yyrv = new GossipArith("SUB", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : exp '/' exp
        { yyrv = new GossipArith("DIV", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr49() { // exp : exp '*' exp
        { yyrv = new GossipArith("MUL", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr50() { // exp : exp AND exp
        { yyrv = new GossipAnd(((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr51() { // exp : exp OR exp
        { yyrv = new GossipOr(((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr52() { // exp : exp '<' exp
        { yyrv = new GossipRel("LT", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr53() { // exp : exp LEQ exp
        { yyrv = new GossipRel("LE", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr54() { // exp : exp EQ exp
        { yyrv = new GossipRel("EQ", ((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr55() { // exp : exp CONCAT exp
        { yyrv = new GossipConcat(((GossipExpression)yysv[yysp-3]), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr56() { // exp : '-' exp
        { yyrv = new GossipArith("SUB", new GossipNumber(0), ((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr57() { // exp : '!' exp
        { yyrv = new GossipNot(((GossipExpression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 118: return 123;
            case 85: return 106;
            case 80: return 104;
            case 78: return 102;
            case 76: return 101;
            case 75: return 100;
            case 74: return 99;
            case 73: return 98;
            case 72: return 97;
            case 71: return 96;
            case 70: return 95;
            case 69: return 94;
            case 68: return 93;
            case 61: return 86;
            case 59: return 83;
            case 58: return 82;
            case 53: return 67;
            case 51: return 66;
            case 47: return 64;
            case 43: return 62;
            case 37: return 54;
            default: return 108;
        }
    }

    private int yyr58() { // exp_list : exps
        yysp -= 1;
        return yypexp_list();
    }

    private int yyr59() { // exp_list : /* empty */
        { yyrv = new ArrayList<GossipExpression>(); }
        yysv[yysp-=0] = yyrv;
        return yypexp_list();
    }

    private int yypexp_list() {
        switch (yyst[yysp-1]) {
            case 105: return 114;
            case 90: return 109;
            default: return 121;
        }
    }

    private int yyr60() { // exps : exps ',' exp
        { ((List)yysv[yysp-3]).add(((GossipExpression)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 110;
    }

    private int yyr61() { // exps : exp
        { List<GossipExpression> exps = new ArrayList<GossipExpression>(); exps.add(((GossipExpression)yysv[yysp-1])); yyrv = exps; }
        yysv[yysp-=1] = yyrv;
        return 110;
    }

    private int yyr2() { // gossip : gossip class_decl
        { ((List)yysv[yysp-2]).add(((GossipClass)yysv[yysp-1])); yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return 2;
    }

    private int yyr3() { // gossip : /* empty */
        { yyrv = new ArrayList<GossipClass>(); }
        yysv[yysp-=0] = yyrv;
        return 2;
    }

    private int yyr13() { // ids : ids ',' ID
        { ((List)yysv[yysp-3]).add(((GossipToken)yysv[yysp-1]).toVal()); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 18;
    }

    private int yyr14() { // ids : ID
        { List<String> ids = new ArrayList<String>(); ids.add(((GossipToken)yysv[yysp-1]).toVal()); yyrv = ids; }
        yysv[yysp-=1] = yyrv;
        return 18;
    }

    private int yyr29() { // lvalue : ID
        { yyrv = new GossipVarExp(((GossipToken)yysv[yysp-1]).toVal()); }
        yysv[yysp-=1] = yyrv;
        return 27;
    }

    private int yyr30() { // lvalue : simple '[' exp ']'
        { yyrv = new GossipSimple(((GossipExpression)yysv[yysp-4]), new GossipIndex(((GossipExpression)yysv[yysp-2]))); }
        yysv[yysp-=4] = yyrv;
        return 27;
    }

    private int yyr7() { // member_decl : var_decl
        yysp -= 1;
        return 8;
    }

    private int yyr8() { // member_decl : method_decl
        yysp -= 1;
        return 8;
    }

    private int yyr5() { // members : members member_decl
        { ((List)yysv[yysp-2]).add(((GossipMember)yysv[yysp-1])); yyrv = ((List)yysv[yysp-2]); }
        yysv[yysp-=2] = yyrv;
        return 7;
    }

    private int yyr6() { // members : /* empty */
        { yyrv = new ArrayList<GossipMember>(); }
        yysv[yysp-=0] = yyrv;
        return 7;
    }

    private int yyr10() { // method_decl : DEF ID '(' param_list ')' '{' cmds '}'
        { yyrv = new GossipDef(((GossipToken)yysv[yysp-7]).toVal(), ((List)yysv[yysp-5]), ((List)yysv[yysp-2]), ((GossipToken)yysv[yysp-8]).line, ((GossipToken)yysv[yysp-8]).col); }
        yysv[yysp-=8] = yyrv;
        return 9;
    }

    private int yyr43() { // methodcall : simple '.' ID '(' exp_list ')'
        { yyrv = new GossipMethodCallCmd(((GossipExpression)yysv[yysp-6]), ((GossipToken)yysv[yysp-4]).toVal(), ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return 28;
    }

    private int yyr11() { // param_list : ids
        yysp -= 1;
        return 19;
    }

    private int yyr12() { // param_list : /* empty */
        { yyrv = new ArrayList<String>(); }
        yysv[yysp-=0] = yyrv;
        return 19;
    }

    private int yyr31() { // simple : simple suffix
        { yyrv = new GossipSimple(((GossipExpression)yysv[yysp-2]), ((GossipSuffix)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypsimple();
    }

    private int yyr32() { // simple : atom
        yysp -= 1;
        return yypsimple();
    }

    private int yypsimple() {
        switch (yyst[yysp-1]) {
            case 120: return 29;
            case 107: return 29;
            case 92: return 29;
            case 63: return 29;
            case 25: return 29;
            default: return 55;
        }
    }

    private int yyr33() { // atom : THIS
        { yyrv = new GossipThis(); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr34() { // atom : NULL
        { yyrv = new GossipNull(); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr35() { // atom : FALSE
        { yyrv = new GossipFalse(); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr36() { // atom : TRUE
        { yyrv = new GossipTrue(); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr37() { // atom : NUMBER
        { yyrv = new GossipNumber(Double.parseDouble(((GossipToken)yysv[yysp-1]).toVal())); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr38() { // atom : STRING
        { yyrv = new GossipString(((GossipToken)yysv[yysp-1]).toVal()); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr39() { // atom : ID
        { yyrv = new GossipVarExp(((GossipToken)yysv[yysp-1]).toVal()); }
        yysv[yysp-=1] = yyrv;
        return 30;
    }

    private int yyr40() { // atom : '(' exp ')'
        { yyrv = ((GossipExpression)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return 30;
    }

    private int yyr41() { // suffix : '.' ID '(' exp_list ')'
        { yyrv = new GossipMethodCall(((GossipToken)yysv[yysp-4]).toVal(), ((List)yysv[yysp-2])); }
        yysv[yysp-=5] = yyrv;
        return 49;
    }

    private int yyr42() { // suffix : '[' exp ']'
        { yyrv = new GossipIndex(((GossipExpression)yysv[yysp-2])); }
        yysv[yysp-=3] = yyrv;
        return 49;
    }

    private int yyr9() { // var_decl : VAR ID ';'
        { yyrv = new GossipField(((GossipToken)yysv[yysp-2]).toVal(), ((GossipToken)yysv[yysp-3]).line, ((GossipToken)yysv[yysp-3]).col); }
        yysv[yysp-=3] = yyrv;
        return 10;
    }

    protected String[] yyerrmsgs = {
    };


String filename;
GossipScanner scanner;
int tokenType;
Object token;
GossipProgram output;

public GossipParser(String filename, Reader input) {
    this.filename = filename;
    scanner = new GossipScanner(input);
    getToken();
}

int getToken() {
    try {
        token = scanner.getToken();
        if(token != null) {
          tokenType = ((GossipToken)token).type;
        } else
          tokenType = ENDINPUT;
        return tokenType;
    } catch(Exception e) {
        throw new RuntimeException(e);
    }
}

void yyerror(String msg) {
     throw new RuntimeException(filename + " (" + ((GossipToken)token).line + "," + ((GossipToken)token).col + "): "+ msg);
}

}
