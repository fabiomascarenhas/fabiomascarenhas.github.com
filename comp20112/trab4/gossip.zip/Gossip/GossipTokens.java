// Output created by jacc on Tue Nov 22 22:24:16 BRST 2011

interface GossipTokens {
    int ENDINPUT = 0;
    int AND = 1;
    int BREAK = 2;
    int CLASS = 3;
    int CONCAT = 4;
    int DEF = 5;
    int ELSE = 6;
    int EQ = 7;
    int FALSE = 8;
    int ID = 9;
    int IF = 10;
    int LEQ = 11;
    int NEW = 12;
    int NULL = 13;
    int NUMBER = 14;
    int OR = 15;
    int RETURN = 16;
    int STRING = 17;
    int THIS = 18;
    int TRUE = 19;
    int UNM = 20;
    int VAR = 21;
    int WHILE = 22;
    int error = 23;
    // '!' (code=33)
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '.' (code=46)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
    // '[' (code=91)
    // ']' (code=93)
    // '{' (code=123)
    // '}' (code=125)
}
