
public class GossipVisitor {
	void visit(GossipProgram gp) {
		for(GossipClass c : gp.classes.values())
			c.accept(this);
	}
	
	void visit(GossipClass gc) {
		for(GossipField f : gc.fields)
			f.accept(this);
		for(GossipDef m : gc.methods.values())
			m.accept(this);
	}
	
	void visit(GossipField gf) { }
	
	void visit(GossipDef gd) {
		for(GossipCmd cmd : gd.body)
			cmd.accept(this);
	}
	
	void visit(GossipBlock gb) {
		for(GossipCmd cmd : gb.body)
			cmd.accept(this);
	}
	
	void visit(GossipIf gif) {
		gif.cond.accept(this);
		gif.then.accept(this);
		if(gif.celse != null)
			gif.celse.accept(this);
	}
	
	void visit(GossipWhile gw) {
		gw.cond.accept(this);
		gw.body.accept(this);
	}
	
	void visit(GossipBreak gb) { }
	
	void visit(GossipReturn gr) {
		gr.exp.accept(this);
	}
	
	void visit(GossipAssign ga) {
		ga.lval.accept(this);
		ga.rval.accept(this);
	}
	
	void visit(GossipVar gv) {
		gv.exp.accept(this);
	}
	
	void visit(GossipEmpty ge) { }
	
	void visit(GossipMethodCallCmd gmc) {
		gmc.obj.accept(this);
		for(GossipExpression exp : gmc.args)
			exp.accept(this);
	}
	
	void visit(GossipVarExp gve) { }
	
	void visit(GossipSimple gs) {
		gs.exp.accept(this);
		gs.suffix.accept(this);
	}
	
	void visit(GossipIndex gi) {
		gi.exp.accept(this);
	}
	
	void visit(GossipMethodCall gmc) {
		for(GossipExpression arg : gmc.args)
			arg.accept(this);
	}
	
	void visit(GossipThis gth) { }

	void visit(GossipNull gnl) { }

	void visit(GossipTrue gt) { }

	void visit(GossipFalse gf) { }

	void visit(GossipNumber gn) { }

	void visit(GossipString gs) { }
	
	void visit(GossipAnd ga) {
		ga.left.accept(this);
		ga.right.accept(this);
	}

	void visit(GossipOr go) {
		go.left.accept(this);
		go.right.accept(this);
	}
	
	void visit(GossipArith ga) {
		ga.left.accept(this);
		ga.right.accept(this);
	}
	
	void visit(GossipRel gr) {
		gr.left.accept(this);
		gr.right.accept(this);
	}

	void visit(GossipConcat gc) {
		gc.left.accept(this);
		gc.right.accept(this);
	}

	void visit(GossipNew gn) {
		for(GossipExpression arg : gn.args)
			arg.accept(this);
	}
	
	void visit(GossipNot gn) {
		gn.exp.accept(this);
	}
}
