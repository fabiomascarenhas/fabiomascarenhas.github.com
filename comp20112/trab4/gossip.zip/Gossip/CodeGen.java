
import java.util.Stack;

/* Contexto de gera��o de c�digo para o m�todo atual */
class CodeGen {
	SymbolTable st;       // n�vel de escopo atual!
	int temp;             // primeiro registrador livre, para tempor�rios
	int label;            // primeiro label livre
	StringBuilder out;    // sa�da para o c�digo do m�todo atual
	Stack<Integer> exits; // pilha de sa�das de la�o, para break 
	
	CodeGen(int temp) {
		label = 0;
		this.temp = temp;
		out = new StringBuilder();
		exits = new Stack<Integer>();
	}
	
	String label(int lab) {
		return "label" + lab;
	}
	
	void emitLabel(int lab) {
		out.append(label(lab) + ":\n");
	}

	void emit(String s) {
		out.append(s + "\n");
	}

	void emitJmp(int lab) {
		emit("JMP", label(lab));
	}
	
	void emit(String op, String arg1, String arg2, String arg3) {
		out.append("  " + op + " " + arg1 + " " + arg2 + " " + arg3 + "\n");
	}

	void emit(String op, String arg1, String arg2) {
		out.append("  " + op + " " + arg1 + " " + arg2 + "\n");
	}

	void emit(String op, String arg1) {
		out.append("  " + op + " " + arg1 + "\n");
	}			

 	Loc gettemp() {
 		return new Loc(temp++);
 	}
}
