
import java.util.*;

public class GossipVarCheck extends GossipVisitor {
	SymbolTable st;
	Map<String, GossipClass> classes;
	Set<String> predefs;
	GossipClass mainclass;
	
	GossipVarCheck(String[] predefs) {
		this.predefs = new HashSet<String>();
		for(String predef : predefs)
			this.predefs.add(predef);
	}
	
	void visit(GossipProgram gp) {
		gp.st_globals = st = new GlobalTable();
		classes = gp.classes;
		super.visit(gp);
	}
	
	void visit(GossipClass gc) {
		gc.st_fields = st = new ObjectTable(st);
		super.visit(gc);
		st = st.parent;
	}
	
	void visit(GossipField gf) {
		st.put(gf.name);
	}
	
	void visit(GossipDef gd) {
		gd.st_method = st = new LocalTable(st);
		st.put("this");
		for(String param : gd.params) {
			st.put(param);
		}
		super.visit(gd);
		st = st.parent;
	}
	
	void visit(GossipBlock gb) {
		gb.st_block = st = new LocalTable(st);
		super.visit(gb);
		st = st.parent;
	}
	
	void visit(GossipVar gv) {
		st.put(gv.name);
		super.visit(gv);
	}

	void visit(GossipNew gn) {
		if(!classes.containsKey(gn.name) && !predefs.contains(gn.name))
			throw new RuntimeException("classe " + gn.name + " n�o foi definina, linha " + gn.line
					+ ", coluna " + gn.col);
		super.visit(gn);
	}
}
