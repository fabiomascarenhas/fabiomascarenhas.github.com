import java.io.*;

public class GossipDriver {
    public static void main(String[] args) throws Exception {
        FileReader input = new FileReader(args[0]);
        GossipParser parser = new GossipParser(args[0], input);
        parser.parse();
        GossipVarCheck gvc = new GossipVarCheck(new String[] { "Array" });
        parser.output.accept(gvc);
		String fileout = args[0].replace(".gossip", ".asm");
        PrintStream out = new PrintStream(fileout);
        parser.output.codegen(new OutputStreamWriter(out));
        out.close();
    }
}
