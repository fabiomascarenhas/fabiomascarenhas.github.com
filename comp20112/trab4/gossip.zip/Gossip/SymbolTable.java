import java.util.HashMap;

class Loc implements Comparable<Loc> {
	public static Loc global = new Loc(-1);
	public static Loc object = new Loc(-1);

	public int reg;
		
	Loc(int reg) {
		this.reg = reg;
	}
	
	public String toString() {
		if(reg < 0)
			throw new RuntimeException("local n�o � um registrador");
		else
			return "R" + reg;
	}

	public int compareTo(Loc loc) {
		return ((Integer)reg).compareTo(loc.reg);
	}
}

abstract class SymbolTable {
	public SymbolTable parent;
	HashMap<String, Loc> vars;
	
	SymbolTable(SymbolTable parent) {
		vars = new HashMap<String, Loc>();
		this.parent = parent;
	}
	
	abstract void put(String name);
	
	Loc get(String name) {
		Loc pos = vars.get(name);
		if(pos == null && parent != null)
			return parent.get(name);
		else
			return pos;
	}
}

class GlobalTable extends SymbolTable {
	GlobalTable() {
		super(null);
	}	
	
	void put(String name) {
		vars.put(name, Loc.global);
	}
	
	Loc get(String name) {
		Loc pos = vars.get(name);
		if(pos == null)
			put(name);
		return Loc.global;
	}
}

class ObjectTable extends SymbolTable {
	ObjectTable(SymbolTable parent) {
		super(parent);
	}
	
	void put(String name) {
		if(!vars.containsKey(name)) {
			vars.put(name, Loc.object);
		} else
			throw new RuntimeException("vari�vel " + name + " redeclarada no mesmo escopo");
	}
}

class LocalTable extends SymbolTable {
	int free;
	int max;
	
	LocalTable(SymbolTable parent) {
		super(parent);
		if(parent != null && parent instanceof LocalTable)
			free = ((LocalTable)parent).free;
		else
			free = 0;
		max = free;
	}
	
	void update(int free) {
		max = Math.max(max, free);
		if(parent instanceof LocalTable) {
			((LocalTable)parent).update(free);
		}
	}
	
	void put(String name) {
		if(!vars.containsKey(name)) {
			vars.put(name, new Loc(free++));
			update(free);
		} else
			throw new RuntimeException("vari�vel " + name + " redeclarada no mesmo escopo");
	}
}
