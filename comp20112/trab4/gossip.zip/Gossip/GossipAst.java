
import java.util.*;
import java.io.*;

import org.apache.commons.lang3.StringUtils;

abstract class GossipNode {
	abstract void accept(GossipVisitor v);
}

abstract class GossipExpression extends GossipNode {
	void codegen(CodeGen ctx, Loc target) {
		// TODO: implementar nas subclasses
		ctx.emit("  ; nao implementado");
	}
	void jumpfalse(CodeGen ctx, int lab) {
		// TODO: implementar nas subclasses
		ctx.emit("  ; nao implementado");
	}
}

abstract class GossipCmd extends GossipNode {
	void codegen(CodeGen ctx) {
		// TODO: implementar nas subclasses
		ctx.emit("  ; nao implementado");
	}
}

class GossipProgram extends GossipNode {
	public Map<String, GossipClass> classes;
	public SymbolTable st_globals;
	public GossipClass mainclass;
	
	GossipProgram(List<GossipClass> classes) {
		this.classes = new HashMap<String, GossipClass>();
		for(GossipClass c : classes) {
			if(this.classes.containsKey(c.name))
				throw new RuntimeException("classe " + c.name + " redeclarada na linha " + c.line);
			this.classes.put(c.name, c);
			if(c.methods.containsKey("main")) {
				if(mainclass != null)
					throw new RuntimeException("main duplicado na classe " + c.name + ", linha " + c.line);
				mainclass = c;
			}
		}
		if(mainclass == null) {
			throw new RuntimeException("n�o existe m�todo main em nenhuma classe do programa");
		}
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	void codegen(Writer out) throws IOException {
		for(GossipClass c : classes.values()) {
			c.codegen(out);
		}
		out.write("function main:\n");
		CodeGen ctx = new CodeGen(0);
		/* TODO: c�digo para registrar classes e m�todos e chamar __GOSSIP_RUN */
		ctx.emit("RETURN", "R0", "1");
		out.write(ctx.out.toString());
		out.flush();
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for(GossipClass c : classes.values()) {
			sb.append(c.toString());
		}
		return sb.toString();
	}
}

class GossipClass extends GossipNode {
	public String name;
	public List<GossipField> fields;
	public Map<String, GossipDef> methods;
	public SymbolTable st_fields;
	
	public int line, col;
	
	GossipClass(String name, List<GossipMember> members, int line, int col) {
		this.name = name;
		this.line = line;
		this.col = col;
		fields = new ArrayList<GossipField>();
		methods = new HashMap<String, GossipDef>();
		for(GossipMember member : members) {
			if(member instanceof GossipField) {
				fields.add((GossipField)member);
			} else {
				GossipDef m = (GossipDef)member;
				if(methods.containsKey(m.name))
					throw new RuntimeException("m�todo " + m.name + " redeclarado na linha " + m.line);
				methods.put(m.name, m);
			}
		}
	}
	
	void codegen(Writer out) throws IOException {
		for(GossipDef m : methods.values()) {
			out.write("function " + name + "_" + m.name + ":\n");
			m.codegen(out);
			out.write("\n");
		}
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class " + name + " {\n");
		for(GossipField f : fields)
			sb.append(f.toString());
		for(GossipDef m : methods.values())
			sb.append(m.toString());
		sb.append("}\n");
		return sb.toString();
	}
}

abstract class GossipMember extends GossipNode {
}

class GossipField extends GossipMember {
	public String name;
	
	public int line, col;
	
	GossipField(String name, int line, int col) {
		this.name = name;
		this.line = line;
		this.col = col;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "var " + name + ";\n";
	}
}

class GossipDef extends GossipMember {
	public String name;
	public List<String> params;
	public List<GossipCmd> body;
	public SymbolTable st_method;
	
	public int line, col;
	
	GossipDef(String name, List<String> params, List<GossipCmd> body, int line, int col) {
		this.name = name;
		this.params = params;
		this.body = body;
		this.line = line;
		this.col = col;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	void codegen(Writer out) throws IOException {
		CodeGen ctx = new CodeGen(((LocalTable)st_method).max);
		ctx.st = st_method;
		for(GossipCmd cmd : body)
			cmd.codegen(ctx);
		ctx.emit("RETURN", "R0", "1");
		out.write(ctx.out.toString());
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("def " + name + "(");
		sb.append(StringUtils.join(params, ","));
		sb.append(") {\n");
		for(GossipCmd cmd : body)
			sb.append(cmd.toString());
		sb.append("}\n");
		return sb.toString();
	}
}

class GossipBlock extends GossipCmd {
	public List<GossipCmd> body;
	public SymbolTable st_block;
	
	GossipBlock(List<GossipCmd> body) {
		this.body = body;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("{\n");
		for(GossipCmd cmd : body)
			sb.append(cmd.toString());
		sb.append("}\n");
		return sb.toString();
	}
}

class GossipIf extends GossipCmd {
	public GossipExpression cond;
	public GossipCmd then;
	public GossipCmd celse;
	
	GossipIf(GossipExpression cond, GossipCmd then, GossipCmd celse) {
		this.cond = cond;
		this.then = then;
		this.celse = celse;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "if(" + cond.toString() + ")\n" + then.toString() +
				(celse == null ? "" : "else\n" + celse.toString());
	}
}

class GossipWhile extends GossipCmd {
	public GossipExpression cond;
	public GossipCmd body;
	
	GossipWhile(GossipExpression cond, GossipCmd body) {
		this.cond = cond;
		this.body = body;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "while(" + cond.toString() + ")\n" + body.toString();
	}
}

class GossipBreak extends GossipCmd {
	GossipBreak() {}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "break;\n";
	}
}

class GossipReturn extends GossipCmd {
	public GossipExpression exp;
	
	GossipReturn(GossipExpression exp) {
		this.exp = exp;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "return " + exp.toString() + ";\n";
	}
}

class GossipAssign extends GossipCmd {
	public GossipExpression lval;
	public GossipExpression rval;
	
	GossipAssign(GossipExpression lval, GossipExpression rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return lval.toString() + " = " + rval.toString() + ";\n";
	}
}

class GossipEmpty extends GossipCmd {
	GossipEmpty() { }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return ";\n";
	}
}

class GossipMethodCallCmd extends GossipCmd {
	public GossipExpression obj;
	public String name;
	public List<GossipExpression> args;

	GossipMethodCallCmd(GossipExpression obj, String name, List<GossipExpression> args) {
		this.obj = obj;
		this.name = name;
		this.args = args;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return obj.toString() + "." + name + "(" + StringUtils.join(args, ",") + ");\n";
	}
}

class GossipVar extends GossipCmd {
	public String name;
	public GossipExpression exp;
	
	public int line, col;

	GossipVar(String name, GossipExpression exp, int line, int col) {
		this.name = name;
		this.exp = exp;
		this.line = line;
		this.col = col;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "var " + name + " = " + exp.toString() + ";\n";
	}
}

class GossipVarExp extends GossipExpression {
	public String name;
	
	GossipVarExp(String name) { this.name = name; }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return name;
	}
}

class GossipSimple extends GossipExpression {
	public GossipExpression exp;
	public GossipSuffix suffix;
	
	GossipSimple(GossipExpression exp, GossipSuffix suffix) {
		this.exp = exp;
		this.suffix = suffix;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return exp.toString() + suffix.toString();
	}
}

abstract class GossipSuffix extends GossipNode { }

class GossipIndex extends GossipSuffix {
	public GossipExpression exp;
	
	GossipIndex(GossipExpression exp) {
		this.exp = exp;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "[" + exp.toString() + "]";
	}
}

class GossipMethodCall extends GossipSuffix {
	public String name;
	public List<GossipExpression> args;
	
	GossipMethodCall(String name, List<GossipExpression> args) {
		this.name = name;
		this.args = args;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "." + name + "(" + StringUtils.join(args, ",") + ")";
	}
}

class GossipThis extends GossipExpression {
	GossipThis() { }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "this";
	}
}

class GossipNull extends GossipExpression {
	GossipNull() { }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "null";
	}
}

class GossipTrue extends GossipExpression {
	GossipTrue() { }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "true";
	}
}

class GossipFalse extends GossipExpression {
	GossipFalse() { }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "false";
	}
}

class GossipNumber extends GossipExpression {
	public double num;
	
	GossipNumber(double num) { this.num = num; }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "" + num;
	}
}

class GossipString extends GossipExpression {
	public String str;
	
	GossipString(String str) { this.str = str; }
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return str;
	}
}

class GossipArith extends GossipExpression {
	public String op;
	public GossipExpression left;
	public GossipExpression right;
	
	GossipArith(String op, GossipExpression left, GossipExpression right) {
		this.op = op;
		this.left = left;
		this.right = right;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		String op = "";
		if(this.op == "ADD") op = "+";
		else if(this.op == "SUB") op = "-";
		else if(this.op == "MUL") op = "*";
		else if(this.op == "DIV") op = "/";
		return "(" + left.toString() + op + right.toString() + ")";
	}
}

class GossipRel extends GossipExpression {
	public String op;
	public GossipExpression left;
	public GossipExpression right;
	
	GossipRel(String op, GossipExpression left, GossipExpression right) {
		this.op = op;
		this.left = left;
		this.right = right;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		String op = "";
		if(this.op == "EQ") op = "==";
		else if(this.op == "LEQ") op = "<=";
		else if(this.op == "LT") op = "<";
		return "(" + left.toString() + op + right.toString() + ")";
	}
}

class GossipAnd extends GossipExpression {
	public GossipExpression left;
	public GossipExpression right;
	
	GossipAnd(GossipExpression left, GossipExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "(" + left.toString() + " && " + right.toString() + ")";
	}
}

class GossipOr extends GossipExpression {
	public GossipExpression left;
	public GossipExpression right;
	
	GossipOr(GossipExpression left, GossipExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "(" + left.toString() + " || " + right.toString() + ")";
	}
}


class GossipConcat extends GossipExpression {
	public GossipExpression left;
	public GossipExpression right;
	
	GossipConcat(GossipExpression left, GossipExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "(" + left.toString() + " .. " + right.toString() + ")";
	}
}

class GossipNot extends GossipExpression {
	public GossipExpression exp;

	GossipNot(GossipExpression exp) {
		this.exp = exp;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}

	public String toString() {
		return "(!" + exp.toString() + ")";
	}
}

class GossipNew extends GossipExpression {
	public String name;
	public List<GossipExpression> args;
	
	public int line, col;
	
	GossipNew(String name, List<GossipExpression> args, int line, int col) {
		this.name = name;
		this.args = args;
		this.line = line;
		this.col = col;
	}
	
	void accept(GossipVisitor v) {
		v.visit(this);
	}
	
	public String toString() {
		return "new " + name + "(" + StringUtils.join(args, ",") + ")";
	}
}
