x = tonumber(io.read('*l'))
if (0<x) then
fact = 1
repeat
fact = (fact*x)
x = (x-1)
until (x==0)
print(fact)
end
print(((-fact)*2))