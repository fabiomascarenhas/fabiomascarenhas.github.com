// Output created by jacc on Wed Sep 21 16:43:57 BRT 2011


import java.io.Reader;

class TINYParser implements TINYTokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private String[] yysv;
    private String yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new String[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 50:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                        case IF:
                            yyn = 10;
                            continue;
                        case READ:
                            yyn = 11;
                            continue;
                        case REPEAT:
                            yyn = 12;
                            continue;
                        case WRITE:
                            yyn = 13;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 51:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 100;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 52:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 53:
                    switch (yytok) {
                        case ';':
                            yyn = 14;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 54:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 55:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 56:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 57:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 58:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 59:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 15;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 60:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 61:
                    switch (yytok) {
                        case ID:
                            yyn = 22;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 62:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                        case IF:
                            yyn = 10;
                            continue;
                        case READ:
                            yyn = 11;
                            continue;
                        case REPEAT:
                            yyn = 12;
                            continue;
                        case WRITE:
                            yyn = 13;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 63:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 64:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                        case IF:
                            yyn = 10;
                            continue;
                        case READ:
                            yyn = 11;
                            continue;
                        case REPEAT:
                            yyn = 12;
                            continue;
                        case WRITE:
                            yyn = 13;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 65:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 66:
                    switch (yytok) {
                        case THEN:
                            yyn = 27;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 67:
                    yyn = yys17();
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 68:
                    yyn = yys18();
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 69:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 70:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 71:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 72:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 73:
                    switch (yytok) {
                        case ';':
                            yyn = 14;
                            continue;
                        case UNTIL:
                            yyn = 37;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 74:
                    yyn = yys24();
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 75:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 76:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 77:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                        case IF:
                            yyn = 10;
                            continue;
                        case READ:
                            yyn = 11;
                            continue;
                        case REPEAT:
                            yyn = 12;
                            continue;
                        case WRITE:
                            yyn = 13;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 78:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 79:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 80:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 81:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 82:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 83:
                    switch (yytok) {
                        case '(':
                        case NUM:
                        case '-':
                        case ID:
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 84:
                    switch (yytok) {
                        case '(':
                        case NUM:
                        case '-':
                        case ID:
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 85:
                    switch (yytok) {
                        case '*':
                            yyn = 29;
                            continue;
                        case '+':
                            yyn = 30;
                            continue;
                        case '-':
                            yyn = 31;
                            continue;
                        case '/':
                            yyn = 32;
                            continue;
                        case ')':
                            yyn = 44;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 86:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 87:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                        case NUM:
                            yyn = 19;
                            continue;
                        case '(':
                            yyn = 20;
                            continue;
                        case '-':
                            yyn = 21;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 88:
                    switch (yytok) {
                        case ';':
                            yyn = 14;
                            continue;
                        case ELSE:
                            yyn = 47;
                            continue;
                        case END:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 89:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 90:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 91:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 92:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 93:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 94:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 95:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 96:
                    switch (yytok) {
                        case END:
                            yyn = 48;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 97:
                    switch (yytok) {
                        case ID:
                            yyn = 9;
                            continue;
                        case IF:
                            yyn = 10;
                            continue;
                        case READ:
                            yyn = 11;
                            continue;
                        case REPEAT:
                            yyn = 12;
                            continue;
                        case WRITE:
                            yyn = 13;
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    switch (yytok) {
                        case ';':
                            yyn = 14;
                            continue;
                        case END:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 103;
                    continue;

                case 100:
                    return true;
                case 101:
                    yyerror("stack overflow");
                case 102:
                    return false;
                case 103:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        String[] newyysv = new String[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys17() {
        switch (yytok) {
            case '*':
                return 29;
            case '+':
                return 30;
            case '-':
                return 31;
            case '/':
                return 32;
            case '<':
                return 33;
            case '=':
                return 34;
            case ENDINPUT:
            case UNTIL:
            case END:
            case ';':
            case THEN:
            case ELSE:
                return yyr16();
        }
        return 103;
    }

    private int yys18() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case IF:
            case ID:
            case error:
            case READ:
            case ATTRIB:
            case UNM:
            case NUM:
            case STRING:
            case '(':
                return 103;
        }
        return yyr22();
    }

    private int yys19() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case IF:
            case ID:
            case error:
            case READ:
            case ATTRIB:
            case UNM:
            case NUM:
            case STRING:
            case '(':
                return 103;
        }
        return yyr21();
    }

    private int yys24() {
        switch (yytok) {
            case '*':
                return 29;
            case '+':
                return 30;
            case '-':
                return 31;
            case '/':
                return 32;
            case ENDINPUT:
            case UNTIL:
            case END:
            case ';':
            case ELSE:
                return yyr15();
        }
        return 103;
    }

    private int yys36() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case IF:
            case ID:
            case error:
            case READ:
            case ATTRIB:
            case UNM:
            case NUM:
            case STRING:
            case '(':
                return 103;
        }
        return yyr23();
    }

    private int yys39() {
        switch (yytok) {
            case '*':
                return 29;
            case '+':
                return 30;
            case '-':
                return 31;
            case '/':
                return 32;
            case ENDINPUT:
            case UNTIL:
            case END:
            case ';':
            case THEN:
            case ELSE:
                return yyr17();
        }
        return 103;
    }

    private int yys40() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case IF:
            case ID:
            case error:
            case READ:
            case ATTRIB:
            case UNM:
            case NUM:
            case STRING:
            case '(':
                return 103;
        }
        return yyr26();
    }

    private int yys41() {
        switch (yytok) {
            case '*':
                return 29;
            case '/':
                return 32;
            case ENDINPUT:
            case UNTIL:
            case END:
            case '<':
            case ';':
            case THEN:
            case '-':
            case '+':
            case '=':
            case ')':
            case ELSE:
                return yyr24();
        }
        return 103;
    }

    private int yys42() {
        switch (yytok) {
            case '*':
                return 29;
            case '/':
                return 32;
            case ENDINPUT:
            case UNTIL:
            case END:
            case '<':
            case ';':
            case THEN:
            case '-':
            case '+':
            case '=':
            case ')':
            case ELSE:
                return yyr25();
        }
        return 103;
    }

    private int yys43() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case IF:
            case ID:
            case error:
            case READ:
            case ATTRIB:
            case UNM:
            case NUM:
            case STRING:
            case '(':
                return 103;
        }
        return yyr27();
    }

    private int yys44() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case IF:
            case ID:
            case error:
            case READ:
            case ATTRIB:
            case UNM:
            case NUM:
            case STRING:
            case '(':
                return 103;
        }
        return yyr20();
    }

    private int yyr1() { // tiny : cmd_seq
        { output = yysv[yysp-1]; }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr4() { // cmd : if_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr5() { // cmd : repeat_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr6() { // cmd : assign_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr7() { // cmd : read_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr8() { // cmd : write_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 14: return 25;
            default: return 2;
        }
    }

    private int yyr2() { // cmd_seq : cmd
        yysp -= 1;
        return yypcmd_seq();
    }

    private int yyr3() { // cmd_seq : cmd_seq ';' cmd
        { yyrv = yysv[yysp-3] + "\n" + yysv[yysp-1]; }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 27: return 38;
            case 12: return 23;
            case 0: return 3;
            default: return 49;
        }
    }

    private int yyr10() { // else_cmd : ELSE cmd_seq
        { yyrv = "else\n" + yysv[yysp-1]; }
        yysv[yysp-=2] = yyrv;
        return 46;
    }

    private int yyr11() { // else_cmd : /* empty */
        { yyrv = ""; }
        yysv[yysp-=0] = yyrv;
        return 46;
    }

    private int yyr16() { // exp : simple_exp
        yysp -= 1;
        return yypexp();
    }

    private int yyr17() { // exp : simple_exp rel_op simple_exp
        { yyrv = "(" + yysv[yysp-3] + yysv[yysp-2] + yysv[yysp-1] + ")"; }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 15: return 26;
            case 10: return 16;
            default: return 45;
        }
    }

    private int yyr9() { // if_cmd : IF exp THEN cmd_seq else_cmd END
        { yyrv = "if " + yysv[yysp-5] + " then\n" + yysv[yysp-3] + yysv[yysp-2] + "\nend"; }
        yysv[yysp-=6] = yyrv;
        return 4;
    }

    private int yyr14() { // read_cmd : READ ID
        { yyrv = yysv[yysp-1] + " = tonumber(io.read('*l'))"; }
        yysv[yysp-=2] = yyrv;
        return 5;
    }

    private int yyr18() { // rel_op : '<'
        { yyrv = "<"; }
        yysv[yysp-=1] = yyrv;
        return 28;
    }

    private int yyr19() { // rel_op : '='
        { yyrv = "=="; }
        yysv[yysp-=1] = yyrv;
        return 28;
    }

    private int yyr12() { // repeat_cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = "repeat\n" + yysv[yysp-3] + "\nuntil " + yysv[yysp-1]; }
        yysv[yysp-=4] = yyrv;
        return 6;
    }

    private int yyr20() { // simple_exp : '(' simple_exp ')'
        { yyrv = yysv[yysp-2]; }
        yysv[yysp-=3] = yyrv;
        return yypsimple_exp();
    }

    private int yyr21() { // simple_exp : NUM
        yysp -= 1;
        return yypsimple_exp();
    }

    private int yyr22() { // simple_exp : ID
        yysp -= 1;
        return yypsimple_exp();
    }

    private int yyr23() { // simple_exp : '-' simple_exp
        { yyrv = "(-" + yysv[yysp-1] + ")"; }
        yysv[yysp-=2] = yyrv;
        return yypsimple_exp();
    }

    private int yyr24() { // simple_exp : simple_exp '+' simple_exp
        { yyrv = "(" + yysv[yysp-3] + "+" + yysv[yysp-1] + ")"; }
        yysv[yysp-=3] = yyrv;
        return yypsimple_exp();
    }

    private int yyr25() { // simple_exp : simple_exp '-' simple_exp
        { yyrv = "(" + yysv[yysp-3] + "-" + yysv[yysp-1] + ")"; }
        yysv[yysp-=3] = yyrv;
        return yypsimple_exp();
    }

    private int yyr26() { // simple_exp : simple_exp '*' simple_exp
        { yyrv = "(" + yysv[yysp-3] + "*" + yysv[yysp-1] + ")"; }
        yysv[yysp-=3] = yyrv;
        return yypsimple_exp();
    }

    private int yyr27() { // simple_exp : simple_exp '/' simple_exp
        { yyrv = "(" + yysv[yysp-3] + "/" + yysv[yysp-1] + ")"; }
        yysv[yysp-=3] = yyrv;
        return yypsimple_exp();
    }

    private int yypsimple_exp() {
        switch (yyst[yysp-1]) {
            case 32: return 43;
            case 31: return 42;
            case 30: return 41;
            case 29: return 40;
            case 28: return 39;
            case 21: return 36;
            case 20: return 35;
            case 13: return 24;
            default: return 17;
        }
    }

    private int yyr13() { // assign_cmd : ID ATTRIB exp
        { yyrv = yysv[yysp-3] + " = " + yysv[yysp-1]; }
        yysv[yysp-=3] = yyrv;
        return 7;
    }

    private int yyr15() { // write_cmd : WRITE simple_exp
        { yyrv = "print(" + yysv[yysp-1] + ")"; }
        yysv[yysp-=2] = yyrv;
        return 8;
    }

    protected String[] yyerrmsgs = {
    };


int tokenType;
String tokenVal;
TINYScanner scanner;
String output;

TINYParser(Reader input) {
    scanner = new TINYScanner(input);
    getToken();
}

int getToken() {
    try {
            TINYToken tok = scanner.getToken();
            tokenType = tok.type;
            tokenVal = (tok.type == NUM) ? 
               String.valueOf(tok.intVal) :
               tok.strVal; 
            return tokenType;
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
}

void yyerror(String msg) {
    throw new RuntimeException(msg);
}

}
