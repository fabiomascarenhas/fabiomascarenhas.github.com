package tiny;

import java.util.Collections;
import java.util.List;
import java.util.Map;

abstract class Visitor {
	void visit(Program tp) {
		for(Command cmd : tp.body)
			cmd.accept(this);
	}
	
	void visit(VarCommand tvc) {
	}
	
	void visit(IfCommand tif) {
		tif.cond.accept(this);
		for(Command cmd : tif.cmd_then)
			cmd.accept(this);
		if(tif.cmd_else != null) 
			for(Command cmd : tif.cmd_else)
				cmd.accept(this);
	}
	
	void visit(RepeatCommand tr) {
		for(Command cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
	}
	
	void visit(AssignCommand ta) {
		ta.rval.accept(this);
	}
	
	void visit(ReadCommand tr) {
	}
	
	void visit(WriteCommand tw) {
		tw.exp.accept(this);
	}
	
	void visit(NumeralExpression tn) {
	}

	void visit(VarExpression tn) {
	}
	
	void visit(UnmExpression tu) {
		tu.exp.accept(this);
	}
	

	void visit(NotExpression tu) {
		tu.exp.accept(this);
	}
	
	void visit(LtExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(EqExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(AddExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(SubExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}
	
	void visit(MulExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(DivExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(AndExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(OrExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}
	
	void visit(Function func) {
		for(Command cmd : func.body)
			cmd.accept(this);
	}
	
	void visit(FuncProgram fp) {
		for(Function func : fp.funcs)
			func.accept(this);
	}
	
	void visit(FuncallCommand fc) {
		if(fc.args != null)
			for(Expression arg : fc.args)
				arg.accept(this);
	}

	void visit(FuncallExpression fe) {
		if(fe.args != null)
			for(Expression arg : fe.args)
				arg.accept(this);
	}
	
	void visit(ReturnCommand rc) {
		if(rc.exp != null)
			rc.exp.accept(this);
	}
}

abstract class Node {
	abstract void accept(Visitor v);
}

abstract class Command extends Node {
	void codegen(CodeGen ctx) {
		throw new RuntimeException("n�o implementado");
	}
}

abstract class Expression extends Node {
	public int type;
	
	public static int INT = 1;
	public static int BOOL = 2;

	void codegen(CodeGen ctx, Integer target) {
		throw new RuntimeException("n�o implementado");
	}
	
	void jumpfalse(CodeGen ctx, int label) {
		throw new RuntimeException("n�o implementado");
	}
}

class Program extends Command {
	public List<Command> body;
	public SymbolTable st_body;
	
	Program(List<Command> body) {
		this.body = body;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx) {
		ctx.st = st_body;
		ctx.emit("function main:");
		for(Command cmd : body)
			cmd.codegen(ctx);
		ctx.emit("RETURN", "R0","1");
	}

}

class FuncProgram extends Command {
	public List<Function> funcs;
	public Map<String, Integer> arities;
	
	FuncProgram(List<Function> funcs) {
		this.funcs = funcs;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx) {
		for(Function func : funcs)
			func.codegen(ctx);
		ctx.emit("\nfunction main:");
		for(Function func : funcs) {
			ctx.emit("CLOSURE", "R0", 
					"TINY_" + func.name,
					String.valueOf(func.params.size()));
			ctx.emit("SETGLOBAL", "R0",
					"TINY_" + func.name);
		}
		ctx.emit("GETGLOBAL", "R0", "TINY_main");
		ctx.emit("CALL", "R0", "1", "1");
		ctx.emit("RETURN", "R0", "1");
	}
}

class Function extends Command {
	public String name;
	public List<String> params;
	public List<Command> body;
	public SymbolTable st_body;
	
	Function(String name, List<String> params, List<Command> body) {
		this.name = name;
		this.params = params;
		this.body = body;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx) {
		ctx.st = st_body;
		ctx.temp = Collections.max(ctx.st.vars.values()) + 1;
		ctx.emit("function TINY_" + name + ":");
		for(Command cmd : body) {
			cmd.codegen(ctx);
		}
		ctx.emit("LOADK", "R0", "0");
		ctx.emit("RETURN", "R0", "2");
		ctx.emit("\n");
		ctx.st = ctx.st.parent;
	}
}

class VarCommand extends Command {
	String name;
	
	VarCommand(String name) {
		this.name = name;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx) {
		ctx.emit("LOADK", "R" + ctx.st.get(name), "0");
	}
}

class IfCommand extends Command {
	public Expression cond;
	public List<Command> cmd_then;
	public List<Command> cmd_else;
	public SymbolTable st_then;
	public SymbolTable st_else;
	
	IfCommand(Expression cond, List<Command> cmd_then, List<Command> cmd_else) {
		this.cond = cond;
		this.cmd_then = cmd_then;
		this.cmd_else = cmd_else;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx) {
		int lelse, lout;
		if(this.cmd_else != null) {
			lelse = ctx.label++;
			lout = ctx.label++;
		} else {
			lelse = lout = ctx.label++;
		}
		cond.jumpfalse(ctx, lelse);
		ctx.st = st_then;
		for(Command cmd : cmd_then)
			cmd.codegen(ctx);
		ctx.st = ctx.st.parent;
		if(cmd_else != null) {
			ctx.emit("JMP", "label" + lout);
			ctx.label(lelse);
			ctx.st = st_else;
			for(Command cmd : cmd_else)
				cmd.codegen(ctx);
			ctx.st = ctx.st.parent;
		}
		ctx.label(lout);
	}
}

class RepeatCommand extends Command {
	public Expression cond;
	public List<Command> cmd_body;
	public SymbolTable st_body;
	
	RepeatCommand(List<Command> cmd_body, Expression cond) {
		this.cond = cond;
		this.cmd_body = cmd_body;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx) {
		int lrepeat = ctx.label++;
		ctx.label(lrepeat);
		ctx.st = st_body;
		for(Command cmd : cmd_body)
			cmd.codegen(ctx);
		cond.jumpfalse(ctx, lrepeat);
		ctx.st = ctx.st.parent;
	}
}

class AssignCommand extends Command {
	public String lval;
	public Expression rval;
	
	AssignCommand(String lval, Expression rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx) {
		rval.codegen(ctx, ctx.st.get(lval));
	}
}

class ReadCommand extends Command {
	public String var;
	
	ReadCommand(String var) {
		this.var = var;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx) {
		int read = ctx.st.get(var);
		ctx.emit("GETGLOBAL", "R" + read, "read");
		ctx.emit("CALL", "R" + read, "1", "2");
	}
}

class WriteCommand extends Command {
	public Expression exp;
	
	WriteCommand(Expression exp) {
		this.exp = exp;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx) {
		int print = ctx.temp++;
		int pexp = ctx.temp++;
		ctx.emit("GETGLOBAL", "R" + print, "print");
		exp.codegen(ctx, pexp);
		ctx.emit("CALL", "R" + print, "2", "1");
		ctx.temp = ctx.temp - 2;
	}
}

class NumeralExpression extends Expression {
	public int val;
	
	NumeralExpression(int val) {
		this.val = val;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx, Integer target) {
		ctx.emit("LOADK", "R" + target, String.valueOf(val));
	}
}

class VarExpression extends Expression {
	public String name;
	
	VarExpression(String name) {
		this.name = name;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx, Integer target) {
		int var = ctx.st.get(name);
		if(var != target)
			ctx.emit("MOVE", "R" + target, " R" + var);
	}
}

class UnmExpression extends Expression {
	public Expression exp;
	
	UnmExpression(Expression exp) {
		this.exp = exp;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx, Integer target) {
		exp.codegen(ctx, target);
		ctx.emit("UNM", "R" + target, "R" + target);
	}
}

abstract class BinopExpression extends Expression {
	public Expression left;
	public Expression right;
}

class LtExpression extends BinopExpression {
	LtExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void jumpfalse(CodeGen ctx, int label) {
		int t1 = ctx.temp++;
		int t2 = ctx.temp++;
		left.codegen(ctx, t1);
		right.codegen(ctx, t2);
		ctx.emit("LT", "false", "R" + t1, "R" + t2);
		ctx.emit("JMP", "label" + label);
		ctx.temp -= 2;
	}
}

class EqExpression extends BinopExpression {
	EqExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void jumpfalse(CodeGen ctx, int label) {
		int t1 = ctx.temp++;
		int t2 = ctx.temp++;
		left.codegen(ctx, t1);
		right.codegen(ctx, t2);
		ctx.emit("EQ", "false", "R" + t1, "R" + t2);
		ctx.emit("JMP", "label" + label);
		ctx.temp -= 2;
	}
}

class AddExpression extends BinopExpression {
	AddExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx, Integer target) {
		left.codegen(ctx, target);
		int r = ctx.temp++;
		right.codegen(ctx, r);
		ctx.emit("ADD", "R" + target, "R" +
					target, "R" + r);
		ctx.temp--;
	}
}

class SubExpression extends BinopExpression {
	SubExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx, Integer target) {
		left.codegen(ctx, target);
		int r = ctx.temp++;
		right.codegen(ctx, r);
		ctx.emit("SUB", "R" + target, "R" +
					target, "R" + r);
		ctx.temp--;
	}
}

class MulExpression extends BinopExpression {
	MulExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx, Integer target) {
		left.codegen(ctx, target);
		int r = ctx.temp++;
		right.codegen(ctx, r);
		ctx.emit("MUL", "R" + target, "R" +
					target, "R" + r);
		ctx.temp--;
	}
}

class DivExpression extends BinopExpression {
	DivExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx, Integer target) {
		int div = ctx.temp++;
		int n1 = ctx.temp++;
		int n2 = ctx.temp++;
		ctx.emit("GETGLOBAL", "R" + div, "div");
		left.codegen(ctx, n1);
		right.codegen(ctx, n2);
		ctx.emit("CALL", "R" + div, "3", "2");
		ctx.emit("MOVE", "R" + target, "R" + div);
		ctx.temp -= 3;
	}
}

class AndExpression extends BinopExpression {
	AndExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void jumpfalse(CodeGen ctx, int label) {
		left.jumpfalse(ctx, label);
		right.jumpfalse(ctx, label);
	}
}

class OrExpression extends BinopExpression {
	OrExpression(Expression left, Expression right) {
		this.left = left;
		this.right = right;
	}
	
	void accept(Visitor tv) {
		tv.visit(this);
	}

	void jumpfalse(CodeGen ctx, int label) {
		int lr = ctx.label++;
		int lout = ctx.label++;
		left.jumpfalse(ctx, lr);
		ctx.emit("JMP", "label" + lout);
		ctx.label(lr);
		right.jumpfalse(ctx, label);
		ctx.label(lout);
	}
}

class NotExpression extends Expression {
	public Expression exp;
	
	NotExpression(Expression exp) {
		this.exp = exp;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void jumpfalse(CodeGen ctx, int label) {
		int lout = ctx.label++;
		exp.jumpfalse(ctx, lout);
		ctx.emit("JMP", "label" + label);
		ctx.label(lout);
	}
}

class FuncallCommand extends Command {
	public String name;
	public List<Expression> args;
	
	FuncallCommand(String name, List<Expression> args) {
		this.name = name;
		this.args = args;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}

	void codegen(CodeGen ctx) {
		int func = ctx.temp++;
		ctx.temp += args.size();
		ctx.emit("GETGLOBAL", "R" + func,
				"TINY_" + name);
		int rarg = func + 1;
		for(Expression arg : args) {
			arg.codegen(ctx, rarg++);
		}
		ctx.emit("CALL", "R" + func,
				String.valueOf(args.size() + 1), "1");
		ctx.temp -= args.size() + 1;
	}
}

class FuncallExpression extends Expression {
	public String name;
	public List<Expression> args;
	
	FuncallExpression(String name, List<Expression> args) {
		this.name = name;
		this.args = args;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx, Integer target) {
		int func = ctx.temp++;
		ctx.temp += args.size();
		ctx.emit("GETGLOBAL", "R" + func,
				"TINY_" + name);
		int rarg = func + 1;
		for(Expression arg : args) {
			arg.codegen(ctx, rarg++);
		}
		ctx.emit("CALL", "R" + func,
				String.valueOf(args.size() + 1), "2");
		ctx.emit("MOVE", "R" + target, "R" + func);
		ctx.temp -= args.size() + 1;
	}
}

class ReturnCommand extends Command {
	public Expression exp;
	
	ReturnCommand(Expression exp) {
		this.exp = exp;
	}

	void accept(Visitor tv) {
		tv.visit(this);
	}
	
	void codegen(CodeGen ctx) {
		int temp = ctx.temp++;
		if(exp != null) {
			exp.codegen(ctx, temp);
		} else {
			ctx.emit("LOADK", "R" + temp, "0");
		}
		ctx.emit("RETURN", "R" + temp, "2");
		ctx.temp--;
	}
}
