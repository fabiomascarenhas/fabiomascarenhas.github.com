// Output created by jacc on Wed Nov 09 16:38:00 BRST 2011

package tiny;

import java.io.Reader;
import java.util.*;

class Parser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 87:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 88:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 174;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 89:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 90:
                    switch (yytok) {
                        case ';':
                            yyn = 22;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 91:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 92:
                    switch (yytok) {
                        case ';':
                            yyn = 23;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 93:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 94:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 95:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 96:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 97:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr17();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 100:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr16();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    switch (yytok) {
                        case ID:
                            yyn = 24;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 25;
                            continue;
                        case '(':
                            yyn = 26;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    switch (yytok) {
                        case ID:
                            yyn = 33;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    yyn = yys18();
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    switch (yytok) {
                        case ID:
                            yyn = 36;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    yyn = yys22();
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    switch (yytok) {
                        case FUNCTION:
                            yyn = 14;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    switch (yytok) {
                        case '(':
                            yyn = 40;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    yyn = yys27();
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    yyn = yys28();
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    yyn = yys30();
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr26();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    switch (yytok) {
                        case ';':
                            yyn = 22;
                            continue;
                        case UNTIL:
                            yyn = 58;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ID:
                            yyn = 61;
                            continue;
                        case ')':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    switch (yytok) {
                        case ',':
                            yyn = 62;
                            continue;
                        case ')':
                            yyn = yyr45();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case ')':
                            yyn = 63;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    yyn = yys54();
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    yyn = yys57();
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ',':
                            yyn = 76;
                            continue;
                        case ')':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ')':
                            yyn = 77;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case NOT:
                            yyn = 29;
                            continue;
                        case NUM:
                            yyn = 30;
                            continue;
                        case '(':
                            yyn = 31;
                            continue;
                        case '-':
                            yyn = 32;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case ';':
                            yyn = 22;
                            continue;
                        case ELSE:
                            yyn = 80;
                            continue;
                        case END:
                            yyn = yyr23();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ')':
                            yyn = 81;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    switch (yytok) {
                        case ID:
                            yyn = 82;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys78();
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    switch (yytok) {
                        case END:
                            yyn = 84;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys80();
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys81();
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    switch (yytok) {
                        case ';':
                            yyn = 22;
                            continue;
                        case END:
                            yyn = 86;
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                        case UNTIL:
                        case END:
                            yyn = yyr21();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    switch (yytok) {
                        case ';':
                            yyn = 22;
                            continue;
                        case END:
                            yyn = yyr22();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 177;
                    continue;

                case 174:
                    return true;
                case 175:
                    yyerror("stack overflow");
                case 176:
                    return false;
                case 177:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case FUNCTION:
                return 14;
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 177;
    }

    private int yys18() {
        switch (yytok) {
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 177;
    }

    private int yys19() {
        switch (yytok) {
            case ID:
                return 28;
            case NOT:
                return 29;
            case NUM:
                return 30;
            case '(':
                return 31;
            case '-':
                return 32;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr30();
        }
        return 177;
    }

    private int yys22() {
        switch (yytok) {
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 177;
    }

    private int yys26() {
        switch (yytok) {
            case ID:
                return 28;
            case NOT:
                return 29;
            case NUM:
                return 30;
            case '(':
                return 31;
            case '-':
                return 32;
            case ')':
                return yyr46();
        }
        return 177;
    }

    private int yys27() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case THEN:
                return 47;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
        }
        return 177;
    }

    private int yys28() {
        switch (yytok) {
            case UNM:
            case NOT:
            case IF:
            case REPEAT:
            case FUNCTION:
            case VAR:
            case ATTRIB:
            case NUM:
            case ID:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
                return 177;
            case '(':
                return 54;
        }
        return yyr33();
    }

    private int yys30() {
        switch (yytok) {
            case REPEAT:
            case NOT:
            case IF:
            case ID:
            case '(':
            case VAR:
            case ATTRIB:
            case NUM:
            case FUNCTION:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
            case UNM:
                return 177;
        }
        return yyr32();
    }

    private int yys35() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr29();
        }
        return 177;
    }

    private int yys37() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr27();
        }
        return 177;
    }

    private int yys41() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr25();
        }
        return 177;
    }

    private int yys42() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ',':
            case ')':
                return yyr47();
        }
        return 177;
    }

    private int yys47() {
        switch (yytok) {
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 177;
    }

    private int yys54() {
        switch (yytok) {
            case ID:
                return 28;
            case NOT:
                return 29;
            case NUM:
                return 30;
            case '(':
                return 31;
            case '-':
                return 32;
            case ')':
                return yyr46();
        }
        return 177;
    }

    private int yys55() {
        switch (yytok) {
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case THEN:
            case ';':
            case ',':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case END:
            case ENDINPUT:
            case AND:
                return yyr35();
        }
        return 177;
    }

    private int yys56() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ')':
                return 74;
        }
        return 177;
    }

    private int yys57() {
        switch (yytok) {
            case REPEAT:
            case NOT:
            case IF:
            case ID:
            case '(':
            case VAR:
            case ATTRIB:
            case NUM:
            case FUNCTION:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
            case UNM:
                return 177;
        }
        return yyr36();
    }

    private int yys64() {
        switch (yytok) {
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case THEN:
            case ';':
            case ',':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case END:
            case ENDINPUT:
            case AND:
                return yyr43();
        }
        return 177;
    }

    private int yys65() {
        switch (yytok) {
            case AND:
                return 45;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case THEN:
            case ';':
            case ',':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case ENDINPUT:
            case END:
                return yyr44();
        }
        return 177;
    }

    private int yys67() {
        switch (yytok) {
            case REPEAT:
            case NOT:
            case IF:
            case ID:
            case '(':
            case VAR:
            case ATTRIB:
            case NUM:
            case FUNCTION:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
            case UNM:
                return 177;
        }
        return yyr41();
    }

    private int yys68() {
        switch (yytok) {
            case '*':
                return 48;
            case '/':
                return 51;
            case THEN:
            case '<':
            case ';':
            case '-':
            case ',':
            case '+':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case END:
            case '=':
            case ENDINPUT:
            case AND:
                return yyr39();
        }
        return 177;
    }

    private int yys69() {
        switch (yytok) {
            case '*':
                return 48;
            case '/':
                return 51;
            case THEN:
            case '<':
            case ';':
            case '-':
            case ',':
            case '+':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case END:
            case '=':
            case ENDINPUT:
            case AND:
                return yyr40();
        }
        return 177;
    }

    private int yys70() {
        switch (yytok) {
            case REPEAT:
            case NOT:
            case IF:
            case ID:
            case '(':
            case VAR:
            case ATTRIB:
            case NUM:
            case FUNCTION:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
            case UNM:
                return 177;
        }
        return yyr42();
    }

    private int yys71() {
        switch (yytok) {
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case THEN:
            case '<':
            case ';':
            case ',':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case END:
            case '=':
            case ENDINPUT:
            case AND:
                return yyr37();
        }
        return 177;
    }

    private int yys72() {
        switch (yytok) {
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case THEN:
            case '<':
            case ';':
            case ',':
            case ELSE:
            case ')':
            case OR:
            case UNTIL:
            case END:
            case '=':
            case ENDINPUT:
            case AND:
                return yyr38();
        }
        return 177;
    }

    private int yys74() {
        switch (yytok) {
            case REPEAT:
            case NOT:
            case IF:
            case ID:
            case '(':
            case VAR:
            case ATTRIB:
            case NUM:
            case FUNCTION:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
            case UNM:
                return 177;
        }
        return yyr31();
    }

    private int yys75() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ENDINPUT:
            case ';':
            case ELSE:
            case UNTIL:
            case END:
                return yyr24();
        }
        return 177;
    }

    private int yys77() {
        switch (yytok) {
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 177;
    }

    private int yys78() {
        switch (yytok) {
            case AND:
                return 45;
            case OR:
                return 46;
            case '*':
                return 48;
            case '+':
                return 49;
            case '-':
                return 50;
            case '/':
                return 51;
            case '<':
                return 52;
            case '=':
                return 53;
            case ',':
            case ')':
                return yyr48();
        }
        return 177;
    }

    private int yys80() {
        switch (yytok) {
            case ID:
                return 15;
            case IF:
                return 16;
            case READ:
                return 17;
            case REPEAT:
                return 18;
            case RETURN:
                return 19;
            case VAR:
                return 20;
            case WRITE:
                return 21;
        }
        return 177;
    }

    private int yys81() {
        switch (yytok) {
            case REPEAT:
            case NOT:
            case IF:
            case ID:
            case '(':
            case VAR:
            case ATTRIB:
            case NUM:
            case FUNCTION:
            case RETURN:
            case STRING:
            case READ:
            case error:
            case WRITE:
            case UNM:
                return 177;
        }
        return yyr34();
    }

    private int yyr1() { // tiny : func_seq
        { output = new FuncProgram(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr2() { // tiny : cmd_seq
        { output = new Program(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr12() { // cmd : if_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr13() { // cmd : repeat_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr14() { // cmd : assign_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr15() { // cmd : read_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr16() { // cmd : write_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr17() { // cmd : var_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr18() { // cmd : funcall_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr19() { // cmd : return_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 22: return 38;
            default: return 2;
        }
    }

    private int yyr10() { // cmd_seq : cmd
        { List<Command> cmds = new ArrayList<Command>();
                                                 cmds.add(((Command)yysv[yysp-1]));
                                                 yyrv = cmds; }
        yysv[yysp-=1] = yyrv;
        return yypcmd_seq();
    }

    private int yyr11() { // cmd_seq : cmd_seq ';' cmd
        { List<Command> cmds = ((List)yysv[yysp-3]);
                                                   cmds.add(((Command)yysv[yysp-1]));
                                                   yyrv = cmds; }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 77: return 83;
            case 47: return 66;
            case 18: return 34;
            case 0: return 3;
            default: return 85;
        }
    }

    private int yyr22() { // else_cmd : ELSE cmd_seq
        { yyrv = ((List)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return 79;
    }

    private int yyr23() { // else_cmd : /* empty */
        { yyrv = null; }
        yysv[yysp-=0] = yyrv;
        return 79;
    }

    private int yyr31() { // exp : '(' exp ')'
        { yyrv = ((Expression)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr32() { // exp : NUM
        { yyrv = new NumeralExpression(((Integer)((Integer)yysv[yysp-1])).intValue()); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr33() { // exp : ID
        { yyrv = new VarExpression((String)((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr34() { // exp : ID '(' exps ')'
        { yyrv = new FuncallExpression(((String)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : NOT exp
        { yyrv = new NotExpression((Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : '-' exp
        { yyrv = new UnmExpression((Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : exp '<' exp
        { yyrv = new LtExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : exp '=' exp
        { yyrv = new EqExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : exp '+' exp
        { yyrv = new AddExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : exp '-' exp
        { yyrv = new SubExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : exp '*' exp
        { yyrv = new MulExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr42() { // exp : exp '/' exp
        { yyrv = new DivExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr43() { // exp : exp AND exp
        { yyrv = new AndExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr44() { // exp : exp OR exp
        { yyrv = new OrExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 62: return 78;
            case 58: return 75;
            case 53: return 72;
            case 52: return 71;
            case 51: return 70;
            case 50: return 69;
            case 49: return 68;
            case 48: return 67;
            case 46: return 65;
            case 45: return 64;
            case 32: return 57;
            case 31: return 56;
            case 29: return 55;
            case 25: return 41;
            case 21: return 37;
            case 19: return 35;
            case 16: return 27;
            default: return 42;
        }
    }

    private int yyr47() { // exp_list : exp
        { List<Expression> exps = new ArrayList<Expression>();
                                exps.add(((Expression)yysv[yysp-1])); yyrv = exps; }
        yysv[yysp-=1] = yyrv;
        return 43;
    }

    private int yyr48() { // exp_list : exp_list ',' exp
        { (((List)yysv[yysp-3])).add(((Expression)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 43;
    }

    private int yyr45() { // exps : exp_list
        yysp -= 1;
        return yypexps();
    }

    private int yyr46() { // exps : /* empty */
        { yyrv = new ArrayList<Expression>(); }
        yysv[yysp-=0] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 26: return 44;
            default: return 73;
        }
    }

    private int yyr5() { // func : FUNCTION ID '(' params ')' cmd_seq END
        { yyrv = new Function(((String)yysv[yysp-6]), ((List)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        switch (yyst[yysp-1]) {
            case 0: return 4;
            default: return 39;
        }
    }

    private int yyr3() { // func_seq : func
        { List<Function> funcs = new ArrayList<Function>();
                                                  funcs.add(((Function)yysv[yysp-1])); yyrv = funcs; }
        yysv[yysp-=1] = yyrv;
        return 5;
    }

    private int yyr4() { // func_seq : func_seq ';' func
        { (((List)yysv[yysp-3])).add(((Function)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 5;
    }

    private int yyr28() { // funcall_cmd : ID '(' exps ')'
        { yyrv = new FuncallCommand(((String)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return 6;
    }

    private int yyr21() { // if_cmd : IF exp THEN cmd_seq else_cmd END
        { yyrv = new IfCommand(((Expression)yysv[yysp-5]), ((List)yysv[yysp-3]), ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return 7;
    }

    private int yyr8() { // param_list : ID
        { List<String> params = new ArrayList<String>();
                                 params.add(((String)yysv[yysp-1])); yyrv = params; }
        yysv[yysp-=1] = yyrv;
        return 59;
    }

    private int yyr9() { // param_list : param_list ',' ID
        { (((List)yysv[yysp-3])).add(((String)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 59;
    }

    private int yyr6() { // params : param_list
        yysp -= 1;
        return 60;
    }

    private int yyr7() { // params : /* empty */
        { yyrv = new ArrayList<String>(); }
        yysv[yysp-=0] = yyrv;
        return 60;
    }

    private int yyr26() { // read_cmd : READ ID
        { yyrv = new ReadCommand((String)((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 8;
    }

    private int yyr24() { // repeat_cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = new RepeatCommand((List<Command>)((List)yysv[yysp-3]),
                                                                                (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return 9;
    }

    private int yyr29() { // return_cmd : RETURN exp
        { yyrv = new ReturnCommand(((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 10;
    }

    private int yyr30() { // return_cmd : RETURN
        { yyrv = new ReturnCommand(null); }
        yysv[yysp-=1] = yyrv;
        return 10;
    }

    private int yyr25() { // assign_cmd : ID ATTRIB exp
        { yyrv = new AssignCommand((String)((String)yysv[yysp-3]),
                                                                                                                 (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 11;
    }

    private int yyr20() { // var_cmd : VAR ID
        { yyrv = new VarCommand((String)((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 12;
    }

    private int yyr27() { // write_cmd : WRITE exp
        { yyrv = new WriteCommand((Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 13;
    }

    protected String[] yyerrmsgs = {
    };


int tokenType;
Object tokenVal;
Scanner scanner;
Command output;

Parser(Reader input) {
    scanner = new Scanner(input);
    getToken();
}

int getToken() {
    try {
            Token tok = scanner.getToken();
            tokenType = tok.type;
            tokenVal = (tok.type == NUM) ? 
               tok.intVal :
               tok.strVal; 
            return tokenType;
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
}

void yyerror(String msg) {
    throw new RuntimeException(msg);
}

}
