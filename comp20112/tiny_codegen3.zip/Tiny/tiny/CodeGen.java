package tiny;

class CodeGen {
	SymbolTable st; // n�vel atual!
	int temp;
	int label;
	StringBuilder out;
	
	CodeGen(int temp) {
		label = 0;
		this.temp = temp;
		out = new StringBuilder();
	}
	
	void label(int lab) {
		out.append("label" + lab + ":\n");
	}

	void emit(String s) {
		out.append(s + "\n");
	}

	void emitJmp(int label, String comment) {
		emit("JMP", "label" + label, " ; " + comment);
	}
	
	void emit(String op, String arg1, String arg2, String arg3) {
		out.append("  " + op + " " + arg1 + " " + arg2 + " " + arg3 + "\n");
	}

	void emit(String op, String arg1, String arg2) {
		out.append("  " + op + " " + arg1 + " " + arg2 + "\n");
	}

	void emit(String op, String arg1) {
		out.append("  " + op + " " + arg1 + "\n");
	}			
}
