// Output created by jacc on Wed Nov 09 16:38:00 BRST 2011

package tiny;

interface Tokens {
    int ENDINPUT = 0;
    int AND = 1;
    int ATTRIB = 2;
    int ELSE = 3;
    int END = 4;
    int FUNCTION = 5;
    int ID = 6;
    int IF = 7;
    int NOT = 8;
    int NUM = 9;
    int OR = 10;
    int READ = 11;
    int REPEAT = 12;
    int RETURN = 13;
    int STRING = 14;
    int THEN = 15;
    int UNM = 16;
    int UNTIL = 17;
    int VAR = 18;
    int WRITE = 19;
    int error = 20;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
