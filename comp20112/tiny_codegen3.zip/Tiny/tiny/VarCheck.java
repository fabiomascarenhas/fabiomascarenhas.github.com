package tiny;

import java.util.*;

class VarCheck extends Visitor {
	SymbolTable st; // n�vel atual!
	Map<String, Integer> ft; // tabela de aridade de fun��es
	int temp;	

	VarCheck() {	
		temp = 0;
		ft = new HashMap<String, Integer>();
	}
	
	void visit(Program tp) {
		tp.st_body = st = new SymbolTable(null);
		for(Command cmd : tp.body)
			cmd.accept(this);
		temp = Math.max(temp, st.free);
	}
	
	void visit(FuncProgram fp) {
		for(Function func : fp.funcs)
			func.accept(this);
		fp.arities = ft;
	}
	
	void visit(Function f) {
		temp = 0;
		if(ft.containsKey(f.name))
			throw new RuntimeException("fun��o redeclarada");
		ft.put(f.name, f.params.size());
		f.st_body = st = new SymbolTable(null);
		for(String param : f.params)
			st.put(param);
		for(Command cmd : f.body)
			cmd.accept(this);
		st = null;
	}
	
	void visit(IfCommand tif) {
		tif.cond.accept(this);
		tif.st_then = st = new SymbolTable(st);
		for(Command cmd : tif.cmd_then)
			cmd.accept(this);
		temp = Math.max(temp, st.free);
		st = st.parent;
		if(tif.cmd_else != null) {
			tif.st_else = st = new SymbolTable(st);
			for(Command cmd : tif.cmd_else)
				cmd.accept(this);
			temp = Math.max(temp, st.free);
			st = st.parent;
		}
	}
	
	void visit(RepeatCommand tr) {
		tr.st_body = st = new SymbolTable(st);
		for(Command cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
		temp = Math.max(temp, st.free);
		st = st.parent;
	}
	
	void visit(AssignCommand ta) {
		if(st.get(ta.lval) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
		ta.rval.accept(this);
	}
	
	void visit(ReadCommand tr) {
		if(st.get(tr.var) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
	}
	
	void visit(VarExpression tv) {
		if(st.get(tv.name) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
	}
	
	void visit(VarCommand tvc) {
		st.put(tvc.name);
	}
}
