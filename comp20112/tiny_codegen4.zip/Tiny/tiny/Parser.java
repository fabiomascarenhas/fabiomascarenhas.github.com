// Output created by jacc on Wed Nov 23 16:40:23 BRST 2011

package tiny;

import java.io.Reader;
import java.util.*;

class Parser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 202;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    switch (yytok) {
                        case ';':
                            yyn = 24;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    switch (yytok) {
                        case ';':
                        case ENDINPUT:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    switch (yytok) {
                        case ';':
                            yyn = 25;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 26;
                            continue;
                        case '[':
                            yyn = 27;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr17();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr16();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 29;
                            continue;
                        case '(':
                            yyn = 30;
                            continue;
                        case '[':
                            yyn = 31;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    switch (yytok) {
                        case ID:
                            yyn = 39;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    yyn = yys20();
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    yyn = yys21();
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    switch (yytok) {
                        case ID:
                            yyn = 42;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    yyn = yys24();
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case FUNCTION:
                            yyn = 16;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    switch (yytok) {
                        case '(':
                            yyn = 48;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    yyn = yys30();
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    yyn = yys33();
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    yyn = yys34();
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr29();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    switch (yytok) {
                        case ';':
                            yyn = 24;
                            continue;
                        case UNTIL:
                            yyn = 67;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ';':
                        case ENDINPUT:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    yyn = yys46();
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case ID:
                            yyn = 72;
                            continue;
                        case ')':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    yyn = yys49();
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    yyn = yys50();
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    switch (yytok) {
                        case ',':
                            yyn = 73;
                            continue;
                        case ')':
                            yyn = yyr51();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case ')':
                            yyn = 74;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    yyn = yys53();
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    yyn = yys63();
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    switch (yytok) {
                        case NUM:
                            yyn = 88;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ',':
                            yyn = 89;
                            continue;
                        case ')':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    switch (yytok) {
                        case ')':
                            yyn = 90;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    switch (yytok) {
                        case ID:
                            yyn = 34;
                            continue;
                        case NOT:
                            yyn = 35;
                            continue;
                        case NUM:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '-':
                            yyn = 38;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr31();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys76();
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys77();
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    switch (yytok) {
                        case ';':
                            yyn = 24;
                            continue;
                        case ELSE:
                            yyn = 93;
                            continue;
                        case END:
                            yyn = yyr25();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys79();
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    yyn = yys80();
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    yyn = yys81();
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    yyn = yys82();
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    yyn = yys83();
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys84();
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ')':
                            yyn = 94;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    yyn = yys86();
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    yyn = yys87();
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    switch (yytok) {
                        case ']':
                            yyn = 95;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    switch (yytok) {
                        case ID:
                            yyn = 96;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    yyn = yys91();
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    switch (yytok) {
                        case END:
                            yyn = 98;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    yyn = yys94();
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr22();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    switch (yytok) {
                        case ',':
                        case ')':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    switch (yytok) {
                        case ';':
                            yyn = 24;
                            continue;
                        case END:
                            yyn = 100;
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    switch (yytok) {
                        case ';':
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ELSE:
                            yyn = yyr23();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    switch (yytok) {
                        case ';':
                            yyn = 24;
                            continue;
                        case END:
                            yyn = yyr24();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    switch (yytok) {
                        case ';':
                        case ENDINPUT:
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 205;
                    continue;

                case 202:
                    return true;
                case 203:
                    yyerror("stack overflow");
                case 204:
                    return false;
                case 205:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case BREAK:
                return 15;
            case FUNCTION:
                return 16;
            case ID:
                return 17;
            case IF:
                return 18;
            case READ:
                return 19;
            case REPEAT:
                return 20;
            case RETURN:
                return 21;
            case VAR:
                return 22;
            case WRITE:
                return 23;
        }
        return 205;
    }

    private int yys20() {
        switch (yytok) {
            case BREAK:
                return 15;
            case ID:
                return 17;
            case IF:
                return 18;
            case READ:
                return 19;
            case REPEAT:
                return 20;
            case RETURN:
                return 21;
            case VAR:
                return 22;
            case WRITE:
                return 23;
        }
        return 205;
    }

    private int yys21() {
        switch (yytok) {
            case ID:
                return 34;
            case NOT:
                return 35;
            case NUM:
                return 36;
            case '(':
                return 37;
            case '-':
                return 38;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr33();
        }
        return 205;
    }

    private int yys24() {
        switch (yytok) {
            case BREAK:
                return 15;
            case ID:
                return 17;
            case IF:
                return 18;
            case READ:
                return 19;
            case REPEAT:
                return 20;
            case RETURN:
                return 21;
            case VAR:
                return 22;
            case WRITE:
                return 23;
        }
        return 205;
    }

    private int yys30() {
        switch (yytok) {
            case ID:
                return 34;
            case NOT:
                return 35;
            case NUM:
                return 36;
            case '(':
                return 37;
            case '-':
                return 38;
            case ')':
                return yyr52();
        }
        return 205;
    }

    private int yys32() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case THEN:
                return 56;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
        }
        return 205;
    }

    private int yys33() {
        switch (yytok) {
            case NOT:
            case VAR:
            case FUNCTION:
            case REPEAT:
            case ID:
            case WRITE:
            case STRING:
            case ATTRIB:
            case NUM:
            case RETURN:
            case BREAK:
            case READ:
            case '(':
            case error:
            case IF:
            case UNM:
                return 205;
            case '[':
                return 27;
        }
        return yyr38();
    }

    private int yys34() {
        switch (yytok) {
            case UNM:
            case VAR:
            case NOT:
            case FUNCTION:
            case ID:
            case WRITE:
            case STRING:
            case ATTRIB:
            case NUM:
            case REPEAT:
            case BREAK:
            case READ:
            case RETURN:
            case error:
            case IF:
                return 205;
            case '[':
                return 31;
            case '(':
                return 63;
        }
        return yyr36();
    }

    private int yys36() {
        switch (yytok) {
            case '<':
            case ';':
            case '/':
            case ',':
            case '+':
            case '*':
            case ')':
            case OR:
            case '-':
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr35();
        }
        return 205;
    }

    private int yys41() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr32();
        }
        return 205;
    }

    private int yys42() {
        switch (yytok) {
            case '[':
                return 68;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr21();
        }
        return 205;
    }

    private int yys43() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr30();
        }
        return 205;
    }

    private int yys46() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr28();
        }
        return 205;
    }

    private int yys47() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ']':
                return 69;
        }
        return 205;
    }

    private int yys49() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr27();
        }
        return 205;
    }

    private int yys50() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ',':
            case ')':
                return yyr53();
        }
        return 205;
    }

    private int yys53() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ']':
                return 75;
        }
        return 205;
    }

    private int yys56() {
        switch (yytok) {
            case BREAK:
                return 15;
            case ID:
                return 17;
            case IF:
                return 18;
            case READ:
                return 19;
            case REPEAT:
                return 20;
            case RETURN:
                return 21;
            case VAR:
                return 22;
            case WRITE:
                return 23;
        }
        return 205;
    }

    private int yys63() {
        switch (yytok) {
            case ID:
                return 34;
            case NOT:
                return 35;
            case NUM:
                return 36;
            case '(':
                return 37;
            case '-':
                return 38;
            case ')':
                return yyr52();
        }
        return 205;
    }

    private int yys64() {
        switch (yytok) {
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case ',':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr39();
        }
        return 205;
    }

    private int yys65() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ')':
                return 86;
        }
        return 205;
    }

    private int yys66() {
        switch (yytok) {
            case '<':
            case ';':
            case '/':
            case ',':
            case '+':
            case '*':
            case ')':
            case OR:
            case '-':
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr40();
        }
        return 205;
    }

    private int yys69() {
        switch (yytok) {
            case REPEAT:
            case IF:
            case RETURN:
            case READ:
            case error:
            case NOT:
            case STRING:
            case ID:
            case NUM:
            case FUNCTION:
            case BREAK:
            case '(':
            case WRITE:
            case VAR:
            case UNM:
                return 205;
        }
        return yyr49();
    }

    private int yys75() {
        switch (yytok) {
            case REPEAT:
            case IF:
            case RETURN:
            case READ:
            case error:
            case NOT:
            case STRING:
            case ID:
            case NUM:
            case FUNCTION:
            case BREAK:
            case '(':
            case WRITE:
            case VAR:
            case UNM:
                return 205;
        }
        return yyr50();
    }

    private int yys76() {
        switch (yytok) {
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case ',':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr47();
        }
        return 205;
    }

    private int yys77() {
        switch (yytok) {
            case AND:
                return 54;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case ',':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case ']':
            case THEN:
            case ELSE:
                return yyr48();
        }
        return 205;
    }

    private int yys79() {
        switch (yytok) {
            case '<':
            case ';':
            case '/':
            case ',':
            case '+':
            case '*':
            case ')':
            case OR:
            case '-':
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr45();
        }
        return 205;
    }

    private int yys80() {
        switch (yytok) {
            case '*':
                return 57;
            case '/':
                return 60;
            case '<':
            case ';':
            case '-':
            case ',':
            case '+':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr43();
        }
        return 205;
    }

    private int yys81() {
        switch (yytok) {
            case '*':
                return 57;
            case '/':
                return 60;
            case '<':
            case ';':
            case '-':
            case ',':
            case '+':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr44();
        }
        return 205;
    }

    private int yys82() {
        switch (yytok) {
            case '<':
            case ';':
            case '/':
            case ',':
            case '+':
            case '*':
            case ')':
            case OR:
            case '-':
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr46();
        }
        return 205;
    }

    private int yys83() {
        switch (yytok) {
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
            case ';':
            case ',':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr41();
        }
        return 205;
    }

    private int yys84() {
        switch (yytok) {
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
            case ';':
            case ',':
            case ')':
            case OR:
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr42();
        }
        return 205;
    }

    private int yys86() {
        switch (yytok) {
            case '<':
            case ';':
            case '/':
            case ',':
            case '+':
            case '*':
            case ')':
            case OR:
            case '-':
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr34();
        }
        return 205;
    }

    private int yys87() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ';':
            case END:
            case UNTIL:
            case ENDINPUT:
            case ELSE:
                return yyr26();
        }
        return 205;
    }

    private int yys90() {
        switch (yytok) {
            case BREAK:
                return 15;
            case ID:
                return 17;
            case IF:
                return 18;
            case READ:
                return 19;
            case REPEAT:
                return 20;
            case RETURN:
                return 21;
            case VAR:
                return 22;
            case WRITE:
                return 23;
        }
        return 205;
    }

    private int yys91() {
        switch (yytok) {
            case AND:
                return 54;
            case OR:
                return 55;
            case '*':
                return 57;
            case '+':
                return 58;
            case '-':
                return 59;
            case '/':
                return 60;
            case '<':
                return 61;
            case '=':
                return 62;
            case ',':
            case ')':
                return yyr54();
        }
        return 205;
    }

    private int yys93() {
        switch (yytok) {
            case BREAK:
                return 15;
            case ID:
                return 17;
            case IF:
                return 18;
            case READ:
                return 19;
            case REPEAT:
                return 20;
            case RETURN:
                return 21;
            case VAR:
                return 22;
            case WRITE:
                return 23;
        }
        return 205;
    }

    private int yys94() {
        switch (yytok) {
            case '<':
            case ';':
            case '/':
            case ',':
            case '+':
            case '*':
            case ')':
            case OR:
            case '-':
            case END:
            case UNTIL:
            case ENDINPUT:
            case '=':
            case ']':
            case THEN:
            case ELSE:
            case AND:
                return yyr37();
        }
        return 205;
    }

    private int yyr1() { // tiny : func_seq
        { output = new FuncProgram(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr2() { // tiny : cmd_seq
        { output = new Program(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr27() { // assign_cmd : ID ATTRIB exp
        { yyrv = new AssignCommand((String)((String)yysv[yysp-3]),
                                                                                                                 (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 2;
    }

    private int yyr28() { // assign_cmd : array ATTRIB exp
        { yyrv = new ArrayAssignCommand((ArrayExpression)yysv[yysp-3],
                                                                                                (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 2;
    }

    private int yyr12() { // cmd : if_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr13() { // cmd : repeat_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr14() { // cmd : assign_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr15() { // cmd : read_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr16() { // cmd : write_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr17() { // cmd : var_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr18() { // cmd : funcall_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr19() { // cmd : return_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr20() { // cmd : BREAK
        { yyrv = new BreakCommand(); }
        yysv[yysp-=1] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 24: return 44;
            default: return 3;
        }
    }

    private int yyr10() { // cmd_seq : cmd
        { List<Command> cmds = new ArrayList<Command>();
                                                 cmds.add(((Command)yysv[yysp-1]));
                                                 yyrv = cmds; }
        yysv[yysp-=1] = yyrv;
        return yypcmd_seq();
    }

    private int yyr11() { // cmd_seq : cmd_seq ';' cmd
        { List<Command> cmds = ((List)yysv[yysp-3]);
                                                   cmds.add(((Command)yysv[yysp-1]));
                                                   yyrv = cmds; }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 90: return 97;
            case 56: return 78;
            case 20: return 40;
            case 0: return 4;
            default: return 99;
        }
    }

    private int yyr24() { // else_cmd : ELSE cmd_seq
        { yyrv = ((List)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return 92;
    }

    private int yyr25() { // else_cmd : /* empty */
        { yyrv = null; }
        yysv[yysp-=0] = yyrv;
        return 92;
    }

    private int yyr34() { // exp : '(' exp ')'
        { yyrv = ((Expression)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : NUM
        { yyrv = new NumeralExpression(((Integer)((Integer)yysv[yysp-1])).intValue()); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : ID
        { yyrv = new VarExpression((String)((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : ID '(' exps ')'
        { yyrv = new FuncallExpression(((String)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : array
        yysp -= 1;
        return yypexp();
    }

    private int yyr39() { // exp : NOT exp
        { yyrv = new NotExpression((Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : '-' exp
        { yyrv = new UnmExpression((Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : exp '<' exp
        { yyrv = new LtExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr42() { // exp : exp '=' exp
        { yyrv = new EqExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr43() { // exp : exp '+' exp
        { yyrv = new AddExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr44() { // exp : exp '-' exp
        { yyrv = new SubExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr45() { // exp : exp '*' exp
        { yyrv = new MulExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : exp '/' exp
        { yyrv = new DivExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : exp AND exp
        { yyrv = new AndExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : exp OR exp
        { yyrv = new OrExpression((Expression)((Expression)yysv[yysp-3]),
                                                                           (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 73: return 91;
            case 67: return 87;
            case 62: return 84;
            case 61: return 83;
            case 60: return 82;
            case 59: return 81;
            case 58: return 80;
            case 57: return 79;
            case 55: return 77;
            case 54: return 76;
            case 38: return 66;
            case 37: return 65;
            case 35: return 64;
            case 31: return 53;
            case 29: return 49;
            case 27: return 47;
            case 26: return 46;
            case 23: return 43;
            case 21: return 41;
            case 18: return 32;
            default: return 50;
        }
    }

    private int yyr53() { // exp_list : exp
        { List<Expression> exps = new ArrayList<Expression>();
                                exps.add(((Expression)yysv[yysp-1])); yyrv = exps; }
        yysv[yysp-=1] = yyrv;
        return 51;
    }

    private int yyr54() { // exp_list : exp_list ',' exp
        { (((List)yysv[yysp-3])).add(((Expression)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 51;
    }

    private int yyr51() { // exps : exp_list
        yysp -= 1;
        return yypexps();
    }

    private int yyr52() { // exps : /* empty */
        { yyrv = new ArrayList<Expression>(); }
        yysv[yysp-=0] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 30: return 52;
            default: return 85;
        }
    }

    private int yyr5() { // func : FUNCTION ID '(' params ')' cmd_seq END
        { yyrv = new Function(((String)yysv[yysp-6]), ((List)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        switch (yyst[yysp-1]) {
            case 0: return 5;
            default: return 45;
        }
    }

    private int yyr3() { // func_seq : func
        { List<Function> funcs = new ArrayList<Function>();
                                                  funcs.add(((Function)yysv[yysp-1])); yyrv = funcs; }
        yysv[yysp-=1] = yyrv;
        return 6;
    }

    private int yyr4() { // func_seq : func_seq ';' func
        { (((List)yysv[yysp-3])).add(((Function)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 6;
    }

    private int yyr31() { // funcall_cmd : ID '(' exps ')'
        { yyrv = new FuncallCommand(((String)yysv[yysp-4]), ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return 7;
    }

    private int yyr23() { // if_cmd : IF exp THEN cmd_seq else_cmd END
        { yyrv = new IfCommand(((Expression)yysv[yysp-5]), ((List)yysv[yysp-3]), ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return 8;
    }

    private int yyr8() { // param_list : ID
        { List<String> params = new ArrayList<String>();
                                 params.add(((String)yysv[yysp-1])); yyrv = params; }
        yysv[yysp-=1] = yyrv;
        return 70;
    }

    private int yyr9() { // param_list : param_list ',' ID
        { (((List)yysv[yysp-3])).add(((String)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 70;
    }

    private int yyr6() { // params : param_list
        yysp -= 1;
        return 71;
    }

    private int yyr7() { // params : /* empty */
        { yyrv = new ArrayList<String>(); }
        yysv[yysp-=0] = yyrv;
        return 71;
    }

    private int yyr29() { // read_cmd : READ ID
        { yyrv = new ReadCommand((String)((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 9;
    }

    private int yyr26() { // repeat_cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = new RepeatCommand((List<Command>)((List)yysv[yysp-3]),
                                                                                (Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return 10;
    }

    private int yyr32() { // return_cmd : RETURN exp
        { yyrv = new ReturnCommand(((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 11;
    }

    private int yyr33() { // return_cmd : RETURN
        { yyrv = new ReturnCommand(null); }
        yysv[yysp-=1] = yyrv;
        return 11;
    }

    private int yyr49() { // array : array '[' exp ']'
        { yyrv = new ArrayExpression((Expression)yysv[yysp-4], (Expression)((Expression)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yyparray();
    }

    private int yyr50() { // array : ID '[' exp ']'
        { yyrv = new ArrayExpression(new VarExpression((String)((String)yysv[yysp-4])), (Expression)((Expression)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yyparray();
    }

    private int yyparray() {
        switch (yyst[yysp-1]) {
            case 93: return 12;
            case 90: return 12;
            case 56: return 12;
            case 24: return 12;
            case 20: return 12;
            case 0: return 12;
            default: return 33;
        }
    }

    private int yyr21() { // var_cmd : VAR ID
        { yyrv = new VarCommand((String)((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 13;
    }

    private int yyr22() { // var_cmd : VAR ID '[' NUM ']'
        { yyrv = new ArrayCommand((String)((String)yysv[yysp-4]), (Integer)((Integer)yysv[yysp-2])); }
        yysv[yysp-=5] = yyrv;
        return 13;
    }

    private int yyr30() { // write_cmd : WRITE exp
        { yyrv = new WriteCommand((Expression)((Expression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 14;
    }

    protected String[] yyerrmsgs = {
    };


int tokenType;
Object tokenVal;
Scanner scanner;
Command output;

Parser(Reader input) {
    scanner = new Scanner(input);
    getToken();
}

int getToken() {
    try {
            Token tok = scanner.getToken();
            tokenType = tok.type;
            tokenVal = (tok.type == NUM) ? 
               tok.intVal :
               tok.strVal; 
            return tokenType;
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
}

void yyerror(String msg) {
    throw new RuntimeException(msg);
}

}
