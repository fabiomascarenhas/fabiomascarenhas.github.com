package tiny;

import java.io.*;
import java.lang.reflect.Method;

import org.luaj.vm2.*;
import org.luaj.vm2.lib.jse.*;

public class Driver {
	public static void main(String[] args) throws Exception {
    		String filein = args[0];
        FileReader input = new FileReader(filein);
        Parser parser = new Parser(input);
        parser.parse();
        VarCheck tvc = new VarCheck();
        parser.output.accept(tvc);
        TypeCheck ttc = new TypeCheck();
        parser.output.accept(ttc);
        System.out.println();
        CodeGen cg = new CodeGen(tvc.temp);
        parser.output.codegen(cg);
		String fileout = filein.replace(".tiny", ".asm");
        PrintStream out = new PrintStream(fileout);
        out.print(cg.out.toString());
        out.close();
        Method asm = Class.forName("lasm").getMethod("main", new Class[] { String[].class });
        asm.invoke(null, (Object)(new String[] { fileout }));
        LuaValue _G = JsePlatform.standardGlobals();
        _G.set("div", _G.get("loadstring").call(LuaValue.valueOf("local a, b = ... ; return math.floor(a/b)")));
        _G.set("read", _G.get("loadstring").call(LuaValue.valueOf("return tonumber(io.read('*l'))")));
    		_G.get("dofile").call(LuaValue.valueOf("d.out"));
    }
}
