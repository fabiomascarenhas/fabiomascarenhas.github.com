// Output created by jacc on Wed Nov 23 16:40:23 BRST 2011

package tiny;

interface Tokens {
    int ENDINPUT = 0;
    int AND = 1;
    int ATTRIB = 2;
    int BREAK = 3;
    int ELSE = 4;
    int END = 5;
    int FUNCTION = 6;
    int ID = 7;
    int IF = 8;
    int NOT = 9;
    int NUM = 10;
    int OR = 11;
    int READ = 12;
    int REPEAT = 13;
    int RETURN = 14;
    int STRING = 15;
    int THEN = 16;
    int UNM = 17;
    int UNTIL = 18;
    int VAR = 19;
    int WRITE = 20;
    int error = 21;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
    // '[' (code=91)
    // ']' (code=93)
}
