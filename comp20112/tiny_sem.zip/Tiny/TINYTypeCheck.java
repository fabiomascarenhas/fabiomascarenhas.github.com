
class TINYTypeCheck extends TINYVisitor {
	void visit(TINYIfCommand tif) {
		tif.cond.accept(this);
		if(tif.cond.type!=TINYExpression.BOOL)
			throw new RuntimeException("condi��o do if n�o � exp. booleana");
		for(TINYCommand cmd : tif.cmd_then)
			cmd.accept(this);
		if(tif.cmd_else != null)
			for(TINYCommand cmd : tif.cmd_else)
				cmd.accept(this);
	}
	
	void visit(TINYRepeatCommand tr) {
		for(TINYCommand cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
		if(tr.cond.type!=TINYExpression.BOOL)
			throw new RuntimeException("condi��o do repeat n�o � exp. booleana");
	}
	
	void visit(TINYWriteCommand tw) {
		tw.exp.accept(this);
		if(tw.exp.type!=TINYExpression.INT)
			throw new RuntimeException("express�o do write n�o � num�rica");		
	}
	
	void visit(TINYAssignCommand ta) {
		ta.rval.accept(this);
		if(ta.rval.type!=TINYExpression.INT)
			throw new RuntimeException("lado direito da atrib. n�o � exp. num�rica");		
	}
	
	void visit(TINYNumeralExpression tn) {
		tn.type = TINYExpression.INT;
	}
	
	void visit(TINYVarExpression tv) {
		tv.type = TINYExpression.INT;
	}

	void visit(TINYUnmExpression tu) {
		tu.exp.accept(this);
		if(tu.exp.type != TINYExpression.INT)
			throw new RuntimeException("tipos inv�lidos no menos");
		tu.type = TINYExpression.INT;
	}
	
	void visitRel(TINYBinopExpression tr) {
		tr.left.accept(this);
		tr.right.accept(this);
		if(tr.left.type != TINYExpression.INT
				|| tr.right.type != TINYExpression.INT)
			throw new RuntimeException("tipos inv�lidos na compara��o");
		tr.type = TINYExpression.BOOL;
	}
	
	void visit(TINYLtExpression tr) {
		visitRel(tr);
	}

	void visit(TINYEqExpression tr) {
		visitRel(tr);
	}

	void visitArith(TINYBinopExpression tr) {
		tr.left.accept(this);
		tr.right.accept(this);
		if(tr.left.type != TINYExpression.INT
				|| tr.right.type != TINYExpression.INT)
			throw new RuntimeException("tipos inv�lidos na op. aritm�tica");
		tr.type = TINYExpression.INT;
	}

	void visit(TINYAddExpression tr) {
		visitArith(tr);
	}

	void visit(TINYSubExpression tr) {
		visitArith(tr);
	}

	void visit(TINYMulExpression tr) {
		visitArith(tr);
	}
	
	void visit(TINYDivExpression tr) {
		visitArith(tr);
	}

}