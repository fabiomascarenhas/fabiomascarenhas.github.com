import java.util.List;

abstract class TINYVisitor {
	void visit(TINYProgram tp) {
		for(TINYCommand cmd : tp.body)
			cmd.accept(this);
	}
	
	void visit(TINYVarCommand tvc) {
	}
	
	void visit(TINYIfCommand tif) {
		tif.cond.accept(this);
		for(TINYCommand cmd : tif.cmd_then)
			cmd.accept(this);
		if(tif.cmd_else != null) 
			for(TINYCommand cmd : tif.cmd_else)
				cmd.accept(this);
	}
	
	void visit(TINYRepeatCommand tr) {
		for(TINYCommand cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
	}
	
	void visit(TINYAssignCommand ta) {
		ta.rval.accept(this);
	}
	
	void visit(TINYReadCommand tr) {
	}
	
	void visit(TINYWriteCommand tw) {
		tw.exp.accept(this);
	}
	
	void visit(TINYNumeralExpression tn) {
	}

	void visit(TINYVarExpression tn) {
	}
	
	void visit(TINYUnmExpression tu) {
		tu.exp.accept(this);
	}
	
	void visit(TINYLtExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(TINYEqExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(TINYAddExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(TINYSubExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}
	
	void visit(TINYMulExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}

	void visit(TINYDivExpression tb) {
		tb.left.accept(this);
		tb.right.accept(this);
	}
}

abstract class TINYNode {
	abstract void accept(TINYVisitor v);
}

abstract class TINYCommand extends TINYNode {
}

abstract class TINYExpression extends TINYNode {
	public int type;
	
	public static int INT = 1;
	public static int BOOL = 2;
}

class TINYProgram extends TINYCommand {
	public List<TINYCommand> body;
	public SymbolTable st_body;
	
	TINYProgram(List<TINYCommand> body) {
		this.body = body;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYVarCommand extends TINYCommand {
	String name;
	
	TINYVarCommand(String name) {
		this.name = name;
	}
	
	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYIfCommand extends TINYCommand {
	public TINYExpression cond;
	public List<TINYCommand> cmd_then;
	public List<TINYCommand> cmd_else;
	public SymbolTable st_then;
	public SymbolTable st_else;
	
	TINYIfCommand(TINYExpression cond, List<TINYCommand> cmd_then, List<TINYCommand> cmd_else) {
		this.cond = cond;
		this.cmd_then = cmd_then;
		this.cmd_else = cmd_else;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYRepeatCommand extends TINYCommand {
	public TINYExpression cond;
	public List<TINYCommand> cmd_body;
	public SymbolTable st_body;
	
	TINYRepeatCommand(List<TINYCommand> cmd_body, TINYExpression cond) {
		this.cond = cond;
		this.cmd_body = cmd_body;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYAssignCommand extends TINYCommand {
	public String lval;
	public TINYExpression rval;
	
	TINYAssignCommand(String lval, TINYExpression rval) {
		this.lval = lval;
		this.rval = rval;
	}
	
	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYReadCommand extends TINYCommand {
	public String var;
	
	TINYReadCommand(String var) {
		this.var = var;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYWriteCommand extends TINYCommand {
	public TINYExpression exp;
	
	TINYWriteCommand(TINYExpression exp) {
		this.exp = exp;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYNumeralExpression extends TINYExpression {
	public int val;
	
	TINYNumeralExpression(int val) {
		this.val = val;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYVarExpression extends TINYExpression {
	public String name;
	
	TINYVarExpression(String name) {
		this.name = name;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYUnmExpression extends TINYExpression {
	public TINYExpression exp;
	
	TINYUnmExpression(TINYExpression exp) {
		this.exp = exp;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

abstract class TINYBinopExpression extends TINYExpression {
	public TINYExpression left;
	public TINYExpression right;
}

class TINYLtExpression extends TINYBinopExpression {
	TINYLtExpression(TINYExpression left, TINYExpression right) {
		this.left = left;
		this.right = right;
	}
	
	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYEqExpression extends TINYBinopExpression {
	TINYEqExpression(TINYExpression left, TINYExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYAddExpression extends TINYBinopExpression {
	TINYAddExpression(TINYExpression left, TINYExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYSubExpression extends TINYBinopExpression {
	TINYSubExpression(TINYExpression left, TINYExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYMulExpression extends TINYBinopExpression {
	TINYMulExpression(TINYExpression left, TINYExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}

class TINYDivExpression extends TINYBinopExpression {
	TINYDivExpression(TINYExpression left, TINYExpression right) {
		this.left = left;
		this.right = right;
	}

	void accept(TINYVisitor tv) {
		tv.visit(this);
	}
}
