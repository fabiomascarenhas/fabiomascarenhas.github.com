
class TINYVarCheck extends TINYVisitor {
	SymbolTable st; // n�vel atual!
		
	TINYVarCheck() {	}
	
	void visit(TINYProgram tp) {
		tp.st_body = st = new SymbolTable(null);
		for(TINYCommand cmd : tp.body)
			cmd.accept(this);
	}
	
	void visit(TINYIfCommand tif) {
		tif.cond.accept(this);
		tif.st_then = st = new SymbolTable(st);
		for(TINYCommand cmd : tif.cmd_then)
			cmd.accept(this);
		st = st.parent;
		if(tif.cmd_else != null) {
			tif.st_else = st = new SymbolTable(st);
			for(TINYCommand cmd : tif.cmd_else)
				cmd.accept(this);
			st = st.parent;
		}
	}
	
	void visit(TINYRepeatCommand tr) {
		tr.st_body = st = new SymbolTable(st);
		for(TINYCommand cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
		st = st.parent;
	}
	
	void visit(TINYAssignCommand ta) {
		if(st.get(ta.lval) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
		ta.rval.accept(this);
	}
	
	void visit(TINYReadCommand tr) {
		if(st.get(tr.var) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
	}
	
	void visit(TINYVarExpression tv) {
		if(st.get(tv.name) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
	}
	
	void visit(TINYVarCommand tvc) {
		st.put(tvc.name);
	}
}
