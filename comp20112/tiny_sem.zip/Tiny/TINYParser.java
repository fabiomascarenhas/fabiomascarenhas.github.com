// Output created by jacc on Mon Oct 24 16:50:41 BRST 2011


import java.io.Reader;
import java.util.*;

class TINYParser implements TINYTokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tokenType
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 52:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 53:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 104;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 54:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 55:
                    switch (yytok) {
                        case ';':
                            yyn = 16;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 56:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 57:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 58:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 59:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 60:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 61:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 62:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 17;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 63:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 64:
                    switch (yytok) {
                        case ID:
                            yyn = 23;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 65:
                    yyn = yys13();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 66:
                    switch (yytok) {
                        case ID:
                            yyn = 25;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 67:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 68:
                    yyn = yys16();
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 69:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 70:
                    yyn = yys18();
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 71:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 72:
                    yyn = yys20();
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 73:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 74:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 75:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr16();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 76:
                    switch (yytok) {
                        case ';':
                            yyn = 16;
                            continue;
                        case UNTIL:
                            yyn = 38;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 77:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 78:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 79:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 80:
                    yyn = yys28();
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 81:
                    yyn = yys29();
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 82:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 83:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 84:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 85:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 86:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 87:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 88:
                    yyn = yys36();
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 89:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 90:
                    switch (yytok) {
                        case ID:
                            yyn = 19;
                            continue;
                        case NUM:
                            yyn = 20;
                            continue;
                        case '(':
                            yyn = 21;
                            continue;
                        case '-':
                            yyn = 22;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 91:
                    switch (yytok) {
                        case ';':
                            yyn = 16;
                            continue;
                        case ELSE:
                            yyn = 49;
                            continue;
                        case END:
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 92:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 93:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 94:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 95:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 96:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 97:
                    yyn = yys45();
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    yyn = yys46();
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 100:
                    switch (yytok) {
                        case END:
                            yyn = 50;
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    yyn = yys49();
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    yysv[yysp] = (tokenVal
                                 );
                    yytok = (getToken()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    switch (yytok) {
                        case ENDINPUT:
                        case UNTIL:
                        case END:
                        case ';':
                        case ELSE:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    switch (yytok) {
                        case ';':
                            yyn = 16;
                            continue;
                        case END:
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 107;
                    continue;

                case 104:
                    return true;
                case 105:
                    yyerror("stack overflow");
                case 106:
                    return false;
                case 107:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case ID:
                return 10;
            case IF:
                return 11;
            case READ:
                return 12;
            case REPEAT:
                return 13;
            case VAR:
                return 14;
            case WRITE:
                return 15;
        }
        return 107;
    }

    private int yys13() {
        switch (yytok) {
            case ID:
                return 10;
            case IF:
                return 11;
            case READ:
                return 12;
            case REPEAT:
                return 13;
            case VAR:
                return 14;
            case WRITE:
                return 15;
        }
        return 107;
    }

    private int yys16() {
        switch (yytok) {
            case ID:
                return 10;
            case IF:
                return 11;
            case READ:
                return 12;
            case REPEAT:
                return 13;
            case VAR:
                return 14;
            case WRITE:
                return 15;
        }
        return 107;
    }

    private int yys18() {
        switch (yytok) {
            case THEN:
                return 29;
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '<':
                return 34;
            case '=':
                return 35;
        }
        return 107;
    }

    private int yys19() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case UNM:
            case STRING:
            case error:
            case READ:
            case ID:
            case NUM:
            case IF:
            case ATTRIB:
            case '(':
            case VAR:
                return 107;
        }
        return yyr20();
    }

    private int yys20() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case UNM:
            case STRING:
            case error:
            case READ:
            case ID:
            case NUM:
            case IF:
            case ATTRIB:
            case '(':
            case VAR:
                return 107;
        }
        return yyr19();
    }

    private int yys26() {
        switch (yytok) {
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '<':
                return 34;
            case '=':
                return 35;
            case ENDINPUT:
            case UNTIL:
            case END:
            case ';':
            case ELSE:
                return yyr17();
        }
        return 107;
    }

    private int yys28() {
        switch (yytok) {
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '<':
                return 34;
            case '=':
                return 35;
            case ENDINPUT:
            case UNTIL:
            case END:
            case ';':
            case ELSE:
                return yyr15();
        }
        return 107;
    }

    private int yys29() {
        switch (yytok) {
            case ID:
                return 10;
            case IF:
                return 11;
            case READ:
                return 12;
            case REPEAT:
                return 13;
            case VAR:
                return 14;
            case WRITE:
                return 15;
        }
        return 107;
    }

    private int yys36() {
        switch (yytok) {
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '<':
                return 34;
            case '=':
                return 35;
            case ')':
                return 46;
        }
        return 107;
    }

    private int yys37() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case UNM:
            case STRING:
            case error:
            case READ:
            case ID:
            case NUM:
            case IF:
            case ATTRIB:
            case '(':
            case VAR:
                return 107;
        }
        return yyr21();
    }

    private int yys40() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case UNM:
            case STRING:
            case error:
            case READ:
            case ID:
            case NUM:
            case IF:
            case ATTRIB:
            case '(':
            case VAR:
                return 107;
        }
        return yyr26();
    }

    private int yys41() {
        switch (yytok) {
            case '*':
                return 30;
            case '/':
                return 33;
            case '=':
            case UNTIL:
            case END:
            case ';':
            case '-':
            case THEN:
            case '+':
            case '<':
            case ')':
            case ENDINPUT:
            case ELSE:
                return yyr24();
        }
        return 107;
    }

    private int yys42() {
        switch (yytok) {
            case '*':
                return 30;
            case '/':
                return 33;
            case '=':
            case UNTIL:
            case END:
            case ';':
            case '-':
            case THEN:
            case '+':
            case '<':
            case ')':
            case ENDINPUT:
            case ELSE:
                return yyr25();
        }
        return 107;
    }

    private int yys43() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case UNM:
            case STRING:
            case error:
            case READ:
            case ID:
            case NUM:
            case IF:
            case ATTRIB:
            case '(':
            case VAR:
                return 107;
        }
        return yyr27();
    }

    private int yys44() {
        switch (yytok) {
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '=':
            case UNTIL:
            case END:
            case '<':
            case ';':
            case THEN:
            case ')':
            case ENDINPUT:
            case ELSE:
                return yyr22();
        }
        return 107;
    }

    private int yys45() {
        switch (yytok) {
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '=':
            case UNTIL:
            case END:
            case '<':
            case ';':
            case THEN:
            case ')':
            case ENDINPUT:
            case ELSE:
                return yyr23();
        }
        return 107;
    }

    private int yys46() {
        switch (yytok) {
            case REPEAT:
            case WRITE:
            case UNM:
            case STRING:
            case error:
            case READ:
            case ID:
            case NUM:
            case IF:
            case ATTRIB:
            case '(':
            case VAR:
                return 107;
        }
        return yyr18();
    }

    private int yys47() {
        switch (yytok) {
            case '*':
                return 30;
            case '+':
                return 31;
            case '-':
                return 32;
            case '/':
                return 33;
            case '<':
                return 34;
            case '=':
                return 35;
            case ENDINPUT:
            case UNTIL:
            case END:
            case ';':
            case ELSE:
                return yyr14();
        }
        return 107;
    }

    private int yys49() {
        switch (yytok) {
            case ID:
                return 10;
            case IF:
                return 11;
            case READ:
                return 12;
            case REPEAT:
                return 13;
            case VAR:
                return 14;
            case WRITE:
                return 15;
        }
        return 107;
    }

    private int yyr1() { // tiny : cmd_seq
        { output = new TINYProgram(((List)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr4() { // cmd : if_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr5() { // cmd : repeat_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr6() { // cmd : assign_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr7() { // cmd : read_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr8() { // cmd : write_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yyr9() { // cmd : var_cmd
        yysp -= 1;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 16: return 27;
            default: return 2;
        }
    }

    private int yyr2() { // cmd_seq : cmd
        { List<TINYCommand> cmds = new ArrayList<TINYCommand>();
                                                 cmds.add(((TINYCommand)yysv[yysp-1]));
                                                 yyrv = cmds; }
        yysv[yysp-=1] = yyrv;
        return yypcmd_seq();
    }

    private int yyr3() { // cmd_seq : cmd_seq ';' cmd
        { List<TINYCommand> cmds = ((List)yysv[yysp-3]);
                                                   cmds.add(((TINYCommand)yysv[yysp-1]));
                                                   yyrv = cmds; }
        yysv[yysp-=3] = yyrv;
        return yypcmd_seq();
    }

    private int yypcmd_seq() {
        switch (yyst[yysp-1]) {
            case 29: return 39;
            case 13: return 24;
            case 0: return 3;
            default: return 51;
        }
    }

    private int yyr12() { // else_cmd : ELSE cmd_seq
        { yyrv = ((List)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return 48;
    }

    private int yyr13() { // else_cmd : /* empty */
        { yyrv = null; }
        yysv[yysp-=0] = yyrv;
        return 48;
    }

    private int yyr18() { // exp : '(' exp ')'
        { yyrv = ((TINYExpression)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr19() { // exp : NUM
        { yyrv = new TINYNumeralExpression(((Integer)((Integer)yysv[yysp-1])).intValue()); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr20() { // exp : ID
        { yyrv = new TINYVarExpression((String)((String)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr21() { // exp : '-' exp
        { yyrv = new TINYUnmExpression((TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr22() { // exp : exp '<' exp
        { yyrv = new TINYLtExpression((TINYExpression)((TINYExpression)yysv[yysp-3]),
                                                                           (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr23() { // exp : exp '=' exp
        { yyrv = new TINYEqExpression((TINYExpression)((TINYExpression)yysv[yysp-3]),
                                                                           (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr24() { // exp : exp '+' exp
        { yyrv = new TINYAddExpression((TINYExpression)((TINYExpression)yysv[yysp-3]),
                                                                           (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr25() { // exp : exp '-' exp
        { yyrv = new TINYSubExpression((TINYExpression)((TINYExpression)yysv[yysp-3]),
                                                                           (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr26() { // exp : exp '*' exp
        { yyrv = new TINYMulExpression((TINYExpression)((TINYExpression)yysv[yysp-3]),
                                                                           (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr27() { // exp : exp '/' exp
        { yyrv = new TINYDivExpression((TINYExpression)((TINYExpression)yysv[yysp-3]),
                                                                           (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 35: return 45;
            case 34: return 44;
            case 33: return 43;
            case 32: return 42;
            case 31: return 41;
            case 30: return 40;
            case 22: return 37;
            case 21: return 36;
            case 17: return 28;
            case 15: return 26;
            case 11: return 18;
            default: return 47;
        }
    }

    private int yyr11() { // if_cmd : IF exp THEN cmd_seq else_cmd END
        { yyrv = new TINYIfCommand(((TINYExpression)yysv[yysp-5]), ((List)yysv[yysp-3]), ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return 4;
    }

    private int yyr16() { // read_cmd : READ ID
        { yyrv = new TINYReadCommand((String)((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 5;
    }

    private int yyr14() { // repeat_cmd : REPEAT cmd_seq UNTIL exp
        { yyrv = new TINYRepeatCommand((List<TINYCommand>)((List)yysv[yysp-3]),
                                                                                (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return 6;
    }

    private int yyr15() { // assign_cmd : ID ATTRIB exp
        { yyrv = new TINYAssignCommand((String)((String)yysv[yysp-3]),
                                                                                                                 (TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 7;
    }

    private int yyr10() { // var_cmd : VAR ID
        { yyrv = new TINYVarCommand((String)((String)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 8;
    }

    private int yyr17() { // write_cmd : WRITE exp
        { yyrv = new TINYWriteCommand((TINYExpression)((TINYExpression)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return 9;
    }

    protected String[] yyerrmsgs = {
    };


int tokenType;
Object tokenVal;
TINYScanner scanner;
TINYProgram output;

TINYParser(Reader input) {
    scanner = new TINYScanner(input);
    getToken();
}

int getToken() {
    try {
            TINYToken tok = scanner.getToken();
            tokenType = tok.type;
            tokenVal = (tok.type == NUM) ? 
               tok.intVal :
               tok.strVal; 
            return tokenType;
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
}

void yyerror(String msg) {
    throw new RuntimeException(msg);
}

}
