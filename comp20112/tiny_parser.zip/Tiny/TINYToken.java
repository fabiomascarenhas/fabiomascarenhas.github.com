class TINYToken {
	static final int EOF = 0;
    static final int IF = 1;
    static final int THEN = 2;
    static final int ELSE = 3;
    static final int END = 4;
    static final int REPEAT = 5;
    static final int UNTIL = 6;
    static final int READ = 7;
    static final int WRITE = 8;
    static final int ATTRIB = 9;
    static final int NUM = 10;
    static final int ID = 11;
    static final int STRING = 12;

    static String[] names = new String[]{"EOF", "IF", "THEN",
            "ELSE", "END", "REPEAT", "UNTIL", "READ", "WRITE", "ATTRIB",
            "NUM", "ID", "STRING"
    };

    public int type;
    public int intVal;
    public String strVal;

    public TINYToken(int type) {
        this.type = type;
    }

    public TINYToken(int type, int intVal) {
        this.type = type;
        this.intVal = intVal;
    }

    public TINYToken(int type, String strVal) {
        this.type = type;
        this.strVal = strVal;
    }
    
    public boolean is(int type) {
    		return this.type == type;
    }

    public String toString() {
        if (this.type < 10) {
            return TINYToken.names[this.type];
        } else if (this.type == 10) {
            return "NUM: " + this.intVal;
        } else if (this.type == 11) {
            return "ID: " + this.strVal;
        } else if (this.type == 12) {
            return "STRING: " + this.strVal;
        } else {
            return Character.toString((char) this.type);
        }
    }
}
