import java.io.*;

/*

tiny       ::= cmd-seq
cmd-seq    ::= cmd {';' cmd}
cmd        ::= if-cmd | repeat-cmd | assign-cmd | read-cmd | write-cmd
if-cmd     ::= IF exp THEN cmd-seq [ELSE cmd-seq] END
repeat-cmd ::= REPEAT cmd-seq UNTIL exp
assign-cmd ::= ID ':=' exp
read-cmd   ::= READ ID
write-cmd  ::= WRITE exp
exp        ::= simple-exp [rel-op simple-exp]
rel-op     ::= '<' | '='
simple-exp ::= term {add-op term}
add-op     ::= '+' | '-'
term       ::= factor {mul-op factor}
mul-op     ::= '*' | '/'
factor     ::= '(' exp ')' | NUMBER | ID

*/

public class TINYParser {
	TINYScanner scan;
	PrintStream out;
	TINYToken token;   // lookahead
	
	public TINYParser(Reader input, PrintStream output) throws Exception {
		scan = new TINYScanner(input);
		out = output;
		token = scan.getToken();
	}

	void match(int type) throws Exception {
		if(token.is(type)) {
			token = scan.getToken();
		} else throw new
			Exception("token inv�lido: " + token + 
					", esperado " + (new TINYToken(type)).toString());
	}
	
	// tiny ::= cmd-seq
	void tiny() throws Exception {
		cmdSeq();
		if(!token.is(TINYToken.EOF)) {
			throw new 
				Exception("final de arquivo esperado, mas " + token + " lido");
		}
	}
	
	// cmd-seq ::= cmd {';' cmd}
	void cmdSeq() throws Exception {
		cmd();
		while(token.is(';')) {
			match(';');
			out.print('\n');
			cmd();
		}
		out.print('\n');
	}

	// cmd ::= if-cmd | repeat-cmd | assign-cmd | read-cmd
	//         | write-cmd
	void cmd() throws Exception {
		switch(token.type) {
		case TINYToken.IF:     ifCmd(); break;
		case TINYToken.REPEAT: repeatCmd(); break;
		case TINYToken.ID:     assignCmd(); break;
		case TINYToken.READ:   readCmd(); break;
		case TINYToken.WRITE:  writeCmd(); break;
		default:
			throw new Exception("comando inv�lido, token " + token);
		}
	}
	
	// if-cmd ::= IF exp THEN cmd-seq [ELSE cmd-seq] END
	void ifCmd() throws Exception {
		match(TINYToken.IF);
		out.print("if ");
		exp();
		match(TINYToken.THEN);
		out.print(" then \n");
		cmdSeq();
		if(token.is(TINYToken.ELSE)) {
			match(TINYToken.ELSE);
			out.print("else\n");
			cmdSeq();
		}
		match(TINYToken.END);
		out.print("end");
	}
	
	// repeat-cmd ::= REPEAT cmd-seq UNTIL exp
	void repeatCmd() throws Exception {
		match(TINYToken.REPEAT);
		out.print("repeat\n");
		cmdSeq();
		match(TINYToken.UNTIL);
		out.print("until ");
		exp();
	}
	
	// assign-cmd ::= ID ':=' exp
	void assignCmd() throws Exception {
		out.print(token.strVal);
		match(TINYToken.ID);
		match(TINYToken.ATTRIB);
		out.print(" = ");
		exp();
	}
	
	// read-cmd ::= READ ID
	void readCmd() throws Exception {
		match(TINYToken.READ);
		if(token.is(TINYToken.ID)) {
			out.print(token.strVal + " = " + "tonumber(io.read('*l'))");
		} else
			throw new Exception("par�metro de read n�o � identificador, � " + token);
		match(TINYToken.ID);
	}
	
	// write-cmd ::= WRITE exp
	void writeCmd() throws Exception {
		match(TINYToken.WRITE);
		out.print("print(");
		exp();
		out.print(")");
	}
	
	// exp    ::= simple-exp [rel-op simple-exp]
	// rel-op ::= '<' | '='
	void exp() throws Exception {
		simpleExp();
		if(token.is('=')) {
			out.print(" == ");
			match('=');
			simpleExp();
		} else if(token.is('<')) {
			out.print(" < ");
			match('<');
			simpleExp();
		}
	}
	
	// simple-exp ::= term {add-op term}
	// add-op     ::= '+' | '-'
	void simpleExp() throws Exception {
		term();
		while(token.is('+') || token.is('-')) {
			out.print(" " + (char)token.type + " ");
			token = scan.getToken();
			term();
		}
	}
	
	// term   ::= factor {mul-op factor}
	// mul-op ::= '*' | '/'
	void term() throws Exception {
		factor();
		while(token.is('*') || token.is('/')) {
			out.print(" " + (char)token.type + " ");
			token = scan.getToken();
			factor();
		}
	}
	
	// factor     ::= '(' exp ')' | NUMBER | ID
	void factor() throws Exception {
		switch(token.type) {
		case '(': {
			match('(');
			out.print("(");
			exp();
			match(')');
			out.print(")");
			break;
		}
		case TINYToken.NUM: {
			out.print(token.intVal);
			match(TINYToken.NUM);
			break;
		}
		case TINYToken.ID: {
			out.print(token.strVal);
			match(TINYToken.ID);
			break;
		}
		default:
			throw new Exception("operando inv�lido em express�o, token " + token);
		}
	}
	
}
