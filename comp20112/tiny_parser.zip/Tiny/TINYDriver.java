import java.io.*;
import org.luaj.vm2.*;
import org.luaj.vm2.lib.jse.*;

public class TINYDriver {
    public static void main(String[] args) throws Exception {
    		String filein = args[0];
    		String fileout = filein.replace(".tiny", ".lua");
        FileReader input = new FileReader(filein);
        PrintStream out = new PrintStream(fileout);
        TINYParser parser = new TINYParser(input, out);
        parser.tiny();
        LuaValue _G = JsePlatform.standardGlobals();
    		_G.get("dofile").call(LuaValue.valueOf(fileout));        
    }
}
