// Output created by jacc on Mon Nov 07 14:42:25 BRST 2011

package tiny;

interface Tokens {
    int ENDINPUT = 0;
    int AND = 1;
    int ATTRIB = 2;
    int ELSE = 3;
    int END = 4;
    int ID = 5;
    int IF = 6;
    int NOT = 7;
    int NUM = 8;
    int OR = 9;
    int READ = 10;
    int REPEAT = 11;
    int STRING = 12;
    int THEN = 13;
    int UNM = 14;
    int UNTIL = 15;
    int VAR = 16;
    int WRITE = 17;
    int error = 18;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // '-' (code=45)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
