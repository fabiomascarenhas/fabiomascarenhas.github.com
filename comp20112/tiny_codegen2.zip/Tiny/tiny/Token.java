package tiny;


class Token implements Tokens {
	static final int EOF = 0;
	
    static String[] names = new String[]{"EOF", "IF", "THEN",
            "ELSE", "END", "REPEAT", "UNTIL", "READ", "WRITE", "ATTRIB",
            "NUM", "ID", "STRING"
    };

    public int type;
    public int intVal;
    public String strVal;

    public Token(int type) {
        this.type = type;
    }

    public Token(int type, int intVal) {
        this.type = type;
        this.intVal = intVal;
    }

    public Token(int type, String strVal) {
        this.type = type;
        this.strVal = strVal;
    }
    
    public boolean is(int type) {
    		return this.type == type;
    }

    public String toString() {
        if (this.type < 10) {
            return Token.names[this.type];
        } else if (this.type == 10) {
            return "NUM: " + this.intVal;
        } else if (this.type == 11) {
            return "ID: " + this.strVal;
        } else if (this.type == 12) {
            return "STRING: " + this.strVal;
        } else {
            return Character.toString((char) this.type);
        }
    }
}
