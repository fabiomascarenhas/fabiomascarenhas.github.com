package tiny;


class VarCheck extends Visitor {
	SymbolTable st; // n�vel atual!
	int temp;	

	VarCheck() {	
		temp = 0;
	}
	
	void visit(Program tp) {
		tp.st_body = st = new SymbolTable(null);
		for(Command cmd : tp.body)
			cmd.accept(this);
		temp = Math.max(temp, st.free);
	}
	
	void visit(IfCommand tif) {
		tif.cond.accept(this);
		tif.st_then = st = new SymbolTable(st);
		for(Command cmd : tif.cmd_then)
			cmd.accept(this);
		temp = Math.max(temp, st.free);
		st = st.parent;
		if(tif.cmd_else != null) {
			tif.st_else = st = new SymbolTable(st);
			for(Command cmd : tif.cmd_else)
				cmd.accept(this);
			temp = Math.max(temp, st.free);
			st = st.parent;
		}
	}
	
	void visit(RepeatCommand tr) {
		tr.st_body = st = new SymbolTable(st);
		for(Command cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
		temp = Math.max(temp, st.free);
		st = st.parent;
	}
	
	void visit(AssignCommand ta) {
		if(st.get(ta.lval) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
		ta.rval.accept(this);
	}
	
	void visit(ReadCommand tr) {
		if(st.get(tr.var) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
	}
	
	void visit(VarExpression tv) {
		if(st.get(tv.name) == null)
			throw new RuntimeException("vari�vel n�o definida neste ponto");
	}
	
	void visit(VarCommand tvc) {
		st.put(tvc.name);
	}
}
