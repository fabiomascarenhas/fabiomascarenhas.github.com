package tiny;

import java.util.HashMap;

class SymbolTable {
	SymbolTable parent;
	HashMap<String, Integer> vars;
	int free;
	
	SymbolTable(SymbolTable parent) {
		this.parent = parent;
		free = (parent == null ? 0 : parent.free);
		vars = new HashMap<String, Integer>();
	}
	
	void put(String name) {
		if(!vars.containsKey(name)) {
			vars.put(name, free++);
		} else
			throw new RuntimeException("vari�vel " + name + " redeclarada no mesmo escopo");
	}
	
	Integer get(String name) {
		Integer pos = vars.get(name);
		if(pos == null && parent != null)
			return parent.get(name);
		else
			return pos;
	}
}