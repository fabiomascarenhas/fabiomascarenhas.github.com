package tiny;

class TypeCheck extends Visitor {
	void visit(IfCommand tif) {
		tif.cond.accept(this);
		if(tif.cond.type!=Expression.BOOL)
			throw new RuntimeException("condi��o do if n�o � exp. booleana");
		for(Command cmd : tif.cmd_then)
			cmd.accept(this);
		if(tif.cmd_else != null)
			for(Command cmd : tif.cmd_else)
				cmd.accept(this);
	}
	
	void visit(RepeatCommand tr) {
		for(Command cmd : tr.cmd_body)
			cmd.accept(this);
		tr.cond.accept(this);
		if(tr.cond.type!=Expression.BOOL)
			throw new RuntimeException("condi��o do repeat n�o � exp. booleana");
	}
	
	void visit(WriteCommand tw) {
		tw.exp.accept(this);
		if(tw.exp.type!=Expression.INT)
			throw new RuntimeException("express�o do write n�o � num�rica");		
	}
	
	void visit(AssignCommand ta) {
		ta.rval.accept(this);
		if(ta.rval.type!=Expression.INT)
			throw new RuntimeException("lado direito da atrib. n�o � exp. num�rica");		
	}
	
	void visit(NumeralExpression tn) {
		tn.type = Expression.INT;
	}
	
	void visit(VarExpression tv) {
		tv.type = Expression.INT;
	}

	void visit(UnmExpression tu) {
		tu.exp.accept(this);
		if(tu.exp.type != Expression.INT)
			throw new RuntimeException("tipos inv�lidos no menos");
		tu.type = Expression.INT;
	}
	
	void visitRel(BinopExpression tr) {
		tr.left.accept(this);
		tr.right.accept(this);
		if(tr.left.type != Expression.INT
				|| tr.right.type != Expression.INT)
			throw new RuntimeException("tipos inv�lidos na compara��o");
		tr.type = Expression.BOOL;
	}
	
	void visit(LtExpression tr) {
		visitRel(tr);
	}

	void visit(EqExpression tr) {
		visitRel(tr);
	}

	void visitArith(BinopExpression tr) {
		tr.left.accept(this);
		tr.right.accept(this);
		if(tr.left.type != Expression.INT
				|| tr.right.type != Expression.INT)
			throw new RuntimeException("tipos inv�lidos na op. aritm�tica");
		tr.type = Expression.INT;
	}

	void visit(AddExpression tr) {
		visitArith(tr);
	}

	void visit(SubExpression tr) {
		visitArith(tr);
	}

	void visit(MulExpression tr) {
		visitArith(tr);
	}
	
	void visit(DivExpression tr) {
		visitArith(tr);
	}

}