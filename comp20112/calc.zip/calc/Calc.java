public class Calc {

    // Analisador léxico

    static final char integer = '0';
    static int token;                       // Tipo token
    static int tokval;                      // Valor token
    static int c;                           // Próx. caractere

    static void initInput() {
        c = getChar();
        getToken();
    }

    static int getChar() {
        int c = 0;
        try {
            c = System.in.read();
        } catch (Exception e) {
            calcError("Error in input stream");
        }
        return c;
    }

    static void getToken() {
        while (Character.isWhitespace((char)c)) { // Ignore espaços
            c = getChar();
        }

        if (c<0) {                                // EOF
            token = 0;
            return;
        }

        switch (c) {                              // Tokens especiais
            case '+' :
            case '-' :
            case '*' :
            case '/' :
            case ';' :
            case '(' :
            case ')' : token = c;
                       c     = getChar();
                       return;
            default  : if (Character.isDigit((char)c)) { // Numerais
                           int n = 0;
                           do {
                               n = 10*n + (c - '0');
                               c = getChar();
                           } while (Character.isDigit((char)c));
                           tokval = n;
                           token  = integer;
                           return;
                       }
        }
        calcError("Illegal character "+c);  // Erro léxico
    }

    // Analisador sintático

    static Expr expr() {                    // Expr = Term [('+' | '-') Term]*
        Expr e = term();                    
                                            
        for (;;) {
            if (token=='+') {
                getToken();
                e = new BinExpr('+',e,term());
            } else if (token=='-') {
                getToken();
                e = new BinExpr('-',e,term());
            } else {
                return e;
            }
        }
    }

    static Expr term() {                    // Term = Atom [('*' | '/') Atom]*
        Expr t = atom();                    
                                            
        for (;;) {
            if (token=='*') {
                getToken();
                t = new BinExpr('*',t,atom());
            } else if (token=='/') {
                getToken();
                t = new BinExpr('/',t,atom());
            } else {
                return t;
            }
        }
    }

    static Expr atom() {                    // Atom = integer
        if (token==integer) {               //      | '(' Expr ')
            int f = tokval;
            getToken();
            return new IntExpr(f);
        } else if (token=='(') {
            getToken();
            Expr e = expr();
            if (token==')') {
                getToken();
            } else {
                calcError("missing close paren");
            }
            return e;
        } else {
            calcError("syntax error");
        }
        return null;
    }


    // Tratamento de erros

    static void calcError(String msg) {
        System.out.println("ERROR: " + msg + "; TOKEN: " + token);
        System.exit(1);
    }


    // Árvore sintática

    abstract static class Expr {
        abstract void compile(int reg);
        abstract int eval();
    }

    static class IntExpr extends Expr {
        private int value;
        IntExpr(int value) {
            this.value = value;
        }

        void compile(int reg) { // mov reg, value
            emit("LOADK R[" + reg + "] " + value);
        }

        int eval() {
            return value;
        }
    }

    static class BinExpr extends Expr {
        private char op;
        private Expr left;
        private Expr right;

        BinExpr(char op, Expr left, Expr right) {
            this.op    = op;
            this.left  = left;
            this.right = right;
        }

        void compile(int reg) {
            left.compile(reg);       // reg = resultado de left
            right.compile(reg + 1);  // reg+1 = resultado de right
            switch (op) {            // op reg, reg, reg+1
                case '+' : emit("ADD R[" + reg + "] R[" + reg + "] R[" + (reg + 1) + "]");
                           break;
                case '-' : emit("SUB R[" + reg + "] R[" + reg + "] R[" + (reg + 1) + "]");
                           break;
                case '*' : emit("MUL R[" + reg + "] R[" + reg + "] R[" + (reg + 1) + "]");
                           break;
                case '/' : emit("DIV R[" + reg + "] R[" + reg + "] R[" + (reg + 1) + "]");
                           break;
            }
        }

        int eval() {
            int l = left.eval();
            int r = right.eval();
            switch (op) {
                case '+' : return l + r;
                case '-' : return l - r;
                case '*' : return l * r;
                case '/' : return l / r;
            }
            return 0;
        }
    }

    static void emit(String instr) {
        System.out.println("   " + instr);
    }

    // Driver --------------------------------------------------------------

    public static void main(String[] args) {
        initInput();
        System.out.println("main function:");
        while(token != 0) {
            Expr e = expr();
            System.out.println("   ; Result = " + e.eval());
            System.out.println("   GETGLOBAL R[0] \"print\"");
            e.compile(1);
            System.out.println("   CALL R[0] 2 1");
            if (token==';') {
                getToken();
            } else if (token!=0) {
                calcError("syntax error");
            }
        }
        System.out.println("   RETURN R[0] 1");
    }
}
