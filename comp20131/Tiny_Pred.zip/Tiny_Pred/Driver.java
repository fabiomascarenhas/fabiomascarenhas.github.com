import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Driver {
	public static void main(String[] args) throws IOException {
		File f = new File(args[0]);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		Tree prog = parser.parse();
		String fname = f.getName();
		prog.printDot(fname.substring(0, fname.lastIndexOf('.')) + ".gv");
	}

	public static void ll1parse(String name) throws IOException {
		File f = new File(name);
		FileReader fr = new FileReader(f);
		ScannerJFlex scan = new ScannerJFlex(fr);
		ArrayList<String> tokens = new ArrayList<String>();
		Token tok;
		while((tok = scan.leToken()).tipo != 0)
			tokens.add(tok.toToken());
		String[] stokens = tokens.toArray(new String[0]);
		String fname = f.getName();
		Grammar g = new Grammar();
		g.rules("S", "CMDS");
		g.rules("CMDS", "CMD CMDREP");
		g.rules("CMDREP", "; CMD CMDREP");
		g.rules("CMDREP", "");
		g.rules("CMD", "if COND then CMDS ELSEP end");
		g.rules("CMD", "repeat CMDS until COND");
		g.rules("CMD", "id := EXP");
		g.rules("CMD", "read id");
		g.rules("CMD", "write EXP");
		g.rules("ELSEP", "else CMDS");
		g.rules("ELSEP", "");
		g.rules("COND", "EXP CONDR");
		g.rules("CONDR", "< EXP");
		g.rules("CONDR", "= EXP");
		g.rules("EXP" , "TERMO EXPR");
		g.rules("EXPR", "+ TERMO EXPR");
		g.rules("EXPR", "- TERMO EXPR");
		g.rules("EXPR", "");
		g.rules("TERMO" , "FATOR TERMOR");
		g.rules("TERMOR", "* FATOR TERMOR");
		g.rules("TERMOR", "/ FATOR TERMOR");
		g.rules("TERMOR", "");
		g.rules("FATOR", "( EXP )");
		g.rules("FATOR", "num");
		g.rules("FATOR", "id");
		g.computeSets();
		String program = Grammar.join(stokens, " ").substring(1);
		Tree prog = g.parse(program);
		prog.printDot("ll1-" + fname.substring(0, fname.lastIndexOf('.')) + ".gv");
	}

}
