import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if COND then CMDS [ else CMDS ] end
       | repeat CMDS until COND
       | id := EXP
       | read id
       | write EXP
COND  -> EXP ( < EXP | = EXP )
EXP   -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id 
 */
public class Parser {
	public Token la;
	public ScannerJFlex scan;
	
	class Erro extends RuntimeException {
		public int token;
		
		public Erro(int token) {
			this.token = token;
		}
	}

	public Parser(Reader in) throws IOException {
		scan = new ScannerJFlex(in);
		la = scan.leToken();
	}

	public String match(int token) throws IOException {
		if(la.tipo == token) {
			String termo = la.val;
			la = scan.leToken();
			return termo;
		} else throw new Erro(token);
	}

	public Tree parse() throws IOException {
		try {
			Tree res = CMDS();
			if(la.tipo != 0)
				throw new RuntimeException("erro de sintaxe em " + la);
			return res;
		} catch(Erro e) {
			throw new RuntimeException("erro de sintaxe em " + la);
		}
	}

	// CMDS  -> CMD { ; CMD }
	public Tree CMDS() throws IOException {
		Tree res = new Tree("CMDS");
		res.child(CMD());
		while(la.tipo == ';') {
			res.child(match(';'));
			res.child(CMD());
		}
		return res;
	}

	/*
     CMD   -> if COND then CMDS [ else CMDS ] end
       | repeat CMDS until COND
       | id := EXP
       | read id
       | write EXP
	 */
	public Tree CMD() throws IOException {
		Tree res = new Tree("CMD");
		switch(la.tipo) {
		case 5: // if COND then CMDS [ else CMDS ] end
			res.child(match(5)); // if
			res.child(COND());
			res.child(match(6));
			res.child(CMDS());
			if(la.tipo == 7) { // else CMDS
				res.child(match(7)); // else
				res.child(CMDS());
			}
			res.child(match(8)); // end
			break;
		case 9: // repeat CMDS until COND
			res.child(match(9)); // repeat
			res.child(CMDS());
			res.child(match(10)); // until
			res.child(COND());
			break;
		case 2: // id := EXP
			res.child(match(2));
			res.child(match(11)); // :=
			res.child(EXP());
			break;
		case 4: // read id
			res.child(match(4)); // read
			res.child(match(2)); // id
			break;
		case 3: // write EXP
			res.child(match(3)); // write
			res.child(EXP());
			break;
		default: throw new Erro(la.tipo);
		}
		return res;
	}

	// COND  -> EXP ( < EXP | = EXP )
	public Tree COND() throws IOException {
		Tree res = new Tree("COND");
		res.child(EXP());
		if(la.tipo == '<') {
			res.child(match('<'));
			res.child(EXP());
		} else {
			res.child(match('='));
			res.child(EXP());
		}
		return res;
	}

/*	// EXP   -> TERMO { + TERMO | - TERMO }
	public Tree EXP() throws IOException {
		Tree res = new Tree("EXP");
		res.child(TERMO());
		while(la.tipo == '+' || la.tipo == '-') {
			res.child(match(la.tipo));
			res.child(TERMO());
		}
		return res;
	}
*/
	// EXP   -> EXP + TERMO | EXP - TERMO | TERMO
	public Tree EXP() throws IOException {
		Tree res = new Tree("EXP");
		res.child(TERMO());
		while(la.tipo == '+' || la.tipo == '-') {
			Tree nres = new Tree("EXP");
			nres.child(res);
			nres.child(match(la.tipo));
			nres.child(TERMO());
			res = nres;
		}
		return res;
	}

/*	// TERMO   -> FATOR { * FATOR | / FATOR }
	public Tree TERMO() throws IOException {
		Tree res = new Tree("TERMO");
		res.child(FATOR());
		while(la.tipo == '*' || la.tipo == '/') {
			res.child(match(la.tipo));
			res.child(FATOR());
		}
		return res;
	}
*/
	// TERMO   -> TERMO * FATOR | TERMO / FATOR | FATOR
	public Tree TERMO() throws IOException {
		Tree res = new Tree("TERMO");
		res.child(FATOR());
		while(la.tipo == '*' || la.tipo == '/') {
			Tree nres = new Tree("TERMO");
			nres.child(res);
			nres.child(match(la.tipo));
			nres.child(FATOR());
			res = nres;
		}
		return res;
	}

	
	// FATOR -> "(" EXP ")" | num | id 
	public Tree FATOR() throws IOException {
		Tree res = new Tree("FATOR");
		switch(la.tipo) {
		case '(':
			res.child(match('('));
			res.child(EXP());
			res.child(match(')'));
			break;
		case 1:
			res.child(match(1)); // num
			break;
		case 2:
			res.child(match(2)); // id
			break;
		default: throw new Erro(la.tipo);
		}
		return res;
	}
}
