import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;

public class Driver {
	public static void main(String[] args) throws IOException {
		String name = args[0];
		File f = new File(name);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		parser.parse();
		Tiny prog = parser.saida;
		String saida = prog.toString();
		StringReader sr = new StringReader(saida);
		parser = new Parser(sr);
		parser.parse();
		System.out.println(saida);
		if(!saida.equals(parser.saida.toString())) {
			throw new RuntimeException("bug no parser: programa mal formado");
		}
		prog.tipos();
	}

}
