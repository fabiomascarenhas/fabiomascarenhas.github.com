import java.util.ArrayList;
import java.util.List;

class Tiny {
	List<Proc> procs;
	Bloco corpo;
	
	public Tiny(Bloco _corpo) {
		procs = new ArrayList<Proc>();
		corpo = _corpo;
	}

	public Tiny(List<Proc> _procs, Bloco _corpo) {
		procs = _procs;
		corpo = _corpo;
	}

	public String toString() {
		String res = "";
		for(Proc proc: procs)
			res += proc + ";\n";
		res += corpo;
		return res;
	}
	
	public TabSimb<Boolean> procs() {
		TabSimb<Boolean> esc = new TabSimb<Boolean>();
		for(Proc proc: procs) {
			if(!esc.inserir(proc.nome.nome, true))
				throw new RuntimeException("procedimento duplicado: " + proc.nome);
		}
		return esc;
	}
	
	public TabSimb<String> gvars() {
		TabSimb<String> esc = new TabSimb<String>();
		for(Decl decl: corpo.vars) {
			for(Id var: decl.vars) { 
			  if(!esc.inserir(var.nome, decl.tipo))
				  throw new RuntimeException("variável duplicada: " + var.nome);
		
			}
		}
		return esc;
	}
	
	public void tipos() {
		TabSimb<Boolean> eprocs = procs();
		TabSimb<String> egv = gvars();
		for(Proc proc: procs)
			proc.corpo.tipos(eprocs, egv);
		for(Cmd cmd: corpo.cmds)
			cmd.tipos(eprocs, egv);
	}
}

class Proc {
	Id nome;
	Bloco corpo;
	
	public Proc(Id _nome, Bloco _corpo) {
		nome = _nome;
		corpo = _corpo;
	}
	
	public String toString() {
		return "procedure " + nome + "()\n" + corpo + "\nend"; 
	}
}

class Bloco {
	List<Decl> vars;
	List<Cmd> cmds;
	
	public Bloco(List<Decl> _vars, Cmd cmd) {
		vars = _vars;
		cmds = new java.util.ArrayList<Cmd>();
		cmds.add(cmd);
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}

	public String toString() {
		String res = "";
		if(!vars.isEmpty()) {
			res += "var " + vars.get(0);
			for(int i = 1; i < vars.size(); i++)
				res += ", " + vars.get(i);
			res += ";\n";
		}
		res += cmds.get(0);
		for(int i = 1; i < cmds.size(); i++)
			res += ";\n" + cmds.get(i);
		return res;
	}
	
	public void tipos(TabSimb<Boolean> eprocs,
			          TabSimb<String> escPai) {
		TabSimb<String> esc = new TabSimb<String>(escPai);
		for(Decl decl: vars) {
			for(Id var: decl.vars) {
				if(!esc.inserir(var.nome, decl.tipo))
					throw new RuntimeException("declaração dupla: " + var.nome);
			}
		}
		for(Cmd cmd: cmds) {
			cmd.tipos(eprocs, esc);
		}
	}
}

class Decl {
	String tipo;
	List<Id> vars;
	
	public Decl(String _tipo, List<Id> _vars) {
		tipo = _tipo;
		vars = _vars;
	}
	
	public String toString() {
		String res = "" + vars.get(0);
		for(int i = 1; i < vars.size(); i++)
			res += ", " + vars.get(i);
		res += ": " + tipo;
		return res;
	}
}

interface Cmd {
	void tipos(TabSimb<Boolean> eprocs,
			   TabSimb<String> esc);
}

class Tipo {
	// t1 <= t2? (subsunção)
	public static void verifica(String t1, String t2) {
		if(!t1.equals(t2)) {
			if(!t1.equals("int") ||
					!t2.equals("real"))
				throw new RuntimeException("erro de tipo, esperado "
					+ t2 + ", encontrado " + t1);
		}
	}
}

class If implements Cmd {
	Exp cond;
	Bloco cif;
	Bloco celse;
	
	public If(Exp _cond, Bloco _cif) {
		cond = _cond;
		cif = _cif;
		celse = null;
	}
	
	public If(Exp _cond, Bloco _cif,
			Bloco _celse) {
		cond = _cond;
		cif = _cif;
		celse = _celse;
	}
	
	public String toString() {
		return "if " + cond + " then\n" + cif +
				(celse == null ? "" : "\nelse\n" + celse) + "\nend";
	}
	
	public void tipos(TabSimb<Boolean> eprocs,
			          TabSimb<String> esc) {
		Tipo.verifica(cond.tipo(eprocs, esc), "bool");
		cif.tipos(eprocs, esc);
		if(celse != null) celse.tipos(eprocs, esc);
	}
}

class Repeat implements Cmd {
	Bloco corpo;
	Exp cond;
	
	public Repeat(Bloco _corpo, Exp _cond) {
		corpo = _corpo;
		cond = _cond;
	}

	public String toString() {
		return "repeat\n" + corpo + "\nuntil " + cond;
	}

	public void tipos(TabSimb<Boolean> eprocs, 
			TabSimb<String> esc) {
		// Escopo do corpo não inclui a condição
		corpo.tipos(eprocs, esc);
		Tipo.verifica(cond.tipo(eprocs, esc), "bool");
	}
}

class Atrib implements Cmd {
	Id var;
	Exp exp;
	
	public Atrib(Id _var, Exp _exp) {
		var = _var;
		exp = _exp;
	}
	
	public String toString() {
		return var + " := " + exp;
	}

	public void tipos(TabSimb<Boolean> eprocs,
			          TabSimb<String> esc) {
		String tvar = esc.procurar(var.nome);
		if(tvar == null)
			throw new RuntimeException("variável não declarada: " + var.nome);
		// podemos atribuir uma expressão inteira
		// a uma variável real, mas não o contrário
		Tipo.verifica(exp.tipo(eprocs, esc), tvar);
	}
}

class Read implements Cmd {
	Id var;
	
	public Read(Id _var) {
		var = _var;
	}

	public String toString() {
		return "read " + var;
	}

	public void tipos(TabSimb<Boolean> eprocs,
			          TabSimb<String> esc) {
		if(esc.procurar(var.nome) == null)
			throw new RuntimeException("variável não declarada: " + var.nome);
	}
}

class Write implements Cmd {
	Exp exp;
	
	public Write(Exp _exp) {
		exp = _exp;
	}

	public String toString() {
		return "write " + exp;
	}

	public void tipos(TabSimb<Boolean> eprocs,
			          TabSimb<String> esc) {
		exp.tipo(eprocs, esc);
	}
}

interface Exp {
	String tipo(TabSimb<Boolean> eprocs, TabSimb<String> esc);
}

class Menor implements Exp {
	Exp e1;
	Exp e2;
	
	public Menor(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " < " + e2 + ")";
	}
	
	public String tipo(TabSimb<Boolean> eprocs, 
			           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "bool";
	}
}

class Igual implements Exp {
	Exp e1;
	Exp e2;
	
	public Igual(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " = " + e2 + ")";
	}

	public String tipo(TabSimb<Boolean> eprocs,
			           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(!t1.equals("bool") || !t2.equals("bool")) {
			Tipo.verifica(t1, "real");
			Tipo.verifica(t2, "real");
		}
		return "bool";
	}
}

class Soma implements Exp {
	Exp e1;
	Exp e2;
	
	public Soma(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " + " + e2 + ")";
	}

	public String tipo(TabSimb<Boolean> eprocs,
			           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(t1.equals("int") && t2.equals("int"))
			return "int";
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}
}

class Sub implements Exp {
	Exp e1;
	Exp e2;
	
	public Sub(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " - " + e2 + ")";
	}

	public String tipo(TabSimb<Boolean> eprocs,
	           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(t1.equals("int") && t2.equals("int"))
			return "int";
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}
}

class Mult implements Exp {
	Exp e1;
	Exp e2;
	
	public Mult(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " * " + e2 + ")";
	}

	public String tipo(TabSimb<Boolean> eprocs,
	           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(t1.equals("int") && t2.equals("int"))
			return "int";
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}
}

class Div implements Exp {
	Exp e1;
	Exp e2;
	
	public Div(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " / " + e2 + ")";
	}

	public String tipo(TabSimb<Boolean> eprocs,
	           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}
}

class Num implements Exp {
	int val;
	
	public Num(String lexeme) {
		val = Integer.parseInt(lexeme);
	}

	public String toString() {
		return "" + val;
	}

	public String tipo(TabSimb<Boolean> eprocs,
			TabSimb<String> esc) {
		return "int";
	}
}

class Id implements Exp {
	String nome;
	
	public Id(String _nome) {
		nome = _nome;
	}

	public String toString() {
		return nome;
	}

	public String tipo(TabSimb<Boolean> eprocs,
			TabSimb<String> esc) {
		String tvar = esc.procurar(nome); 
		if(tvar == null)
			throw new RuntimeException("variável não existe: " + nome);
		return tvar;
	}
}

class Chamada implements Cmd {
	Id proc;
	
	public Chamada(Id _proc) {
		proc = _proc;
	}
	
	public String toString() {
		return "" + proc;
	}
	
	public void tipos(TabSimb<Boolean> eprocs,
			TabSimb<String> esc) {
		if(eprocs.procurar(proc.nome) == null)
			throw new RuntimeException("procedimento não existe: " + proc.nome);
	}
}
