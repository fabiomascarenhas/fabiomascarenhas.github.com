import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Driver {
	public static void main(String[] args) throws IOException {
		String name = args[0];
		File f = new File(name);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		parser.parse();
		Tree prog = parser.saida;
		String fname = f.getName();
		prog.printDot("jacc-" + fname.substring(0, fname.lastIndexOf('.')) + ".gv");
	}

}
