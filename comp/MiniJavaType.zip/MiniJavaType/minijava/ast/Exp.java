package minijava.ast;

import minijava.TabSimb;

public interface Exp {
	String tipo(TabSimb<String> vars);
}
