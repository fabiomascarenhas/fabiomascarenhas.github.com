package minijava.ast;

import minijava.TabSimb;

public class Indexa implements Exp {
	public Exp vet;
	public Exp ind;
	public int lin;
	
	public Indexa(Exp _vet, Exp _ind, int _lin) {
		vet = _vet;
		ind = _ind;
		lin = _lin;
	}
	
	public String toString() {
		return vet + "[" + ind + "]";
	}

	@Override
	public String tipo(TabSimb<String> vars) {
		// TODO: tipagem da expressão de indexação
		// o tipo de uma indexação é sempre "int", mas antes precisamos:
		//   verificar que o tipo de "tvet" é subtipo de "int[]"
		//   verificar que o tipo de "tind" é subtipo de "int"
		return null;
	}

}
