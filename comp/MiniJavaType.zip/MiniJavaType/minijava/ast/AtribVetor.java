package minijava.ast;

import minijava.TabSimb;

public class AtribVetor implements Cmd {
	public String nome;
	public Exp ind;
	public Exp rval;
	public int lin;
	
	public AtribVetor(String _nome, Exp _ind, Exp _rval, int _lin) {
		nome = _nome;
		ind = _ind;
		rval = _rval;
		lin = _lin;
	}

	public String toString() {
		return nome + "[" + ind + "]" + " = " + rval + ";";
	}

	@Override
	public void tipos(TabSimb<String> vars) {
		String tlval = vars.procurar(nome);
		if(tlval == null)
			throw new RuntimeException("variável " + nome + " não declarada na linha " + lin);
		Tipo.subtipo(tlval, "int[]", lin);
		String tind = ind.tipo(vars);
		Tipo.subtipo(tind, "int", lin);
		String trval = rval.tipo(vars);
		Tipo.subtipo(trval, "int", lin);
	}
	
}
