package minijava.ast;

import minijava.TabSimb;

public class Nao implements Exp {
	public Exp e;
	public int lin;
	
	public Nao(Exp _e, int _lin) {
		e = _e;
		lin = _lin;
	}
	
	public String toString() {
		return "(!" + e + ")";
	}

	@Override
	public String tipo(TabSimb<String> vars) {
		String te = e.tipo(vars);
		Tipo.subtipo(te, "boolean", lin);
		return "boolean";
	}
}
