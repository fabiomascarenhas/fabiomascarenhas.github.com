package minijava.ast;

import minijava.TabSimb;

public class This implements Exp {
	public int lin;
	
	public This(int _lin) {
		lin = _lin;
	}

	public String toString() {
		return "this";
	}

	@Override
	public String tipo(TabSimb<String> vars) {
		String tself = vars.procurar("this");
		if(tself == null)
			throw new RuntimeException("this usado fora do contexto de um método na linha " + lin);
		return tself;
	}
}
