package minijava.ast;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import minijava.TabSimb;

public class Prog {
	public String main;
	public String args;
	public Cmd cmd;
	public List<Classe> cls;
	
	public static Map<String, Classe> classes = new HashMap<String, Classe>();
		
	public Prog(String _main, String _args, Cmd _cmd, List<Classe> _cls) {
		main = _main;
		args = _args;
		cmd = _cmd;
		cls = _cls;
	}

	public String toString() {
		String res = "class " + main + " {\n  public static void main(String[] " + args +
				") {\n" + cmd + "\n  }\n}\n";
		for(Classe classe: cls)
			res += classe + "\n";
		return res;
	}
	
	public void tipos() {
		for(Classe classe: cls) {
			if(main.equals(classe.nome) || classes.containsKey(classe.nome)) {
				throw new RuntimeException("classe redefinida " + classe.nome + " na linha " + classe.lin);
			} else {
				Tipo.subclasseDe.put(classe.nome, classe.pai);
				classes.put(classe.nome, classe);
			}
		}
		for(Classe classe: cls) {
			classe.adicionaCampos();
			classe.adicionaMetodos();
		}
		for(Classe classe: cls) {
			classe.tipos();
		}
		cmd.tipos(new TabSimb<String>());
	}
}
