package minijava.ast;

import minijava.TabSimb;

public class Length implements Exp {
	public Exp exp;
	public int lin;
	
	public Length(Exp _exp, int _lin) {
		exp = _exp;
		lin = _lin;
	}

	public String toString() {
		return exp + ".length";
	}

	@Override
	public String tipo(TabSimb<String> vars) {
		String tobj = exp.tipo(vars);
		if(tobj.equals("int[]"))
			return "int";
		Classe classe = Prog.classes.get(tobj);
		if(classe == null)
			throw new RuntimeException(tobj + " não é uma classe declarada na linha " + lin);
		for(String campo: classe.todosCampos.keySet()) {
			if(campo.equals("length"))
				return classe.todosCampos.get(campo);
		}
		throw new RuntimeException(tobj + " não tem um campo length na linha " + lin);
	}
}
