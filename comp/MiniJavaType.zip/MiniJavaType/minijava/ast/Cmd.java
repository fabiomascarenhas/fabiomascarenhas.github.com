package minijava.ast;

import minijava.TabSimb;

public interface Cmd {
	void tipos(TabSimb<String> vars);
}
