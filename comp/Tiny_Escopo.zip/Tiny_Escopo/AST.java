import java.util.ArrayList;
import java.util.List;

class Tiny {
	List<Proc> procs;
	Bloco corpo;
	
	public Tiny(Bloco _corpo) {
		procs = new ArrayList<Proc>();
		corpo = _corpo;
	}

	public Tiny(List<Proc> _procs, Bloco _corpo) {
		procs = _procs;
		corpo = _corpo;
	}

	public String toString() {
		return "Tiny(" + corpo + ")";
	}
	
	public TabSimb<Boolean> procs() {
		TabSimb<Boolean> esc = new TabSimb<Boolean>();
		for(Proc proc: procs) {
			if(!esc.inserir(proc.nome.nome, true))
				throw new RuntimeException("procedimento duplicado: " + proc.nome);
		}
		return esc;
	}
	
	public TabSimb<Boolean> gvars() {
		TabSimb<Boolean> esc = new TabSimb<Boolean>();
		for(Id var: corpo.vars) {
			if(!esc.inserir(var.nome, true))
				throw new RuntimeException("variável duplicado: " + var.nome);
		}
		return esc;
	}
	
	public void escopo() {
		TabSimb<Boolean> eprocs = procs();
		TabSimb<Boolean> egv = gvars();
		for(Proc proc: procs)
			proc.corpo.escopo(eprocs, egv);
		for(Cmd cmd: corpo.cmds)
			cmd.escopo(eprocs, egv);
	}
}

class Proc {
	Id nome;
	Bloco corpo;
	
	public Proc(Id _nome, Bloco _corpo) {
		nome = _nome;
		corpo = _corpo;
	}
}

class Bloco {
	List<Id> vars;
	List<Cmd> cmds;
	
	public Bloco(List<Id> _vars, Cmd cmd) {
		vars = _vars;
		cmds = new java.util.ArrayList<Cmd>();
		cmds.add(cmd);
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("Bloco(");
		if(!vars.isEmpty()) {
			buf.append("Var(");
			for(Id var: vars) {
				buf.append(var.toString());
				buf.append(",");
			}
			buf.append("), ");
		}
		for(Cmd cmd: cmds) {
			buf.append(cmd.toString());
			buf.append(",\n");
		}
		buf.append(")");
		return buf.toString();
	}
	
	public void escopo(TabSimb<Boolean> eprocs,
			           TabSimb<Boolean> escPai) {
		TabSimb<Boolean> esc = new TabSimb<Boolean>(escPai);
		for(Id var: vars) {
			if(!esc.inserir(var.nome, true))
				throw new RuntimeException("declaração dupla: " + var.nome);
		}
		for(Cmd cmd: cmds) {
			cmd.escopo(eprocs, esc);
		}
	}
}

interface Cmd {
	void escopo(TabSimb<Boolean> eprocs,
			    TabSimb<Boolean> esc);
}

class If implements Cmd {
	Cond cond;
	Bloco cif;
	Bloco celse;
	
	public If(Cond _cond, Bloco _cif) {
		cond = _cond;
		cif = _cif;
		celse = null;
	}
	
	public If(Cond _cond, Bloco _cif,
			Bloco _celse) {
		cond = _cond;
		cif = _cif;
		celse = _celse;
	}
	
	public String toString() {
		return "If(" + cond.toString() +
				", " + cif.toString() +
				(celse == null ? "" : 
					", " + celse.toString()) +
				")";
	}
	
	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		cond.escopo(eprocs, esc);
		cif.escopo(eprocs, esc);
		if(celse != null) celse.escopo(eprocs, esc);
	}
}

class Repeat implements Cmd {
	Bloco corpo;
	Cond cond;
	
	public Repeat(Bloco _corpo, Cond _cond) {
		corpo = _corpo;
		cond = _cond;
	}

	public String toString() {
		return "Repeat(" + corpo +
				"," + cond + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs, 
			TabSimb<Boolean> esc) {
		// Escopo do corpo não inclui a condição
		corpo.escopo(eprocs, esc);
		cond.escopo(eprocs, esc);
	}
}

class Atrib implements Cmd {
	Id var;
	Exp exp;
	
	public Atrib(Id _var, Exp _exp) {
		var = _var;
		exp = _exp;
	}
	
	public String toString() {
		return "Atrib(" + var + ", " + exp + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		if(esc.procurar(var.nome) == null)
			throw new RuntimeException("variável não declarada: " + var.nome);
		exp.escopo(eprocs, esc);
	}
}

class Read implements Cmd {
	Id var;
	
	public Read(Id _var) {
		var = _var;
	}

	public String toString() {
		return "Read(" + var + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		if(esc.procurar(var.nome) == null)
			throw new RuntimeException("variável não declarada: " + var.nome);
	}
}

class Write implements Cmd {
	Exp exp;
	
	public Write(Exp _exp) {
		exp = _exp;
	}

	public String toString() {
		return "Write(" + exp + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		exp.escopo(eprocs, esc);
	}
}

interface Cond {
	void escopo(TabSimb<Boolean> eprocs, TabSimb<Boolean> esc);
}

class Menor implements Cond {
	Exp e1;
	Exp e2;
	
	public Menor(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "Menor(" + e1 + ", " + e2 + ")";
	}
	
	public void escopo(TabSimb<Boolean> eprocs, 
			TabSimb<Boolean> esc) {
		e1.escopo(eprocs, esc);
		e2.escopo(eprocs, esc);
	}
}

class Igual implements Cond {
	Exp e1;
	Exp e2;
	
	public Igual(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "Igual(" + e1 + ", " + e2 + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		e1.escopo(eprocs, esc);
		e2.escopo(eprocs, esc);
	}
}

interface Exp {
	void escopo(TabSimb<Boolean> eprocs, TabSimb<Boolean> esc);
}

class Soma implements Exp {
	Exp e1;
	Exp e2;
	
	public Soma(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "Soma(" + e1 + ", " + e2 + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		e1.escopo(eprocs, esc);
		e2.escopo(eprocs, esc);
	}
}

class Sub implements Exp {
	Exp e1;
	Exp e2;
	
	public Sub(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "Sub(" + e1 + ", " + e2 + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		e1.escopo(eprocs, esc);
		e2.escopo(eprocs, esc);
	}
}

class Mult implements Exp {
	Exp e1;
	Exp e2;
	
	public Mult(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "Mult(" + e1 + ", " + e2 + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		e1.escopo(eprocs, esc);
		e2.escopo(eprocs, esc);
	}
}

class Div implements Exp {
	Exp e1;
	Exp e2;
	
	public Div(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "Div(" + e1 + ", " + e2 + ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		e1.escopo(eprocs, esc);
		e2.escopo(eprocs, esc);
	}
}

class Num implements Exp {
	int val;
	
	public Num(String lexeme) {
		val = Integer.parseInt(lexeme);
	}

	public String toString() {
		return "Num(" + val+ ")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {}
}

class Id implements Exp {
	String nome;
	
	public Id(String _nome) {
		nome = _nome;
	}

	public String toString() {
		return "Id(\"" + nome + "\")";
	}

	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		if(esc.procurar(nome) == null)
			throw new RuntimeException("variável não existe: " + nome);
	}
}

class Chamada implements Cmd, Exp {
	Id proc;
	
	public Chamada(Id _proc) {
		proc = _proc;
	}
	
	public void escopo(TabSimb<Boolean> eprocs,
			TabSimb<Boolean> esc) {
		if(eprocs.procurar(proc.nome) == null)
			throw new RuntimeException("procedimento não existe: " + proc.nome);
	}
}
