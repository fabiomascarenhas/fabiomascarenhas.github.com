// Output created by jacc on Wed Jun 05 16:12:10 BRT 2013


class Parser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 65:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 66:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 130;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 67:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 68:
                    switch (yytok) {
                        case ';':
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 69:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 70:
                    switch (yytok) {
                        case ID:
                            yyn = 11;
                            continue;
                        case IF:
                            yyn = 12;
                            continue;
                        case READ:
                            yyn = 13;
                            continue;
                        case REPEAT:
                            yyn = 14;
                            continue;
                        case WRITE:
                            yyn = 15;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 71:
                    switch (yytok) {
                        case ID:
                            yyn = 16;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 72:
                    switch (yytok) {
                        case ID:
                            yyn = 18;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 73:
                    switch (yytok) {
                        case ID:
                            yyn = 11;
                            continue;
                        case IF:
                            yyn = 12;
                            continue;
                        case READ:
                            yyn = 13;
                            continue;
                        case REPEAT:
                            yyn = 14;
                            continue;
                        case WRITE:
                            yyn = 15;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 74:
                    yyn = yys9();
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 75:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 76:
                    switch (yytok) {
                        case ATRIB:
                            yyn = 22;
                            continue;
                        case '(':
                            yyn = 23;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 77:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 78:
                    switch (yytok) {
                        case ID:
                            yyn = 29;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 79:
                    yyn = yys14();
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 80:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 81:
                    switch (yytok) {
                        case '(':
                            yyn = 32;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 82:
                    switch (yytok) {
                        case ',':
                            yyn = 33;
                            continue;
                        case ';':
                            yyn = 34;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 83:
                    switch (yytok) {
                        case ';':
                        case ',':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 84:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 85:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 86:
                    switch (yytok) {
                        case ';':
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 87:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 88:
                    switch (yytok) {
                        case ')':
                            yyn = 36;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 89:
                    switch (yytok) {
                        case THEN:
                            yyn = 37;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 90:
                    yyn = yys25();
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 91:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 92:
                    yyn = yys27();
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 93:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 94:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr16();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 95:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case UNTIL:
                            yyn = 46;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 96:
                    yyn = yys31();
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 97:
                    switch (yytok) {
                        case ')':
                            yyn = 47;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 98:
                    switch (yytok) {
                        case ID:
                            yyn = 48;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 99:
                    switch (yytok) {
                        case WRITE:
                        case IF:
                        case REPEAT:
                        case READ:
                        case ID:
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 100:
                    yyn = yys35();
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 101:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    switch (yytok) {
                        case ')':
                            yyn = 56;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    switch (yytok) {
                        case '*':
                            yyn = 38;
                            continue;
                        case '+':
                            yyn = 39;
                            continue;
                        case '-':
                            yyn = 40;
                            continue;
                        case '/':
                            yyn = 41;
                            continue;
                        case ')':
                            yyn = 57;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    switch (yytok) {
                        case ID:
                            yyn = 26;
                            continue;
                        case NUM:
                            yyn = 27;
                            continue;
                        case '(':
                            yyn = 28;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    switch (yytok) {
                        case ';':
                        case ',':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ELSE:
                            yyn = 60;
                            continue;
                        case END:
                            yyn = 61;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    yyn = yys50();
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    yyn = yys51();
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    yyn = yys53();
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    yyn = yys54();
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    yyn = yys56();
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    yyn = yys57();
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 62;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 64;
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    switch (yytok) {
                        case ENDINPUT:
                        case END:
                        case ';':
                        case UNTIL:
                        case ELSE:
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 133;
                    continue;

                case 130:
                    return true;
                case 131:
                    yyerror("stack overflow");
                case 132:
                    return false;
                case 133:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case PROCEDURE:
                return 6;
            case VAR:
                return 7;
            case WRITE:
            case IF:
            case REPEAT:
            case READ:
            case ID:
                return yyr9();
        }
        return 133;
    }

    private int yys9() {
        switch (yytok) {
            case PROCEDURE:
                return 6;
            case VAR:
                return 7;
            case WRITE:
            case IF:
            case REPEAT:
            case READ:
            case ID:
                return yyr9();
        }
        return 133;
    }

    private int yys14() {
        switch (yytok) {
            case VAR:
                return 7;
            case WRITE:
            case IF:
            case REPEAT:
            case READ:
            case ID:
                return yyr9();
        }
        return 133;
    }

    private int yys25() {
        switch (yytok) {
            case '*':
                return 38;
            case '+':
                return 39;
            case '-':
                return 40;
            case '/':
                return 41;
            case '<':
                return 42;
            case '=':
                return 43;
        }
        return 133;
    }

    private int yys26() {
        switch (yytok) {
            case ID:
            case WRITE:
            case VAR:
            case REPEAT:
            case PROCEDURE:
            case error:
            case ATRIB:
            case NUM:
            case IF:
            case ',':
            case READ:
                return 133;
            case '(':
                return 44;
        }
        return yyr27();
    }

    private int yys27() {
        switch (yytok) {
            case ID:
            case error:
            case VAR:
            case REPEAT:
            case '(':
            case PROCEDURE:
            case ATRIB:
            case NUM:
            case IF:
            case ',':
            case READ:
            case WRITE:
                return 133;
        }
        return yyr26();
    }

    private int yys31() {
        switch (yytok) {
            case '*':
                return 38;
            case '+':
                return 39;
            case '-':
                return 40;
            case '/':
                return 41;
            case ENDINPUT:
            case END:
            case ';':
            case UNTIL:
            case ELSE:
                return yyr17();
        }
        return 133;
    }

    private int yys35() {
        switch (yytok) {
            case '*':
                return 38;
            case '+':
                return 39;
            case '-':
                return 40;
            case '/':
                return 41;
            case ENDINPUT:
            case END:
            case ';':
            case UNTIL:
            case ELSE:
                return yyr15();
        }
        return 133;
    }

    private int yys37() {
        switch (yytok) {
            case VAR:
                return 7;
            case WRITE:
            case IF:
            case REPEAT:
            case READ:
            case ID:
                return yyr9();
        }
        return 133;
    }

    private int yys47() {
        switch (yytok) {
            case VAR:
                return 7;
            case WRITE:
            case IF:
            case REPEAT:
            case READ:
            case ID:
                return yyr9();
        }
        return 133;
    }

    private int yys50() {
        switch (yytok) {
            case ID:
            case error:
            case VAR:
            case REPEAT:
            case '(':
            case PROCEDURE:
            case ATRIB:
            case NUM:
            case IF:
            case ',':
            case READ:
            case WRITE:
                return 133;
        }
        return yyr23();
    }

    private int yys51() {
        switch (yytok) {
            case '*':
                return 38;
            case '/':
                return 41;
            case ENDINPUT:
            case '=':
            case END:
            case UNTIL:
            case '-':
            case THEN:
            case ';':
            case '<':
            case '+':
            case ')':
            case ELSE:
                return yyr21();
        }
        return 133;
    }

    private int yys52() {
        switch (yytok) {
            case '*':
                return 38;
            case '/':
                return 41;
            case ENDINPUT:
            case '=':
            case END:
            case UNTIL:
            case '-':
            case THEN:
            case ';':
            case '<':
            case '+':
            case ')':
            case ELSE:
                return yyr22();
        }
        return 133;
    }

    private int yys53() {
        switch (yytok) {
            case ID:
            case error:
            case VAR:
            case REPEAT:
            case '(':
            case PROCEDURE:
            case ATRIB:
            case NUM:
            case IF:
            case ',':
            case READ:
            case WRITE:
                return 133;
        }
        return yyr24();
    }

    private int yys54() {
        switch (yytok) {
            case '*':
                return 38;
            case '+':
                return 39;
            case '-':
                return 40;
            case '/':
                return 41;
            case ENDINPUT:
            case END:
            case ';':
            case UNTIL:
            case THEN:
            case ELSE:
                return yyr19();
        }
        return 133;
    }

    private int yys55() {
        switch (yytok) {
            case '*':
                return 38;
            case '+':
                return 39;
            case '-':
                return 40;
            case '/':
                return 41;
            case ENDINPUT:
            case END:
            case ';':
            case UNTIL:
            case THEN:
            case ELSE:
                return yyr20();
        }
        return 133;
    }

    private int yys56() {
        switch (yytok) {
            case ID:
            case error:
            case VAR:
            case REPEAT:
            case '(':
            case PROCEDURE:
            case ATRIB:
            case NUM:
            case IF:
            case ',':
            case READ:
            case WRITE:
                return 133;
        }
        return yyr28();
    }

    private int yys57() {
        switch (yytok) {
            case ID:
            case error:
            case VAR:
            case REPEAT:
            case '(':
            case PROCEDURE:
            case ATRIB:
            case NUM:
            case IF:
            case ',':
            case READ:
            case WRITE:
                return 133;
        }
        return yyr25();
    }

    private int yys60() {
        switch (yytok) {
            case VAR:
                return 7;
            case WRITE:
            case IF:
            case REPEAT:
            case READ:
            case ID:
                return yyr9();
        }
        return 133;
    }

    private int yyr1() { // tiny : procs ';' cmds
        { saida = new Tiny(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1])); yyrv = saida; }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr2() { // tiny : cmds
        { saida = new Tiny(((Bloco)yysv[yysp-1])); yyrv = saida; }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr6() { // cmds : cmds ';' cmd
        { ((Bloco)((Bloco)yysv[yysp-3])).add(((Cmd)yysv[yysp-1])); yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr7() { // cmds : var cmd
        { yyrv = new Bloco(((java.util.List)yysv[yysp-2]), ((Cmd)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 47: return 59;
            case 37: return 49;
            case 14: return 30;
            case 9: return 20;
            case 0: return 2;
            default: return 63;
        }
    }

    private int yyr19() { // cond : exp '<' exp
        { yyrv = new Menor(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcond();
    }

    private int yyr20() { // cond : exp '=' exp
        { yyrv = new Igual(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcond();
    }

    private int yypcond() {
        switch (yyst[yysp-1]) {
            case 12: return 24;
            default: return 58;
        }
    }

    private int yyr21() { // exp : exp '+' exp
        { yyrv = new Soma(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr22() { // exp : exp '-' exp
        { yyrv = new Sub(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr23() { // exp : exp '*' exp
        { yyrv = new Mult(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr24() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr25() { // exp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr26() { // exp : NUM
        { yyrv = new Num(((Token)yysv[yysp-1]).val); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr27() { // exp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).val); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr28() { // exp : ID '(' ')'
        { yyrv = new Chamada(new Id(((Token)yysv[yysp-3]).val)); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 43: return 55;
            case 42: return 54;
            case 41: return 53;
            case 40: return 52;
            case 39: return 51;
            case 38: return 50;
            case 28: return 45;
            case 22: return 35;
            case 15: return 31;
            default: return 25;
        }
    }

    private int yyr10() { // ids : ids ',' ID
        { ((java.util.List<Id>)((java.util.List)yysv[yysp-3])).add(new Id(((Token)yysv[yysp-1]).val)); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 17;
    }

    private int yyr11() { // ids : ID
        { yyrv = new java.util.ArrayList<Id>();
                     ((java.util.List<Id>)yyrv).add(new Id(((Token)yysv[yysp-1]).val)); }
        yysv[yysp-=1] = yyrv;
        return 17;
    }

    private int yyr5() { // proc : PROCEDURE ID '(' ')' cmds END
        { yyrv = new Proc(new Id(((Token)yysv[yysp-5]).val), ((Bloco)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        switch (yyst[yysp-1]) {
            case 0: return 3;
            default: return 21;
        }
    }

    private int yyr3() { // procs : procs ';' proc
        { ((java.util.List)((java.util.List)yysv[yysp-3])).add(((Proc)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 4;
    }

    private int yyr4() { // procs : proc
        { yyrv = new java.util.ArrayList<Proc>();
                      ((java.util.List<Proc>)yyrv).add(((Proc)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 4;
    }

    private int yyr12() { // cmd : IF cond THEN cmds END
        { yyrv = new If(((Cond)yysv[yysp-4]), ((Bloco)yysv[yysp-2])); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr13() { // cmd : IF cond THEN cmds ELSE cmds END
        { yyrv = new If(((Cond)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr14() { // cmd : REPEAT cmds UNTIL cond
        { yyrv = new Repeat(((Bloco)yysv[yysp-3]), ((Cond)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr15() { // cmd : ID ATRIB exp
        { yyrv = new Atrib(new Id(((Token)yysv[yysp-3]).val), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr16() { // cmd : READ ID
        { yyrv = new Read(new Id(((Token)yysv[yysp-1]).val)); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr17() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr18() { // cmd : ID '(' ')'
        { yyrv = new Chamada(new Id(((Token)yysv[yysp-3]).val)); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 5: return 10;
            default: return 19;
        }
    }

    private int yyr8() { // var : VAR ids ';'
        { yyrv = ((java.util.List)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return 5;
    }

    private int yyr9() { // var : /* empty */
        { yyrv = new java.util.ArrayList<Id>(); }
        yysv[yysp-=0] = yyrv;
        return 5;
    }

    protected String[] yyerrmsgs = {
    };


ScannerJFlex scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Tiny saida; // workaround pro bug do tipo do parse()

public Parser(java.io.Reader entrada) {
  scan = new ScannerJFlex(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.leToken();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException(msg);
}

}
