// Output created by jacc on Wed Jun 05 16:12:10 BRT 2013

interface Tokens {
    int ENDINPUT = 0;
    int ATRIB = 1;
    int ELSE = 2;
    int END = 3;
    int ID = 4;
    int IF = 5;
    int NUM = 6;
    int PROCEDURE = 7;
    int READ = 8;
    int REPEAT = 9;
    int THEN = 10;
    int UNTIL = 11;
    int VAR = 12;
    int WRITE = 13;
    int error = 14;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
