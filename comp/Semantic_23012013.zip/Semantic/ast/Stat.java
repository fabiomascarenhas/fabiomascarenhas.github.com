package ast;

import java.util.Map;

public abstract class Stat extends Node {
	public Stat(int line, int col) {
		super(line, col);
	}
	
	public abstract void eval(Map<String, Object> env);
}
