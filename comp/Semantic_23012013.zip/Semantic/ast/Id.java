package ast;

import java.util.Map;

public class Id extends Exp {
	public String name;
	
	public Id(String name, int line, int col) {
		super(line, col);
		this.name = name;
	}
	
	public String label() {
		return name;
	}
	
	public Object eval(Map<String,Object> env) {
		return env.get(name);
	}
}
