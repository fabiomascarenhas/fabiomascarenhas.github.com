package ast;

import java.lang.reflect.Field;
import java.util.Map;

public abstract class Exp extends Node {
	public Exp(int line, int col) {
		super(line, col);
	}
	
	public abstract Object eval(Map<String,Object> env);
}
