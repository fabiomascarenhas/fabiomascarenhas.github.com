package ast;

import java.util.Map;

public class Atrib extends Stat{
	public Id lval;
	public Exp rval;
	
	public Atrib(Id lval, Exp rval, int line, int col) {
		super(line, col);
		this.lval = lval;
		this.rval = rval;
	}
	
	public String label() {
		return "=";
	}
	
	public void eval(Map<String,Object> env) {
		env.put(lval.name, rval.eval(env));
	}
}
