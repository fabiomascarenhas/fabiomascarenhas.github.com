package ast;

import java.util.Map;

public class If extends Stat {
	public Exp cond;
	public Bloco bthen;
	public Bloco belse;

	public If(Exp cond, Bloco bthen, Bloco belse, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.bthen = bthen;
		this.belse = belse;
	}

	@Override
	public void eval(Map<String, Object> env) {
		if((Boolean)cond.eval(env)) {
			bthen.eval(env);
		} else {
			if(belse != null)
				belse.eval(env);
		}
	}

	@Override
	public String label() {
		return "if";
	}

}
