package ast;

import java.util.Map;

public class Num extends Exp {
	public double val;
	
	public Num(String tok, int line, int col) {
		super(line, col);
		val = Double.parseDouble(tok);
	}

	public Object eval(Map<String,Object> env) {
		return val;
	}

	public String label() {
		return "" + val;
	}
}
