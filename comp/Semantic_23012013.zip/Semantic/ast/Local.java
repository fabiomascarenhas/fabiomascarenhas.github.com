package ast;

import java.util.Map;

public class Local extends Stat{
	public Id id;
	public Exp rval;
	
	public Local(Id id, Exp rval, int line, int col) {
		super(line, col);
		this.id = id;
		this.rval = rval;
	}
	
	public String label() {
		return "=";
	}
	
	public void eval(Map<String,Object> env) {
		if(rval != null)
			env.put(id.name, rval.eval(env));
	}
}
