package ast;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;

public class SymbolTable<T> {
	public HashMap<String, T> map;
	public SymbolTable<T> parent;
	
	public SymbolTable(SymbolTable<T> parent) {
		map = new HashMap<String, T>();
		this.parent = parent;
	}
	
	public SymbolTable() {
		this(null);
	}
	
	public T lookup(String name) {
		if(map.containsKey(name))
			return map.get(name);
		else
			return parent != null ? parent.lookup(name) : null;
	}
	
	public void bind(String name, T value) {
		map.put(name, value);
	}
	
	public void update(String name, T value) {
		if(parent == null || map.containsKey(name))
			map.put(name, value);
		else
			parent.update(name,  value);
	}
	
	public boolean check(String name) {
		return map.containsKey(name);
	}
	
	public String toString() {
		StringBuffer buf = new StringBuffer();
		for(Entry<String, T> pair: map.entrySet()) {
			buf.append(pair.getKey());
			buf.append(": ");
			buf.append(pair.getValue());
			buf.append("\\n");
		}
		return buf.toString();
	}
	
	public void printDot(String filename) {
		BufferedWriter buf;
		try {
			buf = new BufferedWriter(new FileWriter(filename));
			try {
				buf.write("digraph tree {\n");
				int i = 0;
				SymbolTable<T> cur = this;
				do {
					buf.write("" + i);
					buf.write(" [label=\"");
					buf.write(cur.toString());
					buf.write("\",shape=box]\n");
					i++;
					cur = cur.parent;
					if(cur != null) {
						buf.write((i-1) + " -> " + i + "\n");
					}
				} while(cur != null);
				buf.write("}\n");
			} finally {
				buf.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
