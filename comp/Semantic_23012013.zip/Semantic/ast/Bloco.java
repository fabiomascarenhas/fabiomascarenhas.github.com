package ast;

import java.util.List;
import java.util.Map;

public class Bloco extends Stat {
	public List<Stat> stats;
	
	public Bloco(List<Stat> stats, int line, int col) {
		super(line, col);
		this.stats = stats;
	}

	@Override
	public void eval(Map<String, Object> env) {
		for(Stat s: stats)
			s.eval(env);
	}

	@Override
	public String label() {
		return "bloco";
	}
}
