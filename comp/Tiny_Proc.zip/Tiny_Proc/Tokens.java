// Output created by jacc on Mon Jul 01 16:23:49 BRT 2013

interface Tokens {
    int ENDINPUT = 0;
    int ATRIB = 1;
    int BEGIN = 2;
    int BOOL = 3;
    int ELSE = 4;
    int END = 5;
    int ID = 6;
    int IF = 7;
    int INT = 8;
    int NUM = 9;
    int PROCEDURE = 10;
    int READ = 11;
    int REAL = 12;
    int REPEAT = 13;
    int RETURN = 14;
    int THEN = 15;
    int UNTIL = 16;
    int VAR = 17;
    int WRITE = 18;
    int error = 19;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
