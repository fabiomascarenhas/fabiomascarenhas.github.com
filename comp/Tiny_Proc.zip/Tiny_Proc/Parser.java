// Output created by jacc on Mon Jul 01 16:23:49 BRT 2013


class Parser implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 102:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 103:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 204;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 104:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 105:
                    switch (yytok) {
                        case ';':
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 106:
                    switch (yytok) {
                        case ';':
                            yyn = 9;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 107:
                    switch (yytok) {
                        case ID:
                            yyn = 11;
                            continue;
                        case IF:
                            yyn = 12;
                            continue;
                        case READ:
                            yyn = 13;
                            continue;
                        case REPEAT:
                            yyn = 14;
                            continue;
                        case WRITE:
                            yyn = 15;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 108:
                    switch (yytok) {
                        case ID:
                            yyn = 16;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 109:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 110:
                    switch (yytok) {
                        case ID:
                            yyn = 11;
                            continue;
                        case IF:
                            yyn = 12;
                            continue;
                        case READ:
                            yyn = 13;
                            continue;
                        case REPEAT:
                            yyn = 14;
                            continue;
                        case WRITE:
                            yyn = 15;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 111:
                    yyn = yys9();
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 112:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 113:
                    switch (yytok) {
                        case ATRIB:
                            yyn = 24;
                            continue;
                        case '(':
                            yyn = 25;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 114:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 115:
                    switch (yytok) {
                        case ID:
                            yyn = 30;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 116:
                    yyn = yys14();
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 117:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 118:
                    switch (yytok) {
                        case '(':
                            yyn = 33;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 119:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 120:
                    switch (yytok) {
                        case ',':
                            yyn = 34;
                            continue;
                        case ';':
                            yyn = 35;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 121:
                    switch (yytok) {
                        case ',':
                            yyn = 36;
                            continue;
                        case ':':
                            yyn = 37;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 122:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 123:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 124:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    switch (yytok) {
                        case ';':
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                        case ')':
                            yyn = 41;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    yyn = yys26();
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    yyn = yys27();
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    yyn = yys28();
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr25();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case UNTIL:
                            yyn = 51;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    yyn = yys32();
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                        case ')':
                            yyn = 53;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    switch (yytok) {
                        case ID:
                            yyn = 20;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    switch (yytok) {
                        case IF:
                        case REPEAT:
                        case ID:
                        case READ:
                        case WRITE:
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    switch (yytok) {
                        case ID:
                            yyn = 55;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case BOOL:
                            yyn = 57;
                            continue;
                        case INT:
                            yyn = 58;
                            continue;
                        case REAL:
                            yyn = 59;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    switch (yytok) {
                        case ')':
                            yyn = 60;
                            continue;
                        case ',':
                            yyn = 61;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                        case ')':
                            yyn = 70;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    yyn = yys50();
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    switch (yytok) {
                        case ',':
                            yyn = 34;
                            continue;
                        case ')':
                            yyn = 73;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case ':':
                            yyn = 74;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                        case BEGIN:
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                        case BEGIN:
                            yyn = yyr16();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case ';':
                        case ',':
                        case ')':
                        case BEGIN:
                            yyn = yyr17();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case ELSE:
                            yyn = 76;
                            continue;
                        case END:
                            yyn = 77;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys63();
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ',':
                            yyn = 61;
                            continue;
                        case ')':
                            yyn = 78;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    switch (yytok) {
                        case ':':
                            yyn = 79;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case BOOL:
                            yyn = 57;
                            continue;
                        case INT:
                            yyn = 58;
                            continue;
                        case REAL:
                            yyn = 59;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys76();
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr21();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys78();
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    switch (yytok) {
                        case BOOL:
                            yyn = 57;
                            continue;
                        case INT:
                            yyn = 58;
                            continue;
                        case REAL:
                            yyn = 59;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 83;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    switch (yytok) {
                        case ';':
                            yyn = 8;
                            continue;
                        case END:
                            yyn = 84;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 85;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys83();
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ENDINPUT:
                        case ';':
                        case END:
                        case UNTIL:
                        case ELSE:
                            yyn = yyr22();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    yyn = yys85();
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    switch (yytok) {
                        case ';':
                            yyn = 90;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    switch (yytok) {
                        case ';':
                            yyn = 92;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    yyn = yys91();
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys92();
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    switch (yytok) {
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    switch (yytok) {
                        case ID:
                            yyn = 27;
                            continue;
                        case NUM:
                            yyn = 28;
                            continue;
                        case '(':
                            yyn = 29;
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    switch (yytok) {
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    yyn = yys99();
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 207;
                    continue;

                case 204:
                    return true;
                case 205:
                    yyerror("stack overflow");
                case 206:
                    return false;
                case 207:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case PROCEDURE:
                return 6;
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys9() {
        switch (yytok) {
            case PROCEDURE:
                return 6;
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys14() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys26() {
        switch (yytok) {
            case THEN:
                return 42;
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
        }
        return 207;
    }

    private int yys27() {
        switch (yytok) {
            case '(':
                return 49;
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr37();
        }
        return 207;
    }

    private int yys28() {
        switch (yytok) {
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr36();
        }
        return 207;
    }

    private int yys32() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case ENDINPUT:
            case ';':
            case END:
            case UNTIL:
            case ELSE:
                return yyr26();
        }
        return 207;
    }

    private int yys38() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case ENDINPUT:
            case ';':
            case END:
            case UNTIL:
            case ELSE:
                return yyr24();
        }
        return 207;
    }

    private int yys39() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case ',':
            case ')':
                return yyr41();
        }
        return 207;
    }

    private int yys42() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys50() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case ')':
                return 71;
        }
        return 207;
    }

    private int yys63() {
        switch (yytok) {
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr31();
        }
        return 207;
    }

    private int yys64() {
        switch (yytok) {
            case '*':
                return 43;
            case '/':
                return 46;
            case THEN:
            case '<':
            case ';':
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr29();
        }
        return 207;
    }

    private int yys65() {
        switch (yytok) {
            case '*':
                return 43;
            case '/':
                return 46;
            case THEN:
            case '<':
            case ';':
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr30();
        }
        return 207;
    }

    private int yys66() {
        switch (yytok) {
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr32();
        }
        return 207;
    }

    private int yys67() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case THEN:
            case '<':
            case ';':
            case ',':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr33();
        }
        return 207;
    }

    private int yys68() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case THEN:
            case '<':
            case ';':
            case ',':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr34();
        }
        return 207;
    }

    private int yys70() {
        switch (yytok) {
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr38();
        }
        return 207;
    }

    private int yys71() {
        switch (yytok) {
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr35();
        }
        return 207;
    }

    private int yys72() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case ENDINPUT:
            case ';':
            case END:
            case UNTIL:
            case ELSE:
                return yyr23();
        }
        return 207;
    }

    private int yys75() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case ',':
            case ')':
                return yyr40();
        }
        return 207;
    }

    private int yys76() {
        switch (yytok) {
            case VAR:
                return 7;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys78() {
        switch (yytok) {
            case THEN:
            case '<':
            case ';':
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case '=':
            case ENDINPUT:
            case ELSE:
                return yyr39();
        }
        return 207;
    }

    private int yys83() {
        switch (yytok) {
            case VAR:
                return 7;
            case RETURN:
                return 87;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys85() {
        switch (yytok) {
            case VAR:
                return 7;
            case RETURN:
                return 89;
            case IF:
            case REPEAT:
            case ID:
            case READ:
            case WRITE:
                return yyr12();
        }
        return 207;
    }

    private int yys90() {
        switch (yytok) {
            case ID:
                return 11;
            case IF:
                return 12;
            case READ:
                return 13;
            case REPEAT:
                return 14;
            case WRITE:
                return 15;
            case RETURN:
                return 94;
        }
        return 207;
    }

    private int yys91() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case END:
                return 95;
        }
        return 207;
    }

    private int yys92() {
        switch (yytok) {
            case ID:
                return 11;
            case IF:
                return 12;
            case READ:
                return 13;
            case REPEAT:
                return 14;
            case WRITE:
                return 15;
            case RETURN:
                return 96;
        }
        return 207;
    }

    private int yys93() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case END:
                return 97;
        }
        return 207;
    }

    private int yys98() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case END:
                return 100;
        }
        return 207;
    }

    private int yys99() {
        switch (yytok) {
            case '*':
                return 43;
            case '+':
                return 44;
            case '-':
                return 45;
            case '/':
                return 46;
            case '<':
                return 47;
            case '=':
                return 48;
            case END:
                return 101;
        }
        return 207;
    }

    private int yyr1() { // tiny : procs ';' cmds
        { saida = new Tiny(((java.util.List)yysv[yysp-3]), ((Bloco)yysv[yysp-1])); yyrv = saida; }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr2() { // tiny : cmds
        { saida = new Tiny(((Bloco)yysv[yysp-1])); yyrv = saida; }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr9() { // cmds : cmds ';' cmd
        { ((Bloco)((Bloco)yysv[yysp-3])).add(((Cmd)yysv[yysp-1])); yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr10() { // cmds : var cmd
        { yyrv = new Bloco(((java.util.List)yysv[yysp-2]), ((Cmd)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 83: return 86;
            case 76: return 81;
            case 42: return 62;
            case 14: return 31;
            case 9: return 22;
            case 0: return 2;
            default: return 88;
        }
    }

    private int yyr15() { // decl : ids ':' tipo
        { yyrv = new Decl(((String)yysv[yysp-1]), ((java.util.List)yysv[yysp-3])); }
        yysv[yysp-=3] = yyrv;
        switch (yyst[yysp-1]) {
            case 34: return 54;
            default: return 17;
        }
    }

    private int yyr13() { // decls : decls ',' decl
        { ((java.util.List)yysv[yysp-3]).add(((Decl)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypdecls();
    }

    private int yyr14() { // decls : decl
        { java.util.List<Decl> l = new java.util.ArrayList<Decl>();
                     l.add(((Decl)yysv[yysp-1])); yyrv = l; }
        yysv[yysp-=1] = yyrv;
        return yypdecls();
    }

    private int yypdecls() {
        switch (yyst[yysp-1]) {
            case 7: return 18;
            default: return 52;
        }
    }

    private int yyr29() { // exp : exp '+' exp
        { yyrv = new Soma(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr30() { // exp : exp '-' exp
        { yyrv = new Sub(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr31() { // exp : exp '*' exp
        { yyrv = new Mult(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr32() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr33() { // exp : exp '<' exp
        { yyrv = new Menor(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr34() { // exp : exp '=' exp
        { yyrv = new Igual(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr35() { // exp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr36() { // exp : NUM
        { yyrv = new Num(((Token)yysv[yysp-1]).val); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr37() { // exp : ID
        { yyrv = new Id(((Token)yysv[yysp-1]).val); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : ID '(' ')'
        { yyrv = new ExpChamada(new Id(((Token)yysv[yysp-3]).val), new java.util.ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : ID '(' exps ')'
        { yyrv = new ExpChamada(new Id(((Token)yysv[yysp-4]).val), ((java.util.List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 96: return 99;
            case 94: return 98;
            case 89: return 93;
            case 87: return 91;
            case 61: return 75;
            case 51: return 72;
            case 48: return 68;
            case 47: return 67;
            case 46: return 66;
            case 45: return 65;
            case 44: return 64;
            case 43: return 63;
            case 29: return 50;
            case 24: return 38;
            case 15: return 32;
            case 12: return 26;
            default: return 39;
        }
    }

    private int yyr40() { // exps : exps ',' exp
        { ((java.util.List<Exp>)((java.util.List)yysv[yysp-3])).add(((Exp)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr41() { // exps : exp
        { java.util.List<Exp> exps = new java.util.ArrayList<Exp>(); exps.add(((Exp)yysv[yysp-1])); yyrv = exps; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 25: return 40;
            default: return 69;
        }
    }

    private int yyr19() { // ids : ids ',' ID
        { ((java.util.List<Id>)((java.util.List)yysv[yysp-3])).add(new Id(((Token)yysv[yysp-1]).val)); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 19;
    }

    private int yyr20() { // ids : ID
        { yyrv = new java.util.ArrayList<Id>();
                     ((java.util.List<Id>)yyrv).add(new Id(((Token)yysv[yysp-1]).val)); }
        yysv[yysp-=1] = yyrv;
        return 19;
    }

    private int yyr5() { // proc : PROCEDURE ID '(' ')' ':' tipo BEGIN cmds ';' RETURN exp END
        { yyrv = new Proc(new Id(((Token)yysv[yysp-11]).val), new java.util.ArrayList<Decl>(), ((String)yysv[yysp-7]), ((Bloco)yysv[yysp-5]), ((Exp)yysv[yysp-2])); }
        yysv[yysp-=12] = yyrv;
        return yypproc();
    }

    private int yyr6() { // proc : PROCEDURE ID '(' decls ')' ':' tipo BEGIN cmds ';' RETURN exp END
        { yyrv = new Proc(new Id(((Token)yysv[yysp-12]).val), ((java.util.List)yysv[yysp-10]), ((String)yysv[yysp-7]), ((Bloco)yysv[yysp-5]), ((Exp)yysv[yysp-2])); }
        yysv[yysp-=13] = yyrv;
        return yypproc();
    }

    private int yyr7() { // proc : PROCEDURE ID '(' ')' ':' tipo BEGIN RETURN exp END
        { yyrv = new Proc(new Id(((Token)yysv[yysp-9]).val), new java.util.ArrayList<Decl>(), ((String)yysv[yysp-5]), null, ((Exp)yysv[yysp-2])); }
        yysv[yysp-=10] = yyrv;
        return yypproc();
    }

    private int yyr8() { // proc : PROCEDURE ID '(' decls ')' ':' tipo BEGIN RETURN exp END
        { yyrv = new Proc(new Id(((Token)yysv[yysp-10]).val), ((java.util.List)yysv[yysp-8]), ((String)yysv[yysp-5]), null, ((Exp)yysv[yysp-2])); }
        yysv[yysp-=11] = yyrv;
        return yypproc();
    }

    private int yypproc() {
        switch (yyst[yysp-1]) {
            case 0: return 3;
            default: return 23;
        }
    }

    private int yyr3() { // procs : procs ';' proc
        { ((java.util.List)((java.util.List)yysv[yysp-3])).add(((Proc)yysv[yysp-1])); yyrv = ((java.util.List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 4;
    }

    private int yyr4() { // procs : proc
        { yyrv = new java.util.ArrayList<Proc>();
                      ((java.util.List<Proc>)yyrv).add(((Proc)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 4;
    }

    private int yyr21() { // cmd : IF exp THEN cmds END
        { yyrv = new If(((Exp)yysv[yysp-4]), ((Bloco)yysv[yysp-2])); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr22() { // cmd : IF exp THEN cmds ELSE cmds END
        { yyrv = new If(((Exp)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2])); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr23() { // cmd : REPEAT cmds UNTIL exp
        { yyrv = new Repeat(((Bloco)yysv[yysp-3]), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr24() { // cmd : ID ATRIB exp
        { yyrv = new Atrib(new Id(((Token)yysv[yysp-3]).val), ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr25() { // cmd : READ ID
        { yyrv = new Read(new Id(((Token)yysv[yysp-1]).val)); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr26() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1])); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr27() { // cmd : ID '(' ')'
        { yyrv = new CmdChamada(new Id(((Token)yysv[yysp-3]).val), new java.util.ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr28() { // cmd : ID '(' exps ')'
        { yyrv = new CmdChamada(new Id(((Token)yysv[yysp-4]).val), ((java.util.List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 5: return 10;
            default: return 21;
        }
    }

    private int yyr16() { // tipo : INT
        { yyrv = "int"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr17() { // tipo : REAL
        { yyrv = "real"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr18() { // tipo : BOOL
        { yyrv = "bool"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 74: return 80;
            case 37: return 56;
            default: return 82;
        }
    }

    private int yyr11() { // var : VAR decls ';'
        { yyrv = ((java.util.List)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return 5;
    }

    private int yyr12() { // var : /* empty */
        { yyrv = new java.util.ArrayList<Decl>(); }
        yysv[yysp-=0] = yyrv;
        return 5;
    }

    protected String[] yyerrmsgs = {
    };


ScannerJFlex scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Tiny saida; // workaround pro bug do tipo do parse()

public Parser(java.io.Reader entrada) {
  scan = new ScannerJFlex(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.leToken();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException(msg + ": " + token);
}

}
