
public class Token {
	public int tipo;
	public String val;
		
	public Token(int tipo, String val) {
		this.tipo = tipo;
		this.val = val;
	}
		
	public String toString() {
		return "<" + tipo + "," + val + ">";
	}
	
	public String toToken() {
		switch(tipo) {
		case 0: return "<<EOF>>";
		case 1: return "num";
		case 2: return "id";
		default: return val;
		}
	}
}
