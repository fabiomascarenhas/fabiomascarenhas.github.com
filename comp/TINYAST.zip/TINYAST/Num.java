
public class Num extends Node implements Exp {
	public String val;
	
	public Num(Token tok) {
		super(tok.lin);
		val = tok.lexeme;
	}
}
