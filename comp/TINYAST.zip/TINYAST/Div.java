
public class Div extends Node implements Exp {
	public Exp esq;
	public Exp dir;
	
	public Div(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}
}
