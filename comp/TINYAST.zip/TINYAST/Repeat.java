import java.util.List;

public class Repeat extends Node implements Cmd{
	public List<Cmd> corpo;
	public Exp cond;
	
	public Repeat(List<Cmd> cs, Exp cd, int _lin) {
		super(_lin);
		corpo = cs;
		cond = cd;
	}
}
