import java.util.List;

public class Prog extends Node {
	public List<Cmd> corpo;
	
	public Prog(List<Cmd> cs) {
		super(1);
		corpo = cs;
	}
}
