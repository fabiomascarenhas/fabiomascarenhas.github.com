import java.util.ArrayList;
import java.util.List;

public class If extends Node implements Cmd {
	public Exp cond;
	public List<Cmd> cthen;
	public List<Cmd> celse;
	
	public If(Exp cd, List<Cmd> ct, List<Cmd> ce, int _lin) {
		super(_lin);
		cond = cd;
		cthen = ct;
		celse = ce;
	}

	public If(Exp cd, List<Cmd> ct, int _lin) {
		this(cd, ct, new ArrayList<Cmd>(), _lin);
	}
}
