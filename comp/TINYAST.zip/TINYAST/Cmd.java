
public interface Cmd {

}
