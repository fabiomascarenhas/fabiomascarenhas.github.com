import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Driver {
	public static void main(String[] args) throws IOException {
		String name = args[0];
		File f = new File(name);
		FileReader fr = new FileReader(f);
		ScannerJFlex scan = new ScannerJFlex(fr);
		ArrayList<String> tokens = new ArrayList<String>();
		Token tok;
		while((tok = scan.leToken()).tipo != 0)
			tokens.add(tok.toToken());
		String[] stokens = tokens.toArray(new String[0]);
		String fname = f.getName();
		Grammar g = new Grammar();
		g.rules("S", "CMDS");
		g.rules("CMDS", "CMDS ; CMD");
		g.rules("CMDS", "CMD");
		g.rules("CMD", "if COND then CMDS end");
		g.rules("CMD", "if COND then CMDS else CMDS end");
		g.rules("CMD", "repeat CMDS until COND");
		g.rules("CMD", "id := EXP");
		g.rules("CMD", "read id");
		g.rules("CMD", "write EXP");
		g.rules("COND", "EXP < EXP");
		g.rules("COND", "EXP = EXP");
		g.rules("EXP" , "EXP + EXP");
		g.rules("EXP" , "EXP - EXP");
		g.rules("EXP" , "EXP * EXP");
		g.rules("EXP" , "EXP / EXP");
		g.rules("EXP" , "( EXP )");
		g.rules("EXP", "num");
		g.rules("EXP", "id");
		SLRParser parser = new SLRParser(g, new String[] { "+ -", "* /" });
		parser.setInput(stokens);
		Tree prog = parser.parse();
		prog.printDot("slr-" + fname.substring(0, fname.lastIndexOf('.')) + ".gv");
	}

}
