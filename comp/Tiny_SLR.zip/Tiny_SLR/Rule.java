import java.util.Arrays;
import java.util.Set;

public class Rule {
	public String head;
	public String[] body;
	public Set<String> firstPlus;
	
	public Rule(String head, String... body) {
		this.head = head;
		this.body = body;
	}
	
	public boolean canDerive(String term) {
		return head.equals(term);
	}
			
	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append(head);
		buf.append(" ->");
		for(String term: body) {
			buf.append(" ");
			buf.append(term);
		}
		if(firstPlus != null && !firstPlus.isEmpty()) {
			buf.append("  ");
			buf.append(firstPlus.toString());
		}
		return buf.toString();
	}
	
	public int hashCode() {
		return head.hashCode() + body.length;
	}
	
	public boolean equals(Object o) {
		if(o instanceof Rule) {
			Rule r = (Rule)o;
			return r.head.equals(head) &&
				Arrays.equals(r.body, body);
		}
		return false;
	}
}