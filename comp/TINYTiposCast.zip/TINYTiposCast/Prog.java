import java.util.List;

public class Prog extends Node {
	public Bloco corpo;
	
	public Prog(Bloco cs) {
		super(cs.lin);
		corpo = cs;
	}
	
	public void checaTipo() {
		corpo.checaTipo(null);
	}
}
