
public interface Cmd {
	void checaTipo(TabSimb<String> tipos);
}
