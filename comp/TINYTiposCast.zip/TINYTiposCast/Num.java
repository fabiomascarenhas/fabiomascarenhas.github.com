
public class Num extends Exp {
	public String val;
	
	public Num(Token tok) {
		super(tok.lin);
		val = tok.lexeme;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return "int";
	}
}
