
public class Id extends Exp {
	public String nome;
	
	public Id(Token tok) {
		super(tok.lin);
		nome = tok.lexeme;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return tipos.procurar(nome, lin);
	}
}
