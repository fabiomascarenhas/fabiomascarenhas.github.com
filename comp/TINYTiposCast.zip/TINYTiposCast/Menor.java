
public class Menor extends Exp {
	public Exp esq;
	public Exp dir;
	
	public Menor(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		String tesq = esq.checaTipo(tipos);
		String tdir = dir.checaTipo(tipos);
		if(tesq.equals("int") && tdir.equals("int"))
			return "bool";
		if(Tipo.subtipo(tesq, "real") &&
		   Tipo.subtipo(tdir, "real")) {
			if(!tesq.equals("real"))
				esq = new Cast(esq, "real");
			if(!tdir.equals("real"))
				dir = new Cast(dir, "real");
			return "bool";
		}
		throw new RuntimeException("erro de tipo na linha " + 
				lin + ", tipos da comparação < são " + tesq + " e " + tdir);
	}
}
