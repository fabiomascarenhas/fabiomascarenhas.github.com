import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;


public class Soma implements Exp {
	public Exp esq;
	public Exp dir;
	
	public Soma(Exp esq, Exp dir) {
		this.esq = esq;
		this.dir = dir;
	}

	@Override
	public int valor(Map<String, Integer> vars) {
		return esq.valor(vars) + dir.valor(vars);
	}

	@Override
	public void geraCodigo(Writer saida, List<String> vars) throws IOException {
		esq.geraCodigo(saida, vars);
		dir.geraCodigo(saida, vars);
		saida.append("iadd\n");
	}

}
