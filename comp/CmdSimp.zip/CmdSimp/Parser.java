import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

/*
PROG -> CMD ; PROG
PROG -> 
CMD  -> id = EXP
CMD  -> print EXP
EXP  -> EXP + AEXP
EXP  -> EXP - AEXP
EXP  -> AEXP
AEXP -> id
AEXP -> num
AEXP -> ( EXP )
 */
public class Parser {
	public Scanner scan;
	
	public Token prox;
	
	public Parser(Reader ent) throws IOException {
		scan = new Scanner(ent);
		prox = scan.leToken();
	}
	
	public Prog parse() throws IOException {
		ArrayList<Cmd> cmds = new ArrayList<Cmd>();
		while(prox.tipo != 0) {
			cmds.add(cmd());
			if(prox.tipo != ';')
				throw new RuntimeException("comando n�o terminado "
						+ prox);
			prox = scan.leToken();
		}
		return new Prog(cmds);
	}
	
	// CMD  -> id = EXP
	// CMD  -> print EXP
	public Cmd cmd() throws IOException {
		if(prox.tipo == 2) {
			// CMD -> id = EXP
			String id = prox.val;
			prox = scan.leToken();
			if(prox.tipo != '=')
				throw new RuntimeException("atribui��o inv�lida "+
						prox);
			prox = scan.leToken();
			Exp exp = exp();
			return new Atrib(id, exp);
		} else if(prox.tipo == 3) {
			// CMD -> print EXP
			prox = scan.leToken();
			Exp exp = exp();
			return new Print(exp);
		} else
			throw new RuntimeException("comando inv�lido " 
					+ prox);
	}
	
	// EXP  -> EXP + AEXP
	// EXP  -> EXP - AEXP
	// EXP  -> AEXP
	public Exp exp() throws IOException {
		Exp res = aexp();
		while(prox.tipo == '+' ||
				prox.tipo == '-') {
			if(prox.tipo == '+') {
				prox = scan.leToken();
				Exp dir = aexp();
				res = new Soma(res, dir);
			} else {
				prox = scan.leToken();
				Exp dir = aexp();
				res = new Sub(res, dir);
			}
		}
		return res;
	}
	
	// AEXP -> id
	// AEXP -> num
	// AEXP -> ( EXP )
	public Exp aexp() throws IOException {
		switch(prox.tipo) {
		case 1: 	// AEXP -> num
			String num = prox.val;
			prox = scan.leToken();
			return new Num(num);
		case 2:
			String id = prox.val;
			prox = scan.leToken();
			return new Id(id);
		case '(':
			prox = scan.leToken();
			Exp exp = exp();
			if(prox.tipo != ')')
				throw new RuntimeException("expressao invalida "+
						prox);
			prox = scan.leToken();
			return exp;
		default:
			throw new RuntimeException("express�o inv�lida "
					+ prox);
		}
	}
}
