import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;


public class Id implements Exp {
	public String id;
	
	public Id(String id) {
		this.id = id;
	}

	@Override
	public int valor(Map<String, Integer> vars) {
		return vars.get(id);
	}

	@Override
	public void geraCodigo(Writer saida, List<String> vars) throws IOException {
		saida.append("iload " + vars.indexOf(id) + "\n");
	}

}
