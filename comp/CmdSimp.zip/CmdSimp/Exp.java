import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;

public interface Exp {
	void codigo(List<String> vars, StringBuffer out);
	BigInteger eval(HashMap<String, BigInteger> vars);
}
