import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;

public interface Exp {
	public int valor(Map<String, Integer> vars);
	public void geraCodigo(Writer saida, List<String> vars)
			throws IOException;
}
