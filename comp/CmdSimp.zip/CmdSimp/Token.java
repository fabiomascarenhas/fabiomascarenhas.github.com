
public class Token {
	public int tipo;
	public String val;
	
	public Token(int tipo, String val) {
		this.tipo = tipo;
		this.val = val;
	}
	
	public String toString() {
		return "<" + tipo + "," + val + ">";
	}
}
