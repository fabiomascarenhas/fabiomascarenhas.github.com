import java.io.IOException;
import java.io.Reader;

// Le a entrada caractere a caractere
// e retorna o próximo token
public class Scanner {
	int la;
	int linha;
	Reader in;
	
	public Scanner(Reader _in) {
		in = _in;
		linha = 1;
		proximo();
	}
	
	public void proximo() {
		try {
			la = in.read();
			if(la == '\n') linha++;
		} catch(IOException e) {
			throw new RuntimeException("erro na leitura na linha " + linha);
		}
	}
	
	public Token token() {
		while(Character.isWhitespace(la))
			proximo();
		if(la == -1) return new Token(0, "<<EOF>>", linha);
		if(Character.isDigit(la)) {
			String num = "";
			while(Character.isDigit(la)) {
				num += Character.toString((char)la);
				proximo();
			}
			return new Token(Token.NUM, num, linha);
		} else if(Character.isJavaIdentifierStart(la)) {
			String id = "";
			while(Character.isJavaIdentifierPart(la)) {
				id += Character.toString((char)la);
				proximo();
			}
			if(id.equals("print"))
				return new Token(Token.PRINT, id, linha);
			else
				return new Token(Token.ID, id, linha);
		} else {
			Token tok = new Token(la, "" + Character.toString((char)la), linha);
			proximo();
			return tok;
		}
	}
}
