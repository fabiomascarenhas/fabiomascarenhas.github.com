package types;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import ast.Environment;
import ast.Node;

public class RecType extends Type {
	public Var var;
	public Type type;
	
	public RecType(Var var, Type type) {
		this.var = var;
		this.type = type;
	}

	@Override
	public void unify(Var v, Node n) {
		v.unify(this, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}
	
	@Override
	public void constraint(String tag, Node n) {
		type.constraint(tag, n);
	}

	@Override
	public void unify(RecType rt, Node n) {
		Map<Var, Var> rmap1 = new HashMap<Var, Var>();
		Map<Var, Var> rmap2 = new HashMap<Var, Var>();
		Var nv = new Var();
		nv.unify(Void.type, n);
		rmap1.put(var, nv);
		rmap2.put(rt.var, nv);
		type.replace(rmap1).unify(rt.type.replace(rmap2), n);
	}

	@Override
	public void unify(Func f, Node n) {
		Map<Var, Var> rmap = new HashMap<Var, Var>();
		Var nv = new Var();
		nv.unify(this, n);
		rmap.put(var, nv);
		f.unify(type.replace(rmap), n);
	}

	@Override
	public boolean occurs(Var t) {
		return type.occurs(t);
	}
	
	@Override
	public Type replace(Map<Var, Var> nvars) {
		if(nvars.containsKey(var))
			return new RecType(nvars.get(var), type.replace(nvars));
		else
			return new RecType(var, type.replace(nvars));
	}
	
	@Override
	public Type prune() {
		Map<Var, Var> rmap = new HashMap<Var, Var>();
		Type t = this.replace(rmap);
		return t;
	}
	
	@Override
	public Type generalize(Environment<Type> tenv) {
		return new RecType(var, type.generalize(tenv));
	}
	
	@Override
	public Type instantiate() {
		return new RecType(var, type.instantiate());
	}
	
	@Override
	public Set<Var> openVars() {
		Set<Var> vars = type.openVars();
		vars.remove(var);
		return vars;
	}
	
	@Override
	public String toString() {
		return "\\" + var + "." + type;
	}
}
