package types;

import ast.Node;

public class Str extends Type{
	public static Str type = new Str();
	
	private Str() {	}
	
	@Override
	public void unify(Str s, Node n) { }

	@Override
	public void unify(Var v, Node n) {
		v.unify(this, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public String toString() {
		return "str";
	}

	@Override
	public void constraint(String tag, Node n) {
		if(!tag.equals("nil") && 
				!tag.equals("eq") && 
				!tag.equals("ord"))
			n.constraintError(tag, this);
	}

}
