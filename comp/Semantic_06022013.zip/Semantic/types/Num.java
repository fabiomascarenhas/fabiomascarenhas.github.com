package types;

import ast.Node;

public class Num extends Type{
	public static Num type = new Num();
	
	private Num() {	}
	
	@Override
	public void unify(Num i, Node n) { }

	@Override
	public void unify(Var v, Node n) {
		v.unify(this, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public String toString() {
		return "num";
	}

	@Override
	public void constraint(String tag, Node n) {
		if(!tag.equals("eq") && !tag.equals("ord"))
			n.constraintError(tag, this);
	}

}
