package types;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import ast.Environment;
import ast.Node;

public class Var extends Type {
	public Type type;
	public String name;
	public HashSet<String> tags = new HashSet<String>();
	
	public static int last = 1;
	
	public Var() {
		name = "t" + last;
		last++;
	}
	
	public Var(String name) {
		this.name = name;
	}
	
	public Var(Type t) {
		type = t;
	}
	
	public void checkConstraints(Type t, Node n) {
		for(String tag: tags)
			t.constraint(tag, n);
	}
	
	@Override
	public void unify(Num i, Node n) {
		if(type == null) {
			checkConstraints(i, n);
			type = i;
		} else
			type.unify(i, n);
	}

	@Override
	public void unify(Bool b, Node n) {
		if(type == null) {
			checkConstraints(b, n);
			type = b;
		} else
			type.unify(b, n);
	}

	@Override
	public void unify(Str s, Node n) {
		if(type == null) {
			checkConstraints(s, n);
			type = s;
		} else
			type.unify(s, n);
	}

	@Override
	public void unify(Void v, Node n) {
		if(type == null) {
			checkConstraints(v, n);
			type = v;
		} else
			type.unify(v, n);
	}

	@Override
	public void unify(Var v, Node n) {
		if(v != this) {
			if(type == null) {
				if(v.type != null) {
					unify(v.type, n);
				} else {
					tags.addAll(v.tags);
					v.tags.addAll(tags);
					type = v;
				}
			} else
				type.unify(v, n);
		}
	}

	@Override 
	public void unify(RecType rt, Node n) {
		if(type == null) {
			if(!rt.occurs(this)) {
				checkConstraints(rt, n);
				type = rt;
			} else {
				checkConstraints(rt, n);
				Map<Var, Var> rmap = new HashMap<Var, Var>();
				Var nv = new Var();
				nv.tags.addAll(tags);
				rmap.put(this, nv);
				type = new RecType(nv, rt.replace(rmap));
			}
		} else
			type.unify(rt, n);
	}
	
	@Override
	public void unify(Func f, Node n) {
		if(type == null) {
			if(!f.occurs(this)) {
				checkConstraints(f, n);
				type = f;
			} else {
				checkConstraints(f, n);
				Map<Var, Var> rmap = new HashMap<Var, Var>();
				Var nv = new Var();
				nv.tags.addAll(tags);
				rmap.put(this, nv);
				type = new RecType(nv, f.replace(rmap));
//				throw new RuntimeException("recursão de " + name + " no tipo " + f.prune().toString() +
//						" em " + n.line + ", " + n.col);
			}
		} else
			type.unify(f, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public boolean occurs(Var t) {
		if(this == t)
			return true;
		if(type == null)
			return false;
		return type.occurs(t);
	}
	
	@Override
	public Type generalize(Environment<Type> tenv) {
		if(type != null)
			return type.generalize(tenv);
		else
			return this;
	}

	public String toString() {
		if(type == null) {
			StringBuffer sb = new StringBuffer();
			sb.append("<");
			sb.append(name);
			for(String tag: tags) {
				sb.append(",");
				sb.append(tag);
			}
			sb.append(">");
			return sb.toString();
		}
		return type.toString();
	}

	@Override
	public Type replace(Map<Var, Var> nvars) {
		if(type != null) {
			if(!type.occurs(this))
				return type.replace(nvars);
			else
				return type;
		} else {
			if(nvars.containsKey(this))
				return nvars.get(this);
			else
				return this;
		}
	}

	public Set<Var> openVars() {
		if(type == null) {
			Set<Var> vars = new HashSet<Var>();
			vars.add(this);
			return vars;
		}
		return type.openVars();
	}

	@Override
	public void constraint(String tag, Node n) {
		if(type == null) {
			tags.add(tag);
		} else
			type.constraint(tag, n);
	}
	
}
