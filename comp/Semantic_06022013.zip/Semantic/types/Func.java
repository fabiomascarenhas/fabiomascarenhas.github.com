package types;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import ast.Environment;
import ast.Node;

public class Func extends Type {
	public Type ret;
	public Type[] params;
	
	public Func(Type ret, Type ... params) {
		this.params = params;
		this.ret = ret;
	}
	
	@Override
	public void unify(Func f, Node n) {
		if(params.length != f.params.length)
			n.typeError(this, f);
		ret.unify(f.ret, n);
		for(int i = 0; i < params.length; i++)
			params[i].unify(f.params[i], n);
	}

	@Override
	public boolean occurs(Var t) {
		if(ret.occurs(t))
			return true;
		for(Type tp : params)
			if(tp.occurs(t))
				return true;
		return false;
	}

	@Override
	public void unify(Var v, Node n) {
		v.unify(this, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public void unify(RecType rt, Node n) {
		Map<Var, Var> rmap = new HashMap<Var, Var>();
		Var nv = new Var();
		nv.unify(rt, n);
		rmap.put(rt.var, nv);
		this.unify(rt.type.replace(rmap), n);
	}
	
	@Override
	public Type replace(Map<Var, Var> nvars) {
		Type[] sparams = new Type[params.length];
		for(int i = 0; i < params.length; i++)
			sparams[i] = params[i].replace(nvars);
		Type sret = ret.replace(nvars);
		return new Func(sret, sparams);
	}
	
	@Override
	public Type generalize(Environment<Type> tenv) {
		return new GenFunc(this, tenv);
	}
	
	@Override
	public Set<Var> openVars() {
		Set<Var> vars = ret.openVars();
		for(Type t: params) {
			vars.addAll(t.openVars());
		}
		return vars;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		if(params.length > 0)
			sb.append(params[0]);
		for(int i = 1; i < params.length; i++) {
			sb.append(",");
			sb.append(params[i]);
		}
		sb.append(") -> ");
		sb.append(ret);
		return sb.toString();
	}

	@Override
	public void constraint(String tag, Node n) {
		if(!tag.equals("nil") && !tag.equals("eq"))
			n.constraintError(tag, this);
	}
	
}
