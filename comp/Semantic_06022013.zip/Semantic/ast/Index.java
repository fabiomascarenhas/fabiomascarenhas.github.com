package ast;

import types.Type;

public class Index extends Node implements Exp {
	public Exp prefix;
	public Id field;
	
	public Index(Exp prefix, Id field, int line, int col) {
		super(line, col);
		this.prefix = prefix;
		this.field = field;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return null;
	}

	@Override
	public String label() {
		return ".";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return null;
	}

}
