package ast;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Set;

public class SymbolTable<T> implements Environment<T> {
	public HashMap<String, T> map;
	public SymbolTable<T> parent;
	
	public SymbolTable(SymbolTable<T> parent) {
		map = new HashMap<String, T>();
		this.parent = parent;
	}
	
	public SymbolTable() {
		this(null);
	}
	
	public Environment<T> extend() {
		return new SymbolTable<T>(this);
	}
	
	public T lookup(String name) {
		if(map.containsKey(name))
			return map.get(name);
		else if(parent != null)
			return parent.lookup(name);
		else
			throw new RuntimeException(name + " não declarado");
	}
	
	public void bind(String name, T value) {
		map.put(name, value);
	}
	
	public void update(String name, T value) {
		if(map.containsKey(name))
			map.put(name, value);
		else if(parent != null)
			parent.update(name,  value);
		else
			throw new RuntimeException(name + " não declarado");
	}
		
	public String toString() {
		StringBuffer buf = new StringBuffer();
		for(Entry<String, T> pair: map.entrySet()) {
			buf.append(pair.getKey());
			buf.append(": ");
			Object val = pair.getValue();
			if(val instanceof FuncVal) {
				FuncVal f = (FuncVal)val;
				if(f.env == this)
					buf.append("func with this ENV");
				else
					buf.append(val);
			} else
				buf.append(val);
			buf.append("\n");
		}
		if(parent != null) {
			buf.append("==========\n");
			buf.append(parent.toString());
		}
		return buf.toString();
	}
	
	public void printDot(String filename) {
		BufferedWriter buf;
		try {
			buf = new BufferedWriter(new FileWriter(filename));
			try {
				buf.write("digraph tree {\n");
				int i = 0;
				SymbolTable<T> cur = this;
				do {
					buf.write("" + i);
					buf.write(" [label=\"");
					buf.write(cur.toString());
					buf.write("\",shape=box]\n");
					i++;
					cur = cur.parent;
					if(cur != null) {
						buf.write((i-1) + " -> " + i + "\n");
					}
				} while(cur != null);
				buf.write("}\n");
			} finally {
				buf.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Set<T> values() {
		Set<T> set;
		if(parent == null)
			set = new HashSet<T>();
		else
			set = parent.values();
		set.addAll(map.values());
		return set;
	}
}
