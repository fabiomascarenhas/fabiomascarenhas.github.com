package ast;

public class ReturnVal extends RuntimeException {
	public Object val;
	
	public ReturnVal() {
		super();
	}
	
	public ReturnVal(Object val) {
		super();
		this.val = val;
	}
}
