
public class Questao14Rec extends ParserRL {

	public Questao14Rec(String[] input) {
		super(input);
	}

	@Override
	public Tree S() {
		return A();
	}

	public Tree A() {
		Tree res = new Tree("A");
		int atual = pos;
		try {
			Tree rascunho = new Tree("");
			rascunho.child(terminal("("));
			rascunho.child(A());
			rascunho.child(terminal(")"));
			rascunho.child(A());
			res.children.addAll(rascunho.children);
		} catch(Falha f) {
			pos = atual;
		}
		return res;
	}
}
