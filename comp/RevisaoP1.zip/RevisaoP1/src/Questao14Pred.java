
public class Questao14Pred extends ParserPred {

	public Questao14Pred(String[] input) {
		super(input);
	}

	@Override
	public Tree S() {
		return A();
	}

	public Tree A() {
		Tree res = new Tree("A");
		if(la.equals("(")) {
			res.child(terminal("("));
			res.child(A());
			res.child(terminal(")"));
			res.child(A());
		}
		return res;
	}
}
