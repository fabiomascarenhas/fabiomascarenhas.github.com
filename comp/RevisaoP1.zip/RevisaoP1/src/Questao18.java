
public class Questao18 extends ParserPred {

	public Questao18(String[] input) {
		super(input);
	}

	@Override
	public Tree S() {
		return CMD();
	}

	public Tree CMD() {
		Tree res = new Tree("CMD");
		if(la.equals("id")) {
			Tree id = new Tree(terminal("id"));
			if(la.equals(":=")) {
				res.child(ATRIB(id));
			} else {
				res.child(CHAMADA(id));
			}
		} else {
			res.child(terminal("outro"));
		}
		return res;
	}
	
	public Tree ATRIB(Tree id) {
		Tree res = new Tree("ATRIB");
		res.child(id);
		res.child(terminal(":="));
		res.child(terminal("exp"));
		return res;
	}
	
	public Tree CHAMADA(Tree id) {
		Tree res = new Tree("CHAMADA");
		res.child(id);
		res.child(terminal("("));
		res.child(terminal("exp"));
		res.child(terminal(")"));
		return res;
	}
}
