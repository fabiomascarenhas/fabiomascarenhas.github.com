import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Driver {
	public static void printAsm(String fileName, String codigo) throws IOException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write(codigo);
		buf.close();
	}

	public static void main(String[] args) throws IOException {
		File f = new File(args[0]);
		FileReader fr = new FileReader(f);
		//Scanner scan = new ScannerJF(fr);
		//Parser parser = new Parser(scan);
		//Tree arvore = parser.parse();
		ParserJACC parser = new ParserJACC(fr);
		parser.parse();
		parser.saida.checaTipo();
		String fname = f.getPath();
		fname = fname.substring(0, fname.lastIndexOf('.'));
		parser.saida.printDot(fname + ".gv");
		System.out.println(parser.saida.toString());
		printAsm(fname + ".asm", parser.saida.geraCodigo("main"));
	}
}
