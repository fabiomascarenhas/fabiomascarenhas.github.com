
public class Cast extends Exp {
	public Exp exp;
	
	public Cast(Exp _exp, String _tipo) {
		super(0);
		exp = _exp;
		tipo = _tipo;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return tipo;
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		exp.geraCodigo(ctx, vars);
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug no verificador de tipos");
	}
}
