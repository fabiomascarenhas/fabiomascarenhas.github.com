import java.util.HashMap;

public class TabSimb<T> {
	HashMap<String, T> mapa;
	TabSimb<T> pai;
	
	public TabSimb(TabSimb<T> _pai) {
		mapa = new HashMap<String, T>();
		pai = _pai;
	}
	
	public TabSimb() {
		this(null);
	}
	
	void inserir(String nome, T atrib, int lin) {
		if(!mapa.containsKey(nome)) {
			mapa.put(nome, atrib);
		} else {
			throw new RuntimeException(nome + 
					" redefinido na linha "
					+ lin);
		}
	}
	
	T procurar(String nome, int lin) {
		if(mapa.containsKey(nome)) {
			return mapa.get(nome);
		} else if(pai != null) {
			return pai.procurar(nome, lin);
		} else {
			throw new RuntimeException(nome + 
					" não existe na linha " +
					lin);
		}
	}
}
