
public class AtribCampo extends Node implements Cmd {
	public Exp reg;
	public String campo;
	public Exp rval;
	
	private Reg treg;
	
	public AtribCampo(Exp _reg, Token _campo, Exp _rval) {
		super(_campo.lin);
		campo = _campo.lexeme;
		reg = _reg;
		rval = _rval;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		treg = Prog.eregs.procurar(reg.checaTipo(tipos), lin);
		String tlval = treg.tcampos.procurar(campo, lin);
		String trval = rval.checaTipo(tipos);
		if(!Tipo.subtipo(trval, tlval))
			throw new RuntimeException("atribuição inválida na linha " +
					lin + ", esperado " + tlval + " encontrado " + trval);
		if(!tlval.equals(trval))
			rval = new Cast(rval, tlval);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		reg.geraCodigo(ctx, vars); // empilha endereço de reg
		rval.geraCodigo(ctx, vars); // empilha rval
		ctx.stfld(treg.nomes.indexOf(campo) + 1);
	}

}
