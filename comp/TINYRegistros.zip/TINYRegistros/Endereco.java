
public interface Endereco {
	void load(Contexto ctx);
	void store(Contexto ctx);
}
