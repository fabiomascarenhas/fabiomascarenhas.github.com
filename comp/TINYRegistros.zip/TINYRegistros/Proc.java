import java.util.ArrayList;
import java.util.List;

public class Proc extends Node {
	public String nome;
	public List<String> pnomes = new ArrayList<String>();
	public List<String> ptipos = new ArrayList<String>();
	public String tret;
	public Bloco corpo;
	
	public Proc(String _nome, List<Decl> _params, String _tret, Bloco _corpo, int _lin) {
		super(_lin);
		nome = _nome;
		for(Decl decl: _params) {
			for(String nome: decl.vars) {
				pnomes.add(nome);
				ptipos.add(decl.tipo);
			}
		}
		tret = _tret;
		corpo = _corpo;
	}

	
}
