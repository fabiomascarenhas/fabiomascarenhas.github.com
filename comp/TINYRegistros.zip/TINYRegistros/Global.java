
public class Global implements Endereco {
	public String nome;
	
	public Global(String _nome) {
		nome = _nome;
	}
	
	@Override
	public void load(Contexto ctx) {
		ctx.getglobal(nome);
	}

	@Override
	public void store(Contexto ctx) {
		ctx.putglobal(nome);
	}

}
