// Output created by jacc on Mon Feb 22 11:48:57 BRT 2016

interface Tokens {
    int ENDINPUT = 0;
    int ATTRIB = 1;
    int BEGIN = 2;
    int BOOL = 3;
    int ELSE = 4;
    int END = 5;
    int ID = 6;
    int IF = 7;
    int INT = 8;
    int NEW = 9;
    int NIL = 10;
    int NUM = 11;
    int PROCEDURE = 12;
    int READ = 13;
    int REAL = 14;
    int RECORD = 15;
    int REPEAT = 16;
    int SKIP = 17;
    int THEN = 18;
    int UNTIL = 19;
    int VAR = 20;
    int WRITE = 21;
    int error = 22;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '.' (code=46)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
