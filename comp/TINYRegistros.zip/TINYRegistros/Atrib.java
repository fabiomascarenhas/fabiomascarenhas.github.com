
public class Atrib extends Node implements Cmd {
	public String lval;
	public Exp rval;
	
	public Atrib(Token lv, Exp rv) {
		super(lv.lin);
		lval = lv.lexeme;
		rval = rv;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		String tlval = tipos.procurar(lval, lin);
		String trval = rval.checaTipo(tipos);
		if(!Tipo.subtipo(trval, tlval))
			throw new RuntimeException("atribuição inválida na linha " +
					lin + ", esperado " + tlval + " encontrado " + trval);
		if(!tlval.equals(trval))
			rval = new Cast(rval, tlval);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		rval.geraCodigo(ctx, vars); // empilha valor de rval
		vars.procurar(lval, lin).store(ctx); // desempilha e guarda no endereço de lval
	}
}
