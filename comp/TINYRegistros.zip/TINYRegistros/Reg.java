import java.util.ArrayList;
import java.util.List;

public class Reg extends Node {
	public String nome;
	public List<String> nomes;
	public List<String> tipos;
	
	public TabSimb<String> tcampos;
	
	public Reg(String _nome, List<Decl> _decls, int lin) {
		super(lin);
		nome = _nome;
		nomes = new ArrayList<String>();
		tipos = new ArrayList<String>();
		tcampos = new TabSimb<String>();
		for(Decl decl: _decls) {
			for(String var: decl.vars) {
				nomes.add(var);
				tipos.add(decl.tipo);
				tcampos.inserir(var, decl.tipo, decl.lin);
			}
		}
	}
}
