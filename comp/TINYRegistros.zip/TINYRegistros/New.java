
public class New extends Exp {
	public String reg;
	
	public New(Token _reg) {
		super(_reg.lin);
		reg = _reg.lexeme;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		Prog.eregs.procurar(reg, lin);
		return reg;
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		Reg treg = Prog.eregs.procurar(reg, lin);
		ctx.newrec(treg.tipos.size());
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug na análise de tipos");
	}

}
