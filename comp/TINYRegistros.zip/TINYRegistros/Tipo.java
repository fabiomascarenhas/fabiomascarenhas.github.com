import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Tipo {
	static Map<String, Set<String>> subtipoDe = new HashMap<String, Set<String>>();
	
	public static boolean subtipo(String um, String outro) {
		if(um.equals(outro)) // reflexiva
			return true;
		if(um.equals("int") && outro.equals("real"))
			return true;
		Set<String> superts = subtipoDe.get(um);
		if(superts != null && superts.contains(outro))
			return true;
		try {
			Reg reg1 = Prog.eregs.procurar(um, 0);
			Reg reg2 = Prog.eregs.procurar(outro, 0);
			if(reg1.tipos.size() < reg2.tipos.size())
				return false;
			superts = subtipoDe.get(um);
			if(superts == null) {
				superts = new HashSet<String>();
				subtipoDe.put(um, superts);
			}
			superts.add(outro);
			for(int i = 0; i < reg2.tipos.size(); i++) {
				String treg1 = reg1.tipos.get(i);
				String treg2 = reg2.tipos.get(i);
				if(!Tipo.subtipo(treg1, treg2) ||
				   !Tipo.subtipo(treg2, treg1)) {
					superts.remove(outro);
					return false;
				}
			}
			return true;
		} catch(RuntimeException re) {
		}
		return false;
	}
}
