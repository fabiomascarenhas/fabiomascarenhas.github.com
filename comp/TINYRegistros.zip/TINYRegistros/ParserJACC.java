// Output created by jacc on Mon Feb 22 11:48:57 BRT 2016


import java.util.List;
import java.util.ArrayList;

class ParserJACC implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 125:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 126:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 250;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 127:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 128:
                    switch (yytok) {
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 129:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 130:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 131:
                    switch (yytok) {
                        case ';':
                            yyn = 13;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 132:
                    yyn = yys7();
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 133:
                    switch (yytok) {
                        case ID:
                            yyn = 23;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 134:
                    switch (yytok) {
                        case ID:
                            yyn = 24;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 135:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 136:
                    yyn = yys11();
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 137:
                    yyn = yys12();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 138:
                    yyn = yys13();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 139:
                    switch (yytok) {
                        case '.':
                            yyn = 35;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 140:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 141:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 36;
                            continue;
                        case '(':
                            yyn = 37;
                            continue;
                        case '.':
                            yyn = yyr51();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 142:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 143:
                    switch (yytok) {
                        case ID:
                            yyn = 45;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 144:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 145:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                            yyn = yyr36();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 146:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 147:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 148:
                    switch (yytok) {
                        case '(':
                            yyn = 49;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 149:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 50;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 150:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 151:
                    switch (yytok) {
                        case ',':
                            yyn = 51;
                            continue;
                        case ';':
                            yyn = 52;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 152:
                    switch (yytok) {
                        case ',':
                            yyn = 53;
                            continue;
                        case ':':
                            yyn = 54;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 153:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr26();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 154:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case ';':
                            yyn = 55;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ID:
                            yyn = 56;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    switch (yytok) {
                        case '.':
                            yyn = 68;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    yyn = yys40();
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    switch (yytok) {
                        case ID:
                            yyn = 70;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys42();
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                            yyn = yyr33();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case UNTIL:
                            yyn = 72;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    yyn = yys47();
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    yyn = yys48();
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                        case ')':
                            yyn = 75;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case ID:
                            yyn = 28;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys52();
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    switch (yytok) {
                        case ID:
                            yyn = 78;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    switch (yytok) {
                        case BOOL:
                            yyn = 80;
                            continue;
                        case ID:
                            yyn = 81;
                            continue;
                        case INT:
                            yyn = 82;
                            continue;
                        case REAL:
                            yyn = 83;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 85;
                            continue;
                        case '.':
                            yyn = yyr52();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    yyn = yys57();
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    switch (yytok) {
                        case ')':
                            yyn = 86;
                            continue;
                        case ',':
                            yyn = 87;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    yyn = yys61();
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    switch (yytok) {
                        case ID:
                            yyn = 95;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    yyn = yys71();
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    switch (yytok) {
                        case '.':
                            yyn = yyr53();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    switch (yytok) {
                        case ',':
                            yyn = 51;
                            continue;
                        case ')':
                            yyn = 100;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 101;
                            continue;
                        case ':':
                            yyn = 102;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    switch (yytok) {
                        case ',':
                            yyn = 51;
                            continue;
                        case END:
                            yyn = 103;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    switch (yytok) {
                        case ':':
                        case ',':
                            yyn = yyr25();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 204:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 205:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr23();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 206:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr24();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 207:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr21();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 208:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr22();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 209:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 210:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 211:
                    yyn = yys86();
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 212:
                    switch (yytok) {
                        case ID:
                            yyn = 40;
                            continue;
                        case NEW:
                            yyn = 41;
                            continue;
                        case NIL:
                            yyn = 42;
                            continue;
                        case NUM:
                            yyn = 43;
                            continue;
                        case '(':
                            yyn = 44;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 213:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case ELSE:
                            yyn = 106;
                            continue;
                        case END:
                            yyn = 107;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 214:
                    yyn = yys89();
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 215:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 216:
                    yyn = yys91();
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 217:
                    yyn = yys92();
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 218:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 219:
                    yyn = yys94();
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 220:
                    yyn = yys95();
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 221:
                    switch (yytok) {
                        case ',':
                            yyn = 87;
                            continue;
                        case ')':
                            yyn = 108;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 222:
                    yyn = yys97();
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 223:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 224:
                    yyn = yys99();
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 225:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 109;
                            continue;
                        case ':':
                            yyn = 110;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 226:
                    yyn = yys101();
                    continue;

                case 102:
                    yyst[yysp] = 102;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 227:
                    switch (yytok) {
                        case BOOL:
                            yyn = 80;
                            continue;
                        case ID:
                            yyn = 81;
                            continue;
                        case INT:
                            yyn = 82;
                            continue;
                        case REAL:
                            yyn = 83;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 103:
                    yyst[yysp] = 103;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 228:
                    switch (yytok) {
                        case ';':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 104:
                    yyst[yysp] = 104;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 229:
                    yyn = yys104();
                    continue;

                case 105:
                    yyst[yysp] = 105;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 230:
                    yyn = yys105();
                    continue;

                case 106:
                    yyst[yysp] = 106;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 231:
                    yyn = yys106();
                    continue;

                case 107:
                    yyst[yysp] = 107;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 232:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 108:
                    yyst[yysp] = 108;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 233:
                    yyn = yys108();
                    continue;

                case 109:
                    yyst[yysp] = 109;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 234:
                    yyn = yys109();
                    continue;

                case 110:
                    yyst[yysp] = 110;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 235:
                    switch (yytok) {
                        case BOOL:
                            yyn = 80;
                            continue;
                        case ID:
                            yyn = 81;
                            continue;
                        case INT:
                            yyn = 82;
                            continue;
                        case REAL:
                            yyn = 83;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 111:
                    yyst[yysp] = 111;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 236:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 116;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 112:
                    yyst[yysp] = 112;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 237:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 117;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 113:
                    yyst[yysp] = 113;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 238:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 118;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 114:
                    yyst[yysp] = 114;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 239:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 119;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 115:
                    yyst[yysp] = 115;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 240:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 120;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 116:
                    yyst[yysp] = 116;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 241:
                    switch (yytok) {
                        case ';':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 117:
                    yyst[yysp] = 117;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 242:
                    yyn = yys117();
                    continue;

                case 118:
                    yyst[yysp] = 118;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 243:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ENDINPUT:
                        case ';':
                        case ELSE:
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 119:
                    yyst[yysp] = 119;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 244:
                    switch (yytok) {
                        case ';':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 120:
                    yyst[yysp] = 120;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 245:
                    yyn = yys120();
                    continue;

                case 121:
                    yyst[yysp] = 121;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 246:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 123;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 122:
                    yyst[yysp] = 122;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 247:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                        case END:
                            yyn = 124;
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 123:
                    yyst[yysp] = 123;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 248:
                    switch (yytok) {
                        case ';':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 124:
                    yyst[yysp] = 124;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 249:
                    switch (yytok) {
                        case ';':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 253;
                    continue;

                case 250:
                    return true;
                case 251:
                    yyerror("stack overflow");
                case 252:
                    return false;
                case 253:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case RECORD:
                return 9;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys7() {
        switch (yytok) {
            case ID:
                return 16;
            case IF:
                return 17;
            case READ:
                return 18;
            case REPEAT:
                return 19;
            case SKIP:
                return 20;
            case WRITE:
                return 21;
            case '(':
                return 22;
        }
        return 253;
    }

    private int yys11() {
        switch (yytok) {
            case ID:
                return 16;
            case IF:
                return 17;
            case READ:
                return 18;
            case REPEAT:
                return 19;
            case SKIP:
                return 20;
            case WRITE:
                return 21;
            case '(':
                return 22;
        }
        return 253;
    }

    private int yys12() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys13() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case RECORD:
                return 9;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys19() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys37() {
        switch (yytok) {
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case '(':
                return 44;
            case ')':
                return 60;
        }
        return 253;
    }

    private int yys38() {
        switch (yytok) {
            case THEN:
                return 61;
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
        }
        return 253;
    }

    private int yys40() {
        switch (yytok) {
            case '(':
                return 69;
            case '/':
            case '-':
            case '+':
            case '*':
            case ')':
            case ',':
            case END:
            case UNTIL:
            case THEN:
            case '=':
            case '<':
            case ';':
            case ELSE:
            case ENDINPUT:
                return yyr45();
            case '.':
                return yyr51();
        }
        return 253;
    }

    private int yys42() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr49();
        }
        return 253;
    }

    private int yys43() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr44();
        }
        return 253;
    }

    private int yys47() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case END:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case ELSE:
                return yyr32();
        }
        return 253;
    }

    private int yys48() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ')':
                return 73;
        }
        return 253;
    }

    private int yys52() {
        switch (yytok) {
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr16();
        }
        return 253;
    }

    private int yys55() {
        switch (yytok) {
            case PROCEDURE:
                return 8;
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys57() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case END:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case ELSE:
                return yyr30();
        }
        return 253;
    }

    private int yys58() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ',':
            case ')':
                return yyr57();
        }
        return 253;
    }

    private int yys60() {
        switch (yytok) {
            case '.':
                return yyr54();
            case END:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case ELSE:
                return yyr34();
        }
        return 253;
    }

    private int yys61() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys69() {
        switch (yytok) {
            case ID:
                return 40;
            case NEW:
                return 41;
            case NIL:
                return 42;
            case NUM:
                return 43;
            case '(':
                return 44;
            case ')':
                return 97;
        }
        return 253;
    }

    private int yys70() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr48();
        }
        return 253;
    }

    private int yys71() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ')':
                return 98;
        }
        return 253;
    }

    private int yys86() {
        switch (yytok) {
            case '.':
                return yyr55();
            case END:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case ELSE:
                return yyr35();
        }
        return 253;
    }

    private int yys89() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr40();
        }
        return 253;
    }

    private int yys90() {
        switch (yytok) {
            case '*':
                return 62;
            case '/':
                return 65;
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr39();
        }
        return 253;
    }

    private int yys91() {
        switch (yytok) {
            case '*':
                return 62;
            case '/':
                return 65;
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr41();
        }
        return 253;
    }

    private int yys92() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr42();
        }
        return 253;
    }

    private int yys93() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case ',':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr37();
        }
        return 253;
    }

    private int yys94() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case ',':
            case ')':
            case END:
            case UNTIL:
            case THEN:
            case ENDINPUT:
            case '=':
            case '<':
            case ';':
            case ELSE:
                return yyr38();
        }
        return 253;
    }

    private int yys95() {
        switch (yytok) {
            case '/':
            case '-':
            case '+':
            case '*':
            case ')':
            case ',':
            case END:
            case UNTIL:
            case THEN:
            case '=':
            case '<':
            case ';':
            case ELSE:
            case ENDINPUT:
                return yyr50();
            case '.':
                return yyr52();
        }
        return 253;
    }

    private int yys97() {
        switch (yytok) {
            case '/':
            case '-':
            case '+':
            case '*':
            case ')':
            case ',':
            case END:
            case UNTIL:
            case THEN:
            case '=':
            case '<':
            case ';':
            case ELSE:
            case ENDINPUT:
                return yyr46();
            case '.':
                return yyr54();
        }
        return 253;
    }

    private int yys98() {
        switch (yytok) {
            case '/':
            case '-':
            case '+':
            case '*':
            case ')':
            case ',':
            case END:
            case UNTIL:
            case THEN:
            case '=':
            case '<':
            case ';':
            case ELSE:
            case ENDINPUT:
                return yyr43();
            case '.':
                return yyr53();
        }
        return 253;
    }

    private int yys99() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case END:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case ELSE:
                return yyr29();
        }
        return 253;
    }

    private int yys101() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys104() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case END:
            case UNTIL:
            case ENDINPUT:
            case ';':
            case ELSE:
                return yyr31();
        }
        return 253;
    }

    private int yys105() {
        switch (yytok) {
            case '*':
                return 62;
            case '+':
                return 63;
            case '-':
                return 64;
            case '/':
                return 65;
            case '<':
                return 66;
            case '=':
                return 67;
            case ',':
            case ')':
                return yyr56();
        }
        return 253;
    }

    private int yys106() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys108() {
        switch (yytok) {
            case '/':
            case '-':
            case '+':
            case '*':
            case ')':
            case ',':
            case END:
            case UNTIL:
            case THEN:
            case '=':
            case '<':
            case ';':
            case ELSE:
            case ENDINPUT:
                return yyr47();
            case '.':
                return yyr55();
        }
        return 253;
    }

    private int yys109() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys117() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yys120() {
        switch (yytok) {
            case VAR:
                return 10;
            case IF:
            case READ:
            case ID:
            case '(':
            case WRITE:
            case SKIP:
            case REPEAT:
                return yyr17();
        }
        return 253;
    }

    private int yyr1() { // s : regs ';' procs ';' cmds
        { saida = new Prog(((List)yysv[yysp-5]), ((List)yysv[yysp-3]), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=5] = yyrv;
        return 1;
    }

    private int yyr2() { // s : regs ';' cmds
        { saida = new Prog(((List)yysv[yysp-3]), new ArrayList<Proc>(), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr3() { // s : procs ';' cmds
        { saida = new Prog(new ArrayList<Reg>(), ((List)yysv[yysp-3]), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr4() { // s : cmds
        { saida = new Prog(new ArrayList<Reg>(), new ArrayList<Proc>(), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr14() { // cmds : cmds ';' cmd
        { ((Bloco)yysv[yysp-3]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr15() { // cmds : var cmd
        { ((Bloco)yysv[yysp-2]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-2]);  }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 117: return 121;
            case 109: return 114;
            case 106: return 113;
            case 101: return 111;
            case 61: return 88;
            case 55: return 84;
            case 19: return 46;
            case 13: return 32;
            case 12: return 30;
            case 0: return 2;
            default: return 122;
        }
    }

    private int yyr20() { // decl : ids ':' tipo
        { yyrv = new Decl(((List)yysv[yysp-3]), ((String)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        switch (yyst[yysp-1]) {
            case 51: return 77;
            default: return 25;
        }
    }

    private int yyr18() { // decls : decls ',' decl
        { ((List)yysv[yysp-3]).add(((Decl)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypdecls();
    }

    private int yyr19() { // decls : decl
        { List<Decl> decls = new ArrayList<Decl>();
                         decls.add(((Decl)yysv[yysp-1]));
                         yyrv = decls; }
        yysv[yysp-=1] = yyrv;
        return yypdecls();
    }

    private int yypdecls() {
        switch (yyst[yysp-1]) {
            case 49: return 74;
            case 10: return 26;
            default: return 76;
        }
    }

    private int yyr37() { // exp : exp '<' exp
        { yyrv = new Menor(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin);  }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr38() { // exp : exp '=' exp
        { yyrv = new Igual(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr39() { // exp : exp '+' exp
        { yyrv = new Soma(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr40() { // exp : exp '*' exp
        { yyrv = new Mult(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr41() { // exp : exp '-' exp
        { yyrv = new Sub(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr42() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr43() { // exp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr44() { // exp : NUM
        { yyrv = new Num((Token)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr45() { // exp : ID
        { yyrv = new Id((Token)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : ID '(' ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : ID '(' exps ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : NEW ID
        { yyrv = new New((Token)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return yypexp();
    }

    private int yyr49() { // exp : NIL
        { yyrv = new Nil(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr50() { // exp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), (Token)yysv[yysp-1]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 87: return 105;
            case 85: return 104;
            case 72: return 99;
            case 67: return 94;
            case 66: return 93;
            case 65: return 92;
            case 64: return 91;
            case 63: return 90;
            case 62: return 89;
            case 44: return 71;
            case 36: return 57;
            case 22: return 48;
            case 21: return 47;
            case 17: return 38;
            default: return 58;
        }
    }

    private int yyr56() { // exps : exps ',' exp
        { ((List)yysv[yysp-3]).add(((Exp)yysv[yysp-1]));
                      yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr57() { // exps : exp
        { List<Exp> exps = new ArrayList<Exp>();
                      exps.add(((Exp)yysv[yysp-1]));
                      yyrv = exps; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 37: return 59;
            default: return 96;
        }
    }

    private int yyr25() { // ids : ids ',' ID
        { ((List)yysv[yysp-3]).add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 27;
    }

    private int yyr26() { // ids : ID
        { List<String> ids = new ArrayList<String>();
                     ids.add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = ids; }
        yysv[yysp-=1] = yyrv;
        return 27;
    }

    private int yyr9() { // proc : PROCEDURE ID '(' decls ')' BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-7]).lexeme, ((List)yysv[yysp-5]), "void", ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-8]).lin); }
        yysv[yysp-=8] = yyrv;
        return yypproc();
    }

    private int yyr10() { // proc : PROCEDURE ID '(' ')' BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-6]).lexeme, new ArrayList<Decl>(), "void", ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypproc();
    }

    private int yyr11() { // proc : PROCEDURE ID '(' decls ')' ':' tipo BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-9]).lexeme, ((List)yysv[yysp-7]), ((String)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-10]).lin); }
        yysv[yysp-=10] = yyrv;
        return yypproc();
    }

    private int yyr12() { // proc : PROCEDURE ID '(' ')' ':' tipo BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-8]).lexeme, new ArrayList<Decl>(), ((String)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-9]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypproc();
    }

    private int yypproc() {
        switch (yyst[yysp-1]) {
            case 13: return 3;
            case 0: return 3;
            default: return 31;
        }
    }

    private int yyr7() { // procs : procs ';' proc
        { ((List)yysv[yysp-3]).add(((Proc)yysv[yysp-1]));
                         yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypprocs();
    }

    private int yyr8() { // procs : proc
        { List<Proc> procs = new ArrayList<Proc>();
                         procs.add(((Proc)yysv[yysp-1]));
                         yyrv = procs; }
        yysv[yysp-=1] = yyrv;
        return yypprocs();
    }

    private int yypprocs() {
        switch (yyst[yysp-1]) {
            case 0: return 4;
            default: return 33;
        }
    }

    private int yyr13() { // reg : RECORD ID BEGIN decls END
        { yyrv = new Reg(((Token)yysv[yysp-4]).lexeme, ((List)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        switch (yyst[yysp-1]) {
            case 0: return 5;
            default: return 34;
        }
    }

    private int yyr5() { // regs : regs ';' reg
        { ((List)yysv[yysp-3]).add(((Reg)yysv[yysp-1]));
                      yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 6;
    }

    private int yyr6() { // regs : reg
        { List<Reg> regs = new ArrayList<Reg>();
                      regs.add(((Reg)yysv[yysp-1]));
                      yyrv = regs; }
        yysv[yysp-=1] = yyrv;
        return 6;
    }

    private int yyr51() { // rexp : ID
        { yyrv = new Id((Token)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return yyprexp();
    }

    private int yyr52() { // rexp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), (Token)yysv[yysp-1]); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr53() { // rexp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr54() { // rexp : ID '(' ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr55() { // rexp : ID '(' exps ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yyprexp();
    }

    private int yyprexp() {
        switch (yyst[yysp-1]) {
            case 11: return 14;
            case 7: return 14;
            default: return 39;
        }
    }

    private int yyr27() { // cmd : IF exp THEN cmds END
        { yyrv = new If(((Exp)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr28() { // cmd : IF exp THEN cmds ELSE cmds END
        { yyrv = new If(((Exp)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr29() { // cmd : REPEAT cmds UNTIL exp
        { yyrv = new Repeat(((Bloco)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr30() { // cmd : ID ATTRIB exp
        { yyrv = new Atrib((Token)yysv[yysp-3], ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr31() { // cmd : rexp '.' ID ATTRIB exp
        { yyrv = new AtribCampo(((Exp)yysv[yysp-5]), (Token)yysv[yysp-3], ((Exp)yysv[yysp-1])); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr32() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr33() { // cmd : READ ID
        { yyrv = new Read((Token)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr34() { // cmd : ID '(' ')'
        { yyrv = new ChamadaCmd((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr35() { // cmd : ID '(' exps ')'
        { yyrv = new ChamadaCmd((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr36() { // cmd : SKIP
        { yyrv = new Skip(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 7: return 15;
            default: return 29;
        }
    }

    private int yyr21() { // tipo : INT
        { yyrv = "int"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr22() { // tipo : REAL
        { yyrv = "real"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr23() { // tipo : BOOL
        { yyrv = "bool"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr24() { // tipo : ID
        { yyrv = ((Token)yysv[yysp-1]).lexeme; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 102: return 112;
            case 54: return 79;
            default: return 115;
        }
    }

    private int yyr16() { // var : VAR decls ';'
        { yyrv = new Bloco(((List)yysv[yysp-2]), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return 7;
    }

    private int yyr17() { // var : /* empty */
        { yyrv = new Bloco(new ArrayList<Decl>(), 0); }
        yysv[yysp-=0] = yyrv;
        return 7;
    }

    protected String[] yyerrmsgs = {
    };


Scanner scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Prog saida; // workaround pro bug do tipo do parse()

public ParserJACC(java.io.Reader entrada) {
  scan = new ScannerJF(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.token();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException("erro de sintaxe:" + msg);
}

}
