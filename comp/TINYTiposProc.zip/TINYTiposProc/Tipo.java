
public class Tipo {
	public static boolean subtipo(String um, String outro) {
		if(um.equals(outro))
			return true;
		if(um.equals("int") && outro.equals("real"))
			return true;
		return false;
	}
}
