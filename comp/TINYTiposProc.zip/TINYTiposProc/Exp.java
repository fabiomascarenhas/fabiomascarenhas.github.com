
public abstract class Exp extends Node {
	public String tipo = "INDEF";

	public Exp(int _lin) {
		super(_lin);
	}

	public String checaTipo(TabSimb<String> tipos) {
		tipo = checaTipoImpl(tipos);
		return tipo;
	}
	
	public abstract String checaTipoImpl(TabSimb<String> tipos);
}
