
public class Cast extends Exp {
	public Exp exp;
	
	public Cast(Exp _exp, String _tipo) {
		super(0);
		exp = _exp;
		tipo = _tipo;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return tipo;
	}

}
