import java.util.List;

public class Decl extends Node {
	public List<String> vars;
	public String tipo;
	
	public Decl(List<String> _vars, String _tipo) {
		super(0);
		vars = _vars;
		tipo = _tipo;
	}
	
}
