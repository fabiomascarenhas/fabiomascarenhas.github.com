import java.util.List;

public class Prog extends Node {
	public List<Proc> procs;
	public Bloco corpo;
	
	public static TabSimb<Proc> eprocs = new TabSimb<Proc>();
	
	public Prog(List<Proc> _procs, Bloco cs) {
		super(cs.lin);
		procs = _procs;
		corpo = cs;
	}
	
	public void checaTipo() {
		for(Proc proc: procs) {
			eprocs.inserir(proc.nome, proc, proc.lin);
		}
		TabSimb<String> egvars = corpo.checaTipo(null);
		for(Proc proc: procs) {
			TabSimb<String> eproc = new TabSimb<String>(egvars);
			eproc.inserir(proc.nome, proc.tret, proc.lin);
			for(int i = 0; i < proc.pnomes.size(); i++) {
				eproc.inserir(proc.pnomes.get(i),
							  proc.ptipos.get(i),
							  proc.lin);
			}
			proc.corpo.checaTipo(eproc);
		}
	}
}
