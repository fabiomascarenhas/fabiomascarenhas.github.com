import java.util.List;

public class ChamadaExp extends Exp {
	public String proc;
	public List<Exp> args;
	
	public ChamadaExp(Token tok, List<Exp> _args) {
		super(tok.lin);
		proc = tok.lexeme;
		args = _args;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		Proc tproc = Prog.eprocs.procurar(proc, lin);
		if(tproc.tret.equals("void"))
			throw new RuntimeException("procedimento sem valor de retorno usado como expressão na linha " + lin);
		if(tproc.ptipos.size() != args.size())
			throw new RuntimeException("erro na chamada de procedimento na linha " +
		            lin + ", esperados " + tproc.ptipos.size() + " parâmetros e passados " +
					args.size() + " argumentos");
		for(int i = 0; i < tproc.ptipos.size(); i++) {
			String targ = args.get(i).checaTipo(tipos);
			if(!Tipo.subtipo(targ, tproc.ptipos.get(i)))
				throw new RuntimeException("erro no " + (i+1) + "-ésimo argumento da chamada de procedimento na linha " + 
			            lin + ", esperado " + tproc.ptipos.get(i) + " e encontrado " + targ);
			if(!targ.equals(tproc.ptipos.get(i)))
				args.set(i, new Cast(args.get(i), tproc.ptipos.get(i)));
		}
		return tproc.tret;
	}

}
