import java.util.ArrayList;
import java.util.List;

public class Bloco extends Node {
	public List<Decl> vars;
	public List<Cmd> cmds;
	
	public Bloco(List<Decl> vs, int _lin) {
		super(_lin);
		vars = vs;
		cmds = new ArrayList<Cmd>();
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}
	
	public TabSimb<String> checaTipo(TabSimb<String> tipos) {
		TabSimb<String> ebloco = new TabSimb<String>(tipos);
		for(Decl decl: vars) {
			for(String nome: decl.vars) {
				ebloco.inserir(nome, decl.tipo, lin);
			}
		}
		for(Cmd cmd: cmds) {
			cmd.checaTipo(ebloco);
		}
		return ebloco;
	}
}
