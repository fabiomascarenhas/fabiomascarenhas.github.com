package ast;

import java.util.List;

import types.Type;

public class FuncStat extends Node implements Stat {
	public Id name;
	public List<Id> params;
	public Bloco body;
	
	public FuncStat(Id name, List<Id> params, Bloco body,
			int line, int col) {
		super(line, col);
		this.name = name;
		this.params = params;
		this.body = body;
	}

	@Override
	public void run(Environment<Object> env) {
		env.bind(name.name, null);
		env.update(name.name, new FuncVal(params, body, env));
	}

	@Override
	public String label() {
		return "function";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type[] tparams = new Type[params.size()];
		Environment<Type> tbody = tenv.extend();
		for(int i = 0; i < tparams.length; i++) {
			tparams[i] = new types.Var();
			tbody.bind(params.get(i).name, tparams[i]);
		}
		Type tret = new types.Var();
		Type tfunc = new types.Func(tret, tparams);
		tenv.bind(name.name, tfunc);
		tbody.bind("$retval", tret);
		try {
			body.tcStat(tbody);
			tbody.lookup("$retval").unify(types.Void.type, this);
		} catch(ReturnVal rv) { }
		System.out.println(name.name + ": " + tenv.lookup(name.name).prune());
	}

}
