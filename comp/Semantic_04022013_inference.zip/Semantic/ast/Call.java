package ast;

import java.util.List;

import types.Type;
import types.Var;

public class Call extends Node implements Exp, Stat {
	public Exp func;
	public List<Exp> args;
	
	public Call(Exp func, List<Exp> args, int line, int col) {
		super(line, col);
		this.func = func;
		this.args = args;
	}

	@Override
	public void run(Environment<Object> env) {
		eval(env);
	}
	
	@Override
	public Object eval(Environment<Object> env) {
		Func vfunc = (Func)func.eval(env);
		Object[] oargs = new Object[args.size()];
		for(int i = 0; i < oargs.length; i++)
			oargs[i] = args.get(i).eval(env);
		/*
		// Escopo dinâmico
		if(vfunc instanceof FuncVal) {
			((FuncVal)vfunc).env = env;
		}*/
		return vfunc.apply(oargs);
	}

	@Override
	public String label() {
		return "call";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type[] targs = new Type[args.size()];
		for(int i = 0; i < targs.length; i++)
			targs[i] = args.get(i).tcExp(tenv);
		types.Func tf = new types.Func(new Var(), targs);
		tf.unify(func.tcExp(tenv), this);
		return tf.ret;
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		tcExp(tenv);
	}

}
