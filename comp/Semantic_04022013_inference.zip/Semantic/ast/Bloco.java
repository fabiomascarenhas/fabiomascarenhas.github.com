package ast;

import java.util.List;

import types.Type;

public class Bloco extends Node implements Stat {
	public List<Stat> stats;
	
	public Bloco(List<Stat> stats, int line, int col) {
		super(line, col);
		this.stats = stats;
	}

	@Override
	public void run(Environment<Object> env) {
		Environment<Object> benv = env.extend();
		for(Stat s: stats)
			s.run(benv);
	}

	@Override
	public String label() {
		return "bloco";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		tenv = tenv.extend();
		for(Stat s: stats)
			s.tcStat(tenv);
	}
}
