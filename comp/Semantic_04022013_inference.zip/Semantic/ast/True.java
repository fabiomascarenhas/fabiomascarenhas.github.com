package ast;

import types.Type;

public class True extends Node implements Exp {

	public True(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return true;
	}

	@Override
	public String label() {
		return "true";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Bool.type;
	}

}
