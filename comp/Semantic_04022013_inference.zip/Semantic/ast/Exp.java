package ast;

import types.Type;

public interface Exp {
	Object eval(Environment<Object> env);
	Type tcExp(Environment<Type> tenv);
}
