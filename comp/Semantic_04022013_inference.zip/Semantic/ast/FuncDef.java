package ast;

import java.util.List;

import types.Type;

public class FuncDef extends Node implements Exp {
	public List<Id> params;
	public Bloco body;
	
	public FuncDef(List<Id> params, Bloco body,
			int line, int col) {
		super(line, col);
		this.params = params;
		this.body = body;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return new FuncVal(params, body, env);
	}

	@Override
	public String label() {
		return "function";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		tenv = tenv.extend();
		Type[] tparams = new Type[params.size()];
		for(int i = 0; i < tparams.length; i++) {
			tparams[i] = new types.Var();
			tenv.bind(params.get(i).name, tparams[i]);
		}
		Type tret = new types.Var();
		tenv.bind("$retval", tret);
		try {
			body.tcStat(tenv);
			tenv.lookup("$retval").unify(types.Void.type, this);
		} catch(ReturnVal rv) { }
		return new types.Func(tret, tparams);
	}

}
