package types;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import ast.Node;

public abstract class Type {
	
	public void unify(Num i, Node n) {
		n.typeError(this, i);
	}

	public void unify(Str s, Node n) {
		n.typeError(this, s);
	}
	
	public void unify(Bool b, Node n) {
		n.typeError(this, b);
	}
	
	public void unify(Func f, Node n) {
		n.typeError(this, f);
	}

	public void unify(Void v, Node n) {
		n.typeError(this, v);
	}

	public boolean occurs(Var t) {
		return false;
	}
	
	public Type replace(Map<Var, Var> nvars) {
		return this;
	}
	
	public Type prune() {
		//char olast = Var.last;
		//Var.last = 'A';
		//Set<Var> vars = openVars();
		Map<Var, Var> rmap = new HashMap<Var, Var>();
		/*for(Var v: vars) {
			Var nv = new Var();
			rmap.put(v, nv);
		}*/
		Type t = this.replace(rmap);
		//Var.last = olast;
		return t;
	}
		
	public Set<Var> openVars() {
		return new HashSet<Var>();
	}

	public abstract void unify(Var v, Node n);

	public abstract void unify(Type t, Node n);
		
}
