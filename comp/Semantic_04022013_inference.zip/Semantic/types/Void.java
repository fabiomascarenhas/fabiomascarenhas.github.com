package types;

import ast.Node;

public class Void extends Type {
	public static Type type = new Void();
	
	private Void() { }
	
	@Override
	public void unify(Void v, Node n) { }
	
	@Override
	public void unify(Var v, Node n) {
		v.unify(this, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public String toString() {
		return "void";
	}
}
