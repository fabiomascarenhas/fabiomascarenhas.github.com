package types;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import ast.Node;

public class Var extends Type {
	public Type type;
	public String name;
	
	public static char last = 'A';
	
	public Var() {
		name = "" + last;
		last++;
	}
	
	public Var(String name) {
		this.name = name;
	}
	
	public Var(Type t) {
		type = t;
	}
	
	@Override
	public void unify(Num i, Node n) {
		if(type == null) {
			type = i;
		} else
			type.unify(i, n);
	}

	@Override
	public void unify(Bool b, Node n) {
		if(type == null) {
			type = b;
		} else
			type.unify(b, n);
	}

	@Override
	public void unify(Str s, Node n) {
		if(type == null) {
			type = s;
		} else
			type.unify(s, n);
	}

	@Override
	public void unify(Void v, Node n) {
		if(type == null) {
			type = v;
		} else
			type.unify(v, n);
	}

	@Override
	public void unify(Var v, Node n) {
		if(v != this) {
			if(type == null) {
				if(v.type != null) {
					unify(v.type, n);
				} else {
					type = v;
				}
			} else
				type.unify(v, n);
		}
	}

	@Override
	public void unify(Func f, Node n) {
		if(type == null) {
			if(!f.occurs(this)) {
				type = f;
			} else {
				throw new RuntimeException("recursão no tipo " + f.prune().toString());
			}
		} else
			type.unify(f, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public boolean occurs(Var t) {
		if(this == t)
			return true;
		return type == null ? false : type.occurs(t);
	}
	
	public String toString() {
		if(type == null) {
			StringBuffer sb = new StringBuffer();
			sb.append("<");
			sb.append(name);
			sb.append(">");
			return sb.toString();
		} else return type.toString();
	}

	@Override
	public Type replace(Map<Var, Var> nvars) {
		if(type != null) {
			return type.replace(nvars);
		} else {
			if(nvars.containsKey(this))
				return nvars.get(this);
			else
				return this;
		}
	}

	public Set<Var> openVars() {
		if(type == null) {
			Set<Var> vars = new HashSet<Var>();
			vars.add(this);
			return vars;
		} else return type.openVars();
	}
	
}
