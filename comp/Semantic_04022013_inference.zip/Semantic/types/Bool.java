package types;

import ast.Node;

public class Bool extends Type{
	public static Bool type = new Bool();
	
	private Bool() {	}
	
	@Override
	public void unify(Bool b, Node n) { }


	@Override
	public void unify(Var v, Node n) {
		v.unify(this, n);
	}

	@Override
	public void unify(Type t, Node n) {
		t.unify(this, n);
	}

	@Override
	public String toString() {
		return "bool";
	}

}
