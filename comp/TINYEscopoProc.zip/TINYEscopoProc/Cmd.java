
public interface Cmd {
	void checaEscopo(TabSimb<Void> escopo);
}
