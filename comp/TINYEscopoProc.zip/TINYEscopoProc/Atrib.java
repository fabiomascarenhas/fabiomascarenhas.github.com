
public class Atrib extends Node implements Cmd {
	public String lval;
	public Exp rval;
	
	public Atrib(Token lv, Exp rv) {
		super(lv.lin);
		lval = lv.lexeme;
		rval = rv;
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		escopo.procurar(lval, lin);
		rval.checaEscopo(escopo);
	}
}
