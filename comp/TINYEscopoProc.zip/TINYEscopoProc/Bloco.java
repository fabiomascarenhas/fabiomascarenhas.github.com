import java.util.ArrayList;
import java.util.List;

public class Bloco extends Node {
	public List<String> vars;
	public List<Cmd> cmds;
	
	public Bloco(List<String> vs, int _lin) {
		super(_lin);
		vars = vs;
		cmds = new ArrayList<Cmd>();
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}
	
	public TabSimb<Void> checaEscopo(TabSimb<Void> escopo) {
		TabSimb<Void> ebloco = new TabSimb<Void>(escopo);
		for(String nome: vars) {
			ebloco.inserir(nome, null, lin);
		}
		for(Cmd cmd: cmds) {
			cmd.checaEscopo(ebloco);
		}
		return ebloco;
	}
}
