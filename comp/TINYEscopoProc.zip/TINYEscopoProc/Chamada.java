
public class Chamada extends Node implements Cmd {
	public String proc;
	
	public Chamada(Token tok) {
		super(tok.lin);
		proc = tok.lexeme;
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		Prog.eprocs.procurar(proc, lin);
	}

}
