
public class Id extends Node implements Exp {
	public String nome;
	
	public Id(Token tok) {
		super(tok.lin);
		nome = tok.lexeme;
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		escopo.procurar(nome, lin);
	}
}
