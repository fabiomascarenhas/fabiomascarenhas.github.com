
public class Proc extends Node {
	public String nome;
	public Bloco corpo;
	
	public Proc(String _nome, Bloco _corpo, int _lin) {
		super(_lin);
		nome = _nome;
		corpo = _corpo;
	}

	
}
