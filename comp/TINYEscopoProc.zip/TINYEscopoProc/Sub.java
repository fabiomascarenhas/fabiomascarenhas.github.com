
public class Sub extends Node implements Exp {
	public Exp esq;
	public Exp dir;
	
	public Sub(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		esq.checaEscopo(escopo);
		dir.checaEscopo(escopo);
	}
}
