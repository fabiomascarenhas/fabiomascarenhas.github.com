import java.util.List;

public class Prog extends Node {
	public List<Proc> procs;
	public Bloco corpo;
	
	public static TabSimb<Void> eprocs = new TabSimb<Void>();
	
	public Prog(List<Proc> _procs, Bloco cs) {
		super(cs.lin);
		procs = _procs;
		corpo = cs;
	}
	
	public void checaEscopo() {
		for(Proc proc: procs) {
			eprocs.inserir(proc.nome, null, proc.lin);
		}
		TabSimb<Void> egvars = corpo.checaEscopo(null);
		for(Proc proc: procs) {
			proc.corpo.checaEscopo(egvars);
		}
	}
}
