
public class Read extends Node implements Cmd {
	public String nome;
	
	public Read(Token tok) {
		super(tok.lin);
		nome = tok.lexeme;
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		escopo.procurar(nome, lin);
	}
}
