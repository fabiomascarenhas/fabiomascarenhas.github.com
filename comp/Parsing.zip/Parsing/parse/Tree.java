package parse;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Tree {
	public String term;
	public ArrayList<Tree> children;
				
	public Tree(String term) {
		this.term = term.replaceAll("\"", "\\\\\"");
		this.children = new ArrayList<Tree>();
	}

	public void child(String term) {
		children.add(new Tree(term));
	}

	public void child(Tree tree) {
		children.add(tree);
	}

	public void print(StringBuffer buf, int level) {
		for(int i = 0; i < level; i++)
			buf.append(" ");
		buf.append(term);
		if(children.isEmpty())
			buf.append("\n");
		else
			buf.append("--v\n");
		for(Tree child: children) {
			child.print(buf, level + term.length() + 2);
		}
	}
	
	public int printDot(BufferedWriter buf, int count) throws IOException {
		int me = count;
		buf.write(String.valueOf(me));
		buf.write(" [label=\"");
		buf.write(term);
		buf.write("\",shape=box];");
		for(Tree child: children) {
			count++;
			buf.write(String.valueOf(me));
			buf.write("->");
			buf.write(String.valueOf(count));
			buf.write(";\n");
			count = child.printDot(buf, count);
		}
		return count;
	}
	
	public void printDot(String fileName) throws IOException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write("digraph tree {\n");
		printDot(buf, 0);
		buf.write("}");
		buf.close();
	}
			
	public String toString() {
		StringBuffer buf = new StringBuffer();
		print(buf, 0);
		return buf.toString();
	}
}