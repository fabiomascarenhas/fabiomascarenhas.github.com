package parse;

/*
parse.Grammar g = new parse.Grammar();
g.rules("SCRIPT", "BLOCO"); // 0
g.rules("BLOCO", "STAT BLOCO"); // 1
g.rules("BLOCO", "STAT"); // 2
g.rules("STAT", "id = exp"); // 3
g.rules("STAT", "local id = exp"); // 4
g.rules("STAT", "while exp do BLOCO end"); // 5
g.rules("STAT", "if exp then BLOCO end");
g.rules("STAT", "if exp then BLOCO else BLOCO end");
 */
public class ScriptParser {
	// input[pos] � o lookahead
	public int pos;
	public String[] input;
	
	public ScriptParser(String ... input) {
		this.input = input;
		this.pos = 0;
	}
	
	public String la() {
		return pos < input.length ? input[pos] : "<<EOF>>";
	}
	
	public Tree match(String token) {
		if(token.equals(la())) {
			pos++;
			return new Tree(token);
		} else
			throw new RuntimeException("erro de sintaxe em " +
					pos + ", esperado: " + token + ", achado: " +
					la());
	}
	
	public Tree parse() {
		Tree res = script();
		if(pos < input.length)
			throw new RuntimeException("entrada n�o foi toda analisada");
		return res;
	}

	public Tree parse(int pos) {
		this.pos = pos;
		Tree res = script();
		return res;
	}

	// SCRIPT -> BLOCO
	public Tree script() {
		Tree res = new Tree("SCRIPT");
		Tree bloco = bloco();
		res.child(bloco);
		return res;
	}
	
	// BLOCO -> STAT BLOCO
	// BLOCO -> STAT
//	public Tree bloco() {
//		Tree res = new Tree("BLOCO");
//		// L� o prefixo comum (STAT)
//		Tree stat = stat();
//		res.child(stat);
//		// Testa qual sufixo escolher
//		switch(la()) {
//		// Conjunto FIRST(BLOCO)
//		case "if": case "while": case "id": case "local":
//			Tree bloco = bloco();
//			res.child(bloco);
//		}
//		return res;
//	}

	// BLOCO -> STAT {STAT}
	public Tree bloco() {
		Tree res = new Tree("BLOCO");
		// L� o primeiro STAT
		res.child(stat());
		String la = la();
		// Conjunto FIRST(STAT)
		while(la.equals("if") || la.equals("while") ||
				la.equals("id") || la.equals("local")) {
			res.child(stat());
			la = la();
		}
		return res;
	}

	// STAT -> id = exp
	// STAT -> local id = exp
	// STAT -> while exp do BLOCO end
	// STAT -> if exp then BLOCO end
	// STAT -> if exp then BLOCO else BLOCO end
	public Tree stat() {
		Tree res = new Tree("STAT");
		switch(la()) {
		case "id": // STAT -> id = exp
			res.child(match("id"));
			res.child(match("="));
			res.child(match("exp"));
			break;
		case "local": // STAT -> local id = exp
			res.child(match("local"));
			res.child(match("id"));
			res.child(match("="));
			res.child(match("exp"));
			break;
		case "while": // STAT -> while exp do BLOCO end
			res.child(match("while"));
			res.child(match("exp"));
			res.child(match("do"));
			res.child(bloco());
			res.child(match("end"));
			break;
		// STAT -> if exp then BLOCO end
		// STAT -> if exp then BLOCO else BLOCO end
		// ou STAT -> if exp then BLOCO [else BLOCO] end
		case "if":
			res.child(match("if"));
			res.child(match("exp"));
			res.child(match("then"));
			res.child(bloco());
			switch(la()) {
			case "else": // else BLOCO
				res.child(match("else"));
				res.child(bloco());
				break;
			}
			res.child(match("end"));
			break;
		default:
			throw new RuntimeException("comando inv�lido em " + pos +
					", come�ando com: " + la());	
		}
		return res;
	}

}
