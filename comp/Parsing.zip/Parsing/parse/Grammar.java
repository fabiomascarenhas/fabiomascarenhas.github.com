package parse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Stack;

public class Grammar {
	public class Rule {
		public String head;
		public String[] body;
		public Set<String> firstPlus;
		
		public Rule(String head, String... body) {
			this.head = head;
			this.body = body;
		}
		
		public boolean canDerive(String term) {
			return head.equals(term);
		}
				
		public String toString() {
			StringBuffer buf = new StringBuffer();
			buf.append(head);
			buf.append(" ->");
			for(String term: body) {
				buf.append(" ");
				buf.append(term);
			}
			if(firstPlus != null && !firstPlus.isEmpty()) {
				buf.append("  ");
				buf.append(firstPlus.toString());
			}
			return buf.toString();
		}
		
		public int hashCode() {
			return head.hashCode() + body.length;
		}
		
		public boolean equals(Object o) {
			if(o instanceof Rule) {
				Rule r = (Rule)o;
				return r.head.equals(head) &&
					Arrays.equals(r.body, body);
			}
			return false;
		}
	}
		
	public ArrayList<Rule> rules = new ArrayList<Rule>();
	public Set<String> variables = new HashSet<String>();
	public Set<String> terminals = new HashSet<String>();
	public Set<String> lexicon = new HashSet<String>();
	
	public Map<String, Set<String>> FIRST =
			new HashMap<String, Set<String>>();
	public Map<String, Set<String>> FOLLOW =
			new HashMap<String, Set<String>>();
	public Map<String, Boolean> nullable =
			new HashMap<String, Boolean>();
	public boolean ll1;
	
	public Grammar() { }
	
	public void rule(String head, String... body) {
		lexicon.add(head);
		variables.add(head);
		terminals.remove(head);
		for(String term: body) {
			lexicon.add(term);
			if(!variables.contains(term))
				terminals.add(term);
		}
		rules.add(new Rule(head, body));
	}
	
	public void rules(String head, String body) {
		if(body.equals(""))
			this.rule(head, new String[0]);
		else
			this.rule(head, body.split("[ ]+"));
	}
	
	public String toString() {
		StringBuffer buf = new StringBuffer();
		for(int i = 0; i < rules.size(); i++) {
			buf.append(i + ": ");
			buf.append(rules.get(i).toString());
			buf.append("\n");
		}
		return buf.toString();
	}
	
	public String[] leftDerive1(String[] form, int rl) {
		String[] nil = new String[] {};
		ArrayList<String> dform = new ArrayList<String>();
		boolean found = false;
		for(String term: form) {
			Rule r = rules.get(rl);
			if(!found && r.canDerive(term)) {
				found = true;
				for(String bterm: r.body) {
					dform.add(bterm);
				}
			} else {
				dform.add(term);
			}
		}
		return dform.toArray(nil);
	}

	public String[] rightDerive1(String[] form, int rl) {
		String[] nil = new String[] {};
		ArrayList<String> dform = new ArrayList<String>();
		boolean found = false;
		Rule r = rules.get(rl);
		for(int i = form.length-1; i >= 0; i--) {
			String term = form[i];
			if(!found && r.canDerive(term)) {
				found = true;
				for(int j = r.body.length-1; j >= 0; j--){
					String bterm = r.body[j];
					dform.add(0, bterm);;
				}
			} else {
				dform.add(0, term);
			}
		}
		return dform.toArray(nil);
	}

	public String[] leftDerive(String[] form, int... rls) {
		for(int rl: rls) {
			form = leftDerive1(form, rl);
		}
		return form;
	}

	public String[] rightDerive(String[] form, int... rls) {
		for(int rl: rls) {
			form = rightDerive1(form, rl);
		}
		return form;
	}

	public String[] leftDerive(String start, int... rls) {
		return leftDerive(new String[] { start }, rls);
	}

	public String[] rightDerive(String start, int... rls) {
		return rightDerive(new String[] { start }, rls);
	}
	
	public String[] derive(String[] form, int... rls) {
		return leftDerive(form, rls);
	}
	
	public String[] derive(String start, int... rls) {
		return leftDerive(start, rls);
	}

	public String leftDerivation(String start, int... rls) {
		StringBuffer buf = new StringBuffer();
		buf.append(start);
		String[] form = new String[] { start };
		for(int rl: rls) {
			buf.append(" -" + rl + "->");
			form = leftDerive1(form, rl);
			buf.append(join(form, " "));
			buf.append("\n");
		}
		return buf.toString();
	}

	public String derivation(String start, int... rls) {
		return leftDerivation(start, rls);
	}

	public String rightDerivation(String start, int... rls) {
		StringBuffer buf = new StringBuffer();
		buf.append(start);
		String[] form = new String[] { start };
		for(int rl: rls) {
			buf.append(" -" + rl + "->");
			form = rightDerive1(form, rl);
			buf.append(join(form, " "));
			buf.append("\n");
		}
		return buf.toString();
	}

	public boolean treeDerive1(Tree t, int rl) {
		Rule r = rules.get(rl);
		if(t.children.isEmpty()) {
			if(r.canDerive(t.term)) {
				for(String bterm: r.body) {
					t.child(bterm);
				}
				return true;
			} else return false;
		} else {
			boolean found = false;
			for(Tree child: t.children) {
				if(treeDerive1(child, rl)) {
					found = true;
					break;
				}
			}
			return found;
		}
	}
	
	public Tree treeDerive(String start, int... rls) {
		Tree t = new Tree(start);
		for(int rl : rls) {
			treeDerive1(t, rl);
		}
		return t;
	}
	
	public boolean isNullable(String ... terms) {
		boolean isnull = true;
		for(String term: terms) {
			if(!nullable.get(term)) {
				isnull = false;
				break;
			}
		}
		return isnull;
	}

	public boolean isNullable(String[] terms, int i, int j) {
		boolean isnull = true;
		for(; i <= j ; i++) {
			if(!nullable.get(terms[i])) {
				isnull = false;
				break;
			}
		}
		return isnull;
	}

	public void computeSets() {
		for(String term: lexicon) {
			FIRST.put(term, new HashSet<String>());
			nullable.put(term, false);
		}
		for(String term: variables) {
			FOLLOW.put(term, new HashSet<String>());
		}
		for(String term: terminals) {
			FIRST.get(term).add(term);
		}
		FOLLOW.get(rules.get(0).head).add("<<EOF>>");
		boolean changed;
		do {
			changed = false;
			for(Rule r: rules) {
				if(isNullable(r.body))
					changed = !nullable.put(r.head, true) || changed;
				for(int i = 0; i < r.body.length; i++) {
					if(isNullable(r.body, 0, i-1)) {
						changed = FIRST.get(r.head).addAll(FIRST.get(r.body[i]))
								|| changed;
					}
					if(variables.contains(r.body[i]) &&
							isNullable(r.body, i+1, r.body.length-1)) {
						changed = FOLLOW.get(r.body[i]).addAll(FOLLOW.get(r.head))
								|| changed;
					}
					for(int j = i + 1; j < r.body.length; j++) {
						if(variables.contains(r.body[i]) && 
								(i + 1 == j || isNullable(r.body, i+1, j-1))) {
							changed = FOLLOW.get(r.body[i]).addAll(FIRST.get(r.body[j]))
									|| changed;
						}
					}
				}
			}
		} while(changed);
		ll1 = true;
		for(String var: variables) {
			Set<String> terms = new HashSet<String>();
			for(Rule r: rules) {
				if(r.head.equals(var)) {
					r.firstPlus = firstPlus(r.head, r.body);
					for(String t: r.firstPlus) {
						if(!terms.add(t))
							ll1 = false;
					}
				}
			}
		}
	}
	
	public Set<String> firstPlus(String head, String ... terms) {
		Set<String> res = new HashSet<String>();
		for(String term: terms) {
			res.addAll(FIRST.get(term));
			if(!nullable.get(term))
				break;
		}
		if(isNullable(terms))
			res.addAll(FOLLOW.get(head));
		return res;
	}
	
	public HashSet<String> first(HashSet<String> last, String ... terms) {
		HashSet<String> res = new HashSet<String>();
		for(String term: terms) {
			res.addAll(FIRST.get(term));
			if(!nullable.get(term))
				break;
		}
		if(isNullable(terms))
			res.addAll(last);
		return res;
	}

	public Tree parse(String input) {
		return this.parse(input.split("[ ]+"));
	}
	
	public Tree parse(String[] input) {
		Tree tree = new Tree(rules.get(0).head);
		Stack<Tree> nextFocus = new Stack<Tree>();
		nextFocus.add(new Tree("<<EOF>>"));
		nextFocus.add(tree);
		int pos = 0; // lookahead
		while(!nextFocus.isEmpty() || pos < input.length) {
			Tree focus = nextFocus.pop();
			if(variables.contains(focus.term)) { // foco é NT
				boolean error = true;
				for(Rule r: rules) {
					if(r.head.equals(focus.term)) {
						String lookAhead = pos < input.length ? input[pos] : "<<EOF>>";
						if(r.firstPlus.contains(lookAhead)) {
							// escolho a regra r
							error = false;
							for(String term: r.body) {
								focus.child(term);
							}
							Collections.reverse(focus.children);
							nextFocus.addAll(focus.children);
							Collections.reverse(focus.children);
							break;
						}
					}
				}
				if(error) 
					throw new RuntimeException("erro de sintaxe em " + pos);
			} else { // foco é terminal
				String lookAhead = pos < input.length ? input[pos] : "<<EOF>>";
				if(focus.term.equals(lookAhead)) {
					pos++;
				} else {
					throw new RuntimeException("erro de sintaxe em " + pos +
							", input: " + input[pos] + ", foco: " +
							focus.term);
				}
			}	
		}
		return tree;
	}
	
	
	public static String join(String[] arr, String sep) {
		StringBuffer buf = new StringBuffer();
		for(String s: arr) {
			buf.append(sep);
			buf.append(s);
		}
		return buf.toString();
	}
}
