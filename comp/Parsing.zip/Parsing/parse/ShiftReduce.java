package parse;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import parse.Grammar.Rule;

public class ShiftReduce {
	public Grammar g;
	public int pos;
	public String[] input;
	public Stack<Tree> stack;
	
	public List<Integer> reductions;
	
	public ShiftReduce(Grammar g) {
		this.g = g;
	}

	public void setInput(String ... input) {
		this.input = input;
		this.pos = 0;
		this.stack = new Stack<Tree>();
		this.reductions = new ArrayList<Integer>();
		System.out.println(configuration());
	}
	
	public void setInput(String input) {
		setInput(input.split("[ ]+"));
	}
	
	public String configuration() {
		StringBuffer config = new StringBuffer();
		for(Tree item : stack) {
			config.append(item.term);
			config.append(" ");
		}
		config.append("|");
		for(int i = pos; i < input.length; i++) {
			config.append(" ");
			config.append(input[i]);
		}
		return config.toString();
	}
	
	public ShiftReduce shift() {
		stack.push(new Tree(input[pos++])); // shift
		System.out.println(configuration());
		return this;
	}
	
	public ShiftReduce shift(int n) {
		for(int i = 0; i < n; i++)
			shift();
		return this;
	}
	
	public ShiftReduce reduce(int rule) {
		Rule r = g.rules.get(rule);
		Tree node = new Tree(r.head); // nó lado esquerdo
		for(int i = r.body.length - 1; i >= 0; i--) {
			Tree child = stack.pop(); // desempilha lado direito
			if(!child.term.equals(r.body[i]))
				throw new RuntimeException("redução inválida");
			node.children.add(0, child); // constrói árvore
		}
		stack.push(node); // empilha lado esquerdo
		reductions.add(0, rule);
		System.out.println(configuration());
		return this;
	}
	
	public Tree accept() {
		if(pos == input.length && stack.size() == 1) {
			return stack.pop();
		} else
			throw new RuntimeException("erro de sintaxe");
	}
	
	public String derivation() {
		int[] rls = new int[reductions.size()];
		for(int i = 0; i < rls.length; i++)
			rls[i] = reductions.get(i);
		return g.rightDerivation(g.rules.get(0).head, rls);
	}
}
