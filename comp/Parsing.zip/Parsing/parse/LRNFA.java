package parse;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

import parse.Grammar.Rule;

public class LRNFA {
	public State init;
	public ArrayList<State> states = new ArrayList<State>();

	private static int nextState = 0;
	
	public class Item {
		public Grammar.Rule rule;
		public int dot;
		
		public Item(Grammar.Rule rule, int dot) {
			this.rule = rule;
			this.dot = dot;
		}
		
		public String toString() {
			StringBuffer buf = new StringBuffer();
			buf.append(rule.head + "->");
			if(dot == 0) buf.append(" .");
			for(int i = 0; i < rule.body.length; i++) {
				buf.append(" ");
				buf.append(rule.body[i]);
				if(dot == i + 1)
					buf.append(" .");
			}
			return buf.toString();
		}
		
		public int hashCode() {
			return Integer.rotateLeft(rule.hashCode(), dot);
		}
		
		public boolean equals(Object o) {
			if(o instanceof Item) {
				Item i = (Item)o;
				return i.dot == dot && i.rule.equals(rule);
			}
			return false;
		}
	}
	
	public class State {
		public Item item;
		public HashSet<State> epsilon = new HashSet<State>();
		public HashMap<String, State> trans = 
				new HashMap<String, State>();
		public int id = nextState++;
				
		public State(Grammar g, int rule, int dot) {
			item(new Item(g.rules.get(rule), dot));
		}
		
		public State(Item item) {
			item(item);
		}
		
		public void item(Grammar g, int rule, int dot) {
			item(new Item(g.rules.get(rule), dot));
		}

		public void item(Item item) {
			this.item = item;;
		}
		
		public void epsilon(State s) {
			epsilon.add(s);
		}
		
		public void trans(String term, State s) {
			trans.put(term, s);
		}
		
		public String label() {
			StringBuffer buf = new StringBuffer();
			buf.append(id);
			buf.append(" [label=\"");
			buf.append(item.toString());
			buf.append("\\n");
			buf.append("\",shape=box];\n");
			return buf.toString();
		}
		
		public String transitions() {
			StringBuffer buf = new StringBuffer();
			for(State s : epsilon) {
				buf.append(" ");
				buf.append(id);
				buf.append(" -> ");
				buf.append(s.id);
				buf.append(" [label=\"VAZIO\"]\n");
			}
			for(Entry<String, State> pair : trans.entrySet()) {
				buf.append(" ");
				buf.append(id);
				buf.append(" -> ");
				buf.append(pair.getValue().id);
				buf.append(" [label=\"");
				buf.append(pair.getKey());
				buf.append("\"]\n");
			}
			return buf.toString();
		}
		

		public int hashCode() {
			return item.hashCode();
		}
		
		public boolean equals(Object o) {
			if(o instanceof State) {
				State s = (State)o;
				return s.item.equals(item);
			}
			return false;
		}
		
		public String toString() {
			return item.toString();
		}
	}
	
	public State fromItem(Rule r, int dot) {
		for(State s: states) {
			if(s.item.rule.equals(r) && s.item.dot == dot)
				return s;
		}
		return null;
	}
	
	public void fill(Grammar g) {
		for(Rule r: g.rules) {
			for(int i = 0; i <= r.body.length; i++) {
				states.add(new State(new Item(r, i)));
			}
		}
		init = states.get(0);
		for(State s: states) {
			Item i = s.item;
			if(i.dot < i.rule.body.length) {
				if(g.variables.contains(i.rule.body[i.dot])) {
					for(Rule r: g.rules)
						if(r.head.equals(i.rule.body[i.dot]))
							s.epsilon(fromItem(r, 0));
				}
				s.trans(i.rule.body[i.dot], fromItem(i.rule, i.dot+1));
			}
		}
	}
	
	public LRNFA() { }
	
	public LRNFA(Grammar g) {
		fill(g);
	}
		
	public void printDot(String fileName) throws IOException {
		BufferedWriter buf = new BufferedWriter(new FileWriter(fileName));
		buf.write("digraph NFA {\n");
		for(State s: states) {
			buf.write(s.label());
		}
		for(State s: states) {
			buf.write(s.transitions());
		}
		buf.write("}\n");
		buf.close();
	}

}
