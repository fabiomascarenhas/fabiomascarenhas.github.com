// Output created by jacc on Wed Jan 16 17:06:50 BRST 2013


class Calc implements CalcTokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private parse.Tree[] yysv;
    private parse.Tree yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new parse.Tree[yyss];
        yytok = (token
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 15:
                    switch (yytok) {
                        case INTEGER:
                            yyn = 3;
                            continue;
                        case '(':
                            yyn = 4;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 16:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 30;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 17:
                    switch (yytok) {
                        case '*':
                            yyn = 5;
                            continue;
                        case '+':
                            yyn = 6;
                            continue;
                        case '-':
                            yyn = 7;
                            continue;
                        case '/':
                            yyn = 8;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 18:
                    switch (yytok) {
                        case '(':
                        case error:
                        case INTEGER:
                            yyn = 33;
                            continue;
                    }
                    yyn = yyr7();
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 19:
                    switch (yytok) {
                        case INTEGER:
                            yyn = 3;
                            continue;
                        case '(':
                            yyn = 4;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 20:
                    switch (yytok) {
                        case INTEGER:
                            yyn = 3;
                            continue;
                        case '(':
                            yyn = 4;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 21:
                    switch (yytok) {
                        case INTEGER:
                            yyn = 3;
                            continue;
                        case '(':
                            yyn = 4;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 22:
                    switch (yytok) {
                        case INTEGER:
                            yyn = 3;
                            continue;
                        case '(':
                            yyn = 4;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 23:
                    switch (yytok) {
                        case INTEGER:
                            yyn = 3;
                            continue;
                        case '(':
                            yyn = 4;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 24:
                    switch (yytok) {
                        case '*':
                            yyn = 5;
                            continue;
                        case '+':
                            yyn = 6;
                            continue;
                        case '-':
                            yyn = 7;
                            continue;
                        case '/':
                            yyn = 8;
                            continue;
                        case ')':
                            yyn = 14;
                            continue;
                    }
                    yyn = 33;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 25:
                    switch (yytok) {
                        case '(':
                        case error:
                        case INTEGER:
                            yyn = 33;
                            continue;
                    }
                    yyn = yyr4();
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 26:
                    switch (yytok) {
                        case '(':
                        case INTEGER:
                        case error:
                            yyn = 33;
                            continue;
                        case '*':
                            yyn = 5;
                            continue;
                        case '/':
                            yyn = 8;
                            continue;
                    }
                    yyn = yyr2();
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 27:
                    switch (yytok) {
                        case '(':
                        case INTEGER:
                        case error:
                            yyn = 33;
                            continue;
                        case '*':
                            yyn = 5;
                            continue;
                        case '/':
                            yyn = 8;
                            continue;
                    }
                    yyn = yyr3();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 28:
                    switch (yytok) {
                        case '(':
                        case error:
                        case INTEGER:
                            yyn = 33;
                            continue;
                    }
                    yyn = yyr5();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    yysv[yysp] = (yylval
                                 );
                    yytok = (yylex()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 29:
                    switch (yytok) {
                        case '(':
                        case error:
                        case INTEGER:
                            yyn = 33;
                            continue;
                    }
                    yyn = yyr6();
                    continue;

                case 30:
                    return true;
                case 31:
                    yyerror("stack overflow");
                case 32:
                    return false;
                case 33:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        parse.Tree[] newyysv = new parse.Tree[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yyr1() { // prog : expr
        { parse.Tree t = new parse.Tree("S"); 
                          t.child(yysv[yysp-1]); yyrv = t; yylval = t; }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr2() { // expr : expr '+' expr
        { parse.Tree t = new parse.Tree("E");
                           t.child(yysv[yysp-3]); t.child("+"); t.child(yysv[yysp-1]);
                           yyrv = t; }
        yysv[yysp-=3] = yyrv;
        return yypexpr();
    }

    private int yyr3() { // expr : expr '-' expr
        { parse.Tree t = new parse.Tree("E");
                           t.child(yysv[yysp-3]); t.child("-"); t.child(yysv[yysp-1]);
                           yyrv = t; }
        yysv[yysp-=3] = yyrv;
        return yypexpr();
    }

    private int yyr4() { // expr : expr '*' expr
        { parse.Tree t = new parse.Tree("E");
                           t.child(yysv[yysp-3]); t.child("*"); t.child(yysv[yysp-1]);
                           yyrv = t; }
        yysv[yysp-=3] = yyrv;
        return yypexpr();
    }

    private int yyr5() { // expr : expr '/' expr
        { parse.Tree t = new parse.Tree("E");
                           t.child(yysv[yysp-3]); t.child("/"); t.child(yysv[yysp-1]);
                           yyrv = t; }
        yysv[yysp-=3] = yyrv;
        return yypexpr();
    }

    private int yyr6() { // expr : '(' expr ')'
        { parse.Tree t = new parse.Tree("E");
                           t.child("("); t.child(yysv[yysp-2]); t.child(")");
                           yyrv = t; }
        yysv[yysp-=3] = yyrv;
        return yypexpr();
    }

    private int yyr7() { // expr : INTEGER
        { parse.Tree t = new parse.Tree("num");
                                         yyrv = t; }
        yysv[yysp-=1] = yyrv;
        return yypexpr();
    }

    private int yypexpr() {
        switch (yyst[yysp-1]) {
            case 7: return 12;
            case 6: return 11;
            case 5: return 10;
            case 4: return 9;
            case 0: return 2;
            default: return 13;
        }
    }

    protected String[] yyerrmsgs = {
    };


  private void yyerror(String msg) {
    System.out.println("ERROR: " + msg);
    System.exit(1);
  }

  private int c;

  /** Read a single input character from standard input.
   */
  private void nextChar() {
    if (c>=0) {
      try {
        c = System.in.read();
      } catch (Exception e) {
        c = (-1);
      }
    }
  }

  int token;
  parse.Tree yylval;

  /** Read the next token and return the
   *  corresponding integer code.
   */
  int yylex() {
    for (;;) {
      // Skip whitespace
      while (c==' ' || c=='\n' || c=='\t' || c=='\r') {
        nextChar();
      }
      if (c<0) {
        return (token=ENDINPUT);
      }
      switch (c) {
        case '+' : nextChar();
                   return token='+';
        case '-' : nextChar();
                   return token='-';
        case '*' : nextChar();
                   return token='*';
        case '/' : nextChar();
                   return token='/';
        case '(' : nextChar();
                   return token='(';
        case ')' : nextChar();
                   return token=')';
        case ';' : nextChar();
                   return token=';';
        default  : if (Character.isDigit((char)c)) {
                     int n = 0;
                       do {
                         n = 10*n + (c - '0');
                         nextChar();
                       } while (Character.isDigit((char)c));
                       //yylval = n;
                       return token=INTEGER;
                     } else {
                       yyerror("Illegal character "+c);
                       nextChar();
                     }
      }
    }
  }

  public static void main(String[] args) throws java.io.IOException {
    Calc calc = new Calc();
    calc.nextChar(); // prime the character input stream
    calc.yylex();    // prime the token input stream
    calc.parse();    // parse the input
    calc.yylval.printDot("expjacc.gv");
  }

}
