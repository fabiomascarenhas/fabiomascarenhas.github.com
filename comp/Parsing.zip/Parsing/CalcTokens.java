// Output created by jacc on Mon Jan 11 11:44:35 BRST 2016

interface CalcTokens {
    int ENDINPUT = 0;
    int INTEGER = 1;
    int error = 2;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // '-' (code=45)
    // '/' (code=47)
}
