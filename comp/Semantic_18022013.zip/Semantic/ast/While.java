package ast;

import types.Type;

public class While extends Node implements Stat {
	public Exp cond;
	public Bloco corpo;
	
	public While(Exp cond, Bloco corpo, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.corpo = corpo;
	}

	@Override
	public void run(Environment<Object> env) {
		while((Boolean)cond.eval(env)) {
			corpo.run(env);
		}
	}

	@Override
	public String label() {
		return "while";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type tcond = cond.tcExp(tenv);
		tcond.checkEq(types.Bool.type, (Node)cond);
		try {
			corpo.tcStat(tenv);
		} catch(ReturnVal rv) { }
	}

}
