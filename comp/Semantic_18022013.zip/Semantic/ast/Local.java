package ast;

import types.Type;

public class Local extends Node implements Stat{
	public Id id;
	public Exp rval;
	
	public Local(Id id, Exp rval, int line, int col) {
		super(line, col);
		this.id = id;
		this.rval = rval;
	}
	
	public String label() {
		return "=";
	}
	
	public void run(Environment<Object> env) {
		if(rval != null)
			env.bind(id.name, rval.eval(env));
		else
			env.bind(id.name, null);
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		if(id.type == null)
			id.type = rval.tcExp(tenv);
		// lado direito não pode ser nil ou resultado
		// de chamada de função com tipo de retorno void
		if(id.type != types.Any.type &&
				id.type != types.Void.type)
			tenv.bind(id.name, id.type);
		else
			throw new RuntimeException(
					"tipo inválido para declaração de variável, linha " +
					line + ", col " + col + ": " + id.type);
	}
}
