package ast;

import types.Type;

public class Nil extends Node implements Exp {

	public Nil(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return null;
	}

	@Override
	public String label() {
		return "nil";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Any.type;
	}

}
