package ast;

import types.Type;

public class Eq extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Eq(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		Object ol = l.eval(env);
		Object or = r.eval(env);
		if(ol != null && or != null)
			return ol.equals(or);
		else
			return ol == or;
	}

	@Override
	public String label() {
		return "==";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type tl = l.tcExp(tenv);
		Type tr = r.tcExp(tenv);
		tl.checkEq(tr, this);
		return types.Bool.type;
	}

}
