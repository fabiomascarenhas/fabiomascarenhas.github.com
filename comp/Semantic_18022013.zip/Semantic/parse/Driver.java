package parse;

public class Driver {
	public static ast.Environment<types.Type> globalTEnv() {
		ast.Environment<types.Type> tenv = new ast.SymbolTable<types.Type>();
		tenv.bind("print", 
						new types.Func(types.Void.type, types.Any.type));
		tenv.bind("tostring",
						new types.Func(types.Str.type, types.Any.type));
		return tenv;
	}
	
	public static ast.Environment<Object> globalEnv() {
		ast.Environment<Object> env = new ast.SymbolTable<Object>();
		env.bind("print", new ast.PrintFunc());
		env.bind("tostring", new ast.ToStringFunc());
		return env;
	}
	
	public static void main(String[] args) throws java.io.IOException {
		String filename = args[0];
		java.io.FileReader f = new java.io.FileReader(filename);
		parse.Scanner scan = new parse.Scanner(f);
		parse.ScriptParser parser = new parse.ScriptParser(scan);
		ast.Bloco bloco = parser.parseBloco();
		bloco.printDot(filename + ".gv");
		try {
			bloco.tcStat(globalTEnv());
		} catch(RuntimeException re) {
			re.printStackTrace();
		}
		bloco.run(globalEnv());
	}
}
