package parse;

import ast.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import types.Type;

public class ScriptParser {
	public Scanner input;
	public Token la;
	
	public ScriptParser(Scanner input) {
		this.input = input;
	}
	
	public Token match(int token) {
		if(la.type == token) {
			Token tok = la;
			try {
				la = input.nextToken();
			} catch(IOException e) {
				throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
			}
			return tok;
		} else
			throw new RuntimeException("erro de sintaxe em " +
					la.line + ":" + la.col + ", esperado: "
					+ token + ", achado: " +
					la.type + "(" + la.val + ")");
	}
	
	public Exp parse() {
		try {
			la = input.nextToken();
			match(Token.LPE);
			return exp();
		} catch(IOException e) {
			throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
		}
	}
	
	public Bloco parseBloco() {
		try {
			la = input.nextToken();
			match(Token.LPE);
			return bloco();
		} catch(IOException e) {
			throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
		}
	}

	public Exp parseExp(Token la) {
		this.la = la;
		return exp();
	}

	
	// BLOCO -> {STAT} [RET]
	public Bloco bloco() {
		ArrayList<Stat> stats = new ArrayList<Stat>();
		int line = la.line; int col = la.col;
		// Conjunto FIRST(STAT)
		while(la.type == Token.DO || la.type == Token.IF ||
				la.type == Token.WHILE || la.type == '(' ||
				la.type == Token.ID || la.type == Token.LOCAL ||
				la.type == Token.FUNCTION) {
			stats.add(stat());
		}
		if(la.type == Token.RETURN) {
			stats.add(ret());
		}
		return new Bloco(stats, line, col);
	}
	
	public Stat ret() {
		Token tok = match(Token.RETURN);
		return new Return(exp(), tok.line, tok.col);
	}

	public Id id() {
		Token tok_id = match(Token.ID);
		return new Id(tok_id.val, tok_id.line, tok_id.col);
	}
	
	// STAT -> do BLOCO end
	// STAT -> while EXP do BLOCO end
	// STAT -> if exp then BLOCO [else BLOCO] end
	// STAT -> local id [= EXP]
	// STAT -> function id ( [IDS] ) -> TYPE BLOCO end
	// STAT -> LVAL = EXP
	public Stat stat() {
		switch(la.type) {
		case Token.DO: // STAT -> id = exp
			match(Token.DO);
			Bloco bloco = bloco();
			match(Token.END);
			return bloco;
		case Token.WHILE: { // STAT -> while EXP do BLOCO end
			Token tok = match(Token.WHILE);
			Exp cond = exp();
			match(Token.DO);
			Bloco b = bloco();
			match(Token.END);
			return new While(cond, b, tok.line, tok.col);
		}
		// STAT -> if exp then BLOCO [else BLOCO] end
		case Token.IF: {
			Token tok = match(Token.IF);
			Exp cond = exp();
			match(Token.THEN);
			Bloco bthen = bloco();
			Bloco belse = null;
			if(la.type == Token.ELSE) {
				match(Token.ELSE);
				belse = bloco();
			}
			match(Token.END);
			return new If(cond, bthen, belse, tok.line, tok.col);
		}
		// STAT -> local id = EXP
		// STAT -> local id : TYPE
		case Token.LOCAL: { 
			Token tok = match(Token.LOCAL);
			Id id = id();
			Exp init = null;
			if(la.type == '=') {
				match('=');
				init = exp();
			} else {
				match(':');
				id.type = type();
			}
			return new Local(id, init, tok.line, tok.col);
		}
		// STAT -> function id ( [IDS] ) -> TYPE BLOCO end
		case Token.FUNCTION: {
			Token tok = match(Token.FUNCTION);
			Id id = id();
			match('(');
			List<Id> params;
			if(la.type != ')')
				params = ids();
			else
				params = new ArrayList<Id>();
			match(')');
			match(Token.FUNCTYPE);
			Type retType = type();
			Bloco b = bloco();
			match(Token.END);
			return new FuncStat(id, params, b, retType, tok.line, tok.col);
		}
		// STAT -> LVAL = EXP
		// STAT -> PEXP ( [EXPS] )
		case Token.ID:
		case '(': {
			Exp pexp = pexp();
			if(pexp instanceof Call) {
				return (Call)pexp;
			} else {
				Id id = (Id)pexp;
				Token tok = match('=');
				Exp rval = exp();
				return new Atrib(id, rval, tok.line, tok.col);
			}
		}
		default:
			throw new RuntimeException("comando inválido em " + la.line + ":" + la.col +
					", começando com: " + la.type + "(" + la.val + ")");	
		}
	}

	// EXP -> LEXP
	public Exp exp() {
		return lexp();
	}
	
	// LEXP -> REXP
	public Exp lexp() {
		return rexp();
	}
	
	// REXP   -> REXP < CEXP
	// REXP   -> REXP == CEXP
	// REXP   -> REXP ~= CEXP
	// REXP   -> CEXP
	public Exp rexp() {
		Exp res = cexp();
		while(la.type == Token.NEQ || la.type == Token.EQ
				|| la.type == '<') {
			if(la.type == Token.NEQ){ 
				Token tok = match(Token.NEQ);
				res = new Neq(res, cexp(), tok.line, tok.col);
			} else if(la.type == Token.EQ) {
				Token tok = match(Token.EQ);
				res = new Eq(res, cexp(), tok.line, tok.col);
			} else {
				Token tok = match('<');
				res = new Menor(res, cexp(), tok.line, tok.col);
			}
		}
		return res;
	}
	
	// CEXP -> AEXP .. CEXP
	// CEXP -> AEXP
	public Exp cexp() {
		Exp res = aexp();
		if(la.type == Token.CONCAT) {
			Token tok = match(Token.CONCAT);
			res = new Concat(res, cexp(), tok.line, tok.col);
		}
		return res;
	}
	
	// AEXP   -> AEXP + MEXP
	// AEXP   -> AEXP - MEXP
	// AEXP   -> MEXP
	public Exp aexp() {
		Exp res = mexp();
		while(la.type == '+' || la.type == '-') {
			if(la.type == '+') {
				Token tok = match('+');
				res = new Soma(res, mexp(), tok.line, tok.col);
			} else {
				Token tok = match('-');
				res = new Sub(res, mexp(), tok.line, tok.col);
			}
		}
		return res;
	}

	// MEXP   -> MEXP * SEXP
	// MEXP   -> MEXP / SEXP
	// MEXP   -> SEXP
	public Exp mexp() {
		Exp res = sexp();
		while(la.type == '*' || la.type == '/') {
			if(la.type == '*') {
				Token tok = match('*');
				res = new Mul(res, sexp(), tok.line, tok.col);
			} else {
				Token tok = match('/');
				res = new Div(res, sexp(), tok.line, tok.col);
			}
		}
		return res;
	}
	
	// SEXP -> num
	// SEXP -> string
	// SEXP -> nil
	// SEXP -> true
	// SEXP -> false
	// SEXP -> function ( [IDS] ) -> TYPE BLOCO end
	// SEXP -> PEXP
	public Exp sexp() {
		switch(la.type) {
		case Token.NUM: {
			Token tok = match(Token.NUM);
			return new Num(tok.val, tok.line, tok.col);
		}
		case Token.STRING: {
			Token tok = match(Token.STRING);
			return new Str(tok.val, tok.line, tok.col);
		}
		case Token.NIL: {
			Token tok = match(Token.NIL);
			return new Nil(tok.line, tok.col);
		}
		case Token.TRUE: {
			Token tok = match(Token.TRUE);
			return new True(tok.line, tok.col);
		}
		case Token.FALSE: {
			Token tok = match(Token.FALSE);
			return new False(tok.line, tok.col);
		}
		case Token.FUNCTION: {
			Token tok = match(Token.FUNCTION);
			match('(');
			List<Id> params;
			if(la.type != ')')
				params = ids();
			else
				params = new ArrayList<Id>();
			match(')');
			match(Token.FUNCTYPE);
			Type retType = type();
			Bloco b = bloco();
			match(Token.END);
			return new FuncDef(params, b, retType, tok.line, tok.col);
		}
		default:
			return pexp();
		}
	}

	// PEXP   -> id
	// PEXP   -> ( EXP )
	public Exp pexp() {
		Exp res;
		switch(la.type) {
		case Token.ID:
			res = id();
			break;
		case '(':
			match('(');
			res = exp();
			match(')');
			break;
		default:
			throw new RuntimeException("expressão inválida em " + la.line + ":" + la.col +
					", começando com: " + la.type + "(" + la.val + ")");	
		}
		while(la.type == '(' || la.type == '.') {
			if(la.type == '(') {
				Token tok = match('(');
				if(la.type != ')')
					res = new Call(res, exps(), tok.line, tok.col);
				else
					res = new Call(res, new ArrayList<Exp>(), tok.line, tok.col);
				match(')');
			} else {
				Token tok = match('.');
				Id id = id();
				res = new Index(res, id, tok.line, tok.col);
			}
		}
		return res;
	}

	public List<Exp> exps() {
		ArrayList<Exp> res = new ArrayList<Exp>();
		res.add(exp());
		while(la.type == ',') {
			match(',');
			res.add(exp());
		}
		return res;
	}

	// IDS -> id : TYPE {, id : TYPE}
	public List<Id> ids() {
		ArrayList<Id> res = new ArrayList<Id>();
		Id id = id();
		match(':');
		id.type = type();
		res.add(id);
		while(la.type == ',') {
			match(',');
			id = id();
			match(':');
			id.type = type();
			res.add(id);
		}
		return res;
	}
	
	// TYPE -> num
	// TYPE -> string
	// TYPE -> bool
	// TYPE -> void
	// TYPE -> ( [TYPES] ) -> TYPE
	public Type type() {
		switch(la.type) {
		case Token.TNUM:
			match(Token.TNUM);
			return types.Num.type;
		case Token.TSTR:
			match(Token.TSTR);
			return types.Str.type;
		case Token.TBOOL:
			match(Token.TBOOL);
			return types.Bool.type;
		case Token.TVOID:
			match(Token.TVOID);
			return types.Void.type;
		default:
			match('(');
			List<Type> types;
			if(la.type != ')')
				types = types();
			else
				types = new ArrayList<Type>();
			match(')');
			match(Token.FUNCTYPE);
			return new types.Func(type(), types.toArray(new Type[0]));
		}
	}

	public List<Type> types() {
		ArrayList<Type> res = new ArrayList<Type>();
		res.add(type());
		while(la.type == ',') {
			match(',');
			res.add(type());
		}
		return res;
	}

}