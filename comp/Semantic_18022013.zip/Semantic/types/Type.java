package types;

import ast.Node;

public abstract class Type {
	
	public void checkEq(Num i, Node n) {
		n.typeError(this, i);
	}

	public void checkEq(Str s, Node n) {
		n.typeError(this, s);
	}
	
	public void checkEq(Bool b, Node n) {
		n.typeError(this, b);
	}
	
	public void checkEq(Func f, Node n) {
		n.typeError(this, f);
	}

	public void checkEq(Void v, Node n) {
		n.typeError(this, v);
	}

	public abstract void checkEq(Type t, Node n);
			
}
