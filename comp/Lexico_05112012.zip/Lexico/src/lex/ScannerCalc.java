package lex;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class ScannerCalc implements Scanner {
	public Reader input;
	public int lookAhead;
	StringBuffer token;

	public ScannerCalc() { }
	
	@Override
	public void setInput(String input) {
		this.input = new StringReader(input);
		try {
			lookAhead = this.input.read();
		} catch(IOException ioe) {
			throw new RuntimeException(ioe);
		}
	}

	public void nextChar() {
		token.append((char)lookAhead);
		try {
			lookAhead = input.read();
		} catch(IOException ioe) {
			throw new RuntimeException(ioe);
		}
	}
	
	public void error(int state) {
		throw new RuntimeException("estado: " + state + ", caractere inv�lido: " + (char)lookAhead);
	}
	
	@Override
	public Token nextToken() {
		int state = 0;
		token = new StringBuffer();
		while(true) {
			int c = lookAhead;
			switch(state) {
			case 0:
				if(c == ' ' || c == '\n' || c == '\r' || c == '\t') {
					state = 0; nextChar(); continue;
				}
				if(c >= '0' && c <= '9') { state = 1; nextChar(); continue; }
				if(c == '(') { state = 2; nextChar(); continue; }
				if(c == ')') { state = 3; nextChar(); continue; }
				if(c == '+') { state = 4; nextChar(); continue; }
				if(c == '-') { state = 5; nextChar(); continue; }
				if(c == '*') { state = 6; nextChar(); continue; }
				if(c == '/') { state = 7; nextChar(); continue; }
				if(c == -1) { state = 8; nextChar(); continue; }
				error(state);
			case 1:
				if(c >= '0' && c <= '9') { state = 1; nextChar(); continue; }
				return new Token(1, token.toString());
			case 2:
				return new Token('(', token.toString());
			case 3:
				return new Token(')', token.toString());
			case 4:
				return new Token('+', token.toString());
			case 5:
				return new Token('-', token.toString());
			case 6:
				return new Token('*', token.toString());
			case 7:
				return new Token('/', token.toString());
			case 8:
				return new Token(Token.EOF, token.toString());
			}
		}
	}

	@Override
	public List<Token> allTokens() {
		List<Token> tokens = new ArrayList<Token>();
		Token tok = nextToken();
		while(tok.type != Token.EOF) {
			tokens.add(tok);
			tok = nextToken();
		}
		return tokens;
	}

}
