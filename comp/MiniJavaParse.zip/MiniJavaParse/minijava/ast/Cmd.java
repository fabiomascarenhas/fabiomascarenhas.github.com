package minijava.ast;

public interface Cmd {

}
