package minijava.ast;

public class Null implements Exp{
	public String toString() {
		return "null";
	}
}
