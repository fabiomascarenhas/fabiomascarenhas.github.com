package minijava.ast;

public interface Exp {

}
