package minijava.ast;

public class False implements Exp {
	public String toString() {
		return "false";
	}
}
