package minijava.ast;

public class True implements Exp{
	public String toString() {
		return "true";
	}
}
