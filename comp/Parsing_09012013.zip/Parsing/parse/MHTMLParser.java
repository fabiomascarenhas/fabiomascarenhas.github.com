package parse;

/*
g.rules("MHTML", "ELEM");
g.rules("ELEM", "ATAG CORPO FTAG");
g.rules("ELEM", "<% SCRIPT %>");
g.rules("ELEM", "<%= REXP %>");
g.rules("ELEM", "AFTAG");
g.rules("CORPO", "ELEM CORPO");
g.rules("CORPO", "word CORPO");
g.rules("CORPO", "");
g.rules("ATAG", "< id >");
g.rules("FTAG", "</ id >");
g.rules("AFTAG", "< id />");
g.rules("SCRIPT", "script");
*/ 
public class MHTMLParser {
	// input[pos] � o lookahead
	public int pos;
	public String[] input;
	
	public ScriptParser sp;
	public RExpParser rp;
	
	public MHTMLParser(String ... input) {
		this.input = input;
		this.pos = 0;
		sp = new ScriptParser(input);
		rp = new RExpParser(input);
	}
	
	public String la() {
		return pos < input.length ? input[pos] : "<<EOF>>";
	}
	
	public Tree match(String token) {
		if(token.equals(la())) {
			pos++;
			return new Tree(token);
		} else
			throw new RuntimeException("erro de sintaxe em " +
					pos + ", esperado: " + token + ", achado: " +
					la());
	}
	
	public Tree parse() {
		Tree res = mhtml();
		if(pos < input.length)
			throw new RuntimeException("entrada n�o foi toda analisada");
		return res;
	}

	// g.rules("MHTML", "ELEM");
	public Tree mhtml() {
		Tree res = new Tree("MHTML");
		res.child(elem());
		return res;
	}

	/*
	g.rules("ELEM", "ATAG CORPO FTAG");
	g.rules("ELEM", "<% SCRIPT %>");
	g.rules("ELEM", "<%= REXP %>");
	g.rules("ELEM", "AFTAG");
	*/
	public Tree elem() {
		Tree res = new Tree("ELEM");
		switch(la()) {
		case "<%":
			// g.rules("ELEM", "<% SCRIPT %>");
			res.child(match("<%"));
			res.child(script());
			res.child(match("%>"));
			break;
		case "<%=":
			// g.rules("ELEM", "<%= REXP %>");
			res.child(match("<%="));
			res.child(rexp());
			res.child(match("%>"));
			break;
		case "<":
			// g.rules("ELEM", "ATAG CORPO FTAG");
			// g.rules("ELEM", "AFTAG");
			// g.rules("ATAG", "< id >");
			// g.rules("AFTAG", "< id />");
			Tree less = match("<");
			Tree id = match("id");
			if(la().equals(">")) {
				// g.rules("ELEM", "ATAG CORPO FTAG");
				Tree atag = new Tree("ATAG");
				atag.child(less);
				atag.child(id);
				atag.child(match(">"));
				res.child(atag);
				res.child(corpo());
				res.child(ftag());
			} else {
				// g.rules("ELEM", "AFTAG");
				Tree aftag = new Tree("AFTAG");
				aftag.child(less);
				aftag.child(id);
				aftag.child(match("/>"));
				res.child(aftag);
			}
			break;
		default:
			throw new RuntimeException("elemento inv�lido em " + pos +
					", come�ando com: " + la());	
		}
		return res;
	}
	
	// g.rules("CORPO", "ELEM CORPO");
	// g.rules("CORPO", "word CORPO");
	// g.rules("CORPO", "");
//	public Tree corpo() {
//		Tree res = new Tree("CORPO");
//		switch(la()) {
//		case "<%": case "<%=": case "<":
//			// g.rules("CORPO", "ELEM CORPO");
//			res.child(elem());
//			res.child(corpo());
//			break;
//		case "word":
//			// g.rules("CORPO", "word CORPO");
//			res.child(match("word"));
//			res.child(corpo());
//			break;
//		}
//		return res;
//	}

	// g.rules("CORPO", "{ELEM | word}");
	public Tree corpo() {
		Tree res = new Tree("CORPO");
		String la = la();
		while(la.equals("<%") || la.equals("<%=") ||
				la.equals("<") || la.equals("word")) {
			switch(la) {
			case "<%": case "<%=": case "<":
				res.child(elem());
				break;
			case "word":
				res.child(match("word"));
				break;
			}
			la = la();
		}
		return res;
	}

	// g.rules("FTAG", "</ id >");
	public Tree ftag() {
		Tree res = new Tree("FTAG");
		res.child(match("</"));
		res.child(match("id"));
		res.child(match(">"));
		return res;
	}
	
	public Tree rexp() {
		Tree res = rp.parse(pos);
		pos = rp.pos;
		return res;
	}

	public Tree script() {
		Tree res = sp.parse(pos);
		pos = sp.pos;
		return res;
	}
}
