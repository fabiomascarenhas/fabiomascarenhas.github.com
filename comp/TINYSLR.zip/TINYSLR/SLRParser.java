
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Stack;

public class SLRParser {
	public Grammar g;
	public LRDFA aut;
	public Scanner scan;
	public Token la;
	public Stack<Tree> stackTree;
	public Stack<Integer> stackState;
	public boolean accept;
	public HashMap<String, Integer> precedence = 
			new HashMap<String, Integer>();
	
	public HashMap<String, Action[]> ACTION;
	public HashMap<String, Integer[]> GOTO;
		
	public interface Action {
		void run(SLRParser parser);
	}
	
	public class Shift implements Action {
		public int state;
		public String term;
		
		public Shift(int state, String term) {
			this.state = state;
			this.term = term;
		}
		
		public void run(SLRParser parser) {
			parser.shift(state);
		}
		
		public String toString() {
			return "S" + state;
		}
	}
	
	public class Reduce implements Action {
		public Grammar.Rule rule;
		
		public Reduce(Grammar.Rule rule) {
			this.rule = rule;
		}
		
		public void run(SLRParser parser) {
			parser.reduce(rule);
		}
		
		public String toString() {
			return "R" + g.rules.indexOf(rule);
		}
	}
	
	public class Accept extends Reduce {
		public Accept(Grammar.Rule rule) {
			super(rule);
		}
		
		public void run(SLRParser parser) {
			super.run(parser);
			parser.accept();
		}
		
		public String toString() { 
			return "A";
		}
	}
	
	public class Error implements Action {
		public void run(SLRParser parser) {
			parser.error();
		}
		
		public String toString() {
			return "";
		}
	}
	
	public SLRParser(Grammar g) {
		g.computeSets();
		this.g = g;
		aut = new LRDFA(g);
		fill();
	}

	public SLRParser(Grammar g, String ... prec) {
		int l = 0;
		for(String level: prec) {
			String[] ops = level.split("[ ]");
			for(String op: ops)
				precedence.put(op, l);
			l++;
		}
		g.computeSets();
		this.g = g;
		aut = new LRDFA(g);
		fill();
	}

	public void fill() {
		ACTION = new HashMap<String, Action[]>();
		for(String term: g.terminals)
			ACTION.put(term, new Action[aut.states.size()]);
		ACTION.put("<<EOF>>", new Action[aut.states.size()]);
		GOTO = new HashMap<String, Integer[]>();
		for(String term: g.variables)
			GOTO.put(term, new Integer[aut.states.size()]);
		for(int i = 0; i < aut.states.size(); i++) {
			LRDFA.State s = aut.states.get(i);
			for(Entry<String, LRDFA.State> pair: s.trans.entrySet()) {
				String term = pair.getKey();
				if(g.variables.contains(term)) {
					GOTO.get(term)[i] = 
							aut.states.indexOf(pair.getValue());
				} else {
					ACTION.get(term)[i] = new Shift(aut.states.indexOf(pair.getValue()), term);
				}
			}
			for(LRDFA.Item item: s.items) {
				if(item.dot == item.rule.body.length) {
					for(String term: g.FOLLOW.get(item.rule.head)) {
						Action a = ACTION.get(term)[i];
						if(a == null) {
							// Assumindo que FOLLOW(S) = { EOF }
							if(item.rule.equals(g.rules.get(0)))
								ACTION.get(term)[i] = new Accept(item.rule);
							else
								ACTION.get(term)[i] = new Reduce(item.rule);
						} else { // conflitos
							if(a instanceof Shift) {
								Shift sa = (Shift)a;
								Integer precRight = precedence.get(sa.term);
								Integer precLeft = null;
								for(int j = item.rule.body.length-1; j >= 0; j--) {
									if(g.terminals.contains(item.rule.body[j])
										&& precedence.containsKey(item.rule.body[j])) {
										precLeft = precedence.get(item.rule.body[j]);
										break;
									}
								}
								if(precRight != null && precLeft != null) {
									if(precRight <= precLeft)
										ACTION.get(term)[i] = new Reduce(item.rule);
								} else
									System.out.println("conflito: " + sa + " (" + sa.term + "), reduce " + item.rule);
							} else {
								System.out.println("conflito: " + a + ", reduce " + item.rule);
							}
						}
					}
				}
			}
		}
		for(String term: ACTION.keySet()) {
			for(int i = 0; i < aut.states.size(); i++)
				if(ACTION.get(term)[i] == null)
					ACTION.get(term)[i] = new Error();
		}
	}
	
	public void setInput(Scanner scan) {
		this.scan = scan;
		try {
			this.la = scan.token();
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.accept = false;
		this.stackTree = new Stack<Tree>();
		stackTree.push(new Tree("<<EOF>>"));
		this.stackState = new Stack<Integer>();
		stackState.push(0);
		System.out.println(configuration());
	}
		
	public String configuration() {
		StringBuffer config = new StringBuffer();
		for(int i = 0; i < stackTree.size(); i++) {
			config.append(stackTree.get(i).term);
			config.append(",");
			config.append(stackState.get(i));
			config.append(" ");
		}
		config.append("|");
		config.append(la().lexeme);
		return config.toString();
	}
	
	public void shift(int state) {
		stackTree.push(new Tree(la().lexeme));
		try {
			la = scan.token();
		} catch (IOException e) {
			e.printStackTrace();
		}
		stackState.push(state);
		System.out.println(configuration());
	}
	
	public void reduce(Grammar.Rule r) {
		Tree node = new Tree(r.head);
		for(int i = r.body.length - 1; i >= 0; i--) {
			stackState.pop();
			Tree child = stackTree.pop();
			node.children.add(0, child);
		}
		stackTree.push(node);
		stackState.push(GOTO.get(node.term)[stackState.peek()]);
		System.out.println(configuration());
	}
	
	public Token la() {
		return this.la;
	}
	
	public void error() {
		throw new RuntimeException("erro de sintaxe: " + la());
	}
	
	public void accept() {
		accept = true;
	}
	
	public Tree parse() {
		while(!accept) {
			ACTION.get(la().nomeTipo())[stackState.peek()].run(this);
		}
		return stackTree.pop();
	}
	
	public void printTable() {
		System.out.println();
		System.out.println(">>>>> ACTION:");
		for(String term: ACTION.keySet()) {
			System.out.print("\t" + term);
		}
		System.out.println();
		for(int i = 0; i < aut.states.size(); i++) {
			System.out.print(i);
			for(String term: ACTION.keySet()) {
				System.out.print("\t" + ACTION.get(term)[i]);
			}
			System.out.println();
		}
		System.out.println();
		System.out.println(">>>>> GOTO:");
		for(String term: GOTO.keySet()) {
			System.out.print("\t" + term);
		}
		System.out.println();
		for(int i = 0; i < aut.states.size(); i++) {
			System.out.print(i);
			for(String term: GOTO.keySet()) {
				System.out.print("\t" + 
						(GOTO.get(term)[i] == null ? "" : GOTO.get(term)[i]));
			}
			System.out.println();
		}
		System.out.println();
	}
}
