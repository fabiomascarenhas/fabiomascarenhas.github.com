import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id
*/

class Falha extends RuntimeException { }

public class Parser {
	ArrayList<Token> tokens;
	int atual = 0;
	int falha = -1;
	Set<Integer> esperados = new HashSet<Integer>();
	
	public Parser(Scanner scan) {
		tokens = new ArrayList<Token>();
		try {
			Token tok;
			do {
				tok = scan.token();
				tokens.add(tok);
			} while(tok.tipo != Token.EOF);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	void match(int tipo) {
		if(tokens.get(atual).tipo == tipo) {
			atual++;
		} else {
			if(atual == falha) {
				esperados.add(tipo);
			} else if(atual > falha) {
				falha = atual;
				esperados.clear();
				esperados.add(tipo);
			}
			throw new Falha();
		}
	}
	
	// S -> CMDS
	void parse() {
		try {
			cmds();
			match(Token.EOF);
		} catch(Falha f) {
			throw new RuntimeException("erro de sintaxe, esperado " + esperados + ", encontrado " + tokens.get(falha));
		}
	}
	
	// CMDS  -> CMD { ; CMD }
	void cmds() {
		cmd();
		while(true) {
			int pos = atual;
			try {
				match(';');
				cmd();
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
	}

 	/*
      CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
	 */
	void cmd() {
		int pos = atual;
		try {
			match(Token.IF);
			exp();
			match(Token.THEN);
			cmds();
			int pos_ = atual;
			try {
				match(Token.ELSE);
				cmds();
			} catch(Falha f) {
				atual = pos_;
			}
			match(Token.END);
		} catch(Falha f) {
			atual = pos;
			// int pos = atual;
			try {
				match(Token.REPEAT);
				cmds();
				match(Token.UNTIL);
				exp();
			} catch(Falha f_) {
				atual = pos;
				// int pos = atual;
				try {
					match(Token.ID);
					match(Token.ATTRIB);
					exp();
				} catch(Falha f__) {
					atual = pos;
					// int pos = atual;
					try {
						match(Token.READ);
						match(Token.ID);
					} catch(Falha f___) {
						atual = pos;
						match(Token.WRITE);
						exp();
					}
				}
			}
		}
	}
	
	// EXP   -> SEXP { < SEXP | = SEXP }
	void exp() {
		sexp();
		while(true) {
			int pos = atual;
			try {
				// int pos = atual;
				try {
					match('<');
					sexp();
				} catch (Falha f) {
					atual = pos;
					match('=');
					sexp();
				}
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
	}

	// SEXP  -> TERMO { + TERMO | - TERMO }
	void sexp() {
		termo();
		while(true) {
			int pos = atual;
			try {
				// int pos = atual;
				try {
					match('+');
					termo();
				} catch (Falha f) {
					atual = pos;
					match('-');
					termo();
				}
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
	}

	// TERMO -> FATOR { * FATOR | / FATOR }
	void termo() {
		fator();
		while(true) {
			int pos = atual;
			try {
				// int pos = atual;
				try {
					match('*');
					fator();
				} catch (Falha f) {
					atual = pos;
					match('/');
					fator();
				}
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
	}

	// FATOR -> "(" EXP ")" | num | id
	void fator() {
		int pos = atual;
		try {
			match('(');
			exp();
			match(')');
		} catch(Falha f) {
			atual = pos;
			// int pos = atual;
			try {
				match(Token.NUM);
			} catch(Falha f_) {
				atual = pos;
				match(Token.ID);
			}
		}
	}
}
