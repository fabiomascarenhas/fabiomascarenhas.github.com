import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP [ < SEXP | = SEXP ]
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id 
 */
public class Parser {
	public Token[] tokens = new Token[0];
	int pos = 0;
	int marca = 0;
	int tipo = 0;

	class Falha extends RuntimeException {
		private static final long serialVersionUID = 1380727764053502891L;

		public int token;
		public int pos;
		
		public Falha(int token, int pos) {
			this.token = token;
			this.pos = pos;
		}
	}

	public Parser(Reader in) {
		Scanner scan = new Scanner(in);
		ArrayList<Token> toks = new ArrayList<Token>();
		try {
			Token tok = scan.token();
			while(tok.tipo != 0) {
				toks.add(tok);
				tok = scan.token();
			}
			toks.add(tok);
		} catch(IOException e) {
			throw new RuntimeException(e);
		}
		tokens = toks.toArray(tokens);
	}

	public String match(int token) {
		if(marca < pos) {
			marca = pos;
			tipo = token;
		}
		if(tokens[pos].tipo == token) {
			String termo = tokens[pos].val;
			pos++;
			return termo;
		} else throw new Falha(token, pos);
	}

	public Tree parse() {
		try {
			Tree t = CMDS();
			if(tokens[pos].tipo != 0)
				throw new Falha(tipo, marca);
			return t;
		} catch(Falha f) {
			Token tok = tokens[f.pos];
			throw new RuntimeException("erro de sintaxe na linha " +
					tok.lin + ", esperado " + f.token + ", encontrado " + tok);
		}
	}
	
	// CMDS  -> CMD { ; CMD }
	public Tree CMDS() {
		Tree t = new Tree("CMDS");
		t.child(CMD());
		while(true) {
			int atual = pos;
			try {
				Tree r = new Tree("");
				r.child(match(';'));
				r.child(CMD());
				t.children.addAll(r.children);
			} catch(Falha f) {
				pos = atual;
				break;
			}
		}
		return t;
	}

	// CMD   -> if EXP then CMDS [ else CMDS ] end
    //          | repeat CMDS until EXP
    //          | id := EXP
    //          | read id
    //          | write EXP
	public Tree CMD() {
		Tree t = new Tree("CMD");
		{
			int atual = pos;
			try {
				Tree r = new Tree("");
				// if EXP then CMDS [ else CMDS ] end
				r.child(match(Token.IF));
				r.child(EXP());
				r.child(match(Token.THEN));
				r.child(CMDS());
				// [ else CMDS ]
				{
					int atual2 = pos;
					try {
						Tree r2 = new Tree("");
						r2.child(match(Token.ELSE));
						r2.child(CMDS());
						r.children.addAll(r2.children);
					} catch(Falha f) {
						pos = atual2;
					}
				}
				r.child(match(Token.END));
				t.children.addAll(r.children);
			} catch(Falha f) {
				pos = atual;
				{
					int atual2 = pos;
					try {
						Tree r = new Tree("");
						// repeat CMDS until EXP
						r.child(match(Token.REPEAT));
						r.child(CMDS());
						r.child(match(Token.UNTIL));
						r.child(EXP());
						t.children.addAll(r.children);
					} catch(Falha f2) {
						pos = atual2;
						{
							int atual3 = pos;
							try {
								Tree r = new Tree("");
								// id := EXP
								r.child(match(Token.ID));
								r.child(match(Token.ATRIB));
								r.child(EXP());
								t.children.addAll(r.children);
							} catch(Falha f3) {
								pos = atual3;
								{
									int atual4 = pos;
									try {
										Tree r = new Tree("");
										// read id
										r.child(match(Token.READ));
										r.child(match(Token.ID));
										t.children.addAll(r.children);
									} catch(Falha f4) {
										pos = atual4;
										// write EXP
										t.child(match(Token.WRITE));
										t.child(EXP());
									}
								}
							}
						} 
					}
				}
			}
		}
		return t;
	}
	
	// EXP   -> SEXP [ < SEXP | = SEXP ]
	Tree EXP() {
		Tree t = new Tree("EXP");
		t.child(SEXP());
		{
			int atual = pos;
			try {
				Tree r = new Tree("");
				// < SEXP | = SEXP
				{
					int atual2 = pos;
					try {
						Tree r2 = new Tree("");
						// < SEXP
						r2.child(match('<'));
						r2.child(SEXP());
						r.children.addAll(r2.children);
					} catch(Falha f2) {
						pos = atual2;
						// = SEXP
						r.child(match('='));
						r.child(SEXP());
					}
				}
				t.children.addAll(r.children);
			} catch(Falha f) {
				pos = atual;
			}
		}
		return t;
	}
	
	// SEXP  -> TERMO { + TERMO | - TERMO }
	public Tree SEXP() {
		Tree t = new Tree("SEXP");
		t.child(TERMO());
		while(true) {
			int atual = pos;
			try {
				Tree r = new Tree("");
				{
					// + TERMO | - TERMO
					int atual2 = pos;
					try {
						Tree r2 = new Tree("");
						// + TERMO
						r2.child(match('+'));
						r2.child(TERMO());
						r.children.addAll(r2.children);
					} catch(Falha f2) {
						pos = atual2;
						// - TERMO
						r.child(match('-'));
						r.child(TERMO());
					}
				}
				t.children.addAll(r.children);
			} catch(Falha f) {
				pos = atual;
				break;
			}
		}
		return t;
	}


	// TERMO  -> FATOR { * FATOR | / FATOR }
	public Tree TERMO() {
		Tree t = new Tree("TERMO");
		t.child(FATOR());
		while(true) {
			int atual = pos;
			try {
				Tree r = new Tree("");
				{
					// * FATOR | / FATOR
					int atual2 = pos;
					try {
						Tree r2 = new Tree("");
						// * FATOR
						r2.child(match('*'));
						r2.child(FATOR());
						r.children.addAll(r2.children);
					} catch(Falha f2) {
						pos = atual2;
						// / FATOR
						r.child(match('/'));
						r.child(FATOR());
					}
				}
				t.children.addAll(r.children);
			} catch(Falha f) {
				pos = atual;
				break;
			}
		}
		return t;
	}
	
	// FATOR -> "(" EXP ")" | num | id 
	public Tree FATOR() {
		Tree t = new Tree("FATOR");
		{
			int atual = pos;
			try {
				Tree r = new Tree("");
				// "(" EXP ")"
				r.child(match('('));
				r.child(EXP());
				r.child(match(')'));
				t.children.addAll(r.children);
			} catch(Falha f) {
				pos = atual;
				{
					int atual2 = pos;
					try {
						Tree r = new Tree("");
						// num
						r.child(match(Token.NUM));
						t.children.addAll(r.children);
					} catch(Falha f2) {
						pos = atual2;
						// id
						t.child(match(Token.ID));
					}
				}
			}
		}
		return t;
	}
}
