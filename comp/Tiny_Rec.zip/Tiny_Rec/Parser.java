import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if COND then CMDS [ else CMDS ] end
       | repeat CMDS until COND
       | id := EXP
       | read id
       | write EXP
COND  -> EXP ( < EXP | = EXP )
EXP   -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id 
 */
public class Parser {
	public Token[] tokens = new Token[0];
	int pos = 0;
	int marca = 0;
	
	class Falha extends RuntimeException { }
	
	public Parser(Reader in) throws IOException {
		ScannerJFlex scan = new ScannerJFlex(in);
		ArrayList<Token> toks = new ArrayList<Token>();
		Token tok = scan.leToken();
		while(tok.tipo != 0) {
			toks.add(tok);
			tok = scan.leToken();
		}
		toks.add(tok);
		tokens = toks.toArray(tokens);
	}
	
	public String match(int token) {
		if(pos > marca) marca = pos;
		if(tokens[pos].tipo == token) {
			String termo = tokens[pos].val;
			pos++;
			return termo;
		} else throw new Falha();
	}
	
	public Tree parse() {
		try {
			Tree res = CMDS();
			if(tokens[pos].tipo != 0)
				throw new RuntimeException("erro de sintaxe em " +
						tokens[marca]);
			return res;
		} catch(Falha f) {
			throw new RuntimeException("erro de sintaxe em " +
					tokens[marca]);
		}
	}
	
	// CMDS  -> CMD { ; CMD }
	public Tree CMDS() {
		Tree res = new Tree("CMDS");
		res.child(CMD());
		while(true) {
			int atual = pos;
			try {
				Tree rascunho = new Tree("");
				rascunho.child(match(';'));
				rascunho.child(CMD());
				res.children.addAll(rascunho.children);
			} catch(Falha f) {
				pos = atual;
				break;
			}
		}
		return res;
	}
	
	/*
     CMD   -> if COND then CMDS [ else CMDS ] end
       | repeat CMDS until COND
       | id := EXP
       | read id
       | write EXP
	 */
	public Tree CMD() {
		Tree res = new Tree("CMD");
		int atual = pos;
		try {
			Tree rascunho = new Tree("");
			// if COND then CMDS [ else CMDS ] end
			rascunho.child(match(5)); // if
			rascunho.child(COND());
			rascunho.child(match(6)); // then
			rascunho.child(CMDS());
			int atual_else = pos;
			try {
				Tree rascunho_else = new Tree("");
				rascunho.child(match(7)); // else
				rascunho.child(CMDS());
				rascunho.children.addAll(rascunho_else.children);
			} catch(Falha f1) {
				pos = atual_else;
			}
			rascunho.child(match(8)); // end
			res.children.addAll(rascunho.children);
		} catch(Falha f2) {
			pos = atual;
		try { 
				Tree rascunho = new Tree("");
			// repeat CMDS until COND
			rascunho.child(match(9)); // repeat
			rascunho.child(CMDS());
			rascunho.child(match(10)); // until
			rascunho.child(COND());
			res.children.addAll(rascunho.children);
		} catch(Falha f3) {
			pos = atual;
		try {
			Tree rascunho = new Tree("");
		    // id := EXP
			rascunho.child(match(2)); // id
			rascunho.child(match(11)); // :=
			rascunho.child(EXP());
			res.children.addAll(rascunho.children);
		} catch(Falha f4) {
			pos = atual;
		try {
			Tree rascunho = new Tree("");
		    // read id
			rascunho.child(match(4)); // read
			rascunho.child(match(2)); // id
			res.children.addAll(rascunho.children);
		} catch(Falha f5) {
			pos = atual;
			Tree rascunho = new Tree("");
		    // write EXP
			rascunho.child(match(3)); // write
			rascunho.child(EXP());
			res.children.addAll(rascunho.children);
		} } } } 
		return res;
	}

	// COND  -> EXP ( < EXP | = EXP )
	public Tree COND() {
		Tree res = new Tree("COND");
		res.child(EXP());
		int atual = pos;
		try {
			// < EXP
			Tree rascunho = new Tree("");
			rascunho.child(match('<'));
			rascunho.child(EXP());
			res.children.addAll(rascunho.children);
		} catch(Falha f) {
			pos = atual;
			// = EXP
			Tree rascunho = new Tree("");
			rascunho.child(match('='));
			rascunho.child(EXP());
			res.children.addAll(rascunho.children);
		}
		return res;
	}
	
	// EXP   -> TERMO { + TERMO | - TERMO }
	public Tree EXP() {
		Tree res = new Tree("EXP");
		res.child(TERMO());
		while(true) {
			int atual = pos;
			try {
				// + TERMO
				Tree rascunho = new Tree("");
				rascunho.child(match('+'));
				rascunho.child(TERMO());
				res.children.addAll(rascunho.children);
			} catch(Falha f1) {
				pos = atual;
			try {
				// - TERMO
				Tree rascunho = new Tree("");
				rascunho.child(match('-'));
				rascunho.child(TERMO());
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				pos = atual;
				break;
			} }
		}
		return res;
	}

	// TERMO   -> FATOR { * FATOR | / FATOR }
	public Tree TERMO() {
		Tree res = new Tree("TERMO");
		res.child(FATOR());
		while(true) {
			int atual = pos;
			try {
				// * FATOR
				Tree rascunho = new Tree("");
				rascunho.child(match('*'));
				rascunho.child(FATOR());
				res.children.addAll(rascunho.children);
			} catch(Falha f1) {
				pos = atual;
			try {
				// / FATOR
				Tree rascunho = new Tree("");
				rascunho.child(match('/'));
				rascunho.child(FATOR());
				res.children.addAll(rascunho.children);
			} catch(Falha f2) {
				pos = atual;
				break;
			} }
		}
		return res;
	}

	// FATOR -> "(" EXP ")" | num | id 
	public Tree FATOR() {
		Tree res = new Tree("FATOR");
		int atual = pos;
		try {
			// "(" EXP ")"
			Tree rascunho = new Tree("");
			rascunho.child(match('('));
			rascunho.child(EXP());
			rascunho.child(match(')'));
			res.children.addAll(rascunho.children);
		} catch(Falha f1) {
			pos = atual;
		try {
			// num
			Tree rascunho = new Tree("");
			rascunho.child(match(1));
			res.children.addAll(rascunho.children);
		} catch(Falha f2) {
			pos = atual;
			// id
			Tree rascunho = new Tree("");
			rascunho.child(match(2));
			res.children.addAll(rascunho.children);
		} }
		return res;
	}
}
