
public class Token {
	public int tipo;
	public String val;
	public int lin;
	
	public static final int NUM = 1;
	public static final int ID = 2;
	public static final int WRITE = 3;
	public static final int READ = 4;
	public static final int IF = 5;
	public static final int THEN = 6;
	public static final int ELSE = 7;
	public static final int END = 8;
	public static final int REPEAT = 9;
	public static final int UNTIL = 10;
	public static final int ATRIB = 11;

	public Token(int tipo, String val, int lin) {
		this.tipo = tipo;
		this.val = val;
		this.lin = lin;
	}
		
	public String toString() {
		return "<" + tipo + "," + val + "," + lin + ">";
	}
}
