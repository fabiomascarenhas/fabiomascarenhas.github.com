package types;

import ast.Node;

public class Num extends Type {
	public static Num type = new Num();
	
	private Num() {	}
	
	@Override
	public void checkEq(Num i, Node n) { }

	@Override
	public void checkEq(Type t, Node n) {
		t.checkEq(this, n);
	}

	@Override
	public String toString() {
		return "num";
	}

}
