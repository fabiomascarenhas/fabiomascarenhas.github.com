package types;

import ast.Node;

public class Bool extends Type{
	public static Bool type = new Bool();
	
	private Bool() {	}
	
	@Override
	public void checkEq(Bool b, Node n) { }


	@Override
	public void checkEq(Type t, Node n) {
		t.checkEq(this, n);
	}

	@Override
	public String toString() {
		return "bool";
	}

}
