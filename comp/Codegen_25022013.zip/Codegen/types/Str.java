package types;

import ast.Node;

public class Str extends Type{
	public static Str type = new Str();
	
	private Str() {	}
	
	@Override
	public void checkEq(Str s, Node n) { }

	@Override
	public void checkEq(Type t, Node n) {
		t.checkEq(this, n);
	}

	@Override
	public String toString() {
		return "str";
	}

}
