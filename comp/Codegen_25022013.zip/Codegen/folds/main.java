package folds;

public class main implements runtime.Func {
  Object tostring;
  Object print;

  public main(Object tostring, Object print) {
    this.tostring = tostring;
    this.print = print;
  }

  @Override
  public Object apply(Object ... args) {
    Object $loc1;
    $loc1 = new nums();
    ((runtime.Func)this.print).apply(((runtime.Func)$loc1).apply(new anon_7_12(), 0.0));
    ((runtime.Func)this.print).apply(((runtime.Func)$loc1).apply(new anon_9_12(), 4.0));
    ((runtime.Func)this.print).apply(((runtime.Func)$loc1).apply(new anon_11_12(), 1.0));
    Object $loc2;
    $loc2 = new numsf();
    Object $loc3;
    $loc3 = ((runtime.Func)$loc2).apply(new anon_17_17(this.print), new anon_23_16(this.print));
    ((runtime.Func)this.print).apply($loc3);
    ((runtime.Func)$loc3).apply();
    Object $loc4;
    $loc4 = new numss();
    ((runtime.Func)this.print).apply(((runtime.Func)$loc4).apply(new anon_31_13(this.tostring), "0.0"));
    return null;
  }
}
