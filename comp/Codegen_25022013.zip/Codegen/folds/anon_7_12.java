package folds;

public class anon_7_12 implements runtime.Func {

  public anon_7_12() { }

  @Override
  public Object apply(Object ... args) {
    return ((Double)args[0]) + ((Double)args[1]);
  }
}
