package folds;

public class anon_9_12 implements runtime.Func {

  public anon_9_12() { }

  @Override
  public Object apply(Object ... args) {
    return ((Double)args[0]) + ((Double)args[1]);
  }
}
