package folds;

public class anon_18_25 implements runtime.Func {
  Object b;
  Object a;
  Object print;

  public anon_18_25(Object b, Object a, Object print) {
    this.b = b;
    this.a = a;
    this.print = print;
  }

  @Override
  public Object apply(Object ... args) {
    ((runtime.Func)this.print).apply(this.a);
    ((runtime.Func)this.b).apply();
    return null;
  }
}
