package folds;

public class numsf implements runtime.Func {

  public numsf() { }

  @Override
  public Object apply(Object ... args) {
    return ((runtime.Func)args[0]).apply(2.0, ((runtime.Func)args[0]).apply(4.0, ((runtime.Func)args[0]).apply(6.0, args[1])));
  }
}
