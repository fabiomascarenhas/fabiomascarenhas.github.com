package folds;

public class nums implements runtime.Func {

  public nums() { }

  @Override
  public Object apply(Object ... args) {
    return ((runtime.Func)args[0]).apply(2.0, ((runtime.Func)args[0]).apply(4.0, ((runtime.Func)args[0]).apply(6.0, args[1])));
  }
}
