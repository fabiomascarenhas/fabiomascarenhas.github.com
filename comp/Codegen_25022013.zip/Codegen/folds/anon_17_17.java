package folds;

public class anon_17_17 implements runtime.Func {
  Object print;

  public anon_17_17(Object print) {
    this.print = print;
  }

  @Override
  public Object apply(Object ... args) {
    return new anon_18_25(args[1], args[0], this.print);
  }
}
