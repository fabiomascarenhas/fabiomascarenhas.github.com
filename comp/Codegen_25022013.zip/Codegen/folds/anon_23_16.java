package folds;

public class anon_23_16 implements runtime.Func {
  Object print;

  public anon_23_16(Object print) {
    this.print = print;
  }

  @Override
  public Object apply(Object ... args) {
    ((runtime.Func)this.print).apply(0.0);
    return null;
  }
}
