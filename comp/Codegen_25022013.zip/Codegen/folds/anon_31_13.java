package folds;

public class anon_31_13 implements runtime.Func {
  Object tostring;

  public anon_31_13(Object tostring) {
    this.tostring = tostring;
  }

  @Override
  public Object apply(Object ... args) {
    return ((String)((runtime.Func)this.tostring).apply(args[0])) + ((String)((String)", ") + ((String)args[1]));
  }
}
