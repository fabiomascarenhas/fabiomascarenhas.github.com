package fat;

public class fat2 implements runtime.Func {

  public fat2() { }

  @Override
  public Object apply(Object ... args) {
    Object $loc1;
    $loc1 = 1.0;
    while(runtime.Values.lessThan(1.0, args[0]))    {
      $loc1 = ((Double)$loc1) * ((Double)args[0]);
      args[0] = ((Double)args[0]) - ((Double)1.0);
    }
    return $loc1;
  }
}
