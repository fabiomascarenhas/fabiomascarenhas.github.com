package fat;

public class fat implements runtime.Func {
  runtime.Upvalue fat;

  public fat(runtime.Upvalue fat) {
    this.fat = fat;
  }

  @Override
  public Object apply(Object ... args) {
    if(runtime.Values.lessThan(args[0], 2.0))
    {
      return 1.0;
    }
    else
    {
      return ((Double)args[0]) * ((Double)((runtime.Func)this.fat.val).apply(((Double)args[0]) - ((Double)1.0)));
    }
  }
}
