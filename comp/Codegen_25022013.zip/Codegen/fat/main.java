package fat;

public class main implements runtime.Func {
  Object print;

  public main(Object print) {
    this.print = print;
  }

  @Override
  public Object apply(Object ... args) {
    runtime.Upvalue $loc1 = new runtime.Upvalue(null);
    $loc1.val = new fat($loc1);
    Object $loc2;
    $loc2 = new fat2();
    ((runtime.Func)this.print).apply(((runtime.Func)$loc1.val).apply(5.0));
    ((runtime.Func)this.print).apply(((runtime.Func)$loc2).apply(5.0));
    return null;
  }
}
