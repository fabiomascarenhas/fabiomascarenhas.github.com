package parse;

import java.io.File;
import java.io.FileWriter;
import java.util.List;

import runtime.Upvalue;

import ast.Id;
import ast.PrimFunc;

public class Driver {
	public static ast.Environment<types.Type> globalTEnv() {
		ast.Environment<types.Type> tenv = new ast.SymbolTable<types.Type>();
		tenv.bind("print", 
						new types.Func(types.Void.type, types.Any.type));
		tenv.bind("tostring",
						new types.Func(types.Str.type, types.Any.type));
		return tenv;
	}
	
	public static ast.Environment<Object> globalEnv() {
		ast.Environment<Object> env = new ast.SymbolTable<Object>();
		env.bind("print", new runtime.PrintFunc());
		env.bind("tostring", new runtime.ToStringFunc());
		return env;
	}

	public static ast.Environment<Object> globalEnv(Id print, Id tostring) {
		ast.Environment<Object> env = new ast.SymbolTable<Object>();
		if(print.shared && print.updated)
			env.bind(print.name, new Upvalue(new runtime.PrintFunc()));
		else
			env.bind(print.name, new runtime.PrintFunc());
		if(tostring.shared && tostring.updated)
			env.bind(tostring.name, new Upvalue(new runtime.ToStringFunc()));
		else
		env.bind(tostring.name, new runtime.ToStringFunc());
		return env;
	}

	public static void main(String[] args) throws java.io.IOException {
		String filename = args[0];
		java.io.FileReader f = new java.io.FileReader(filename);
		parse.Scanner scan = new parse.Scanner(f);
		parse.ScriptParser parser = new parse.ScriptParser(scan);
		ast.Bloco bloco = parser.parseBloco();
		bloco.printDot(filename + ".gv");
		try {
			bloco.tcStat(globalTEnv());
		} catch(RuntimeException re) {
			re.printStackTrace();
		}
		System.out.println(">>>>>> RUN 1");
		bloco.run(globalEnv());
		Id print = new Id("print", 0, 0);
		Id tostring = new Id("tostring", 0, 0);
		List<PrimFunc> funcs = bloco.cc(print, tostring);
		PrimFunc main = null;
		int i = 0;
		for(PrimFunc func: funcs) {
			func.printDot(filename + "_" + func.name + ".gv");
			if(func.main) main = func; 
			System.out.println("FUNCTION " + func.name);
			System.out.println(func.env);
			System.out.println(func.params);
			i++;
		}
		System.out.println(">>>>>> RUN 2");
		main.run(globalEnv(print, tostring));
		for(PrimFunc func: funcs) {
			String pkg = filename.replace(".mhtml", "");
			File pkgPath = new File(pkg);
			pkgPath.mkdirs();
			FileWriter out = new FileWriter(
					new File(pkgPath, func.name + ".java"));
			out.write(func.compile(pkgPath.getName()));
			out.close();
		}
	}
}
