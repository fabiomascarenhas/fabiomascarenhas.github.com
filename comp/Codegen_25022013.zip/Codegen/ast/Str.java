package ast;

import java.util.List;

import types.Type;

import org.apache.commons.lang3.StringEscapeUtils;

public class Str extends Node implements Exp {
	String lit;
	String val;
	
	public Str(String lit, int line, int col) {
		super(line, col);
		this.lit = lit;
		val = StringEscapeUtils.unescapeJava(lit.substring(1, lit.length()-1));
	}

	@Override
	public Object eval(Environment<Object> env) {
		return val;
	}

	@Override
	public String label() {
		return lit;
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Str.type;
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return this;
	}

	@Override
	public String cgExp(Environment<Location> env) {
		return "\"" + StringEscapeUtils.escapeJava(val) + "\"";
	}
}
