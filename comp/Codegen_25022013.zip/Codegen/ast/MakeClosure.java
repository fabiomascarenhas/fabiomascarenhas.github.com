package ast;

import java.util.ArrayList;
import java.util.List;

import types.Type;

public class MakeClosure extends Node implements Exp {
	public PrimFunc func;
	
	public MakeClosure(PrimFunc pf, int line, int col) {
		super(line, col);
		func = pf;
	}

	@Override
	public Object eval(Environment<Object> env) {
		Environment<Object> fenv = new SymbolTable<Object>();
		for(Id name: func.env) {
			fenv.bind(name.name, env.lookup(name.name));
		}
		return new FuncVal(func.params, func.body, fenv);
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public String label() {
		return "closure";
	}

	@Override
	public String cgExp(Environment<Location> env) {
		if(func.env.isEmpty())
			return "new " + func.name + "()";
		StringBuffer buf = new StringBuffer();
		buf.append("new " + func.name + "(");
		List<String> cenv = new ArrayList<String>();
		for(Id name: func.env) {
			cenv.add(env.lookup(name.name).getBox());
		}
		buf.append(cenv.get(0));
		for(int i = 1; i < cenv.size(); i++)
			buf.append(", " + cenv.get(i));
		buf.append(")");
		return buf.toString();
	}

}
