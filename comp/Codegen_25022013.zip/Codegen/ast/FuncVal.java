package ast;

import java.util.List;

import runtime.Func;
import runtime.Upvalue;

public class FuncVal implements Func {
	public List<Id> params;
	public Bloco corpo;
	public Environment<Object> env;
	
	public FuncVal(List<Id> params, Bloco corpo, Environment<Object> env) {
		this.params = params;
		this.corpo = corpo;
		this.env = env;
	}

	@Override
	public Object apply(Object... args) {
		if(args.length != params.size())
			throw new RuntimeException("# de argumentos não bate com # de parâmetros");
		Environment<Object> fenv = env.extend();
		for(int i = 0; i < args.length; i++) {
			Id param = params.get(i);
			if(param.shared && param.updated)
				fenv.bind(param.name, new Upvalue(args[i]));
			else
				fenv.bind(param.name, args[i]);
		}
		try {
			corpo.run(fenv);
			return null;
		} catch(ReturnVal rv) {
			return rv.val;
		}
	}
		
}
