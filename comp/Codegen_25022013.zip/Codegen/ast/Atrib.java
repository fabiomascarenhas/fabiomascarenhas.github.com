package ast;

import java.util.List;

import runtime.Upvalue;
import types.Type;

public class Atrib extends Node implements Stat{
	public Id lval;
	public Exp rval;
	
	public Atrib(Id lval, Exp rval, int line, int col) {
		super(line, col);
		this.lval = lval;
		this.rval = rval;
	}
	
	public String label() {
		return "=";
	}
	
	public void run(Environment<Object> env) {
		Object obj = env.lookup(lval.name);
		if(obj instanceof Upvalue)
			((Upvalue)obj).val = rval.eval(env);
		else
			env.update(lval.name, rval.eval(env));
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type tlval = tenv.lookup(lval.name);
		Type trval = rval.tcExp(tenv);
		tlval.checkEq(trval, this);
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		LocId loc = env.lookup(lval.name);
		loc.id.updated = true;
		return new Atrib((Id)lval.ccExp(env, func, funcs),
				rval.ccExp(env, func, funcs),
				line, col);
	}

	@Override
	public String cgStat(Environment<Location> env, String indent, PrimFunc func) {
		return indent + env.lookup(lval.name).set(rval.cgExp(env));
	}

}
