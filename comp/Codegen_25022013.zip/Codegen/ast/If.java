package ast;

import java.util.List;

import types.Type;

public class If extends Node implements Stat {
	public Exp cond;
	public Bloco bthen;
	public Bloco belse;

	public If(Exp cond, Bloco bthen, Bloco belse, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.bthen = bthen;
		this.belse = belse;
	}

	@Override
	public void run(Environment<Object> env) {
		if((Boolean)cond.eval(env)) {
			bthen.run(env);
		} else {
			if(belse != null)
				belse.run(env);
		}
	}

	@Override
	public String label() {
		return "if";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type tcond = cond.tcExp(tenv);
		tcond.checkEq(types.Bool.type, (Node)cond);
		boolean retThen = false;
		try {
			bthen.tcStat(tenv);
		} catch(ReturnVal rv) {
			retThen = true;
		}
		if(belse != null) {
			try {
				belse.tcStat(tenv);
			} catch(ReturnVal rv) {
				if(retThen)
					throw rv;
			}
		}
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		Exp ccond = cond.ccExp(env, func, funcs);
		Bloco cbthen;
		boolean retThen = false;
		try {
			cbthen = (Bloco)bthen.ccStat(env, func, funcs);
		} catch(ReturnVal rv) {
			retThen = true;
			cbthen = (Bloco)rv.val;
		}
		Bloco cbelse = null;
		if(belse != null) {
			try {
				cbelse = (Bloco)belse.ccStat(env, func, funcs);
			} catch(ReturnVal rv) {
				if(retThen)
					throw new ReturnVal(
							new If(ccond, cbthen, (Bloco)rv.val, line, col));
				else
					cbelse = (Bloco)rv.val;
			}
		}
		return new If(ccond, cbthen, cbelse, line, col);
	}

	@Override
	public String cgStat(Environment<Location> env, String indent, PrimFunc func) {
		StringBuffer buf = new StringBuffer();
		buf.append(indent + "if(" + cond.cgExp(env) + ")\n");
		boolean ret = false;
		try {
			buf.append(bthen.cgStat(env, indent, func));
		} catch(ReturnVal rv) {
			ret = true;
			buf.append(rv.val.toString());
		}
		if(belse != null) {
			buf.append(indent + "else\n");
			try {
				buf.append(belse.cgStat(env, indent, func));
			} catch(ReturnVal rv) {
				buf.append(rv.val.toString());
				if(ret)
					throw new ReturnVal(buf.toString());
			}
		}
		return buf.toString();
	}

}
