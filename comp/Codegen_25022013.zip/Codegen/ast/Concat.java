package ast;

import java.util.List;

import types.Type;

public class Concat extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Concat(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	public Object eval(Environment<Object> env) {
		return (String)l.eval(env) + (String)r.eval(env);
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type tl = l.tcExp(tenv);
		tl.checkEq(types.Str.type, (Node)l);
		Type tr = r.tcExp(tenv);
		tr.checkEq(types.Str.type, (Node)r);
		return types.Str.type;
	}

	public String label() {
		return "..";
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return new Concat(l.ccExp(env, cur, funcs),
				r.ccExp(env, cur, funcs), line, col);
	}

	@Override
	public String cgExp(Environment<Location> env) {
		return "((String)" + l.cgExp(env) + ") + " +
				"((String)" + r.cgExp(env) + ")";
	}
}
