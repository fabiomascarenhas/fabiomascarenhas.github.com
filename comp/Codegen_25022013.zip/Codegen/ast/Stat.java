package ast;

import java.util.List;

import parse.Emitter;

import types.Type;

public interface Stat {
	void run(Environment<Object> env);
	void tcStat(Environment<Type> tenv);
	Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs);
	String cgStat(Environment<Location> env, String indent, PrimFunc func);
}
