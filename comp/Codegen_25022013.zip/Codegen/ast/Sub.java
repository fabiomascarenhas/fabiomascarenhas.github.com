package ast;

import java.util.List;

import types.Type;

public class Sub extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Sub(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	public Object eval(Environment<Object> env) {
		return (Double)l.eval(env) - (Double)r.eval(env);
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type tl = l.tcExp(tenv);
		tl.checkEq(types.Num.type, (Node)l);
		Type tr = r.tcExp(tenv);
		tr.checkEq(types.Num.type, (Node)r);
		return types.Num.type;
	}

	public String label() {
		return "-";
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return new Sub(l.ccExp(env, cur, funcs),
				r.ccExp(env, cur, funcs), line, col);
	}
	
	@Override
	public String cgExp(Environment<Location> env) {
		return "((Double)" + l.cgExp(env) + ") - " +
				"((Double)" + r.cgExp(env) + ")";
	}

}
