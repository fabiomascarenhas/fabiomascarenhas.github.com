package ast;

import parse.Emitter;

public abstract class Location {
	public boolean upvalue;
	
	public Location(boolean upvalue) {
		this.upvalue = upvalue;
	}
	
	public abstract String get();
	public abstract String set(String rval);
	public abstract String getBox();

	public abstract String declare(String indent);
}
