package ast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PrimFunc extends Node {
	public String name;
	public List<Id> params;
	public Bloco body;
	public Set<Id> env;
	public PrimFunc parent;
	public boolean main;
	
	public int nextLoc = 0;
		
	public PrimFunc(String name, List<Id> params, PrimFunc parent) {
		super(0, 0);
		this.name = name;
		this.params = params;
		this.parent = parent;
		env = new HashSet<Id>();
	}
	
	public PrimFunc(int i, int j) {
		super(i, j);
	}

	public void run(Environment<Object> globalEnv) {
		if(main)
			body.run(globalEnv);
	}
	
	@Override
	public String label() {
		return name;
	}

	public int getLoc() {
		nextLoc++;
		return nextLoc;
	}
	
	public String compile(String pkg) {
		StringBuffer buf = new StringBuffer();
		buf.append("package " + pkg + ";\n\n");
		buf.append("public class " + name + " implements runtime.Func {\n");
		Environment<Location> env = new SymbolTable<Location>();
		for(Id var: this.env) {
			Location loc = 
					new LocationEnv(var.name, var.shared && var.updated);
			env.bind(var.name, loc);
			buf.append(loc.declare("  "));
		}
		buf.append("\n");
		if(this.env.isEmpty()) {
			buf.append("  public " + name + "() { }\n\n");
		} else {
			buf.append("  public " + name + "(");
			List<String> vars = new ArrayList<String>();
			for(Id var: this.env) {
				vars.add(var.shared && var.updated ?
						"runtime.Upvalue " + var.name :
							"Object " + var.name);
			} 
			buf.append(vars.get(0));
			for(int i = 1; i < vars.size(); i++)
				buf.append(", " + vars.get(i));
			buf.append(") {\n");
			for(Id var: this.env)
				buf.append("    this." + var.name + " = " + var.name + ";\n");
			buf.append("  }\n\n");
		}
		buf.append("  @Override\n");
		buf.append("  public Object apply(Object ... args) {\n");
		Environment<Location> fenv = env.extend();
		for(int i = 0; i < params.size(); i++) {
			Id param = params.get(i);
			Location loc =
					new LocationParam(i, param.shared && param.updated);
			fenv.bind(param.name, loc);
			buf.append(loc.declare("    "));
		}
		try {
			Environment<Location> benv = fenv.extend();
			for(Stat s: body.stats) {
				buf.append(s.cgStat(benv, "    ", this));
			}
			buf.append("    return null;\n");
		} catch(ReturnVal rv) {
			buf.append(rv.val.toString());
		}
		buf.append("  }\n");
		buf.append("}\n");
		return buf.toString();
	}
}
