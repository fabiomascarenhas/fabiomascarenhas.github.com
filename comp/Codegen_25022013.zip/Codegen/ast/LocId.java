package ast;

public class LocId {
	public PrimFunc owner;
	public Id id;
	
	public LocId(Id id) {
		this.id = id;
	}
	
	public LocId(Id id, PrimFunc owner) {
		this.id = id;
		this.owner = owner;
	}
}
