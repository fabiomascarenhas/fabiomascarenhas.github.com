package ast;

import java.util.ArrayList;
import java.util.List;

import runtime.Func;
import types.Type;

public class Call extends Node implements Exp, Stat {
	public Exp func;
	public List<Exp> args;
	
	public Call(Exp func, List<Exp> args, int line, int col) {
		super(line, col);
		this.func = func;
		this.args = args;
	}

	@Override
	public void run(Environment<Object> env) {
		eval(env);
	}
	
	@Override
	public Object eval(Environment<Object> env) {
		Func vfunc = (Func)func.eval(env);
		Object[] oargs = new Object[args.size()];
		for(int i = 0; i < oargs.length; i++)
			oargs[i] = args.get(i).eval(env);
		/*
		// Escopo dinâmico
		if(vfunc instanceof FuncVal) {
			((FuncVal)vfunc).env = env;
		}*/
		return vfunc.apply(oargs);
	}

	@Override
	public String label() {
		return "call";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		Type[] targs = new Type[args.size()];
		for(int i = 0; i < targs.length; i++)
			targs[i] = args.get(i).tcExp(tenv);
		types.Func tf = (types.Func)func.tcExp(tenv);
		tf.checkArgs(targs, this);
		return tf.ret;
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		tcExp(tenv);
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		Exp cfunc = func.ccExp(env, cur, funcs);
		List<Exp> cargs = new ArrayList<Exp>();
		for(Exp arg: args)
			cargs.add(arg.ccExp(env, cur, funcs));
		return new Call(cfunc, cargs, line, col);
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc cur,
			List<PrimFunc> funcs) {
		Exp cfunc = func.ccExp(env, cur, funcs);
		List<Exp> cargs = new ArrayList<Exp>();
		for(Exp arg: args)
			cargs.add(arg.ccExp(env, cur, funcs));
		return new Call(cfunc, cargs, line, col);
	}

	@Override
	public String cgExp(Environment<Location> env) {
		String cfunc = func.cgExp(env);
		if(args.size() == 0) {
			return "((runtime.Func)" + cfunc + ").apply()";
		}
		String[] cargs = new String[args.size()];
		for(int i = 0; i < args.size(); i++)
			cargs[i] = args.get(i).cgExp(env);
		StringBuffer buf = new StringBuffer();
		buf.append("((runtime.Func)" + cfunc + ").apply(");
		buf.append(cargs[0]);
		for(int i = 1; i < cargs.length; i++)
			buf.append(", " + cargs[i]);
		buf.append(")");
		return buf.toString();
	}

	@Override
	public String cgStat(Environment<Location> env, String indent, PrimFunc func) {
		return indent + cgExp(env) + ";\n";
	}

}
