package ast;

import java.util.List;

import runtime.Upvalue;
import types.Type;

public class Local extends Node implements Stat {
	public Id id;
	public Exp rval;
	
	public Local(Id id, Exp rval, int line, int col) {
		super(line, col);
		this.id = id;
		this.rval = rval;
	}
	
	public String label() {
		return "local=";
	}
	
	public void run(Environment<Object> env) {
		Object val;
		if(id.shared && id.updated)
			val = new Upvalue(rval != null ? rval.eval(env) : null);
		else
			val = rval != null ? rval.eval(env) : null;
		env.bind(id.name, val);
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		if(id.type == null)
			id.type = rval.tcExp(tenv);
		// lado direito não pode ser nil ou resultado
		// de chamada de função com tipo de retorno void
		if(id.type != types.Any.type &&
				id.type != types.Void.type)
			tenv.bind(id.name, id.type);
		else
			throw new RuntimeException(
					"tipo inválido para declaração de variável, linha " +
					line + ", col " + col + ": " + id.type);
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		env.bind(id.name, new LocId(id, func));
		Exp crval = rval != null ? rval.ccExp(env, func, funcs) : null;
		return new Local(id, crval, line, col);
	}

	@Override
	public String cgStat(Environment<Location> env, String indent, PrimFunc func) {
		Location loc; 
		if(id.shared && id.updated) {
			loc = new LocationLocal(func.getLoc(), true);
		} else {
			loc = new LocationLocal(func.getLoc(), false);
		}
		String crval = rval.cgExp(env);
		env.bind(id.name, loc);
		return loc.declare(indent) +
				(rval == null ? "" : indent + loc.set(crval));
	}
}
