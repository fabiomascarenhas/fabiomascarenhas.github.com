package ast;

import java.util.List;

import types.Type;

public class While extends Node implements Stat {
	public Exp cond;
	public Bloco corpo;
	
	public While(Exp cond, Bloco corpo, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.corpo = corpo;
	}

	@Override
	public void run(Environment<Object> env) {
		while((Boolean)cond.eval(env)) {
			corpo.run(env);
		}
	}

	@Override
	public String label() {
		return "while";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type tcond = cond.tcExp(tenv);
		tcond.checkEq(types.Bool.type, (Node)cond);
		try {
			corpo.tcStat(tenv);
		} catch(ReturnVal rv) { }
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		Exp ccond = cond.ccExp(env, func, funcs);
		Bloco ccorpo;
		try {
			ccorpo = (Bloco)corpo.ccStat(env, func, funcs);
		} catch(ReturnVal rv) {
			ccorpo = (Bloco)rv.val;
		}
		return new While(ccond,	ccorpo, line, col);
	}

	@Override
	public String cgStat(Environment<Location> env, String indent, PrimFunc func) {
		StringBuffer buf = new StringBuffer();
		buf.append(indent + "while(" + cond.cgExp(env) + ")");
		try {
			buf.append(corpo.cgStat(env, indent, func));
		} catch(ReturnVal rv) {
			buf.append(rv.val.toString());
		}
		return buf.toString();
	}

}
