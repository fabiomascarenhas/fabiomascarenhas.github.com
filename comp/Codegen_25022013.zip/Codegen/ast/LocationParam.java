package ast;

public class LocationParam extends Location {
	public int idx;

	public LocationParam(int idx, boolean upvalue) {
		super(upvalue);
		this.idx = idx;
	}

	@Override
	public String get() {
		if(upvalue)
			return "$arg" + idx + ".val";
		else
			return "args[" + idx + "]";
	}

	@Override
	public String set(String rval) {
		if(upvalue)
			return "$arg" + idx + ".val = " + rval + ";\n";
		else
			return "args[" + idx + "] = " + rval + ";\n";
	}

	@Override
	public String getBox() {
		if(upvalue)
			return "$arg" + idx;
		else
			return "args[" + idx + "]";
	}

	@Override
	public String declare(String indent) {
		if(upvalue) {
			return indent + "runtime.Upvalue $arg" + idx +
					" = new runtime.Upvalue(args[" +	idx + "]);\n";
		} else {
			return "";
		}
	}

}
