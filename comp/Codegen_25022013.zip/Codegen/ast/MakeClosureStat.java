package ast;

import java.util.ArrayList;
import java.util.List;

import runtime.Upvalue;
import types.Type;

public class MakeClosureStat extends Node implements Stat {
	public Id name;
	public PrimFunc func;
	
	public MakeClosureStat(Id name, PrimFunc pf, int line, int col) {
		super(line, col);
		this.name = name;
		this.func = pf;
	}

	@Override
	public void run(Environment<Object> env) {
		Environment<Object> fenv = new SymbolTable<Object>();
		Upvalue upval = null;
		if(name.shared && name.updated) {
			upval = new Upvalue(null);
			fenv.bind(name.name, upval);
			env.bind(name.name, upval);
		} else {
		}
		for(Id name: func.env) {
			fenv.bind(name.name, env.lookup(name.name));
		}
		FuncVal funval = new FuncVal(func.params, func.body, fenv);
		if(name.shared && name.updated) {
			upval.val = funval;
		} else {
			env.bind(name.name, funval);
		}
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public String label() {
		return "closurestat";
	}

	@Override
	public String cgStat(Environment<Location> env, String indent, PrimFunc func) {
		StringBuffer buf = new StringBuffer();
		Location loc; 
		if(name.shared && name.updated) {
			loc = new LocationLocal(func.getLoc(), true);
		} else {
			loc = new LocationLocal(func.getLoc(), false);
		}
		env.bind(name.name, loc);
		buf.append(loc.declare(indent));
		if(this.func.env.isEmpty()) {
			buf.append(indent + loc.set("new " + this.func.name + "()"));
			return buf.toString();
		}
		StringBuffer make = new StringBuffer();
		make.append("new " + this.func.name + "(");
		List<String> cenv = new ArrayList<String>();
		for(Id name: this.func.env) {
			cenv.add(env.lookup(name.name).getBox());
		}
		make.append(cenv.get(0));
		for(int i = 1; i < cenv.size(); i++)
			make.append(", " + cenv.get(i));
		make.append(")");
		buf.append(indent + loc.set(make.toString()));
		return buf.toString();
	}

}
