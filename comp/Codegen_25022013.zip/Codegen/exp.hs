data Exp t = Soma (Exp t) (Exp t) | Sub (Exp t) (Exp t) | Num t

exp1 = Soma (Sub (Num 3) (Num 2)) (Num 5)

eval (Soma e1 e2) = (eval e1) + (eval e2)
eval (Sub e1 e2) = (eval e1) - (eval e2)
eval (Num n) = n

nats n = n:(nats (n + 1))

nums :: [Integer]
nums = nats 1

tk n [] = []
tk 0 (x:xs) = []
tk 1 (x:xs) = [x]
tk (n+1) (x:xs) = x:(tk n xs)

