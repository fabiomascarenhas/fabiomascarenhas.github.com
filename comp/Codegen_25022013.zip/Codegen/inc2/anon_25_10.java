package inc2;

import runtime.Upvalue;
import runtime.Func;

public class anon_25_10 implements Func {
	public Upvalue n;
	public Upvalue y;
	
	public anon_25_10(Upvalue n, Upvalue y) {
		this.n = n;
		this.y = y;
	}

	@Override
	public Object apply(Object ... args) {
		if(args.length != 1)
			throw new RuntimeException("erro de aridade");
		this.n.val = (Double)this.n.val + (Double)args[0]; // n = n + x
		this.y.val =	 (Double)this.y.val + 1.0;  // y = y + 1
		return this.n.val;
	}
	
}
