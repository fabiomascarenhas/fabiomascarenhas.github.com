package runtime;

import ast.PrimFunc;


public class ToStringFunc extends PrimFunc implements Func {

	public ToStringFunc() {
		super(0, 0);
		name = "runtime.ToStringFunc";
	}

	@Override
	public Object apply(Object... args) {
		return args[0].toString();
	}

}
