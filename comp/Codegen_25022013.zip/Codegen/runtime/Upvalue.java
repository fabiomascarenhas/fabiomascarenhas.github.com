package runtime;

public class Upvalue {
	public Object val;
	
	public Upvalue(Object val) {
		this.val = val;
	}
}
