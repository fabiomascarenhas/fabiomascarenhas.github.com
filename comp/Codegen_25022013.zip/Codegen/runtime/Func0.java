package runtime;

public interface Func0<R> {
	R apply();
}
