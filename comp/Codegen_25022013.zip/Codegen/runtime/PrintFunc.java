package runtime;

import ast.PrimFunc;


public class PrintFunc extends PrimFunc implements Func {

	public PrintFunc() {
		super(0, 0);
		name = "runtime.PrintFunc";
	}
	
	@Override
	public Object apply(Object... args) {
		for(Object arg: args) {
			System.out.print(arg);
			System.out.print("\t");
		}
		System.out.println();
		return null;
	}

}
