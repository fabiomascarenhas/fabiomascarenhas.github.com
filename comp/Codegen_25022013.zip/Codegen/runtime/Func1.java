package runtime;

public interface Func1<R, X> {
	R apply(X x);
}
