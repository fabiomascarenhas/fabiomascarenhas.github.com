package inc;

public class inc implements runtime.Func {
  Object print;
  runtime.Upvalue y;

  public inc(Object print, runtime.Upvalue y) {
    this.print = print;
    this.y = y;
  }

  @Override
  public Object apply(Object ... args) {
    ((runtime.Func)this.print).apply(args[0]);
    this.y.val = ((Double)this.y.val) + ((Double)args[0]);
    return this.y.val;
  }
}
