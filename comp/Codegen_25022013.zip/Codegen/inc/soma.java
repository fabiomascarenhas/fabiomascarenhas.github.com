package inc;

public class soma implements runtime.Func {

  public soma() { }

  @Override
  public Object apply(Object ... args) {
    return ((Double)args[0]) + ((Double)args[1]);
  }
}
