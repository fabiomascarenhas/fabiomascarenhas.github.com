package inc;

public class main implements runtime.Func {
  Object print;

  public main(Object print) {
    this.print = print;
  }

  @Override
  public Object apply(Object ... args) {
    runtime.Upvalue $loc1 = new runtime.Upvalue(null);
    $loc1.val = 0.0;
    Object $loc2;
    $loc2 = new inc(this.print, $loc1);
    Object $loc3;
    $loc3 = new soma();
    ((runtime.Func)this.print).apply(((runtime.Func)$loc3).apply(2.0, 3.0));
    {
      ((runtime.Func)this.print).apply(((runtime.Func)$loc2).apply(1.0));
      Object $loc4;
      $loc4 = 5.0;
      ((runtime.Func)this.print).apply($loc4);
      ((runtime.Func)this.print).apply(((runtime.Func)$loc2).apply(3.0));
    }
    Object $loc5;
    $loc5 = new contador($loc1);
    {
      Object $loc6;
      $loc6 = ((runtime.Func)$loc5).apply(1.0);
      Object $loc7;
      $loc7 = ((runtime.Func)$loc5).apply(1.0);
      ((runtime.Func)this.print).apply(((runtime.Func)$loc6).apply(2.0));
      ((runtime.Func)this.print).apply(((runtime.Func)$loc6).apply(3.0));
      ((runtime.Func)this.print).apply(((runtime.Func)$loc7).apply(1.0));
      ((runtime.Func)this.print).apply($loc1.val);
    }
    return null;
  }
}
