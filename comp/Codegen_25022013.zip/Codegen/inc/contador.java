package inc;

public class contador implements runtime.Func {
  runtime.Upvalue y;

  public contador(runtime.Upvalue y) {
    this.y = y;
  }

  @Override
  public Object apply(Object ... args) {
    runtime.Upvalue $arg0 = new runtime.Upvalue(args[0]);
    return new anon_25_10($arg0, this.y);
  }
}
