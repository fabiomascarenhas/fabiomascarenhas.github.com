
public interface Exp {
	void checaEscopo(TabSimb<Void> escopo);
}
