import java.util.ArrayList;
import java.util.List;

public class If extends Node implements Cmd {
	public Exp cond;
	public Bloco cthen;
	public Bloco celse;
	
	public If(Exp cd, Bloco ct, Bloco ce, int _lin) {
		super(_lin);
		cond = cd;
		cthen = ct;
		celse = ce;
	}

	public If(Exp cd, Bloco ct, int _lin) {
		this(cd, ct, new Bloco(new ArrayList<String>(), _lin), _lin);
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		cond.checaEscopo(escopo);
		cthen.checaEscopo(escopo);
		celse.checaEscopo(escopo);
	}
}
