
public class Write extends Node implements Cmd {
	public Exp exp;
	
	public Write(Exp e, int _lin) {
		super(_lin);
		exp = e;
	}

	@Override
	public void checaEscopo(TabSimb<Void> escopo) {
		exp.checaEscopo(escopo);
	}
}
