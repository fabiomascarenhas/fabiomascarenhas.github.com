package ast;

import java.util.List;

import types.Type;

public class Num extends Node implements Exp {
	public double val;
	
	public Num(String tok, int line, int col) {
		super(line, col);
		val = Double.parseDouble(tok);
	}

	public Object eval(Environment<Object> env) {
		return val;
	}

	public String label() {
		return "" + val;
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Num.type;
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return this;
	}
}
