package ast;

import java.util.List;

import types.Type;

public interface Exp {
	Object eval(Environment<Object> env);
	Type tcExp(Environment<Type> tenv);
	Exp ccExp(Environment<LocId> env, 
			PrimFunc cur, List<PrimFunc> funcs);
}
