package ast;

public interface Func {
	Object apply(Object ... args);
}
