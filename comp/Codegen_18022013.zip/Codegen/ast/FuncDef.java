package ast;

import java.util.List;

import types.Type;

public class FuncDef extends Node implements Exp {
	public List<Id> params;
	public Bloco body;
	public Type retType;
	
	public FuncDef(List<Id> params, Bloco body, Type retType,
			int line, int col) {
		super(line, col);
		this.params = params;
		this.body = body;
		this.retType = retType;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return new FuncVal(params, body, env);
	}

	@Override
	public String label() {
		return "function";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		tenv = tenv.extend();
		Type[] tparams = new Type[params.size()];
		for(int i = 0; i < tparams.length; i++) {
			tparams[i] = params.get(i).type;
			tenv.bind(params.get(i).name, tparams[i]);
		}
		tenv.bind("$retval", retType);
		try {
			body.tcStat(tenv);
			// não houve return em todos os ramos, logo
			// função retorna void
			tenv.lookup("$retval").checkEq(types.Void.type, this);
		} catch(ReturnVal rv) { }
		return new types.Func(retType, tparams);
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		PrimFunc pf = new PrimFunc(params, cur);
		env = env.extend();
		for(Id param : params) {
			env.bind(param.name, new LocId(param, pf, true));
		}
		pf.body = (Bloco)body.ccStat(env, pf, funcs);
		funcs.add(pf);
		return new MakeClosure(pf, line, col);
	}

}
