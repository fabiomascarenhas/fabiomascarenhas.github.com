package ast;

import java.util.List;

import types.Type;

public class MakeClosureStat extends Node implements Stat {
	public Id name;
	public PrimFunc func;
	
	public MakeClosureStat(Id name, PrimFunc pf, int line, int col) {
		super(line, col);
		this.name = name;
		this.func = pf;
	}

	@Override
	public void run(Environment<Object> env) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public String label() {
		return "closurestat";
	}

}
