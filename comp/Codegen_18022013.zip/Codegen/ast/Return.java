package ast;

import java.util.List;

import types.Type;

public class Return extends Node implements Stat {
	public Exp exp;
	
	public Return(Exp exp, int line, int col) {
		super(line, col);
		this.exp = exp;
	}

	@Override
	public void run(Environment<Object> env) {
		throw new ReturnVal(exp.eval(env));
	}

	@Override
	public String label() {
		return "return";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type texp = exp.tcExp(tenv);
		tenv.lookup("$retval").checkEq(texp, this);
		throw new ReturnVal();
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		return new Return(exp.ccExp(env, func, funcs),
				line, col);
	}

}
