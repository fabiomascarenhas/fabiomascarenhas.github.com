package ast;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PrimFunc extends Node {
	public List<Id> params;
	public Bloco body;
	public Set<Id> env;
	public PrimFunc parent;
	public boolean main;
	
	public PrimFunc(List<Id> params, PrimFunc parent) {
		super(0, 0);
		this.params = params;
		this.parent = parent;
		env = new HashSet<Id>();
	}

	@Override
	public String label() {
		return "primfunc";
	}
	
}
