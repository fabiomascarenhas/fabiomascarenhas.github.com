package ast;

import java.util.List;

import types.Type;

public class FuncStat extends Node implements Stat {
	public Id name;
	public List<Id> params;
	public Bloco body;
	public Type retType;
	
	public FuncStat(Id name, List<Id> params, Bloco body,
			Type retType, int line, int col) {
		super(line, col);
		this.name = name;
		this.params = params;
		this.body = body;
		this.retType = retType;
	}

	@Override
	public void run(Environment<Object> env) {
		env.bind(name.name, null);
		env.update(name.name, new FuncVal(params, body, env));
	}

	@Override
	public String label() {
		return "function";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		Type[] tparams = new Type[params.size()];
		Environment<Type> tbody = tenv.extend();
		for(int i = 0; i < tparams.length; i++) {
			tparams[i] = params.get(i).type;
			tbody.bind(params.get(i).name, tparams[i]);
		}
		Type tfunc = new types.Func(retType, tparams);
		// para chamada recursiva
		tenv.bind(name.name, tfunc);
		tbody.bind("$retval", retType);
		try {
			body.tcStat(tbody);
			// não houve return em todos os ramos,
			// função deve retornar tipo void
			tbody.lookup("$retval").checkEq(types.Void.type, this);
		} catch(ReturnVal rv) { }
		System.out.println(name.name + ": " + tenv.lookup(name.name));
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc cur,
			List<PrimFunc> funcs) {
		env.bind(name.name, new LocId(name, cur, false));
		PrimFunc pf = new PrimFunc(params, cur);
		env = env.extend();
		for(Id param : params) {
			env.bind(param.name, new LocId(param, pf, true));
		}
		pf.body = (Bloco)body.ccStat(env, pf, funcs);
		funcs.add(pf);
		return new MakeClosureStat(name, pf, line, col);
	}

}
