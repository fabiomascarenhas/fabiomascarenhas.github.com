package ast;

public class LocId {
	public PrimFunc owner;
	public boolean shared;
	public boolean param;
	public Id id;
	
	public LocId(Id id) {
		this.id = id;
		shared = false;
	}
	
	public LocId(Id id, PrimFunc owner, boolean param) {
		this.id = id;
		this.owner = owner;
		this.param = param;
	}
}
