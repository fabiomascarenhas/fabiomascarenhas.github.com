package ast;

import java.util.List;

import types.Type;

public class MakeClosure extends Node implements Exp {
	public PrimFunc func;
	
	public MakeClosure(PrimFunc pf, int line, int col) {
		super(line, col);
		func = pf;
	}

	@Override
	public Object eval(Environment<Object> env) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		throw new RuntimeException("operação inválida");
	}

	@Override
	public String label() {
		return "closure";
	}

}
