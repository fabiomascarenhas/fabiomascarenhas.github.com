package ast;

import java.util.List;

import types.Type;

public class True extends Node implements Exp {

	public True(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return true;
	}

	@Override
	public String label() {
		return "true";
	}

	@Override
	public Type tcExp(Environment<Type> tenv) {
		return types.Bool.type;
	}

	@Override
	public Exp ccExp(Environment<LocId> env, PrimFunc cur, List<PrimFunc> funcs) {
		return this;
	}

}
