package ast;

import java.util.ArrayList;
import java.util.List;

import types.Type;

public class Bloco extends Node implements Stat {
	public List<Stat> stats;
	
	public Bloco(List<Stat> stats, int line, int col) {
		super(line, col);
		this.stats = stats;
	}

	@Override
	public void run(Environment<Object> env) {
		Environment<Object> benv = env.extend();
		for(Stat s: stats)
			s.run(benv);
	}

	@Override
	public String label() {
		return "bloco";
	}

	@Override
	public void tcStat(Environment<Type> tenv) {
		tenv = tenv.extend();
		for(Stat s: stats)
			s.tcStat(tenv);
	}

	@Override
	public Stat ccStat(Environment<LocId> env, PrimFunc func,
			List<PrimFunc> funcs) {
		env = env.extend();
		List<Stat> cstats = new ArrayList<Stat>();
		for(Stat s: stats) {
			cstats.add(s.ccStat(env, func, funcs));
		}
		return new Bloco(cstats, line, col);
	}
	
	public List<PrimFunc> cc(String ... globals) {
		Environment<LocId> env = new SymbolTable<LocId>();
		PrimFunc top = new PrimFunc(new ArrayList<Id>(), null);
		for(String global : globals)
			env.bind(global, 
					new LocId(new Id(global, line, col), top, false));
		List<PrimFunc> funcs = new ArrayList<PrimFunc>();
		funcs.add(top);
		top.body = (Bloco)ccStat(env, top, funcs);
		top.main = true;
		return funcs;
	}
}
