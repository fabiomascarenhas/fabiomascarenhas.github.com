package types;

import ast.Node;

public class Any extends Type {
	public static Type type = new Any();
	
	private Any() { }
	
	@Override
	public void checkEq(Type t, Node n) { }
	
	public String toString() {
		return "any";
	}
	
}
