package types;

import ast.Node;

public class Func extends Type {
	public Type ret;
	public Type[] params;
	
	public Func(Type ret, Type ... params) {
		this.params = params;
		this.ret = ret;
	}
	
	@Override
	public void checkEq(Func f, Node n) {
		if(params.length != f.params.length)
			n.typeError(this, f);
		ret.checkEq(f.ret, n);
		for(int i = 0; i < params.length; i++)
			params[i].checkEq(f.params[i], n);
	}

	@Override
	public void checkEq(Type t, Node n) {
		t.checkEq(this, n);
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("(");
		if(params.length > 0)
			sb.append(params[0]);
		for(int i = 1; i < params.length; i++) {
			sb.append(",");
			sb.append(params[i]);
		}
		sb.append(") -> ");
		sb.append(ret);
		return sb.toString();
	}

	public void checkArgs(Type[] targs, Node n) {
		if(params.length != targs.length)
			n.arityError();
		for(int i = 0; i < params.length; i++)
			params[i].checkEq(targs[i], n);
	}
	
}
