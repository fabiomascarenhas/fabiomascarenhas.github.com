
public class Mult extends Exp {
	public Exp esq;
	public Exp dir;
	
	public Mult(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		String tesq = esq.checaTipo(tipos);
		String tdir = dir.checaTipo(tipos);
		if(tesq.equals("int") && tdir.equals("int"))
			return "int";
		if(tesq.equals("real") && Tipo.subtipo(tdir, "real")) {
			if(!tdir.equals("real"))
				dir = new Cast(dir, "real");
			return "real";
		}
		if(Tipo.subtipo(tesq, "real") && tdir.equals("real")) {
			if(!tesq.equals("real"))
				esq = new Cast(esq, "real");
			return "real";
		}
		throw new RuntimeException("erro de tipo na linha " + 
			lin + ", tipos da multiplicação são " + tesq + " e " + tdir);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		esq.geraCodigo(ctx, vars); // empilha valor de esq
		dir.geraCodigo(ctx, vars); // empilha valor de dir
		ctx.imul(); // desempilha v. esq e v. dir e empilha v. esq * dir
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug no verificador de tipos");
	}
}
