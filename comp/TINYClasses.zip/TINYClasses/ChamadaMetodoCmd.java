import java.util.List;

public class ChamadaMetodoCmd extends Node implements Cmd {
	public Exp obj;
	public String nome;
	public List<Exp> args;

	private int imet;
	
	public ChamadaMetodoCmd(Exp _obj, Token tok, List<Exp> _args) {
		super(tok.lin);
		obj = _obj;
		nome = tok.lexeme;
		args = _args;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		String tcls = obj.checaTipo(tipos);
		Classe cls = Prog.eclasses.procurar(tcls, lin);
		Proc tmet;
		if(cls.nmets.contains(nome)) {
			imet = cls.nmets.indexOf(nome) + 1;
			tmet = cls.mets.get(imet - 1);
		} else {
			throw new RuntimeException("método " + nome +
					" não existe na classe " + tcls + " na linha " + lin);
		}
		if(tmet.ptipos.size() != args.size())
			throw new RuntimeException("erro na chamada de procedimento na linha " +
		            lin + ", esperados " + tmet.ptipos.size() + " parâmetros e passados " +
					args.size() + " argumentos");
		for(int i = 0; i < tmet.ptipos.size(); i++) {
			String targ = args.get(i).checaTipo(tipos);
			if(!Tipo.subtipo(targ, tmet.ptipos.get(i)))
				throw new RuntimeException("erro no " + (i+1) + "-ésimo argumento da chamada de procedimento na linha " + 
			            lin + ", esperado " + tmet.ptipos.get(i) + " e encontrado " + targ);
			if(!targ.equals(tmet.ptipos.get(i)))
				args.set(i, new Cast(args.get(i), tmet.ptipos.get(i)));
		}
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		for(int i = args.size() - 1; i >= 0; i--) {
			args.get(i).geraCodigo(ctx, vars);
		}
		obj.geraCodigo(ctx, vars);
		ctx.invokevirtual(imet, args.size()); // chama proc e empilha valor de retorno depois de desempilhar args
		ctx.pop();
	}

}
