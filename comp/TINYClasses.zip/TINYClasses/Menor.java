
public class Menor extends Exp {
	public Exp esq;
	public Exp dir;
	
	public Menor(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		String tesq = esq.checaTipo(tipos);
		String tdir = dir.checaTipo(tipos);
		if(tesq.equals("int") && tdir.equals("int"))
			return "bool";
		if(Tipo.subtipo(tesq, "real") &&
		   Tipo.subtipo(tdir, "real")) {
			if(!tesq.equals("real"))
				esq = new Cast(esq, "real");
			if(!tdir.equals("real"))
				dir = new Cast(dir, "real");
			return "bool";
		}
		throw new RuntimeException("erro de tipo na linha " + 
				lin + ", tipos da comparação < são " + tesq + " e " + tdir);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		int labF = ctx.label();
		int labS = ctx.label();
		this.geraSaltoF(ctx, vars, labF);
		ctx.icload(1); // this é verdadeira
		ctx.jmp(labS);
		ctx.label(labF); // labF:
		ctx.icload(0);
		ctx.label(labS); // labS:
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		esq.geraCodigo(ctx, vars); // empilha v. esq
		dir.geraCodigo(ctx, vars); // empilha v. dir
		ctx.if_icmpge(lab); // desempilha v.esq e v.dir e salta para lab se v.esq>=v.dir
	}
}
