// Output created by jacc on Wed Feb 24 12:20:22 BRT 2016


import java.util.List;
import java.util.ArrayList;

class ParserJACC implements Tokens {
    private int yyss = 100;
    private int yytok;
    private int yysp = 0;
    private int[] yyst;
    protected int yyerrno = (-1);
    private Object[] yysv;
    private Object yyrv;

    public boolean parse() {
        int yyn = 0;
        yysp = 0;
        yyst = new int[yyss];
        yysv = new Object[yyss];
        yytok = (tipo
                 );
    loop:
        for (;;) {
            switch (yyn) {
                case 0:
                    yyst[yysp] = 0;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 155:
                    yyn = yys0();
                    continue;

                case 1:
                    yyst[yysp] = 1;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 156:
                    switch (yytok) {
                        case ENDINPUT:
                            yyn = 310;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 2:
                    yyst[yysp] = 2;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 157:
                    switch (yytok) {
                        case ';':
                            yyn = 11;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 3:
                    yyst[yysp] = 3;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 158:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr4();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 4:
                    yyst[yysp] = 4;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 159:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr8();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 5:
                    yyst[yysp] = 5;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 160:
                    switch (yytok) {
                        case ';':
                            yyn = 13;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 6:
                    yyst[yysp] = 6;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 161:
                    switch (yytok) {
                        case ';':
                            yyn = yyr6();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 7:
                    yyst[yysp] = 7;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 162:
                    yyn = yys7();
                    continue;

                case 8:
                    yyst[yysp] = 8;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 163:
                    switch (yytok) {
                        case ID:
                            yyn = 24;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 9:
                    yyst[yysp] = 9;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 164:
                    switch (yytok) {
                        case ID:
                            yyn = 25;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 10:
                    yyst[yysp] = 10;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 165:
                    switch (yytok) {
                        case ID:
                            yyn = 29;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 11:
                    yyst[yysp] = 11;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 166:
                    yyn = yys11();
                    continue;

                case 12:
                    yyst[yysp] = 12;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 167:
                    yyn = yys12();
                    continue;

                case 13:
                    yyst[yysp] = 13;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 168:
                    yyn = yys13();
                    continue;

                case 14:
                    yyst[yysp] = 14;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 169:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr20();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 15:
                    yyst[yysp] = 15;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 170:
                    switch (yytok) {
                        case '.':
                            yyn = 36;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 16:
                    yyst[yysp] = 16;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 171:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 37;
                            continue;
                        case '(':
                            yyn = 38;
                            continue;
                        case '.':
                            yyn = yyr62();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 17:
                    yyst[yysp] = 17;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 172:
                    yyn = yys17();
                    continue;

                case 18:
                    yyst[yysp] = 18;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 173:
                    switch (yytok) {
                        case ID:
                            yyn = 47;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 19:
                    yyst[yysp] = 19;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 174:
                    yyn = yys19();
                    continue;

                case 20:
                    yyst[yysp] = 20;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 175:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr43();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 21:
                    yyst[yysp] = 21;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 176:
                    switch (yytok) {
                        case '.':
                            yyn = yyr63();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 22:
                    yyst[yysp] = 22;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 177:
                    yyn = yys22();
                    continue;

                case 23:
                    yyst[yysp] = 23;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 178:
                    yyn = yys23();
                    continue;

                case 24:
                    yyst[yysp] = 24;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 179:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 51;
                            continue;
                        case ':':
                            yyn = 52;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 25:
                    yyst[yysp] = 25;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 180:
                    switch (yytok) {
                        case '(':
                            yyn = 53;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 26:
                    yyst[yysp] = 26;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 181:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr24();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 27:
                    yyst[yysp] = 27;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 182:
                    switch (yytok) {
                        case ',':
                            yyn = 54;
                            continue;
                        case ';':
                            yyn = 55;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 28:
                    yyst[yysp] = 28;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 183:
                    switch (yytok) {
                        case ',':
                            yyn = 56;
                            continue;
                        case ':':
                            yyn = 57;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 29:
                    yyst[yysp] = 29;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 184:
                    switch (yytok) {
                        case ',':
                        case ':':
                            yyn = yyr31();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 30:
                    yyst[yysp] = 30;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 185:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr2();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 31:
                    yyst[yysp] = 31;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 186:
                    switch (yytok) {
                        case ';':
                            yyn = 58;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 32:
                    yyst[yysp] = 32;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 187:
                    switch (yytok) {
                        case ';':
                            yyn = yyr5();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 33:
                    yyst[yysp] = 33;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 188:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr19();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 34:
                    yyst[yysp] = 34;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 189:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr3();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 35:
                    yyst[yysp] = 35;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 190:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr7();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 36:
                    yyst[yysp] = 36;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 191:
                    switch (yytok) {
                        case ID:
                            yyn = 59;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 37:
                    yyst[yysp] = 37;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 192:
                    yyn = yys37();
                    continue;

                case 38:
                    yyst[yysp] = 38;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 193:
                    yyn = yys38();
                    continue;

                case 39:
                    yyst[yysp] = 39;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 194:
                    yyn = yys39();
                    continue;

                case 40:
                    yyst[yysp] = 40;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 195:
                    switch (yytok) {
                        case '.':
                            yyn = 71;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 41:
                    yyst[yysp] = 41;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 196:
                    yyn = yys41();
                    continue;

                case 42:
                    yyst[yysp] = 42;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 197:
                    switch (yytok) {
                        case ID:
                            yyn = 73;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 43:
                    yyst[yysp] = 43;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 198:
                    yyn = yys43();
                    continue;

                case 44:
                    yyst[yysp] = 44;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 199:
                    yyn = yys44();
                    continue;

                case 45:
                    yyst[yysp] = 45;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 200:
                    yyn = yys45();
                    continue;

                case 46:
                    yyst[yysp] = 46;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 201:
                    yyn = yys46();
                    continue;

                case 47:
                    yyst[yysp] = 47;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 202:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr38();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 48:
                    yyst[yysp] = 48;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 203:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case UNTIL:
                            yyn = 75;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 49:
                    yyst[yysp] = 49;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 204:
                    yyn = yys49();
                    continue;

                case 50:
                    yyst[yysp] = 50;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 205:
                    yyn = yys50();
                    continue;

                case 51:
                    yyst[yysp] = 51;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 206:
                    switch (yytok) {
                        case PROCEDURE:
                            yyn = 9;
                            continue;
                        case ID:
                            yyn = 29;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 52:
                    yyst[yysp] = 52;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 207:
                    switch (yytok) {
                        case ID:
                            yyn = 79;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 53:
                    yyst[yysp] = 53;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 208:
                    switch (yytok) {
                        case ID:
                            yyn = 29;
                            continue;
                        case ')':
                            yyn = 81;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 54:
                    yyst[yysp] = 54;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 209:
                    switch (yytok) {
                        case ID:
                            yyn = 29;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 55:
                    yyst[yysp] = 55;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 210:
                    yyn = yys55();
                    continue;

                case 56:
                    yyst[yysp] = 56;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 211:
                    switch (yytok) {
                        case ID:
                            yyn = 83;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 57:
                    yyst[yysp] = 57;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 212:
                    switch (yytok) {
                        case BOOL:
                            yyn = 85;
                            continue;
                        case ID:
                            yyn = 86;
                            continue;
                        case INT:
                            yyn = 87;
                            continue;
                        case REAL:
                            yyn = 88;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 58:
                    yyst[yysp] = 58;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 213:
                    yyn = yys58();
                    continue;

                case 59:
                    yyst[yysp] = 59;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 214:
                    switch (yytok) {
                        case ATTRIB:
                            yyn = 90;
                            continue;
                        case '(':
                            yyn = 91;
                            continue;
                        case '.':
                            yyn = yyr64();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 60:
                    yyst[yysp] = 60;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 215:
                    yyn = yys60();
                    continue;

                case 61:
                    yyst[yysp] = 61;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 216:
                    yyn = yys61();
                    continue;

                case 62:
                    yyst[yysp] = 62;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 217:
                    switch (yytok) {
                        case ')':
                            yyn = 92;
                            continue;
                        case ',':
                            yyn = 93;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 63:
                    yyst[yysp] = 63;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 218:
                    yyn = yys63();
                    continue;

                case 64:
                    yyst[yysp] = 64;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 219:
                    yyn = yys64();
                    continue;

                case 65:
                    yyst[yysp] = 65;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 220:
                    yyn = yys65();
                    continue;

                case 66:
                    yyst[yysp] = 66;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 221:
                    yyn = yys66();
                    continue;

                case 67:
                    yyst[yysp] = 67;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 222:
                    yyn = yys67();
                    continue;

                case 68:
                    yyst[yysp] = 68;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 223:
                    yyn = yys68();
                    continue;

                case 69:
                    yyst[yysp] = 69;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 224:
                    yyn = yys69();
                    continue;

                case 70:
                    yyst[yysp] = 70;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 225:
                    yyn = yys70();
                    continue;

                case 71:
                    yyst[yysp] = 71;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 226:
                    switch (yytok) {
                        case ID:
                            yyn = 101;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 72:
                    yyst[yysp] = 72;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 227:
                    yyn = yys72();
                    continue;

                case 73:
                    yyst[yysp] = 73;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 228:
                    switch (yytok) {
                        case '(':
                            yyn = 104;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 74:
                    yyst[yysp] = 74;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 229:
                    yyn = yys74();
                    continue;

                case 75:
                    yyst[yysp] = 75;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 230:
                    yyn = yys75();
                    continue;

                case 76:
                    yyst[yysp] = 76;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 231:
                    switch (yytok) {
                        case '.':
                            yyn = yyr65();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 77:
                    yyst[yysp] = 77;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 232:
                    switch (yytok) {
                        case ',':
                            yyn = 54;
                            continue;
                        case END:
                            yyn = 107;
                            continue;
                        case ';':
                            yyn = 108;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 78:
                    yyst[yysp] = 78;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 233:
                    switch (yytok) {
                        case END:
                            yyn = 109;
                            continue;
                        case ';':
                            yyn = 110;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 79:
                    yyst[yysp] = 79;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 234:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 111;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 80:
                    yyst[yysp] = 80;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 235:
                    switch (yytok) {
                        case ',':
                            yyn = 54;
                            continue;
                        case ')':
                            yyn = 112;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 81:
                    yyst[yysp] = 81;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 236:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 113;
                            continue;
                        case ':':
                            yyn = 114;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 82:
                    yyst[yysp] = 82;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 237:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr23();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 83:
                    yyst[yysp] = 83;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 238:
                    switch (yytok) {
                        case ',':
                        case ':':
                            yyn = yyr30();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 84:
                    yyst[yysp] = 84;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 239:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                            yyn = yyr25();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 85:
                    yyst[yysp] = 85;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 240:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr28();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 86:
                    yyst[yysp] = 86;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 241:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr29();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 87:
                    yyst[yysp] = 87;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 242:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr26();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 88:
                    yyst[yysp] = 88;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 243:
                    switch (yytok) {
                        case ',':
                        case ')':
                        case END:
                        case ';':
                        case BEGIN:
                            yyn = yyr27();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 89:
                    yyst[yysp] = 89;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 244:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ENDINPUT:
                            yyn = yyr1();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 90:
                    yyst[yysp] = 90;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 245:
                    yyn = yys90();
                    continue;

                case 91:
                    yyst[yysp] = 91;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 246:
                    yyn = yys91();
                    continue;

                case 92:
                    yyst[yysp] = 92;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 247:
                    yyn = yys92();
                    continue;

                case 93:
                    yyst[yysp] = 93;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 248:
                    yyn = yys93();
                    continue;

                case 94:
                    yyst[yysp] = 94;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 249:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case ELSE:
                            yyn = 119;
                            continue;
                        case END:
                            yyn = 120;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 95:
                    yyst[yysp] = 95;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 250:
                    yyn = yys95();
                    continue;

                case 96:
                    yyst[yysp] = 96;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 251:
                    yyn = yys96();
                    continue;

                case 97:
                    yyst[yysp] = 97;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 252:
                    yyn = yys97();
                    continue;

                case 98:
                    yyst[yysp] = 98;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 253:
                    yyn = yys98();
                    continue;

                case 99:
                    yyst[yysp] = 99;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 254:
                    yyn = yys99();
                    continue;

                case 100:
                    yyst[yysp] = 100;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 255:
                    yyn = yys100();
                    continue;

                case 101:
                    yyst[yysp] = 101;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 256:
                    yyn = yys101();
                    continue;

                case 102:
                    yyst[yysp] = 102;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 257:
                    switch (yytok) {
                        case ',':
                            yyn = 93;
                            continue;
                        case ')':
                            yyn = 122;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 103:
                    yyst[yysp] = 103;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 258:
                    yyn = yys103();
                    continue;

                case 104:
                    yyst[yysp] = 104;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 259:
                    yyn = yys104();
                    continue;

                case 105:
                    yyst[yysp] = 105;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 260:
                    yyn = yys105();
                    continue;

                case 106:
                    yyst[yysp] = 106;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 261:
                    yyn = yys106();
                    continue;

                case 107:
                    yyst[yysp] = 107;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 262:
                    switch (yytok) {
                        case ';':
                            yyn = yyr13();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 108:
                    yyst[yysp] = 108;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 263:
                    switch (yytok) {
                        case PROCEDURE:
                            yyn = 9;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 109:
                    yyst[yysp] = 109;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 264:
                    switch (yytok) {
                        case ';':
                            yyn = yyr15();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 110:
                    yyst[yysp] = 110;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 265:
                    switch (yytok) {
                        case PROCEDURE:
                            yyn = 9;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 111:
                    yyst[yysp] = 111;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 266:
                    switch (yytok) {
                        case PROCEDURE:
                            yyn = 9;
                            continue;
                        case ID:
                            yyn = 29;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 112:
                    yyst[yysp] = 112;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 267:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 128;
                            continue;
                        case ':':
                            yyn = 129;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 113:
                    yyst[yysp] = 113;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 268:
                    yyn = yys113();
                    continue;

                case 114:
                    yyst[yysp] = 114;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 269:
                    switch (yytok) {
                        case BOOL:
                            yyn = 85;
                            continue;
                        case ID:
                            yyn = 86;
                            continue;
                        case INT:
                            yyn = 87;
                            continue;
                        case REAL:
                            yyn = 88;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 115:
                    yyst[yysp] = 115;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 270:
                    yyn = yys115();
                    continue;

                case 116:
                    yyst[yysp] = 116;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 271:
                    switch (yytok) {
                        case ',':
                            yyn = 93;
                            continue;
                        case ')':
                            yyn = 132;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 117:
                    yyst[yysp] = 117;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 272:
                    yyn = yys117();
                    continue;

                case 118:
                    yyst[yysp] = 118;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 273:
                    yyn = yys118();
                    continue;

                case 119:
                    yyst[yysp] = 119;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 274:
                    yyn = yys119();
                    continue;

                case 120:
                    yyst[yysp] = 120;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 275:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr32();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 121:
                    yyst[yysp] = 121;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 276:
                    yyn = yys121();
                    continue;

                case 122:
                    yyst[yysp] = 122;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 277:
                    yyn = yys122();
                    continue;

                case 123:
                    yyst[yysp] = 123;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 278:
                    switch (yytok) {
                        case ',':
                            yyn = 93;
                            continue;
                        case ')':
                            yyn = 136;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 124:
                    yyst[yysp] = 124;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 279:
                    yyn = yys124();
                    continue;

                case 125:
                    yyst[yysp] = 125;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 280:
                    switch (yytok) {
                        case ';':
                            yyn = 110;
                            continue;
                        case END:
                            yyn = 137;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 126:
                    yyst[yysp] = 126;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 281:
                    switch (yytok) {
                        case ',':
                            yyn = 54;
                            continue;
                        case END:
                            yyn = 138;
                            continue;
                        case ';':
                            yyn = 139;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 127:
                    yyst[yysp] = 127;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 282:
                    switch (yytok) {
                        case ';':
                            yyn = 110;
                            continue;
                        case END:
                            yyn = 140;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 128:
                    yyst[yysp] = 128;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 283:
                    yyn = yys128();
                    continue;

                case 129:
                    yyst[yysp] = 129;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 284:
                    switch (yytok) {
                        case BOOL:
                            yyn = 85;
                            continue;
                        case ID:
                            yyn = 86;
                            continue;
                        case INT:
                            yyn = 87;
                            continue;
                        case REAL:
                            yyn = 88;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 130:
                    yyst[yysp] = 130;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 285:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 143;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 131:
                    yyst[yysp] = 131;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 286:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 144;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 132:
                    yyst[yysp] = 132;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 287:
                    yyn = yys132();
                    continue;

                case 133:
                    yyst[yysp] = 133;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 288:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 145;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 134:
                    yyst[yysp] = 134;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 289:
                    switch (yytok) {
                        case ',':
                            yyn = 93;
                            continue;
                        case ')':
                            yyn = 146;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 135:
                    yyst[yysp] = 135;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 290:
                    yyn = yys135();
                    continue;

                case 136:
                    yyst[yysp] = 136;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 291:
                    yyn = yys136();
                    continue;

                case 137:
                    yyst[yysp] = 137;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 292:
                    switch (yytok) {
                        case ';':
                            yyn = yyr14();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 138:
                    yyst[yysp] = 138;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 293:
                    switch (yytok) {
                        case ';':
                            yyn = yyr16();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 139:
                    yyst[yysp] = 139;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 294:
                    switch (yytok) {
                        case PROCEDURE:
                            yyn = 9;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 140:
                    yyst[yysp] = 140;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 295:
                    switch (yytok) {
                        case ';':
                            yyn = yyr18();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 141:
                    yyst[yysp] = 141;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 296:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 148;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 142:
                    yyst[yysp] = 142;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 297:
                    switch (yytok) {
                        case BEGIN:
                            yyn = 149;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 143:
                    yyst[yysp] = 143;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 298:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr10();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 144:
                    yyst[yysp] = 144;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 299:
                    yyn = yys144();
                    continue;

                case 145:
                    yyst[yysp] = 145;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 300:
                    switch (yytok) {
                        case END:
                        case UNTIL:
                        case ELSE:
                        case ENDINPUT:
                        case ';':
                            yyn = yyr33();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 146:
                    yyst[yysp] = 146;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 301:
                    yyn = yys146();
                    continue;

                case 147:
                    yyst[yysp] = 147;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 302:
                    switch (yytok) {
                        case ';':
                            yyn = 110;
                            continue;
                        case END:
                            yyn = 151;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 148:
                    yyst[yysp] = 148;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 303:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr9();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 149:
                    yyst[yysp] = 149;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 304:
                    yyn = yys149();
                    continue;

                case 150:
                    yyst[yysp] = 150;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 305:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 153;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 151:
                    yyst[yysp] = 151;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 306:
                    switch (yytok) {
                        case ';':
                            yyn = yyr17();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 152:
                    yyst[yysp] = 152;
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 307:
                    switch (yytok) {
                        case ';':
                            yyn = 12;
                            continue;
                        case END:
                            yyn = 154;
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 153:
                    yyst[yysp] = 153;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 308:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr12();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 154:
                    yyst[yysp] = 154;
                    yysv[yysp] = (token
                                 );
                    yytok = (proximo()
                            );
                    if (++yysp>=yyst.length) {
                        yyexpand();
                    }
                case 309:
                    switch (yytok) {
                        case END:
                        case ';':
                            yyn = yyr11();
                            continue;
                    }
                    yyn = 313;
                    continue;

                case 310:
                    return true;
                case 311:
                    yyerror("stack overflow");
                case 312:
                    return false;
                case 313:
                    yyerror("syntax error");
                    return false;
            }
        }
    }

    protected void yyexpand() {
        int[] newyyst = new int[2*yyst.length];
        Object[] newyysv = new Object[2*yyst.length];
        for (int i=0; i<yyst.length; i++) {
            newyyst[i] = yyst[i];
            newyysv[i] = yysv[i];
        }
        yyst = newyyst;
        yysv = newyysv;
    }

    private int yys0() {
        switch (yytok) {
            case CLASS:
                return 8;
            case PROCEDURE:
                return 9;
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys7() {
        switch (yytok) {
            case ID:
                return 16;
            case IF:
                return 17;
            case READ:
                return 18;
            case REPEAT:
                return 19;
            case SKIP:
                return 20;
            case THIS:
                return 21;
            case WRITE:
                return 22;
            case '(':
                return 23;
        }
        return 313;
    }

    private int yys11() {
        switch (yytok) {
            case CLASS:
                return 8;
            case PROCEDURE:
                return 9;
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys12() {
        switch (yytok) {
            case ID:
                return 16;
            case IF:
                return 17;
            case READ:
                return 18;
            case REPEAT:
                return 19;
            case SKIP:
                return 20;
            case THIS:
                return 21;
            case WRITE:
                return 22;
            case '(':
                return 23;
        }
        return 313;
    }

    private int yys13() {
        switch (yytok) {
            case PROCEDURE:
                return 9;
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys17() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys19() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys22() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys23() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys37() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys38() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
            case ')':
                return 63;
        }
        return 313;
    }

    private int yys39() {
        switch (yytok) {
            case THEN:
                return 64;
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
        }
        return 313;
    }

    private int yys41() {
        switch (yytok) {
            case '(':
                return 72;
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr52();
            case '.':
                return yyr62();
        }
        return 313;
    }

    private int yys43() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr57();
        }
        return 313;
    }

    private int yys44() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr51();
        }
        return 313;
    }

    private int yys45() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr58();
            case '.':
                return yyr63();
        }
        return 313;
    }

    private int yys46() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys49() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr37();
        }
        return 313;
    }

    private int yys50() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case ')':
                return 76;
        }
        return 313;
    }

    private int yys55() {
        switch (yytok) {
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr21();
        }
        return 313;
    }

    private int yys58() {
        switch (yytok) {
            case PROCEDURE:
                return 9;
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys60() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr35();
        }
        return 313;
    }

    private int yys61() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case ',':
            case ')':
                return yyr71();
        }
        return 313;
    }

    private int yys63() {
        switch (yytok) {
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr39();
            case '.':
                return yyr66();
        }
        return 313;
    }

    private int yys64() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys65() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys66() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys67() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys68() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys69() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys70() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys72() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
            case ')':
                return 103;
        }
        return 313;
    }

    private int yys74() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case ')':
                return 105;
        }
        return 313;
    }

    private int yys75() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys90() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys91() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
            case ')':
                return 117;
        }
        return 313;
    }

    private int yys92() {
        switch (yytok) {
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr40();
            case '.':
                return yyr67();
        }
        return 313;
    }

    private int yys93() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
        }
        return 313;
    }

    private int yys95() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr47();
        }
        return 313;
    }

    private int yys96() {
        switch (yytok) {
            case '*':
                return 65;
            case '/':
                return 68;
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr46();
        }
        return 313;
    }

    private int yys97() {
        switch (yytok) {
            case '*':
                return 65;
            case '/':
                return 68;
            case '-':
            case ',':
            case '+':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr48();
        }
        return 313;
    }

    private int yys98() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr49();
        }
        return 313;
    }

    private int yys99() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case ',':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr44();
        }
        return 313;
    }

    private int yys100() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case ',':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr45();
        }
        return 313;
    }

    private int yys101() {
        switch (yytok) {
            case '(':
                return 121;
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr59();
            case '.':
                return yyr64();
        }
        return 313;
    }

    private int yys103() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr53();
            case '.':
                return yyr66();
        }
        return 313;
    }

    private int yys104() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
            case ')':
                return 124;
        }
        return 313;
    }

    private int yys105() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr50();
            case '.':
                return yyr65();
        }
        return 313;
    }

    private int yys106() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr34();
        }
        return 313;
    }

    private int yys113() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys115() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr36();
        }
        return 313;
    }

    private int yys117() {
        switch (yytok) {
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr41();
            case '.':
                return yyr68();
        }
        return 313;
    }

    private int yys118() {
        switch (yytok) {
            case '*':
                return 65;
            case '+':
                return 66;
            case '-':
                return 67;
            case '/':
                return 68;
            case '<':
                return 69;
            case '=':
                return 70;
            case ',':
            case ')':
                return yyr70();
        }
        return 313;
    }

    private int yys119() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys121() {
        switch (yytok) {
            case ID:
                return 41;
            case NEW:
                return 42;
            case NIL:
                return 43;
            case NUM:
                return 44;
            case THIS:
                return 45;
            case '(':
                return 46;
            case ')':
                return 135;
        }
        return 313;
    }

    private int yys122() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr54();
            case '.':
                return yyr67();
        }
        return 313;
    }

    private int yys124() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr55();
        }
        return 313;
    }

    private int yys128() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys132() {
        switch (yytok) {
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case ';':
                return yyr42();
            case '.':
                return yyr69();
        }
        return 313;
    }

    private int yys135() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr60();
            case '.':
                return yyr68();
        }
        return 313;
    }

    private int yys136() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr56();
        }
        return 313;
    }

    private int yys144() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yys146() {
        switch (yytok) {
            case '/':
            case '-':
            case ',':
            case '+':
            case '*':
            case ')':
            case END:
            case UNTIL:
            case ELSE:
            case ENDINPUT:
            case THEN:
            case '=':
            case '<':
            case ';':
                return yyr61();
            case '.':
                return yyr69();
        }
        return 313;
    }

    private int yys149() {
        switch (yytok) {
            case VAR:
                return 10;
            case READ:
            case ID:
            case '(':
            case WRITE:
            case THIS:
            case SKIP:
            case REPEAT:
            case IF:
                return yyr22();
        }
        return 313;
    }

    private int yyr1() { // s : classes ';' procs ';' cmds
        { saida = new Prog(((List)yysv[yysp-5]), ((List)yysv[yysp-3]), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=5] = yyrv;
        return 1;
    }

    private int yyr2() { // s : classes ';' cmds
        { saida = new Prog(((List)yysv[yysp-3]), new ArrayList<Proc>(), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr3() { // s : procs ';' cmds
        { saida = new Prog(new ArrayList<Classe>(), ((List)yysv[yysp-3]), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return 1;
    }

    private int yyr4() { // s : cmds
        { saida = new Prog(new ArrayList<Classe>(), new ArrayList<Proc>(), ((Bloco)yysv[yysp-1])); }
        yysv[yysp-=1] = yyrv;
        return 1;
    }

    private int yyr5() { // classes : classes ';' classe
        { ((List)yysv[yysp-3]).add(((Classe)yysv[yysp-1]));
                               yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 2;
    }

    private int yyr6() { // classes : classe
        { List<Classe> classes = new ArrayList<Classe>();
                               classes.add(((Classe)yysv[yysp-1]));
                               yyrv = classes; }
        yysv[yysp-=1] = yyrv;
        return 2;
    }

    private int yyr32() { // cmd : IF exp THEN cmds END
        { yyrv = new If(((Exp)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr33() { // cmd : IF exp THEN cmds ELSE cmds END
        { yyrv = new If(((Exp)yysv[yysp-6]), ((Bloco)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypcmd();
    }

    private int yyr34() { // cmd : REPEAT cmds UNTIL exp
        { yyrv = new Repeat(((Bloco)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-4]).lin); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr35() { // cmd : ID ATTRIB exp
        { yyrv = new Atrib((Token)yysv[yysp-3], ((Exp)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr36() { // cmd : rexp '.' ID ATTRIB exp
        { yyrv = new AtribCampo(((Exp)yysv[yysp-5]), (Token)yysv[yysp-3], ((Exp)yysv[yysp-1])); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr37() { // cmd : WRITE exp
        { yyrv = new Write(((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr38() { // cmd : READ ID
        { yyrv = new Read((Token)yysv[yysp-1]); }
        yysv[yysp-=2] = yyrv;
        return yypcmd();
    }

    private int yyr39() { // cmd : ID '(' ')'
        { yyrv = new ChamadaCmd((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yypcmd();
    }

    private int yyr40() { // cmd : ID '(' exps ')'
        { yyrv = new ChamadaCmd((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypcmd();
    }

    private int yyr41() { // cmd : rexp '.' ID '(' ')'
        { yyrv = new ChamadaMetodoCmd(((Exp)yysv[yysp-5]), (Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=5] = yyrv;
        return yypcmd();
    }

    private int yyr42() { // cmd : rexp '.' ID '(' exps ')'
        { yyrv = new ChamadaMetodoCmd(((Exp)yysv[yysp-6]), (Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return yypcmd();
    }

    private int yyr43() { // cmd : SKIP
        { yyrv = new Skip(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypcmd();
    }

    private int yypcmd() {
        switch (yyst[yysp-1]) {
            case 7: return 14;
            default: return 33;
        }
    }

    private int yyr19() { // cmds : cmds ';' cmd
        { ((Bloco)yysv[yysp-3]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypcmds();
    }

    private int yyr20() { // cmds : var cmd
        { ((Bloco)yysv[yysp-2]).add(((Cmd)yysv[yysp-1]));
                      yyrv = ((Bloco)yysv[yysp-2]);  }
        yysv[yysp-=2] = yyrv;
        return yypcmds();
    }

    private int yypcmds() {
        switch (yyst[yysp-1]) {
            case 144: return 150;
            case 128: return 141;
            case 119: return 133;
            case 113: return 130;
            case 64: return 94;
            case 58: return 89;
            case 19: return 48;
            case 13: return 34;
            case 11: return 30;
            case 0: return 3;
            default: return 152;
        }
    }

    private int yyr25() { // decl : ids ':' tipo
        { yyrv = new Decl(((List)yysv[yysp-3]), ((String)yysv[yysp-1])); }
        yysv[yysp-=3] = yyrv;
        switch (yyst[yysp-1]) {
            case 54: return 82;
            default: return 26;
        }
    }

    private int yyr23() { // decls : decls ',' decl
        { ((List)yysv[yysp-3]).add(((Decl)yysv[yysp-1])); yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypdecls();
    }

    private int yyr24() { // decls : decl
        { List<Decl> decls = new ArrayList<Decl>();
                         decls.add(((Decl)yysv[yysp-1]));
                         yyrv = decls; }
        yysv[yysp-=1] = yyrv;
        return yypdecls();
    }

    private int yypdecls() {
        switch (yyst[yysp-1]) {
            case 53: return 80;
            case 51: return 77;
            case 10: return 27;
            default: return 126;
        }
    }

    private int yyr44() { // exp : exp '<' exp
        { yyrv = new Menor(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin);  }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr45() { // exp : exp '=' exp
        { yyrv = new Igual(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr46() { // exp : exp '+' exp
        { yyrv = new Soma(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr47() { // exp : exp '*' exp
        { yyrv = new Mult(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr48() { // exp : exp '-' exp
        { yyrv = new Sub(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr49() { // exp : exp '/' exp
        { yyrv = new Div(((Exp)yysv[yysp-3]), ((Exp)yysv[yysp-1]), ((Token)yysv[yysp-2]).lin); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr50() { // exp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr51() { // exp : NUM
        { yyrv = new Num((Token)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr52() { // exp : ID
        { yyrv = new Id((Token)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr53() { // exp : ID '(' ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr54() { // exp : ID '(' exps ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr55() { // exp : NEW ID '(' ')'
        { yyrv = new New((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=4] = yyrv;
        return yypexp();
    }

    private int yyr56() { // exp : NEW ID '(' exps ')'
        { yyrv = new New((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=5] = yyrv;
        return yypexp();
    }

    private int yyr57() { // exp : NIL
        { yyrv = new Nil(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr58() { // exp : THIS
        { yyrv = new This(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yypexp();
    }

    private int yyr59() { // exp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), (Token)yysv[yysp-1]); }
        yysv[yysp-=3] = yyrv;
        return yypexp();
    }

    private int yyr60() { // exp : rexp '.' ID '(' ')'
        { yyrv = new ChamadaMetodo(((Exp)yysv[yysp-5]), (Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=5] = yyrv;
        return yypexp();
    }

    private int yyr61() { // exp : rexp '.' ID '(' exps ')'
        { yyrv = new ChamadaMetodo(((Exp)yysv[yysp-6]), (Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return yypexp();
    }

    private int yypexp() {
        switch (yyst[yysp-1]) {
            case 93: return 118;
            case 90: return 115;
            case 75: return 106;
            case 70: return 100;
            case 69: return 99;
            case 68: return 98;
            case 67: return 97;
            case 66: return 96;
            case 65: return 95;
            case 46: return 74;
            case 37: return 60;
            case 23: return 50;
            case 22: return 49;
            case 17: return 39;
            default: return 61;
        }
    }

    private int yyr70() { // exps : exps ',' exp
        { ((List)yysv[yysp-3]).add(((Exp)yysv[yysp-1]));
                      yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypexps();
    }

    private int yyr71() { // exps : exp
        { List<Exp> exps = new ArrayList<Exp>();
                      exps.add(((Exp)yysv[yysp-1]));
                      yyrv = exps; }
        yysv[yysp-=1] = yyrv;
        return yypexps();
    }

    private int yypexps() {
        switch (yyst[yysp-1]) {
            case 104: return 123;
            case 91: return 116;
            case 72: return 102;
            case 38: return 62;
            default: return 134;
        }
    }

    private int yyr30() { // ids : ids ',' ID
        { ((List)yysv[yysp-3]).add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return 28;
    }

    private int yyr31() { // ids : ID
        { List<String> ids = new ArrayList<String>();
                     ids.add(((Token)yysv[yysp-1]).lexeme);
                     yyrv = ids; }
        yysv[yysp-=1] = yyrv;
        return 28;
    }

    private int yyr9() { // proc : PROCEDURE ID '(' decls ')' BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-7]).lexeme, ((List)yysv[yysp-5]), "void", ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-8]).lin); }
        yysv[yysp-=8] = yyrv;
        return yypproc();
    }

    private int yyr10() { // proc : PROCEDURE ID '(' ')' BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-6]).lexeme, new ArrayList<Decl>(), "void", ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypproc();
    }

    private int yyr11() { // proc : PROCEDURE ID '(' decls ')' ':' tipo BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-9]).lexeme, ((List)yysv[yysp-7]), ((String)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-10]).lin); }
        yysv[yysp-=10] = yyrv;
        return yypproc();
    }

    private int yyr12() { // proc : PROCEDURE ID '(' ')' ':' tipo BEGIN cmds END
        { yyrv = new Proc(((Token)yysv[yysp-8]).lexeme, new ArrayList<Decl>(), ((String)yysv[yysp-4]), ((Bloco)yysv[yysp-2]), ((Token)yysv[yysp-9]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypproc();
    }

    private int yypproc() {
        switch (yyst[yysp-1]) {
            case 110: return 35;
            case 58: return 35;
            case 13: return 35;
            default: return 4;
        }
    }

    private int yyr7() { // procs : procs ';' proc
        { ((List)yysv[yysp-3]).add(((Proc)yysv[yysp-1]));
                         yyrv = ((List)yysv[yysp-3]); }
        yysv[yysp-=3] = yyrv;
        return yypprocs();
    }

    private int yyr8() { // procs : proc
        { List<Proc> procs = new ArrayList<Proc>();
                         procs.add(((Proc)yysv[yysp-1]));
                         yyrv = procs; }
        yysv[yysp-=1] = yyrv;
        return yypprocs();
    }

    private int yypprocs() {
        switch (yyst[yysp-1]) {
            case 111: return 127;
            case 108: return 125;
            case 51: return 78;
            case 11: return 31;
            case 0: return 5;
            default: return 147;
        }
    }

    private int yyr62() { // rexp : ID
        { yyrv = new Id((Token)yysv[yysp-1]); }
        yysv[yysp-=1] = yyrv;
        return yyprexp();
    }

    private int yyr63() { // rexp : THIS
        { yyrv = new This(((Token)yysv[yysp-1]).lin); }
        yysv[yysp-=1] = yyrv;
        return yyprexp();
    }

    private int yyr64() { // rexp : rexp '.' ID
        { yyrv = new Campo(((Exp)yysv[yysp-3]), (Token)yysv[yysp-1]); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr65() { // rexp : '(' exp ')'
        { yyrv = ((Exp)yysv[yysp-2]); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr66() { // rexp : ID '(' ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=3] = yyrv;
        return yyprexp();
    }

    private int yyr67() { // rexp : ID '(' exps ')'
        { yyrv = new ChamadaExp((Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=4] = yyrv;
        return yyprexp();
    }

    private int yyr68() { // rexp : rexp '.' ID '(' ')'
        { yyrv = new ChamadaMetodo(((Exp)yysv[yysp-5]), (Token)yysv[yysp-3], new ArrayList<Exp>()); }
        yysv[yysp-=5] = yyrv;
        return yyprexp();
    }

    private int yyr69() { // rexp : rexp '.' ID '(' exps ')'
        { yyrv = new ChamadaMetodo(((Exp)yysv[yysp-6]), (Token)yysv[yysp-4], ((List)yysv[yysp-2])); }
        yysv[yysp-=6] = yyrv;
        return yyprexp();
    }

    private int yyprexp() {
        switch (yyst[yysp-1]) {
            case 12: return 15;
            case 7: return 15;
            default: return 40;
        }
    }

    private int yyr13() { // classe : CLASS ID BEGIN decls END
        { yyrv = new Classe(((Token)yysv[yysp-4]).lexeme, null, ((List)yysv[yysp-2]), new ArrayList<Proc>(), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypclasse();
    }

    private int yyr14() { // classe : CLASS ID BEGIN decls ';' procs END
        { yyrv = new Classe(((Token)yysv[yysp-6]).lexeme, null, ((List)yysv[yysp-4]), ((List)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypclasse();
    }

    private int yyr15() { // classe : CLASS ID BEGIN procs END
        { yyrv = new Classe(((Token)yysv[yysp-4]).lexeme, null, new ArrayList<Decl>(), ((List)yysv[yysp-2]), ((Token)yysv[yysp-5]).lin); }
        yysv[yysp-=5] = yyrv;
        return yypclasse();
    }

    private int yyr16() { // classe : CLASS ID ':' ID BEGIN decls END
        { yyrv = new Classe(((Token)yysv[yysp-6]).lexeme, ((Token)yysv[yysp-4]).lexeme, ((List)yysv[yysp-2]), new ArrayList<Proc>(), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypclasse();
    }

    private int yyr17() { // classe : CLASS ID ':' ID BEGIN decls ';' procs END
        { yyrv = new Classe(((Token)yysv[yysp-8]).lexeme, ((Token)yysv[yysp-6]).lexeme, ((List)yysv[yysp-4]), ((List)yysv[yysp-2]), ((Token)yysv[yysp-9]).lin); }
        yysv[yysp-=9] = yyrv;
        return yypclasse();
    }

    private int yyr18() { // classe : CLASS ID ':' ID BEGIN procs END
        { yyrv = new Classe(((Token)yysv[yysp-6]).lexeme, ((Token)yysv[yysp-4]).lexeme, new ArrayList<Decl>(), ((List)yysv[yysp-2]), ((Token)yysv[yysp-7]).lin); }
        yysv[yysp-=7] = yyrv;
        return yypclasse();
    }

    private int yypclasse() {
        switch (yyst[yysp-1]) {
            case 0: return 6;
            default: return 32;
        }
    }

    private int yyr26() { // tipo : INT
        { yyrv = "int"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr27() { // tipo : REAL
        { yyrv = "real"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr28() { // tipo : BOOL
        { yyrv = "bool"; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyr29() { // tipo : ID
        { yyrv = ((Token)yysv[yysp-1]).lexeme; }
        yysv[yysp-=1] = yyrv;
        return yyptipo();
    }

    private int yyptipo() {
        switch (yyst[yysp-1]) {
            case 114: return 131;
            case 57: return 84;
            default: return 142;
        }
    }

    private int yyr21() { // var : VAR decls ';'
        { yyrv = new Bloco(((List)yysv[yysp-2]), ((Token)yysv[yysp-3]).lin); }
        yysv[yysp-=3] = yyrv;
        return 7;
    }

    private int yyr22() { // var : /* empty */
        { yyrv = new Bloco(new ArrayList<Decl>(), 0); }
        yysv[yysp-=0] = yyrv;
        return 7;
    }

    protected String[] yyerrmsgs = {
    };


Scanner scan;

Token token;  // lookahead
int tipo;     // tipo do lookahead

public Prog saida; // workaround pro bug do tipo do parse()

public ParserJACC(java.io.Reader entrada) {
  scan = new ScannerJF(entrada);
  proximo(); // inicializa o lookahead
}

int proximo() {
  try {
    token = scan.token();
    tipo = token.tipo;
    return tipo;
  } catch(java.io.IOException e) {
    throw new RuntimeException(e);
  }
}

void yyerror(String msg) {
  throw new RuntimeException("erro de sintaxe:" + token);
}

}
