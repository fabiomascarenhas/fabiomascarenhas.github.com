import java.util.HashMap;
import java.util.Map;

public class Tipo {
	// classe Foo é subclasse *direta* de classe Bar
	static Map<String, String> superclasse = new HashMap<String, String>();
	
	public static boolean subtipo(String um, String outro) {
		if(um.equals(outro)) // reflexiva
			return true;
		if(um.equals("int") && outro.equals("real"))
			return true;
		if(um.equals("nil") && !outro.equals("int") &&
				!outro.equals("real") && !outro.equals("bool"))
			return true;
		if(!superclasse.containsKey(um))
			return false;
		if(superclasse.get(um).equals(outro))
			return true;
		return subtipo(superclasse.get(um), outro);
	}
}
