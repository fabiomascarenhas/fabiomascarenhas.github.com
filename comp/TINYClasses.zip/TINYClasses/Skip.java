
public class Skip extends Node implements Cmd {

	public Skip(int lin) {
		super(lin);
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
	}

}
