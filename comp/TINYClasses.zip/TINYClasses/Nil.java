
public class Nil extends Exp {

	public Nil(int lin) {
		super(lin);
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return "nil";
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(0);
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug na análise de tipos");
	}

}
