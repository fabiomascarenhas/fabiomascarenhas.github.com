
public class This extends Exp {

	public This(int _lin) {
		super(_lin);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return tipos.procurar("this", lin);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		// TODO Auto-generated method stub
		vars.procurar("this", lin).load(ctx);
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		// TODO Auto-generated method stub
		
	}

}
