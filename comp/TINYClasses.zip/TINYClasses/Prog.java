import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Prog extends Node {
	public List<Classe> cls;
	public List<Proc> procs;
	public Bloco corpo;
	
	public static TabSimb<Proc> eprocs = new TabSimb<Proc>();
	public static TabSimb<Classe> eclasses = new TabSimb<Classe>();
	
	public Prog(List<Classe> _cls, List<Proc> _procs, Bloco cs) {
		super(cs.lin);
		cls = _cls;
		procs = _procs;
		corpo = cs;
	}
	
	public void checaTipo() {
		for(Classe c: cls) {
			eclasses.inserir(c.nome, c, c.lin);
			if(c.sup != null)
				Tipo.superclasse.put(c.nome, c.sup);
		}
		for(Proc proc: procs) {
			eprocs.inserir(proc.nome, proc, proc.lin);
		}
		for(Classe c: cls) {
			c.fechaClasse();
		}
		TabSimb<String> egvars = corpo.checaTipo(null);
		for(Classe c: cls) {
			c.checaTipo(egvars);
		}
		for(Proc proc: procs) {
			TabSimb<String> eproc = new TabSimb<String>(egvars);
			eproc.inserir(proc.nome, proc.tret, proc.lin);
			for(int i = 0; i < proc.pnomes.size(); i++) {
				eproc.inserir(proc.pnomes.get(i),
							  proc.ptipos.get(i),
							  proc.lin);
			}
			proc.corpo.checaTipo(eproc);
		}
	}
	
	public String geraCodigo(String fmain) {
		List<String> globais = new ArrayList<String>();
		List<String> fnames = new ArrayList<String>();
		List<String> funcs = new ArrayList<String>();
		Contexto cmain = new Contexto(fmain, 0);
		TabSimb<Endereco> egvars = corpo.geraCodigo(cmain, null, true);
		cmain.icload(0); // valor de retorno de "main"
		for(String global: egvars.mapa.keySet()) {
			globais.add(global);
		}
		fnames.add(fmain);
		funcs.add(cmain.codigo());
		for(Proc proc: procs) {
			Contexto cproc = new Contexto(proc.nome, proc.pnomes.size());
			TabSimb<Endereco> eproc = new TabSimb<Endereco>(egvars);
			for(int i = 0; i < proc.pnomes.size(); i++) {
				eproc.inserir(proc.pnomes.get(i),
						      cproc.local(),
							  proc.lin);
			}
			// local para valor de retorno
			eproc.inserir(proc.nome, cproc.local(), proc.lin);
			proc.corpo.geraCodigo(cproc, eproc, false);
			// empilha valor de retorno de proc
			eproc.procurar(proc.nome, proc.lin).load(cproc); // empilhar valor de retorno
			fnames.add(proc.nome);
			funcs.add(cproc.codigo());
		}
		Map<String, List<String>> vtables = new HashMap<String, List<String>>();
		for(Classe c: cls) {
			List<String> ms = new ArrayList<String>();
			for(Proc m: c.mets) {
				ms.add("$m_" + m.toString());
				if(!fnames.contains("$m_" + m.toString())) {
					Contexto cproc = new Contexto("$m_" + m.toString(), m.pnomes.size() + 1);
					TabSimb<Endereco> eproc = new TabSimb<Endereco>(egvars);
					eproc.inserir("this", cproc.local(), m.lin);
					for(int i = 0; i < m.pnomes.size(); i++) {
						eproc.inserir(m.pnomes.get(i),
								      cproc.local(),
									  m.lin);
					}
					// local para valor de retorno
					eproc.inserir(m.nome, cproc.local(), m.lin);
					m.corpo.geraCodigo(cproc, eproc, false);
					// empilha valor de retorno de proc
					eproc.procurar(m.nome, m.lin).load(cproc); // empilhar valor de retorno
					fnames.add("$m_" + m.toString());
					funcs.add(cproc.codigo());
				}
			}
			vtables.put("$" + c.nome + "_vtable", ms);
		}
		return Contexto.programa(globais, fnames, funcs, vtables);
	}
}
