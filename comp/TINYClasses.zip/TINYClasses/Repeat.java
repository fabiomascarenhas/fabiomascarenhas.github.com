
public class Repeat extends Node implements Cmd{
	public Bloco corpo;
	public Exp cond;
	
	public Repeat(Bloco cs, Exp cd, int _lin) {
		super(_lin);
		corpo = cs;
		cond = cd;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		String tcond = cond.checaTipo(corpo.checaTipo(tipos));
		if(!tcond.equals("bool"))
			throw new RuntimeException("condição do repeat não é booleana mas " + 
					tcond + " na linha " + lin);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		int lab = ctx.label();
		ctx.label(lab);
		TabSimb<Endereco> vcorpo = corpo.geraCodigo(ctx, vars, false);
		cond.geraSaltoF(ctx, vcorpo, lab);
	}
}
