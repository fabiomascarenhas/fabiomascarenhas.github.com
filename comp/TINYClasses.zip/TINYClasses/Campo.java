
public class Campo extends Exp {
	public Exp reg;
	public String campo;

	private Classe treg;
	
	public Campo(Exp _reg, Token _campo) {
		super(_campo.lin);
		campo = _campo.lexeme;
		reg = _reg;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		treg = Prog.eclasses.procurar(reg.checaTipo(tipos), lin);
		return treg.tcampos.procurar(campo, lin);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		reg.geraCodigo(ctx, vars); // empilha endereço de reg
		ctx.ldfld(treg.nomes.indexOf(campo) + 1);
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug na análise de tipos");
	}

}
