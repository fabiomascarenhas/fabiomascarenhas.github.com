#include <stdio.h>

int fat(int n);
int fat_rep(int n);
int tiny_main();

int main() {
  printf("fat(5) = %d\n", fat(5));
  printf("fat_rep(5) = %d\n", fat(5));
  printf("tiny_main() = %d\n", tiny_main());  
}
