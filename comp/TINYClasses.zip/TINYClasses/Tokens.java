// Output created by jacc on Wed Feb 24 12:20:23 BRT 2016

interface Tokens {
    int ENDINPUT = 0;
    int ATTRIB = 1;
    int BEGIN = 2;
    int BOOL = 3;
    int CLASS = 4;
    int ELSE = 5;
    int END = 6;
    int ID = 7;
    int IF = 8;
    int INT = 9;
    int NEW = 10;
    int NIL = 11;
    int NUM = 12;
    int PROCEDURE = 13;
    int READ = 14;
    int REAL = 15;
    int REPEAT = 16;
    int SKIP = 17;
    int THEN = 18;
    int THIS = 19;
    int UNTIL = 20;
    int VAR = 21;
    int WRITE = 22;
    int error = 23;
    // '(' (code=40)
    // ')' (code=41)
    // '*' (code=42)
    // '+' (code=43)
    // ',' (code=44)
    // '-' (code=45)
    // '.' (code=46)
    // '/' (code=47)
    // ':' (code=58)
    // ';' (code=59)
    // '<' (code=60)
    // '=' (code=61)
}
