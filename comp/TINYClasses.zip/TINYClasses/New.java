import java.util.List;

public class New extends Exp {
	public String cls;
	public List<Exp> args;
	
	public New(Token _reg, List<Exp> _args) {
		super(_reg.lin);
		cls = _reg.lexeme;
		args = _args;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		Classe tcls = Prog.eclasses.procurar(cls, lin);
		if(args.size() != tcls.tipos.size())
			throw new RuntimeException("instanciação não bate com número de campos na linha " + lin);
		for(int i = 0; i < args.size(); i++) {
			String targ = args.get(i).checaTipo(tipos);
			String tcampo = tcls.tipos.get(i);
			if(!Tipo.subtipo(targ, tcampo))
				throw new RuntimeException("erro no " + (i+1) + "-ésimo argumento da chamada de procedimento na linha " + 
			            lin + ", esperado " + tcampo + " e encontrado " + targ);
			if(!targ.equals(tcampo))
				args.set(i, new Cast(args.get(i), tcampo));
		}
		return cls;
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		Classe treg = Prog.eclasses.procurar(cls, lin);
		for(int i = args.size() - 1; i >= 0; i--) {
			args.get(i).geraCodigo(ctx, vars);
		}
		ctx.newrec("$" + cls + "_vtable", treg.tipos.size());
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug na análise de tipos");
	}

}
