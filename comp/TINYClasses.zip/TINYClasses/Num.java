
public class Num extends Exp {
	public String val;
	
	public Num(Token tok) {
		super(tok.lin);
		val = tok.lexeme;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return "int";
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.icload(Integer.parseInt(val));
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		throw new RuntimeException("bug no verificador de tipos");
	}
}
