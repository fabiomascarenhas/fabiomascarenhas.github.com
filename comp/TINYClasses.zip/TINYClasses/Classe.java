import java.util.ArrayList;
import java.util.List;

public class Classe extends Node {
	public String nome;
	public String sup;
	public List<String> nomes;
	public List<String> tipos;
	public List<String> nmets;
	public List<Proc> mets;
	
	public TabSimb<String> tcampos;
	
	private boolean fechada = false;
	
	public Classe(String _nome, String _sup, List<Decl> _decls, List<Proc> _mets, int lin) {
		super(lin);
		nome = _nome;
		sup = _sup;
		nomes = new ArrayList<String>();
		tipos = new ArrayList<String>();
		tcampos = new TabSimb<String>();
		for(Decl decl: _decls) {
			for(String var: decl.vars) {
				nomes.add(var);
				tipos.add(decl.tipo);
			}
		}
		mets = _mets;
	}

	public void fechaClasse() {
		if(fechada) return;
		fechada = true;
		Classe csup = null;
		if(sup != null) {
			csup = Prog.eclasses.procurar(sup, lin);
			csup.fechaClasse();
		}
		List<String> nomes = new ArrayList<String>();
		List<String> tipos = new ArrayList<String>();
		if(sup != null) {
			for(int i = 0; i < csup.nomes.size(); i++) {
				tcampos.inserir(csup.nomes.get(i), csup.tipos.get(i), lin);
				nomes.add(csup.nomes.get(i));
				tipos.add(csup.tipos.get(i));
			}
		}
		for(int i = 0; i < this.nomes.size(); i++) {
			tcampos.inserir(this.nomes.get(i), this.tipos.get(i), lin);
			nomes.add(this.nomes.get(i));
			tipos.add(this.tipos.get(i));
		}
		this.nomes = nomes;
		this.tipos = tipos;
		List<String> nmets = new ArrayList<String>();
		List<Proc> mets = new ArrayList<Proc>();
		if(sup != null) {
			for(int i = 0; i < csup.mets.size(); i++) {
				nmets.add(csup.mets.get(i).nome);
				mets.add(csup.mets.get(i));
			}
		}
		for(int i = 0; i < this.mets.size(); i++) {
			if(nmets.contains(this.mets.get(i).nome)) {
				int isup = nmets.indexOf(this.mets.get(i).nome);
				Proc msup = mets.get(isup);
				Proc mthis = this.mets.get(i);
				if(msup.pnomes.size() != mthis.pnomes.size())
					throw new RuntimeException("redefinindo o método " + msup.nome + 
							" com número diferente de parâmetros na linha " + mthis.lin);
				for(int j = 0; j < msup.ptipos.size(); j++) {
					if(!msup.ptipos.get(j).equals(mthis.ptipos.get(j)))
							throw new RuntimeException("redefinindo o método " + msup.nome + 
									" com parâmetro " + j + "  de tipo diferente na linha " + mthis.lin);
				}
				if(!msup.tret.equals(mthis.tret))
					throw new RuntimeException("redefinindo o método " + msup.nome + 
							" com tipo de retorno diferente na linha " + mthis.lin);
				mets.set(isup, mthis);
			} else {
				nmets.add(this.mets.get(i).nome);
				mets.add(this.mets.get(i));
			}
		}
		this.nmets = nmets;
		this.mets = mets;
	}
	
	public void checaTipo(TabSimb<String> egvars) {
		for(Proc m: this.mets) {
			TabSimb<String> emet = new TabSimb<String>(egvars);
			emet.inserir(m.nome, m.tret, m.lin);
			emet.inserir("this", this.nome, m.lin);
			for(int i = 0; i < m.pnomes.size(); i++) {
				emet.inserir(m.pnomes.get(i),
					   	     m.ptipos.get(i),
							 m.lin);
			}
			m.corpo.checaTipo(emet);
		}
	}
}
