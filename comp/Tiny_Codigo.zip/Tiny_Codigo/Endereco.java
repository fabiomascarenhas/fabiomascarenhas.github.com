
interface Endereco {
	void get(Contexto ctx);
	void put(Contexto ctx);
}

class Global implements Endereco {
	String nome;
	
	public Global(String _nome) {
		nome = _nome;
	}

	@Override
	public void get(Contexto ctx) {
		ctx.getglobal(nome);
	}

	@Override
	public void put(Contexto ctx) {
		ctx.putglobal(nome);
	}
}

class Local implements Endereco {
	int loc;
	
	public Local(int _loc) {
		loc = _loc;
	}

	@Override
	public void get(Contexto ctx) {
		ctx.iload(loc);
	}

	@Override
	public void put(Contexto ctx) {
		ctx.istore(loc);
	}
}