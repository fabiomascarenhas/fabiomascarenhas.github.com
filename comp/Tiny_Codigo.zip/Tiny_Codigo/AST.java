import java.util.ArrayList;
import java.util.List;

class Valor {
	String tipo;
	Object v;
	
	public Valor(int _v) {
		tipo = "int";
		v = _v;
	}
	
	public Valor(double _v) {
		tipo = "real";
		v = _v;
	}
	
	public Valor(boolean _v) {
		tipo = "bool";
		v = _v;
	}
	
	int toInt() {
		return (int)v;
	}
	
	double toDouble() {
		if(tipo.equals("int"))
			return (int)v;
		return (double)v;
	}
	
	boolean toBool() {
		return (boolean)v;
	}

	void set(Valor _v) {
		v = _v.v;
	}
	
	void set(Object _v) {
		v = _v;
	}
	
	public String toString() {
		return v.toString();
	}
}

class Tiny {
	List<Proc> procs;
	Bloco corpo;
	
	public Tiny(Bloco _corpo) {
		procs = new ArrayList<Proc>();
		corpo = _corpo;
	}

	public Tiny(List<Proc> _procs, Bloco _corpo) {
		procs = _procs;
		corpo = _corpo;
	}

	public String toString() {
		String res = "";
		for(Proc proc: procs)
			res += proc + ";\n";
		res += corpo;
		return res;
	}
	
	public TabSimb<Proc> procs() {
		TabSimb<Proc> esc = new TabSimb<Proc>();
		for(Proc proc: procs) {
			if(!esc.inserir(proc.nome.nome, proc))
				throw new RuntimeException("procedimento duplicado: " + proc.nome);
		}
		return esc;
	}
	
	public TabSimb<String> gvars() {
		TabSimb<String> esc = new TabSimb<String>();
		for(Decl decl: corpo.vars) {
			for(Id var: decl.vars) { 
			  if(!esc.inserir(var.nome, decl.tipo))
				  throw new RuntimeException("variável duplicada: " + var.nome);
		
			}
		}
		return esc;
	}
	
	public void tipos() {
		TabSimb<Proc> eprocs = procs();
		TabSimb<String> egv = gvars();
		for(Proc proc: procs)
			proc.corpo.tipos(eprocs, egv);
		for(Cmd cmd: corpo.cmds)
			cmd.tipos(eprocs, egv);
	}
	
	public void prologo(StringBuffer buf) {
		buf.append("extern _printf\n");
		buf.append("extern _scanf\n");
		buf.append("segment .data\n");
		buf.append("$fmt_printf db \"%d\",10,0\n");
		buf.append("$fmt_scanf db \"%d\",0\n");
		buf.append("segment .bss\n");
	}
	
	public String geracod() {
		StringBuffer buf = new StringBuffer();
		prologo(buf);
		TabSimb<Endereco> egv = new TabSimb<Endereco>();
		for(Decl decl: corpo.vars) {
			for(Id var: decl.vars) {
				egv.inserir(var.nome, new Global(var.nome));
				buf.append(var.nome + " resb 4\n"); 
			}
		}
		buf.append("segment .text\n");
		buf.append("global _main\n");
		for(Proc proc: procs) {
			Contexto ctx = new Contexto(proc.nome.nome);
			proc.corpo.geracod(ctx, egv);
			buf.append(ctx.codigo());
		}
		Contexto ctx = new Contexto("main");
		for(Cmd cmd: corpo.cmds) {
			cmd.geracod(ctx, egv);
		}
		buf.append(ctx.codigo());
		return buf.toString();
	}
	
	public TabSimb<Valor> exec() {
		TabSimb<Proc> eprocs = procs();
		TabSimb<Valor> egv = new TabSimb<Valor>();
		for(Decl decl: corpo.vars) {
			for(Id var: decl.vars)
			  egv.inserir(var.nome, Tipo.padrao(decl.tipo));
		}
		for(Cmd cmd: corpo.cmds)
			cmd.exec(eprocs, egv, egv);
		return egv;
	}
}

class Proc {
	Id nome;
	Bloco corpo;
	
	public Proc(Id _nome, Bloco _corpo) {
		nome = _nome;
		corpo = _corpo;
	}
	
	public String toString() {
		return "procedure " + nome + "()\n" + corpo + "\nend"; 
	}
}

class Bloco {
	List<Decl> vars;
	List<Cmd> cmds;
	
	public Bloco(List<Decl> _vars, Cmd cmd) {
		vars = _vars;
		cmds = new java.util.ArrayList<Cmd>();
		cmds.add(cmd);
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}

	public String toString() {
		String res = "";
		if(!vars.isEmpty()) {
			res += "var " + vars.get(0);
			for(int i = 1; i < vars.size(); i++)
				res += ", " + vars.get(i);
			res += ";\n";
		}
		res += cmds.get(0);
		for(int i = 1; i < cmds.size(); i++)
			res += ";\n" + cmds.get(i);
		return res;
	}
	
	public void tipos(TabSimb<Proc> eprocs,
			          TabSimb<String> escPai) {
		TabSimb<String> esc = new TabSimb<String>(escPai);
		for(Decl decl: vars) {
			for(Id var: decl.vars) {
				if(!esc.inserir(var.nome, decl.tipo))
					throw new RuntimeException("declaração dupla: " + var.nome);
			}
		}
		for(Cmd cmd: cmds) {
			cmd.tipos(eprocs, esc);
		}
	}
	
	public void geracod(Contexto ctx, TabSimb<Endereco> escPai) {
		TabSimb<Endereco> esc = new TabSimb<Endereco>(escPai);
		ctx.entraEscopo();
		for(Decl decl: vars) {
			for(Id var: decl.vars)
				esc.inserir(var.nome, new Local(ctx.local()));
		}
		for(Cmd cmd: cmds) {
			cmd.geracod(ctx, esc);
		}
		ctx.saiEscopo();
	}
	
	public void exec(TabSimb<Proc> procs, 
			TabSimb<Valor> globais,
			TabSimb<Valor> envPai) {
		TabSimb<Valor> env = new TabSimb<Valor>(envPai);
		for(Decl decl: vars) {
			for(Id var: decl.vars) {
				env.inserir(var.nome, Tipo.padrao(decl.tipo));
			}
		}
		for(Cmd cmd: cmds) {
			cmd.exec(procs, globais, env);
		}
	}
}

class Decl {
	String tipo;
	List<Id> vars;
	
	public Decl(String _tipo, List<Id> _vars) {
		tipo = _tipo;
		vars = _vars;
	}
	
	public String toString() {
		String res = "" + vars.get(0);
		for(int i = 1; i < vars.size(); i++)
			res += ", " + vars.get(i);
		res += ": " + tipo;
		return res;
	}
}

interface Cmd {
	void tipos(TabSimb<Proc> eprocs,
			   TabSimb<String> esc);
	void exec(TabSimb<Proc> eprocs,
  			  TabSimb<Valor> globais,
			  TabSimb<Valor> env);
	void geracod(Contexto ctx, TabSimb<Endereco> esc);
}

class Tipo {
	// t1 <= t2? (subsunção)
	public static void verifica(String t1, String t2) {
		if(!t1.equals(t2)) {
			if(!t1.equals("int") ||
					!t2.equals("real"))
				throw new RuntimeException("erro de tipo, esperado "
					+ t2 + ", encontrado " + t1);
		}
	}
	
	public static Valor padrao(String t) {
		if(t.equals("int"))
			return new Valor(0);
		else if(t.equals("real"))
			return new Valor(0.0);
		else if(t.equals("bool"))
			return new Valor(false);
		return null;
	}
}

class If implements Cmd {
	Exp cond;
	Bloco cif;
	Bloco celse;
	
	public If(Exp _cond, Bloco _cif) {
		cond = _cond;
		cif = _cif;
		celse = null;
	}
	
	public If(Exp _cond, Bloco _cif,
			Bloco _celse) {
		cond = _cond;
		cif = _cif;
		celse = _celse;
	}
	
	public String toString() {
		return "if " + cond + " then\n" + cif +
				(celse == null ? "" : "\nelse\n" + celse) + "\nend";
	}
	
	public void tipos(TabSimb<Proc> eprocs,
			          TabSimb<String> esc) {
		Tipo.verifica(cond.tipo(eprocs, esc), "bool");
		cif.tipos(eprocs, esc);
		if(celse != null) celse.tipos(eprocs, esc);
	}

	public void exec(TabSimb<Proc> eprocs,
   			         TabSimb<Valor> globais,
			         TabSimb<Valor> env) {
		boolean vc = cond.valor(env).toBool();
		if(vc)
			cif.exec(eprocs, globais, env);
		else
			if(celse != null) celse.exec(eprocs, globais, env);
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		int labif = ctx.label();
		int labelse = ctx.label();
		int labfim = celse == null ? labfim = labelse : ctx.label();
		cond.gerasalto(ctx, esc, labif);
		ctx.jmp(labelse);
		ctx.label(labif);
		cif.geracod(ctx, esc);
		if(celse != null) {
			ctx.jmp(labfim);
			ctx.label(labelse);
			celse.geracod(ctx, esc);
		}
		ctx.label(labfim);
	}
}

class Repeat implements Cmd {
	Bloco corpo;
	Exp cond;
	
	public Repeat(Bloco _corpo, Exp _cond) {
		corpo = _corpo;
		cond = _cond;
	}

	public String toString() {
		return "repeat\n" + corpo + "\nuntil " + cond;
	}

	public void tipos(TabSimb<Proc> eprocs, 
			TabSimb<String> esc) {
		// Escopo do corpo não inclui a condição
		corpo.tipos(eprocs, esc);
		Tipo.verifica(cond.tipo(eprocs, esc), "bool");
	}

	public void exec(TabSimb<Proc> eprocs,
			 TabSimb<Valor> globais,
	         TabSimb<Valor> env) {
		boolean vc;
		do {
			corpo.exec(eprocs, globais, env);
			vc = cond.valor(env).toBool();
		} while(!vc);
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		int labinicio = ctx.label();
		int labfim = ctx.label();
		ctx.label(labinicio);
		corpo.geracod(ctx, esc);
		cond.gerasalto(ctx, esc, labfim);
		ctx.jmp(labinicio);
		ctx.label(labfim);
	}
}

class Atrib implements Cmd {
	Id var;
	Exp exp;
	
	public Atrib(Id _var, Exp _exp) {
		var = _var;
		exp = _exp;
	}
	
	public String toString() {
		return var + " := " + exp;
	}

	public void tipos(TabSimb<Proc> eprocs,
			          TabSimb<String> esc) {
		String tvar = esc.procurar(var.nome);
		if(tvar == null)
			throw new RuntimeException("variável não declarada: " + var.nome);
		// podemos atribuir uma expressão inteira
		// a uma variável real, mas não o contrário
		Tipo.verifica(exp.tipo(eprocs, esc), tvar);
	}

	public void exec(TabSimb<Proc> eprocs,
 			 TabSimb<Valor> globais,
	         TabSimb<Valor> env) {
		Valor v = env.procurar(var.nome);
		v.set(exp.valor(env));
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		exp.geracod(ctx, esc);
		esc.procurar(var.nome).put(ctx);
	}
	
}

class Read implements Cmd {
	Id var;

	private static java.util.Scanner scan = new java.util.Scanner(System.in);

	
	public Read(Id _var) {
		var = _var;
	}

	public String toString() {
		return "read " + var;
	}

	public void tipos(TabSimb<Proc> eprocs,
			          TabSimb<String> esc) {
		if(esc.procurar(var.nome) == null)
			throw new RuntimeException("variável não declarada: " + var.nome);
	}

	public void exec(TabSimb<Proc> eprocs,
			 TabSimb<Valor> globais,
	         TabSimb<Valor> env) {
		Valor v = env.procurar(var.nome);
		switch(v.tipo) {
		case "int": v.set(scan.nextInt()); break;
		case "real": v.set(scan.nextDouble()); break;
		case "bool": v.set(scan.nextBoolean()); break;
		}
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		ctx.read();
		esc.procurar(var.nome).put(ctx);
	}
}

class Write implements Cmd {
	Exp exp;
	
	public Write(Exp _exp) {
		exp = _exp;
	}

	public String toString() {
		return "write " + exp;
	}

	public void tipos(TabSimb<Proc> eprocs,
			          TabSimb<String> esc) {
		exp.tipo(eprocs, esc);
	}

	public void exec(TabSimb<Proc> eprocs,
			 TabSimb<Valor> globais,
	         TabSimb<Valor> env) {
		System.out.println(exp.valor(env));
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		exp.geracod(ctx, esc);
		ctx.write();
	}
}

interface Exp {
	String tipo(TabSimb<Proc> eprocs, TabSimb<String> esc);
	Valor valor(TabSimb<Valor> env);
	void geracod(Contexto ctx, TabSimb<Endereco> esc);
	void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label);
}

class Menor implements Exp {
	Exp e1;
	Exp e2;
	
	public Menor(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " < " + e2 + ")";
	}
	
	public String tipo(TabSimb<Proc> eprocs, 
			           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "bool";
	}
	
	public Valor valor(TabSimb<Valor> env) {
		Valor v1 = e1.valor(env);
		Valor v2 = e2.valor(env);
		return new Valor(v1.toDouble() < v2.toDouble());
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		int lab1 = ctx.label();
		int lab2 = ctx.label();
		gerasalto(ctx, esc, lab1);
		ctx.icload(0);
		ctx.jmp(lab2);
		ctx.label(lab1);
		ctx.icload(1);
		ctx.label(lab2);
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		e1.geracod(ctx, esc);
		e2.geracod(ctx, esc);
		ctx.if_icmplt(label);
	}
}

class Igual implements Exp {
	Exp e1;
	Exp e2;
	
	public Igual(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " = " + e2 + ")";
	}

	public String tipo(TabSimb<Proc> eprocs,
			           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(!t1.equals("bool") || !t2.equals("bool")) {
			Tipo.verifica(t1, "real");
			Tipo.verifica(t2, "real");
		}
		return "bool";
	}

	public Valor valor(TabSimb<Valor> env) {
		Valor v1 = e1.valor(env);
		Valor v2 = e2.valor(env);
		return new Valor(v1.v.equals(v2.v));
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		int lab1 = ctx.label();
		int lab2 = ctx.label();
		gerasalto(ctx, esc, lab1);
		ctx.icload(0);
		ctx.jmp(lab2);
		ctx.label(lab1);
		ctx.icload(1);
		ctx.label(lab2);
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		e1.geracod(ctx, esc);
		e2.geracod(ctx, esc);
		ctx.if_icmpeq(label);
	}
}

class Soma implements Exp {
	Exp e1;
	Exp e2;
	
	public Soma(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " + " + e2 + ")";
	}

	public String tipo(TabSimb<Proc> eprocs,
			           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(t1.equals("int") && t2.equals("int"))
			return "int";
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}

	public Valor valor(TabSimb<Valor> env) {
		Valor v1 = e1.valor(env);
		Valor v2 = e2.valor(env);
		if(v1.tipo.equals("real") || v2.tipo.equals("real"))
			return new Valor(v1.toDouble() + v2.toDouble());
		else
			return new Valor(v1.toInt() + v2.toInt());
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		e1.geracod(ctx, esc);   // empilhar resultado de e1
		e2.geracod(ctx, esc);   // empilhar resutado de e2
		ctx.iadd();             // desempilhar dois valores, 
                                //   fazer o primeiro mais o segundo
                                //   e empilhar o resultado
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {}
}

class Sub implements Exp {
	Exp e1;
	Exp e2;
	
	public Sub(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " - " + e2 + ")";
	}

	public String tipo(TabSimb<Proc> eprocs,
	           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(t1.equals("int") && t2.equals("int"))
			return "int";
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}

	public Valor valor(TabSimb<Valor> env) {
		Valor v1 = e1.valor(env);
		Valor v2 = e2.valor(env);
		if(v1.tipo.equals("real") || v2.tipo.equals("real"))
			return new Valor(v1.toDouble() - v2.toDouble());
		else
			return new Valor(v1.toInt() - v2.toInt());
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		e1.geracod(ctx, esc);   // empilhar resultado de e1
		e2.geracod(ctx, esc);   // empilhar resutado de e2
		ctx.isub();             // desempilhar dois valores, 
                                //   fazer o primeiro menos o segundo
                                //   e empilhar o resultado
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {}
}

class Mult implements Exp {
	Exp e1;
	Exp e2;
	
	public Mult(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " * " + e2 + ")";
	}

	public String tipo(TabSimb<Proc> eprocs,
	           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		if(t1.equals("int") && t2.equals("int"))
			return "int";
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}

	public Valor valor(TabSimb<Valor> env) {
		Valor v1 = e1.valor(env);
		Valor v2 = e2.valor(env);
		if(v1.tipo.equals("real") || v2.tipo.equals("real"))
			return new Valor(v1.toDouble() * v2.toDouble());
		else
			return new Valor(v1.toInt() * v2.toInt());
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		e1.geracod(ctx, esc);   // empilhar resultado de e1
		e2.geracod(ctx, esc);   // empilhar resutado de e2
		ctx.imul();             // desempilhar dois valores, 
                                //   fazer o primeiro vezes o segundo
                                //   e empilhar o resultado
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {}
}

class Div implements Exp {
	Exp e1;
	Exp e2;
	
	public Div(Exp _e1, Exp _e2) {
		e1 = _e1;
		e2 = _e2;
	}

	public String toString() {
		return "(" + e1 + " / " + e2 + ")";
	}

	public String tipo(TabSimb<Proc> eprocs,
	           TabSimb<String> esc) {
		String t1 = e1.tipo(eprocs, esc);
		String t2 = e2.tipo(eprocs, esc);
		Tipo.verifica(t1, "real");
		Tipo.verifica(t2, "real");
		return "real";
	}

	public Valor valor(TabSimb<Valor> env) {
		Valor v1 = e1.valor(env);
		Valor v2 = e2.valor(env);
		return new Valor(v1.toDouble() / v2.toDouble());
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		e1.geracod(ctx, esc);   // empilhar resultado de e1
		e2.geracod(ctx, esc);   // empilhar resutado de e2
		ctx.idiv();             // desempilhar dois valores, 
                                //   fazer o primeiro sobre o segundo
                                //   e empilhar o resultado
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {}
}

class Num implements Exp {
	int val;
	
	public Num(String lexeme) {
		val = Integer.parseInt(lexeme);
	}

	public String toString() {
		return "" + val;
	}

	public String tipo(TabSimb<Proc> eprocs,
			TabSimb<String> esc) {
		return "int";
	}

	public Valor valor(TabSimb<Valor> env) {
		return new Valor(val);
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		ctx.icload(val);   // empilha o valor do número
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {}
}

class Id implements Exp {
	String nome;
	
	public Id(String _nome) {
		nome = _nome;
	}

	public String toString() {
		return nome;
	}

	public String tipo(TabSimb<Proc> eprocs,
			TabSimb<String> esc) {
		String tvar = esc.procurar(nome); 
		if(tvar == null)
			throw new RuntimeException("variável não existe: " + nome);
		return tvar;
	}

	public Valor valor(TabSimb<Valor> env) {
		return env.procurar(nome);
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		esc.procurar(nome).get(ctx);  // empilha valor da variável
	}

	@Override
	public void gerasalto(Contexto ctx, TabSimb<Endereco> esc, int label) {
		esc.procurar(nome).get(ctx);  // empilha valor da variável
		ctx.icload(1);
		ctx.if_icmpeq(label);
	}
}

class Chamada implements Cmd {
	Id proc;
	
	public Chamada(Id _proc) {
		proc = _proc;
	}
	
	public String toString() {
		return "" + proc + "()";
	}
	
	public void tipos(TabSimb<Proc> eprocs,
			TabSimb<String> esc) {
		if(eprocs.procurar(proc.nome) == null)
			throw new RuntimeException("procedimento não existe: " + proc.nome);
	}
	
	public void exec(TabSimb<Proc> eprocs,
			TabSimb<Valor> globais,
			TabSimb<Valor> env) {
		Proc p = eprocs.procurar(proc.nome);
		p.corpo.exec(eprocs, globais, globais);
	}

	@Override
	public void geracod(Contexto ctx, TabSimb<Endereco> esc) {
		ctx.invoke(proc.nome);
	}
}
