import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;

public class Driver {
	public static void main(String[] args) throws IOException {
		String name = args[0];
		String name_asm = name.substring(0, name.lastIndexOf('.')) + ".asm";
		File f = new File(name);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		parser.parse();
		Tiny prog = parser.saida;
		String saida = prog.toString();
		StringReader sr = new StringReader(saida);
		System.out.println(saida);
		parser = new Parser(sr);
		parser.parse();
		if(!saida.equals(parser.saida.toString())) {
			throw new RuntimeException("bug no parser: programa mal formado");
		}
		prog.tipos();
		TabSimb<Valor> globais = prog.exec();
		System.out.println("GLOBAIS:\n" + globais);
		FileWriter fw = new FileWriter(new File(name_asm));
		fw.write(prog.geracod());
		fw.close();
	}

}
