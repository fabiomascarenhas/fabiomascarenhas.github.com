package lex;

public class Token {
	public int type;
	public String val;
	
	public final static int EOF = 0;
	
	public Token(int type, String val) {
		this.type = type;
		this.val = val;
	}
	
	public String toString() {
		if(type < 32)
			return "(" + type + "," + val + ")";
		else
			return "(" + (char)type + ")";
	}
}
