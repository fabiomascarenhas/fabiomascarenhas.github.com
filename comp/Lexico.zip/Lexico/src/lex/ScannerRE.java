package lex;

import java.util.ArrayList;
import java.util.List;

public class ScannerRE implements Scanner {
	public class Rule {
		public String regex;
		public int type;
		
		public Rule(String regex, int type) {
			this.regex = regex;
			this.type = type;
		}
	}
	
	public List<Rule> rules = new ArrayList<Rule>();
	public String regexSpace;
	public String input;

	public void space(String regex) {
		regexSpace = regex;
	}
	
	public void rule(String regex, int type) {
		rules.add(new Rule(regex, type));
	}
	
	@Override
	public void setInput(String input) {
		this.input = input;
	}

	@Override
	public Token nextToken() {
		do {
			String[] result = RE.findAtStart(regexSpace, input);
			if(result[0].length() == 0) break;
			input = result[1];
		} while(true);
		if(input.equals(""))
			return new Token(Token.EOF, "");
		String maxMatch = "";
		String nextInput = input;
		int type = -1;
		for(Rule rule : rules) {
			String[] result = RE.findAtStart(rule.regex, input);
			String match = result[0];
			if(match.length() > maxMatch.length()) {
				maxMatch = match;
				type = rule.type;
				nextInput = result[1];
			}
		}
		if(maxMatch.length() > 0) {
			input = nextInput;
			return new Token(type, maxMatch);
		} else throw new RuntimeException("lexical error at: " +
			input.charAt(0));
	}

	@Override
	public List<Token> allTokens() {
		List<Token> tokens = new ArrayList<Token>();
		Token tok = nextToken();
		while(tok.type != Token.EOF) {
			tokens.add(tok);
			tok = nextToken();
		}
		return tokens;
	}

}
