package lex;

public class Par<A, B> {
	public A a;
	public B b;
	
	public Par(A a, B b) {
		this.a = a;
		this.b = b;
	}
}
