package lex;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RE {
	public static List<String> findAll(String regex, String haystack) {
		Matcher m = Pattern.compile(regex).matcher(haystack);
		List<String> l = new ArrayList<String>();
		while(m.find())
			l.add(m.group());
		return l;
	}
	
	public static String[] findAtStart(String regex, String input) {
		Matcher m = Pattern.compile("^"+regex).matcher(input);
		if(m.find()) {
			return new String[] {
					m.group(), input.substring(m.end()) };
		} else return new String[] { "", input };
	}
}
