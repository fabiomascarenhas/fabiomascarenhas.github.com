import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id
*/
public class Parser {
	public Scanner scan;
	public Token la;
	
	public Parser(Scanner scan) {
		try {
			this.scan = scan;
			la = scan.token();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	String match(int tipo) {
		if(la.tipo == tipo) {
			String lexeme = la.lexeme;
			try {
				la = scan.token();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
			return lexeme;
		} else {
			throw new RuntimeException("erro de sintaxe na linha "+
				la.lin + ", esperado " + tipo + " encontrado " + la.lexeme);
		}
	}
	
	// S -> CMDS
	Tree parse() {
		Tree res = cmds();
		match(Token.EOF);
		return res;
	}
	
	// CMDS  -> CMD { ; CMD }
	Tree cmds() {
		Tree res = new Tree("CMDS");
		res.child(cmd());
		while(la.tipo == ';') {
			res.child(match(';'));
			res.child(cmd());
		}
		return res;
	}

 	/*
      CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
	 */
	Tree cmd() {
		Tree res = new Tree("CMD");
		switch(la.tipo) {
		case Token.IF:
			res.child(match(Token.IF));
			res.child(exp());
			res.child(match(Token.THEN));
			res.child(cmds());
			if(la.tipo == Token.ELSE) {
				res.child(match(Token.ELSE));
				res.child(cmds());
			}
			res.child(match(Token.END));
			break;
		case Token.REPEAT:
			res.child(match(Token.REPEAT));
			res.child(cmds());
			res.child(match(Token.UNTIL));
			res.child(exp());
			break;
		case Token.ID:
			res.child(match(Token.ID));
			res.child(match(Token.ATTRIB));
			res.child(exp());
			break;
		case Token.READ:
			res.child(match(Token.READ));
			res.child(match(Token.ID));
			break;
		case Token.WRITE:
			res.child(match(Token.WRITE));
			res.child(exp());
			break;
		default:
			throw new RuntimeException("erro de sintaxe na linha "+
				la.lin + ", esperado um comando e encontrado " + la.lexeme);
		}
		return res;
	}
	
	// EXP   -> SEXP { < SEXP | = SEXP }
	Tree exp() {
		Tree res = new Tree("EXP");
		res.child(sexp());
		while(la.tipo == '<' || la.tipo == '=') {
			if(la.tipo == '<') {
				res.child(match('<'));
				res.child(sexp());
			} else {
				res.child(match('='));
				res.child(sexp());
			}
		}
		return res;
	}

	// SEXP  -> TERMO { + TERMO | - TERMO }
	Tree sexp() {
		Tree res = new Tree("SEXP");
		res.child(termo());
		while(la.tipo == '+' || la.tipo == '-') {
			if(la.tipo == '+') {
				res.child(match('+'));
				res.child(termo());
			} else {
				res.child(match('-'));
				res.child(termo());
			}
		}
		return res;
	}

	// TERMO -> FATOR { * FATOR | / FATOR }
	Tree termo() {
		Tree res = new Tree("TERMO");
		res.child(fator());
		while(la.tipo == '*' || la.tipo == '/') {
			if(la.tipo == '*') {
				res.child(match('*'));
				res.child(fator());
			} else {
				res.child(match('/'));
				res.child(fator());
			}
		}
		return res;
	}

	// FATOR -> "(" EXP ")" | num | id
	Tree fator() {
		Tree res = new Tree("FATOR");
		switch(la.tipo) {
		case '(':
			res.child(match('('));
			res.child(exp());
			res.child(match(')'));
			break;
		case Token.NUM:
			res.child(match(Token.NUM));
			break;
		case Token.ID:
			res.child(match(Token.ID));
			break;
		default:
			throw new RuntimeException("erro de sintaxe na linha "+
					la.lin + ", esperada uma expressão e encontrado " + la.lexeme);
		}
		return res;
	}
}
