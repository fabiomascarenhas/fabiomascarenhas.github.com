import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;


public class Print implements Cmd {
	public Exp exp;
	
	public Print(Exp exp) {
		this.exp = exp;
	}

	@Override
	public void exec(Map<String, Integer> vars) {
		System.out.println(exp.valor(vars));
	}

	@Override
	public void geraCodigo(Writer saida, List<String> vars) throws IOException {
		saida.append("getstatic java/lang/System/out Ljava/io/PrintStream;\n");
		exp.geraCodigo(saida, vars);
		saida.append("invokevirtual java/io/PrintStream/println(I)V\n");
	}

}
