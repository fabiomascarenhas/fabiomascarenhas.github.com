import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;

public class Num implements Exp {
	public String num;
	
	public Num(String num) {
		this.num = num;
	}

	@Override
	public int valor(Map<String, Integer> vars) {
		return Integer.parseInt(num);
	}

	@Override
	public void geraCodigo(Writer saida, List<String> vars) throws IOException {
		saida.append("ldc " + num + "\n"); 
	}

}
