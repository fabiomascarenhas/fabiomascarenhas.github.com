import java.io.IOException;
import java.io.Reader;

// Tokens: numerais inteiros, identificadores,
//         +, -, (, ), =, ;, print
public class ScannerManual {
	public Reader ent;
	
	public int prox;
	
	public ScannerManual(Reader ent) throws IOException {
		this.ent = ent;
		prox = ent.read();
	}
	
	public Token leNumero() throws IOException {
		String num = "";
		while(Character.isDigit(prox)) {
			num += Character.toString((char)prox);
			prox = ent.read();
		}
		return new Token(1, num);  // 1 == NUM
	}
	
	public Token leId() throws IOException {
		String id = "";
		while(Character.isLetter(prox)) {
			id += Character.toString((char)prox);
			prox = ent.read();
		}
		if(id.equals("print"))
			return new Token(3, "print"); // 3 = print
		else
			return new Token(2, id);  // 2 == ID
	}
	
	public Token leToken() throws IOException {
		while(prox == ' ' || prox == '\n' ||
				prox == '\t')
			prox = ent.read();
		if(prox == -1)
			return new Token(0, ""); // 0 == EOF
		else if(Character.isDigit(prox))
			return leNumero();
		else if(Character.isLetter(prox))
			return leId();
		else if(prox == '(') {
			prox = ent.read();
			return new Token('(', "(");
		} else if(prox == ')') {
			prox = ent.read();
			return new Token(')', ")");
		} else if(prox == ';') {
			prox = ent.read();
			return new Token(';', ";");
		} else if(prox == '=') {
			prox = ent.read();
			return new Token('=', "=");
		} else if(prox == '+') {
			prox = ent.read();
			return new Token('+', "+");
		} else if(prox == '-') {
			prox = ent.read();
			return new Token('-', "-");
		} else
			throw new 
				RuntimeException("caractere inv�lido "
						+ (char)prox);
	}
}
