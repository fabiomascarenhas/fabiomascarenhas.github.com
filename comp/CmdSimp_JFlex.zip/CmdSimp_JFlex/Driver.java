import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Driver {
	public static void main(String[] args) throws IOException {
		File f = new File(args[0]);
		FileReader fr = new FileReader(f);
		Parser parser = new Parser(fr);
		Prog prog = parser.parse();
		prog.exec();
		String fname = f.getName();
		prog.geraCodigo(fname.substring(0, fname.lastIndexOf('.')));
	}
}
