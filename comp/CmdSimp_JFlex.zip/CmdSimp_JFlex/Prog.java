import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Prog {
	public List<Cmd> cmds;
	
	public Prog(List<Cmd> cmds) {
		this.cmds = cmds;
	}

	public void exec() {
		HashMap<String, Integer> vars = new
				HashMap<String, Integer>();
		for(Cmd cmd: cmds)
			cmd.exec(vars);
	}
	
	public void geraCodigo(String nome) throws IOException {
		Writer saida = new FileWriter(nome + ".jasmin");
		try {
			saida.append(".class public " + nome + "\n");
			saida.append(".super java/lang/Object\n");
			saida.append(".method public static main([Ljava/lang/String;)V\n");
			saida.append(".limit stack 100\n");
			saida.append(".limit locals 100\n");
			ArrayList<String> vars = new ArrayList<String>();
			vars.add("__args");
			for(Cmd cmd: cmds)
				cmd.geraCodigo(saida, vars);
			saida.append("return\n");
			saida.append(".end method\n");
		} finally {
			saida.close();
		}
	}

}
