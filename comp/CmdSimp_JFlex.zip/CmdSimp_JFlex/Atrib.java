import java.io.IOException;
import java.io.Writer;
import java.util.List;
import java.util.Map;


public class Atrib implements Cmd {
	public String id;
	public Exp exp;
	
	public Atrib(String id, Exp exp) {
		this.id = id;
		this.exp = exp;
	}

	@Override
	public void exec(Map<String, Integer> vars) {
		int val = exp.valor(vars);
		vars.put(id,  val);
	}

	@Override
	public void geraCodigo(Writer saida, List<String> vars) throws IOException {
		exp.geraCodigo(saida, vars);
		if(!vars.contains(id))
			vars.add(id);
		saida.append("istore " + vars.indexOf(id) + "\n");
	}

}
