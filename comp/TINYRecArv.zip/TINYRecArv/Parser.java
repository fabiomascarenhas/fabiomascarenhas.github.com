import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
EXP   -> SEXP { < SEXP | = SEXP }
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | id
*/

class Falha extends RuntimeException { }

public class Parser {
	ArrayList<Token> tokens;
	int atual = 0;
	int falha = -1;
	Set<Integer> esperados = new HashSet<Integer>();
	
	public Parser(Scanner scan) {
		tokens = new ArrayList<Token>();
		try {
			Token tok;
			do {
				tok = scan.token();
				tokens.add(tok);
			} while(tok.tipo != Token.EOF);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	String match(int tipo) {
		if(tokens.get(atual).tipo == tipo) {
			String lexeme = tokens.get(atual).lexeme;
			atual++;
			return lexeme;
		} else {
			if(atual == falha) {
				esperados.add(tipo);
			} else if(atual > falha) {
				falha = atual;
				esperados.clear();
				esperados.add(tipo);
			}
			throw new Falha();
		}
	}
	
	// S -> CMDS
	Tree parse() {
		try {
			Tree res = cmds();
			match(Token.EOF);
			return res;
		} catch(Falha f) {
			throw new RuntimeException("erro de sintaxe, esperado " + esperados + ", encontrado " + tokens.get(falha));
		}
	}
	
	// CMDS  -> CMD { ; CMD }
	Tree cmds() {
		Tree res = new Tree("CMDS");
		res.child(cmd());
		while(true) {
			int pos = atual;
			try {
				Tree rascunho = new Tree();
				rascunho.child(match(';'));
				rascunho.child(cmd());
				res.children.addAll(rascunho.children);
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
		return res;
	}

 	/*
      CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | id := EXP
       | read id
       | write EXP
	 */
	Tree cmd() {
		Tree res = new Tree("CMD");
		int pos = atual;
		try {
			Tree rascunho = new Tree();
			rascunho.child(match(Token.IF));
			rascunho.child(exp());
			rascunho.child(match(Token.THEN));
			rascunho.child(cmds());
			int pos_ = atual;
			try {
				Tree rascunho_ = new Tree();
				rascunho_.child(match(Token.ELSE));
				rascunho_.child(cmds());
				rascunho.children.addAll(rascunho_.children);
			} catch(Falha f) {
				atual = pos_;
			}
			rascunho.child(match(Token.END));
			res.children.addAll(rascunho.children);
		} catch(Falha f) {
			atual = pos;
			// int pos = atual;
			try {
				Tree rascunho = new Tree();
				rascunho.child(match(Token.REPEAT));
				rascunho.child(cmds());
				rascunho.child(match(Token.UNTIL));
				rascunho.child(exp());
				res.children.addAll(rascunho.children);
			} catch(Falha f_) {
				atual = pos;
				// int pos = atual;
				try {
					Tree rascunho = new Tree();
					rascunho.child(match(Token.ID));
					rascunho.child(match(Token.ATTRIB));
					rascunho.child(exp());
					res.children.addAll(rascunho.children);
				} catch(Falha f__) {
					atual = pos;
					// int pos = atual;
					try {
						Tree rascunho = new Tree();
						rascunho.child(match(Token.READ));
						rascunho.child(match(Token.ID));
						res.children.addAll(rascunho.children);
					} catch(Falha f___) {
						atual = pos;
						res.child(match(Token.WRITE));
						res.child(exp());
					}
				}
			}
		}
		return res;
	}
	
	// EXP   -> SEXP { < SEXP | = SEXP }
	Tree exp() {
		Tree res = new Tree("EXP");
		res.child(sexp());
		while(true) {
			int pos = atual;
			try {
				Tree rascunho = new Tree();
				// int pos = atual;
				try {
					Tree rascunho_ = new Tree();
					rascunho_.child(match('<'));
					rascunho_.child(sexp());
					rascunho.children.addAll(rascunho_.children);
				} catch (Falha f) {
					atual = pos;
					rascunho.child(match('='));
					rascunho.child(sexp());
				}
				res.children.addAll(rascunho.children);
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
		return res;
	}

	// SEXP  -> TERMO { + TERMO | - TERMO }
	Tree sexp() {
		Tree res = new Tree("SEXP");
		res.child(termo());
		while(true) {
			int pos = atual;
			try {
				Tree rascunho = new Tree();
				// int pos = atual;
				try {
					Tree rascunho_ = new Tree();
					rascunho_.child(match('+'));
					rascunho_.child(termo());
					rascunho.children.addAll(rascunho_.children);
				} catch (Falha f) {
					atual = pos;
					rascunho.child(match('-'));
					rascunho.child(termo());
				}
				res.children.addAll(rascunho.children);
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
		return res;
	}

	// TERMO -> FATOR { * FATOR | / FATOR }
	Tree termo() {
		Tree res = new Tree("TERMO");
		res.child(fator());
		while(true) {
			int pos = atual;
			try {
				Tree rascunho = new Tree();
				// int pos = atual;
				try {
					Tree rascunho_ = new Tree();
					rascunho_.child(match('*'));
					rascunho_.child(fator());
					rascunho.children.addAll(rascunho_.children);
				} catch (Falha f) {
					atual = pos;
					rascunho.child(match('/'));
					rascunho.child(fator());
				}
				res.children.addAll(rascunho.children);
			} catch(Falha f) {
				atual = pos;
				break;
			}
		}
		return res;
	}

	// FATOR -> "(" EXP ")" | num | id
	Tree fator() {
		Tree res = new Tree("FATOR");
		int pos = atual;
		try {
			Tree rascunho = new Tree();
			rascunho.child(match('('));
			rascunho.child(exp());
			rascunho.child(match(')'));
			res.children.addAll(rascunho.children);
		} catch(Falha f) {
			atual = pos;
			// int pos = atual;
			try {
				Tree rascunho = new Tree();
				rascunho.child(match(Token.NUM));
				res.children.addAll(rascunho.children);
			} catch(Falha f_) {
				atual = pos;
				res.child(match(Token.ID));
			}
		}
		return res;
	}
}
