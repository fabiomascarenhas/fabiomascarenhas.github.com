import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;

public interface Cmd {
	void codigo(List<String> vars, StringBuffer out);
	void run(HashMap<String, BigInteger> vars);
}
