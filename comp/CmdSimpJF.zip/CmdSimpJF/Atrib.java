import java.math.BigInteger;
import java.util.HashMap;
import java.util.List;


public class Atrib implements Cmd {
	public String id;
	public Exp exp;
	public int lin;
	
	public Atrib(String _id, Exp _exp, int _lin) {
		id = _id;
		exp = _exp;
		lin = _lin;
	}

	public String toString() {
		return id + "=" + exp;
	}

	@Override
	public void run(HashMap<String, BigInteger> vars) {
		vars.put(id, exp.eval(vars));
	}
	
	@Override
	public void codigo(List<String> vars, StringBuffer out) {
		exp.codigo(vars, out);
		if(!vars.contains(id))
			vars.add(id);
		out.append("istore " + vars.indexOf(id) + "\n");
	}
}
