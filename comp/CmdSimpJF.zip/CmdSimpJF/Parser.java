import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Parser {
	public Scanner scan;
	Token la;
	
	public Parser(Scanner _scan) {
		scan = _scan;
		try {
			la = scan.token();
		} catch (IOException e) {
		}
	}
	
	public Token le(int tipo) {
		if(la.tipo == tipo) {
			Token tok = la;
			try {
				la = scan.token();
			} catch (IOException e) {
			}
			return tok;
		} else
			throw new RuntimeException("token inválido na linha " + la.lin + ", :" + la);
	}
	
	public Prog prog() {
		List<Cmd> cmds = new ArrayList<Cmd>();
		while(la.tipo != Token.EOF) { 
	 	  cmds.add(cmd());
		  le(';');
		}
		return new Prog(cmds);
	}
	
	public Cmd cmd() {
		switch(la.tipo) {
		case Token.ID: { // atribuição
			Token id = le(Token.ID);
			le('=');
			Exp exp = exp();
			return new Atrib(id.lexeme, exp, id.lin);
		}
		case Token.PRINT: {
			Token print = le(Token.PRINT);
			Exp exp = exp();
			return new Print(exp, print.lin);
		}
		default:
			throw new RuntimeException("comando inválido na linha " + la.lin + ", :" + la);
		}
	}
	
	public Exp exp() {
		Exp exp1 = aexp();
		while(la.tipo == '+' || la.tipo == '-') {
			if(la.tipo == '+') {
				Token op = le('+');
				Exp exp2 = aexp();
				exp1 = new Soma(exp1, exp2, op.lin);
			} else {
				Token op = le('-');
				Exp exp2 = aexp();
				exp1 = new Sub(exp1, exp2, op.lin);
			}
		}
		return exp1;
	}
	
	public Exp aexp() {
		switch(la.tipo) {
		case Token.ID: {
			Token id = le(Token.ID);
			return new Id(id.lexeme, id.lin);
		}
		case Token.NUM: {
			Token num = le(Token.NUM);
			return new Num(Integer.parseInt(num.lexeme), num.lin);
		}
		case '(': {
			le('(');
			Exp exp = exp();
			le(')');
			return exp;
		}
		default:
			throw new RuntimeException("expressão inválida na linha " + la.lin + ", :" + la);
		}
	}
}
