
public interface Cmd {
	void checaTipo(TabSimb<String> tipos);
	void geraCodigo(Contexto ctx, TabSimb<Endereco> vars);
}
