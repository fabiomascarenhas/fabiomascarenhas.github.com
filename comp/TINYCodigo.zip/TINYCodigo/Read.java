
public class Read extends Node implements Cmd {
	public String nome;
	
	public Read(Token tok) {
		super(tok.lin);
		nome = tok.lexeme;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		tipos.procurar(nome, lin);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		ctx.read(); // le da entrada e empilha
		vars.procurar(nome, lin).store(ctx); // desempilha e guarda no endereço de nome
	}
}
