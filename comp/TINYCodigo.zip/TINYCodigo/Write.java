
public class Write extends Node implements Cmd {
	public Exp exp;
	
	public Write(Exp e, int _lin) {
		super(_lin);
		exp = e;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		exp.checaTipo(tipos);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		exp.geraCodigo(ctx, vars);
		ctx.write(); // desempilha e escreve na saída
	}
}
