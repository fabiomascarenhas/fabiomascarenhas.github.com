
public class Id extends Exp {
	public String nome;
	
	public Id(Token tok) {
		super(tok.lin);
		nome = tok.lexeme;
	}

	@Override
	public String checaTipoImpl(TabSimb<String> tipos) {
		return tipos.procurar(nome, lin);
	}

	@Override
	public void geraCodigo(Contexto ctx, TabSimb<Endereco> vars) {
		vars.procurar(nome, lin).load(ctx);
	}

	@Override
	public void geraSaltoF(Contexto ctx, TabSimb<Endereco> vars, int lab) {
		this.geraCodigo(ctx, vars); // empilhar o valor o this
		ctx.icload(1);
		ctx.if_icmpneq(lab);
	}
}
