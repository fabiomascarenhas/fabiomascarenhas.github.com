import java.util.ArrayList;
import java.util.List;

public class Bloco extends Node {
	public List<Decl> vars;
	public List<Cmd> cmds;
	
	public Bloco(List<Decl> vs, int _lin) {
		super(_lin);
		vars = vs;
		cmds = new ArrayList<Cmd>();
	}
	
	public void add(Cmd cmd) {
		cmds.add(cmd);
	}
	
	public TabSimb<String> checaTipo(TabSimb<String> tipos) {
		TabSimb<String> ebloco = new TabSimb<String>(tipos);
		for(Decl decl: vars) {
			for(String nome: decl.vars) {
				ebloco.inserir(nome, decl.tipo, lin);
			}
		}
		for(Cmd cmd: cmds) {
			cmd.checaTipo(ebloco);
		}
		return ebloco;
	}
	
	public TabSimb<Endereco> geraCodigo(Contexto ctx, TabSimb<Endereco> epai, boolean main) {
		TabSimb<Endereco> ebloco = new TabSimb<Endereco>(epai);
		for(Decl decl: vars) {
			for(String nome: decl.vars) {
				if(main) {
					ebloco.inserir(nome, new Global(nome), lin);
				} else {
					ebloco.inserir(nome, ctx.local(), lin);
				}
			}
		}
		for(Cmd cmd: cmds) {
			cmd.geraCodigo(ctx, ebloco);
		}
		return ebloco;
	}
	
}
