import java.io.IOException;
import java.io.Reader;

/*
S     -> CMDS
CMDS  -> CMD { ; CMD }
CMD   -> if EXP then CMDS [ else CMDS ] end
       | repeat CMDS until EXP
       | ( id := EXP | id '[' EXP ']' := EXP )
       | read id
       | write EXP
EXP   -> SEXP [ < SEXP | = SEXP ]
SEXP  -> TERMO { + TERMO | - TERMO }
TERMO -> FATOR { * FATOR | / FATOR }
FATOR -> "(" EXP ")" | num | ( id | id '[' EXP ']' ) 
 */
public class Parser {
	Scanner scan;
	Token la;

	public Parser(Reader in) {
		scan = new Scanner(in);
		try {
			la = scan.token();
		} catch(IOException e) {
			throw new RuntimeException(e);
		}
	}

	public String match(int token) {
		if(la.tipo == token) {
			String termo = la.val;
			try {
				la = scan.token();
			} catch(IOException e) {
				throw new RuntimeException(e);
			}
			return termo;
		} else
			throw new RuntimeException("erro de sintaxe na linha " + la.lin + 
					", esperado " + token + ", encontrado " + la);
	}

	// S -> CMDS
	public Tree parse() {
		Tree t = CMDS();
		match(Token.EOF);
		return t;
	}

	// CMDS  -> CMD { ; CMD }
	public Tree CMDS() {
		Tree t = new Tree("CMDS");
		t.child(CMD());
		while(la.tipo == ';') {
			t.child(match(';'));
			t.child(CMD());
		}
		return t;
	}

	// CMD   -> if EXP then CMDS [ else CMDS ] end
    //          | repeat CMDS until EXP
    //          | ( id := EXP | id '[' EXP ']' := EXP )
    //          | read id
    //          | write EXP
	public Tree CMD() {
		Tree t = new Tree("CMD");
		switch(la.tipo) {
		case Token.IF:
			// if EXP then CMDS [ else CMDS ] end
			t.child(match(Token.IF));
			t.child(EXP());
			t.child(match(Token.THEN));
			t.child(CMDS());
			if(la.tipo == Token.ELSE) {
				// else CMDS
				t.child(match(Token.ELSE));
				t.child(CMDS());
			}
			t.child(match(Token.END));
			break;
		case Token.REPEAT:
			// repeat CMDS until EXP
			t.child(match(Token.REPEAT));
			t.child(CMDS());
			t.child(match(Token.UNTIL));
			t.child(EXP());
			break;
		case Token.ID:
			// id := EXP | id '[' EXP ']' := EXP
			t.child(match(Token.ID));
			if(la.tipo == Token.ATRIB) {
				// id := EXP
				t.child(match(Token.ATRIB));
				t.child(EXP());
			} else {
				// id '[' EXP ']' := EXP
				t.child(match('['));
				t.child(EXP());
				t.child(match(']'));
				t.child(match(Token.ATRIB));
				t.child(EXP());
			}
			break;
		case Token.READ:
			// read id
			t.child(match(Token.READ));
			t.child(match(Token.ID));
			break;
		case Token.WRITE:
			// write EXP
			t.child(match(Token.WRITE));
			t.child(EXP());
			break;
		default:
			match(Token.IF); // força um erro	
		}
		return t;
	}	
	
	// EXP   -> SEXP [ < SEXP | = SEXP ]
	Tree EXP() {
		Tree t = new Tree("EXP");
		t.child(SEXP());
		if(la.tipo == '<') {
			// < SEXP
			t.child(match('<'));
			t.child(SEXP());
		} else if(la.tipo == '=') {
			// = SEXP
			t.child(match('='));
			t.child(SEXP());
		}
		return t;
	}
	
	// SEXP  -> TERMO { + TERMO | - TERMO }
	Tree SEXP() {
		Tree t = new Tree("SEXP");
		t.child(TERMO());
		while(la.tipo == '+' || la.tipo == '-') {
			if(la.tipo == '+') {
				// + TERMO
				t.child(match('+'));
				t.child(TERMO());
			} else {
				// - TERMO
				t.child(match('-'));
				t.child(TERMO());
			}
		}
		return t;
	}
	
	// TERMO  -> FATOR { * FATOR | / FATOR }
	public Tree TERMO() {
		Tree t = new Tree("TERMO");
		t.child(FATOR());
		while(la.tipo == '*' || la.tipo == '/') {
			if(la.tipo == '*') {
				// * FATOR
				t.child(match('*'));
				t.child(FATOR());
			} else {
				// / FATOR
				t.child(match('/'));
				t.child(FATOR());
			}
		}
		return t;
	}
	
	// FATOR -> "(" EXP ")" | num | ( id | id '[' EXP ']' ) 
	public Tree FATOR() {
		Tree t = new Tree("FATOR");
		switch(la.tipo) {
		case '(':
			t.child(match('('));
			t.child(EXP());
			t.child(match(')'));
			break;
		case Token.NUM:
			t.child(match(Token.NUM));
			break;
		default:
			t.child(match(Token.ID));
			if(la.tipo == '[') {
				t.child(match('['));
				t.child(EXP());
				t.child(match(']'));
			}
		}
		return t;
	}
	
}
