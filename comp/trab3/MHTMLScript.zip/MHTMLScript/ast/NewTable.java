package ast;

public class NewTable extends Node implements Exp {

	public NewTable(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		// TODO cria uma nova tabela
		return null;
	}

	@Override
	public String label() {
		return "{}";
	}

}
