package ast;

public interface Exp {
	Object eval(Environment<Object> env);
}
