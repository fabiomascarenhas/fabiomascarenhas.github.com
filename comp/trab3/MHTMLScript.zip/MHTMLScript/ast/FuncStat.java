package ast;

import java.util.List;

public class FuncStat extends Node implements Stat {
	public Id name;
	public List<Id> params;
	public Bloco body;
	
	public FuncStat(Id name, List<Id> params, Bloco body,
			int line, int col) {
		super(line, col);
		this.name = name;
		this.params = params;
		this.body = body;
	}

	@Override
	public void run(Environment<Object> env) {
		env.bind(name.name, null);
		env.update(name.name, new FuncVal(params, body, env));
	}

	@Override
	public String label() {
		return "function";
	}

}
