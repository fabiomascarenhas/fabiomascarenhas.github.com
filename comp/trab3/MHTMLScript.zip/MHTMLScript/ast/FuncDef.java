package ast;

import java.util.List;

public class FuncDef extends Node implements Exp {
	public List<Id> params;
	public Bloco body;
	
	public FuncDef(List<Id> params, Bloco body,
			int line, int col) {
		super(line, col);
		this.params = params;
		this.body = body;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return new FuncVal(params, body, env);
	}

	@Override
	public String label() {
		return "function";
	}

}
