package ast;

public class If extends Node implements Stat {
	public Exp cond;
	public Bloco bthen;
	public Bloco belse;

	public If(Exp cond, Bloco bthen, Bloco belse, int line, int col) {
		super(line, col);
		this.cond = cond;
		this.bthen = bthen;
		this.belse = belse;
	}

	@Override
	public void run(Environment<Object> env) {
		if((Boolean)cond.eval(env)) {
			bthen.run(env);
		} else {
			if(belse != null)
				belse.run(env);
		}
	}

	@Override
	public String label() {
		return "if";
	}

}
