package ast;

public interface Stat {
	void run(Environment<Object> env);
}
