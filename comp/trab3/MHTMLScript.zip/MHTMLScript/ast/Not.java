package ast;

public class Not extends Node implements Exp {
	public Exp exp;
	
	public Not(Exp exp, int line, int col) {
		super(line, col);
		this.exp = exp;
	}

	@Override
	public Object eval(Environment<Object> env) {
		// TODO especificação do not lógico
		return null;
	}

	@Override
	public String label() {
		return "not";
	}

}
