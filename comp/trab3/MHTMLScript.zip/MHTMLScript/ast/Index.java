package ast;

public class Index extends Node implements Lval {
	public Exp prefix;
	public Id field;
	
	public Index(Exp prefix, Id field, int line, int col) {
		super(line, col);
		this.prefix = prefix;
		this.field = field;
	}

	@Override
	public Object eval(Environment<Object> env) {
		// TODO especificação do que index faz
		return null;
	}

	@Override
	public void set(Environment<Object> env, Object rval) {
		// TODO especificação do que index faz como lval
	}

	@Override
	public String label() {
		return ".";
	}

}
