package ast;

public class Num extends Node implements Exp {
	public double val;
	
	public Num(String tok, int line, int col) {
		super(line, col);
		val = Double.parseDouble(tok);
	}

	public Object eval(Environment<Object> env) {
		return val;
	}

	public String label() {
		return "" + val;
	}

}
