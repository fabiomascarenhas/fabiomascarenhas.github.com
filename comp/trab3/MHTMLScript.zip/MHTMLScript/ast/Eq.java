package ast;

public class Eq extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Eq(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		return l.eval(env).equals(r.eval(env));
	}

	@Override
	public String label() {
		return "==";
	}

}
