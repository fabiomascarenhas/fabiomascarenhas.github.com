package ast;

public class True extends Node implements Exp {

	public True(int line, int col) {
		super(line, col);
	}

	@Override
	public Object eval(Environment<Object> env) {
		return true;
	}

	@Override
	public String label() {
		return "true";
	}

}
