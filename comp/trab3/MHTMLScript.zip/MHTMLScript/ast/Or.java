package ast;

public class Or extends Node implements Exp {
	public Exp l;
	public Exp r;
	
	public Or(Exp l, Exp r, int line, int col) {
		super(line, col);
		this.l = l;
		this.r = r;
	}

	@Override
	public Object eval(Environment<Object> env) {
		// TODO especificar comportamento do or
		return null;
	}

	@Override
	public String label() {
		return "or";
	}

}
