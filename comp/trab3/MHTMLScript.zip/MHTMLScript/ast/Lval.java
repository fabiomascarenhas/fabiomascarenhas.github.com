package ast;

public interface Lval extends Exp {
	void set(Environment<Object> env, Object rval);
}
