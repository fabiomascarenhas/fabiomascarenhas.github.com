package parse;

import java.util.Stack;

import parse.Grammar.Rule;

public class ShiftReduce {
	public Grammar g;
	public int pos;
	public String[] input;
	public Stack<Tree> stack;
	
	public ShiftReduce(Grammar g) {
		this.g = g;
	}

	public void setInput(String ... input) {
		this.input = input;
		this.pos = 0;
		this.stack = new Stack<Tree>();
	}
	
	public void shift() {
		stack.push(new Tree(input[pos++]));
	}
	
	public void reduce(int rule) {
		Rule r = g.rules.get(rule);
		Tree node = new Tree(r.head);
		for(int i = r.body.length - 1; i >= 0; i--) {
			Tree child = stack.pop();
			if(!child.term.equals(r.body[i]))
				throw new RuntimeException("erro de sintaxe");
			node.children.add(0, child);
		}
		stack.push(node);
	}
	
	public Tree accept() {
		if(pos == input.length && stack.size() == 1) {
			return stack.pop();
		} else
			throw new RuntimeException("erro de sintaxe");
	}
}
