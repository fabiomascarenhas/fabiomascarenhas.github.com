package mhtml;

import java.io.IOException;

public class ScriptParser {
	public Scanner input;
	public Token la;
	
	public ScriptParser(Scanner input) {
		this.input = input;
	}
	
	public Tree match(int token) {
		if(la.type == token) {
			String val = la.val;
			try {
				la = input.nextToken();
			} catch(IOException e) {
				throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
			}
			return new Tree(val);
		} else
			throw new RuntimeException("erro de sintaxe em " +
					la.line + ":" + la.col + ", esperado: "
					+ token + ", achado: " +
					la.type + "(" + la.val + ")");
	}
	
	public Tree parseScript(Token la) {
		this.la = la;
		Tree res = script();
		return res;
	}

	public Tree parseExp(Token la) {
		this.la = la;
		Tree res = exp();
		return res;
	}

	// SCRIPT -> BLOCO
	public Tree script() {
		Tree res = new Tree("SCRIPT");
		Tree bloco = bloco();
		res.child(bloco);
		return res;
	}
	
	// BLOCO -> {STAT} [RET]
	public Tree bloco() {
		Tree res = new Tree("BLOCO");
		// Conjunto FIRST(STAT)
		while(la.type == Token.DO || la.type == Token.IF ||
				la.type == Token.WHILE || la.type == '(' ||
				la.type == Token.ID || la.type == Token.LOCAL ||
				la.type == Token.FUNCTION) {
			res.child(stat());
		}
		if(la.type == Token.RETURN)
			res.child(ret());
		return res;
	}

	// STAT -> do BLOCO end
	// STAT -> while EXP do BLOCO end
	// STAT -> function id ( [IDS] ) BLOCO end
	// STAT -> if exp then BLOCO {elseif EXP then BLOCO} [else BLOCO] end
	// STAT -> local id [= EXP]
	// STAT -> LVAL = EXP
	// STAT -> PEXP ( [EXPS] )
	public Tree stat() {
		Tree res = new Tree("STAT");
		switch(la.type) {
		case Token.DO: // STAT -> id = exp
			res.child(match(Token.DO));
			res.child(bloco());
			res.child(match(Token.END));
			break;
		case Token.WHILE: // STAT -> while EXP do BLOCO end
			res.child(match(Token.WHILE));
			res.child(exp());
			res.child(match(Token.DO));
			res.child(bloco());
			res.child(match(Token.END));
			break;
		case Token.FUNCTION: // STAT -> function id ( [IDS] ) BLOCO end
			res.child(match(Token.FUNCTION));
			res.child(match(Token.ID));
			res.child(match('('));
			if(la.type == Token.ID)
				res.child(ids());
			res.child(match(')'));
			res.child(bloco());
			res.child(match(Token.END));
			break;
		// STAT -> if exp then BLOCO {elseif EXP then BLOCO} [else BLOCO] end
		case Token.IF:
			res.child(match(Token.IF));
			res.child(exp());
			res.child(match(Token.THEN));
			res.child(bloco());
			if(la.type == Token.ELSE) {
                            res.child(match(Token.ELSE));
                            res.child(bloco());
			}
			res.child(match(Token.END));
			break;
		case Token.LOCAL: // STAT -> local id [= exp]
			res.child(match(Token.LOCAL));
			res.child(match(Token.ID));
			if(la.type == '=') {
				res.child(match('='));
				res.child(exp());
			}
			break;
		case Token.ID:
		case '(':
			Tree pexp = pexp();
			if(pexp.children.size() > 1) {
				Tree second = pexp.children.get(1);
				if(second.term.equals(".")) {
					// LVAL -> PEXP . id
					Tree lval = new Tree("LVAL");
					lval.child(pexp.children.get(0));
					lval.child(pexp.children.get(1));
					lval.child(pexp.children.get(2));
					res.child(lval);
					res.child(match('='));
					res.child(exp());
				} else if(second.term.equals("(")) {
					// STAT -> PEXP ( [EXPS] )
					res.child(pexp.children.get(0));
					res.children.addAll(pexp.children);
				} else {
					throw new RuntimeException("comando inválido em " + la.line + ":" + la.col +
							", começando com: " + la.type + "(" + la.val + ")");	
				}
			} else {
				// LVAL -> id
				Tree lval = new Tree("LVAL");
				lval.child(pexp.children.get(0));
				res.child(lval);
			}
			break;
		default:
			throw new RuntimeException("comando inválido em " + la.line + ":" + la.col +
					", começando com: " + la.type + "(" + la.val + ")");	
		}
		return res;
	}

	// RET    -> return EXP
	public Tree ret() {
		Tree res = new Tree("RET");
		res.child(match(Token.RETURN));
		res.child(exp());
		return res;
	}
	
	// IDS    -> ID {, ID}
	public Tree ids() {
		Tree res = new Tree("IDS");
		res.child(match(Token.ID));
		while(la.type == ',') {
			res.child(match(','));
			res.child(match(Token.ID));
		}
		return res;
	}

	// EXPS    -> EXP {, EXP}
	public Tree exps() {
		Tree res = new Tree("EXPS");
		res.child(exp());
		while(la.type == ',') {
			res.child(match(','));
			res.child(exp());
		}
		return res;
	}

	// EXP   -> EXP or LEXP
	// EXP   -> LEXP
	public Tree exp() {
		Tree res = new Tree("EXP");
		res.child(lexp());
		while(la.type == Token.OR) {
			Tree expp = new Tree("EXP");
			expp.child(res);
			expp.child(match(Token.OR));
			expp.child(lexp());
			res = expp;
		}
		return res;
	}
	
	// LEXP   -> LEXP and REXP
	// LEXP   -> REXP
	public Tree lexp() {
		Tree res = new Tree("LEXP");
		res.child(rexp());
		while(la.type == Token.AND) {
			Tree lexpp = new Tree("LEXP");
			lexpp.child(res);
			lexpp.child(match(Token.AND));
			lexpp.child(rexp());
			res = lexpp;
		}
		return res;
	}

	// REXP   -> REXP < CEXP
	// REXP   -> REXP == CEXP
	// REXP   -> REXP ~= CEXP
	// REXP   -> CEXP
	public Tree rexp() {
		Tree res = new Tree("REXP");
		res.child(cexp());
		while(la.type == '<' || la.type == Token.EQ ||
				la.type == Token.NEQ) {
			Tree rexpp = new Tree("REXP");
			rexpp.child(res);
			if(la.type == '<') {
				rexpp.child(match('<'));
				rexpp.child(cexp());
			} else if(la.type == Token.EQ) {
				rexpp.child(match(Token.EQ));
				rexpp.child(cexp());
			} else {
				rexpp.child(match(Token.NEQ));
				rexpp.child(cexp());
			}
			res = rexpp;
		}
		return res;
	}

	//	SEXP   -> - SEXP
	//	SEXP   -> not SEXP
	//	SEXP   -> nil
	//	SEXP   -> false
	//	SEXP   -> true
	//	SEXP   -> num
	//	SEXP   -> string
	//	SEXP   -> { }
	//	SEXP   -> function ( [IDS] ) BLOCO end
	//	SEXP   -> PEXP
	public Tree sexp() {
		Tree res = new Tree("SEXP");
		switch(la.type) {
		case '-':
			//	SEXP   -> - SEXP
			res.child(match('-'));
			res.child(sexp());
			break;
		case Token.NOT:
			//	SEXP   -> not SEXP
			res.child(match(Token.NOT));
			res.child(sexp());
			break;
		case Token.NUM: case Token.NIL: case Token.STRING:
		case Token.FALSE: case Token.TRUE:
			//	SEXP   -> nil
			//	SEXP   -> false
			//	SEXP   -> true
			//	SEXP   -> num
			//	SEXP   -> string
			res.child(match(la.type));
			break;
		case '{':
			//	SEXP   -> { }
			res.child(match('{'));
			res.child(match('}'));
			break;
		case Token.FUNCTION:
			//	SEXP   -> function ( [IDS] ) BLOCO end
			res.child(match(Token.FUNCTION));
			res.child(match('('));
			if(la.type != ')')
				res.child(ids());
			res.child(match(')'));
			res.child(bloco());
			res.child(match(Token.END));
			break;
		default:
			//	SEXP   -> PEXP
			res.child(pexp());
		}
		return res;
	}
	
	// PEXP   -> PEXP ( [EXPS] )
	// PEXP   -> PEXP . id 
	// PEXP   -> ( EXP )
	// PEXP   -> id
	Tree pexp() {
		Tree res = new Tree("PEXP");
		if(la.type == Token.ID) {
			res.child(match(Token.ID));
		} else {
			res.child(match('('));
			res.child(exp());
			res.child(match(')'));
		}
		while(la.type == '.' || la.type == '(') {
			Tree pexpp = new Tree("PEXP");
			pexpp.child(res);
			if(la.type == '.') {
				pexpp.child(match('.'));
				pexpp.child(match(Token.ID));
			} else {
				pexpp.child(match('('));
				if(la.type != ')')
					pexpp.child(exps());
				pexpp.child(match(')'));
			}
			res = pexpp;
		}
		return res;
	}
	
}
