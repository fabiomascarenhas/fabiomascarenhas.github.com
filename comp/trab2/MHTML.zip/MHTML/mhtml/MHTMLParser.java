package mhtml;

import java.io.IOException;
import java.util.ArrayList;

public class MHTMLParser {
	public Scanner input;
	public Token la;
		
	public ScriptParser sp;
	
	public MHTMLParser(Scanner input) {
		this.input = input;
		try {
			la = input.nextToken();
		} catch (IOException e) {
			throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
		}
		sp = new ScriptParser(input);
	}
	
	
	public Tree match(int token) {
		if(la.type == token) {
			String val = la.val;
			try {
				la = input.nextToken();
			} catch(IOException e) {
				throw new RuntimeException("erro na leitura da entrada: " + e.getMessage());
			}
			return new Tree(val);
		} else
			throw new RuntimeException("erro de sintaxe em " +
					la.line + ":" + la.col + ", esperado: "
					+ token + ", achado: " +
					la.type + "(" + la.val + ")");
	}
	
	public Tree parse() {
		Tree res = mhtml();
		if(la.type != Token.EOF)
			throw new RuntimeException("entrada não foi toda analisada, parou em " +
					la.line + ":" + la.col + " (" + la.val + ")");
		return res;
	}

	// g.rules("MHTML", "ELEM");
	public Tree mhtml() {
		Tree res = new Tree("MHTML");
		res.child(elem());
		return res;
	}

	/*
	g.rules("ELEM", "ATAG CORPO FTAG");
	g.rules("ELEM", "<% SCRIPT %>");
	g.rules("ELEM", "<%= EXP %>");
	g.rules("ELEM", "AFTAG");
	*/
	public Tree elem() {
		Tree res = new Tree("ELEM");
		switch(la.type) {
		case Token.LP:
			// g.rules("ELEM", "<% SCRIPT %>");
			res.child(match(Token.LP));
			res.child(script());
			res.child(match(Token.PG));
			break;
		case Token.LPE:
			// g.rules("ELEM", "<%= EEXP %>");
			res.child(match(Token.LPE));
			res.child(exp());
			res.child(match(Token.PG));
			break;
		case '<':
			// g.rules("ELEM", "ATAG CORPO FTAG");
			// g.rules("ELEM", "AFTAG");
			// g.rules("ATAG", "< id {ATRIB} >");
			// g.rules("AFTAG", "< id {ATRIB} />");
			Tree less = match('<');
			Tree id = match(Token.ID);
			ArrayList<Tree> atribs = new ArrayList<Tree>();
			while(la.type == Token.ID) {
				atribs.add(atrib());
			}
			if(la.type == '>') {
				// g.rules("ELEM", "ATAG CORPO FTAG");
				Tree atag = new Tree("ATAG");
				atag.child(less);
				atag.child(id);
				for(Tree atrib: atribs)
					atag.child(atrib);
				atag.child(match('>'));
				res.child(atag);
				res.child(corpo());
				res.child(ftag());
			} else {
				// g.rules("ELEM", "AFTAG");
				Tree aftag = new Tree("AFTAG");
				aftag.child(less);
				aftag.child(id);
				for(Tree atrib: atribs)
					aftag.child(atrib);
				aftag.child(match(Token.SG));
				res.child(aftag);
			}
			break;
		default:
			throw new RuntimeException("elemento inválido em " + la.line + ":" + la.col +
					", começando com: " + la.type + "(" + la.val + ")");	
		}
		return res;
	}
	
	// g.rules("ATRIB", "id = string")
	public Tree atrib() {
		Tree res = new Tree("ATRIB");
		res.child(match(Token.ID));
		res.child(match('='));
		res.child(match(Token.STRING));
		return res;
	}
	
	// g.rules("CORPO", "{ELEM | word}");
	public Tree corpo() {
		Tree res = new Tree("CORPO");
		while(la.type == Token.LP || la.type == Token.LPE ||
				la.type == '<' || la.type == Token.WORD) {
			switch(la.type) {
			case Token.LP: case Token.LPE: case '<':
				res.child(elem());
				break;
			case Token.WORD:
				res.child(match(Token.WORD));
				break;
			}
		}
		return res;
	}

	// g.rules("FTAG", "</ id >");
	public Tree ftag() {
		Tree res = new Tree("FTAG");
		res.child(match(Token.LS));
		res.child(match(Token.ID));
		res.child(match('>'));
		return res;
	}
	
	public Tree exp() {
		Tree res = sp.parseExp(la);
		la = sp.la;
		return res;
	}

	public Tree script() {
		Tree res = sp.parseScript(la);
		la = sp.la;
		return res;
	}
}
