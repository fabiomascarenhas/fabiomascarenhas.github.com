
public class Div extends Node implements Exp {
	public Exp esq;
	public Exp dir;
	
	public Div(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}

	@Override
	public String checaTipo(TabSimb<String> tipos) {
		String tesq = esq.checaTipo(tipos);
		String tdir = dir.checaTipo(tipos);
		if(tesq.equals("int") && tdir.equals("int"))
			return "int";
		if(tesq.equals("real") && Tipo.subtipo(tdir, "real"))
			return "real";
		if(Tipo.subtipo(tesq, "real") && tdir.equals("real"))
			return "real";
		throw new RuntimeException("erro de tipo na linha " + 
			lin + ", tipos da divisão são " + tesq + " e " + tdir);
	}
}
