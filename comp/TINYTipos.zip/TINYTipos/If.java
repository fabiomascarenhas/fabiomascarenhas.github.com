import java.util.ArrayList;
import java.util.List;

public class If extends Node implements Cmd {
	public Exp cond;
	public Bloco cthen;
	public Bloco celse;
	
	public If(Exp cd, Bloco ct, Bloco ce, int _lin) {
		super(_lin);
		cond = cd;
		cthen = ct;
		celse = ce;
	}

	public If(Exp cd, Bloco ct, int _lin) {
		this(cd, ct, new Bloco(new ArrayList<Decl>(), _lin), _lin);
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		String tcond = cond.checaTipo(tipos);
		if(!tcond.equals("bool"))
			throw new RuntimeException("condição do if não é booleana mas " + 
					tcond + " na linha " + lin);
		cthen.checaTipo(tipos);
		celse.checaTipo(tipos);
	}
}
