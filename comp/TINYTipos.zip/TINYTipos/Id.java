
public class Id extends Node implements Exp {
	public String nome;
	
	public Id(Token tok) {
		super(tok.lin);
		nome = tok.lexeme;
	}

	@Override
	public String checaTipo(TabSimb<String> tipos) {
		return tipos.procurar(nome, lin);
	}
}
