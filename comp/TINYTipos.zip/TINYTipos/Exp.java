
public interface Exp {
	String checaTipo(TabSimb<String> tipos);
}
