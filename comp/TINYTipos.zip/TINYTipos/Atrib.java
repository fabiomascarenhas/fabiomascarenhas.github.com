
public class Atrib extends Node implements Cmd {
	public String lval;
	public Exp rval;
	
	public Atrib(Token lv, Exp rv) {
		super(lv.lin);
		lval = lv.lexeme;
		rval = rv;
	}

	@Override
	public void checaTipo(TabSimb<String> tipos) {
		String tlval = tipos.procurar(lval, lin);
		String trval = rval.checaTipo(tipos);
		if(!Tipo.subtipo(trval, tlval))
			throw new RuntimeException("atribuição inválida na linha " +
					lin + ", esperado " + tlval + " encontrado " + trval);
	}
}
