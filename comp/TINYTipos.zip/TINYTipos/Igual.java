
public class Igual extends Node implements Exp {
	public Exp esq;
	public Exp dir;
	
	public Igual(Exp e1, Exp e2, int _lin) {
		super(_lin);
		esq = e1;
		dir = e2;
	}
	
	@Override
	public String checaTipo(TabSimb<String> tipos) {
		String tesq = esq.checaTipo(tipos);
		String tdir = dir.checaTipo(tipos);
		if(Tipo.subtipo(tesq, "real") &&
		   Tipo.subtipo(tdir, "real"))
			return "bool";
		throw new RuntimeException("erro de tipo na linha " + 
				lin + ", tipos da comparação = são " + tesq + " e " + tdir);
	}
}
