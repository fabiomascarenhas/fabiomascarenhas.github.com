package simple;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;

public class Scanner {
	InputStream in;
	int lookAhead;
	
	public Scanner(InputStream in) throws IOException {
		this.in = in;
		lookAhead = in.read();
	}
	
	public Token nextToken() throws IOException {
		while(true) {
			if(lookAhead == -1)
				return new Token(Token.EOF);
			switch((char)lookAhead) {
			case ' ': case '\n':
				lookAhead = in.read();
				continue;
			case '(':
				lookAhead = in.read();
				return new Token(Token.LPAR);
			case ')':
				lookAhead = in.read();
				return new Token(Token.RPAR);
			case '+':
				lookAhead = in.read();
				return new Token(Token.PLUS);
			case '-':
				lookAhead = in.read();
				return new Token(Token.MINUS);
			case '*':
				lookAhead = in.read();
				return new Token(Token.TIMES);
			case '/':
				lookAhead = in.read();
				return new Token(Token.DIV);
			case '0': case '1': case '2': case '3':
			case '4': case '5': case '6': case '7':
			case '8': case '9':
				BigDecimal n = new BigDecimal(0);
				while((char)lookAhead >= '0' &&
						(char)lookAhead <= '9') {
					n = n.multiply(
							new BigDecimal(10)).add(
									new BigDecimal(
											(char)lookAhead - '0'));
					lookAhead = in.read();
				}
				return new Token(Token.NUM, n);
			default:
				throw new RuntimeException("caractere inv�lido " + (char)lookAhead);
			}
		}
	}
}
