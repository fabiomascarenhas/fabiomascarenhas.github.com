package simple;

import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;

public class ExpTimes implements Exp {
	public Exp left;
	public Exp right;
	
	public ExpTimes(Exp left, Exp right) {
		this.left = left;
		this.right = right;
	}

	@Override
	public BigDecimal value() {
		return left.value().multiply(right.value());
	}

	@Override
	public void compile(Writer out) throws IOException {
		// pilha = ....
		left.compile(out);
		// pilha = .... vleft
		right.compile(out);
		// pilha = .... vleft vright
		out.append("imul\n");
		// pilha = .... vsoma
	}
}