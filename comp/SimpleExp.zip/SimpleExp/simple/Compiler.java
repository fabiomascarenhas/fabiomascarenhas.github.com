package simple;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;

public class Compiler {
	public Parser p;
	
	public Compiler(InputStream in) throws IOException {
		p = new Parser(in);
	}
	
	public void compile() throws IOException {
		Writer out = new FileWriter("out.jasmin");
		try {
			out.append(".class public CalcOut\n");
			out.append(".super java/lang/Object\n");

			out.append(".method public static main([Ljava/lang/String;)V\n");
			out.append(".limit stack 100\n");
			out.append(".limit locals 1\n");
		  
			out.append("getstatic java/lang/System/out Ljava/io/PrintStream;\n");
			p.parseExp().compile(out);
			out.append("invokevirtual java/io/PrintStream/println(I)V\n");
			out.append("return\n");

			out.append(".end method\n");
		} finally {
			out.close();
		}
	}
}
