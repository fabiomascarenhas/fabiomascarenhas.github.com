package lex;

import java.util.List;

public interface Scanner {
	public void setInput(String input);
	public Token nextToken();
	public List<Token> allTokens();
}
