
# interface Funcao:
#              def valor(self, x)
#              self.formula

class Constante:
    def __init__(self, c):
        self.c = c
        self.formula = str(self.c)

    def valor(self, x):
        return self.c

class Potencia:
    def __init__(self, exp):
        self.exp = exp
        self.formula = "x^" + str(self.exp)

    def valor(self, x):
        return x ** self.exp

class Exp:
    def __init__(self, base):
        self.base = base
        self.formula = str(self.base) + "^x"

    def valor(self, x):
        return self.base ** x

class Escala:
    def __init__(self, fator, func):
        self.fator = fator
        self.func = func
        self.formula = str(fator) + func.formula

    def valor(self, x):
        return self.fator * self.func.valor(x)

class Derivada:
    dx = 0.000001

    def __init__(self, f):
        self.f = f
        self.formula = "Deriv[" + f.formula + "]"

    def valor(self, x):
        return (self.f.valor(x + Derivada.dx) -
                self.f.valor(x)) / Derivada.dx

class Soma:
    def __init__(self, fs):
        self.fs = fs
        formulas = []
        for f in self.fs:
            formulas.append(f.formula)
        self.formula = ("+").join(formulas)

    def valor(self, x):
        v = 0.0
        for f in self.fs:
            v = v + f.valor(x)
        return v
    
class Composta:
    def __init__(self, f, g):
        self.f = f
        self.g = g
        self.formula = "(" + f.formula + ")o(" + g.formula + ")"

    def valor(self, x):
        return self.f.valor(self.g.valor(x))
