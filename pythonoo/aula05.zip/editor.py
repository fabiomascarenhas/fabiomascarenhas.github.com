import gui

class AcaoVazia:
    def executar(self):
        print "CLICOU!"

class ObservadorVazio:
    def desenhar(self, canvas):
        canvas.retangulo(10, 10, 200, 75, (1, 0, 0))

    def inicio(self, x, y):
        print "APERTOU %d, %d" % (x, y)

    def meio(self, x, y):
        print "ARRASTOU %d, %d" % (x, y)

    def fim(self, x, y):
        print "SOLTOU %d, %d" % (x, y)

class Editor:
    def __init__(self):
        self.LARGURA = 800
        self.ALTURA = 600
        self.TITULO = "Editor"
        self.modelo = Modelo()
        self.componentes = [Botao(20, 20, 100, 50, "Mover",
                                  AcaoMover(self.modelo)),
                            Botao(20, 90, 100, 50, "Retangulo",
                                  AcaoRet(self.modelo)),
                            Botao(20, 160, 100, 50, "Apagar",
                                  AcaoApagar(self.modelo)),
                            Canvas(140, 0, self.LARGURA - 140, self.ALTURA,
                                   ObservadorCanvas(self.modelo))]
        self.selecionados = []
    
    def tique(self, dt, teclas):
        pass

    def tecla(self, t):
        pass

    def desenhar(self, tela):
        for c in self.componentes:
            c.desenhar(tela)        

    def arrastou(self, x, y):
        for c in self.selecionados:
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                c.arrastou(x, y)

    def apertou(self, x, y):
        for c in self.componentes:
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                self.selecionados.append(c)
                c.apertou(x, y)
        
    def soltou(self, x, y):
        for c in self.selecionados:
            c.soltou(x, y)
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                c.clicou(x, y)
        self.selecionados = []
    
class Botao:
    def __init__(self, x, y, larg, alt, texto, acao):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos botoes
        self.texto = texto
        self.cor_texto = (1, 1, 1)
        self.cor_fundo = (0, 0, 0)
        self.acao = acao

    def apertou(self, x, y):
        self.cor_texto = (0, 0, 0)
        self.cor_fundo = (1, 1, 1)

    def arrastou(self, x, y):
        pass

    def soltou(self, x, y):
        self.cor_texto = (1, 1, 1)
        self.cor_fundo = (0, 0, 0)

    def clicou(self, x, y):
        self.acao.executar()

    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, self.cor_fundo)
        larg, alt = gui.tamanho_texto(self.texto)
        tela.texto(self.x1 + 50 - larg/2, self.y1 + 25 - alt/2, self.texto, self.cor_texto)

class Canvas:
    def __init__(self, x, y, larg, alt, obs):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos canvas
        self.obs = obs

    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, (0, 0, 0))
        self.tela = tela
        self.obs.desenhar(self)

    def apertou(self, x, y):
        if (x > (self.x1 + 3) and y > (self.y1 + 3) and
            x < (self.x2 - 3) and y < (self.y2 - 3)):
            self.obs.inicio(x - self.x1 - 3, y - self.y1 - 3)

    def arrastou(self, x, y):
        if (x > (self.x1 + 3) and y > (self.y1 + 3) and
            x < (self.x2 - 3) and y < (self.y2 - 3)):
            self.obs.meio(x - self.x1 - 3, y - self.y1 - 3)

    def soltou(self, x, y):
        if (x > (self.x1 + 3) and y > (self.y1 + 3) and
            x < (self.x2 - 3) and y < (self.y2 - 3)):
            self.obs.fim(x - self.x1 - 3, y - self.y1 - 3)

    def clicou(self, x, y):
        pass

    def retangulo(self, x, y, larg, alt, cor):
        self.tela.retangulo(x + self.x1 + 3, y + self.y1 + 3, larg, alt, cor)

class Modelo:
    def __init__(self):
        self.figuras = []
        self.modo = ModoMover(self)
        self.cor = (1, 1, 1)

    def modo_mover(self):
        self.modo.encerrar()
        self.modo = ModoMover(self)

    def modo_ret(self):
        self.modo.encerrar()
        self.modo = ModoRet(self)

    def modo_apagar(self):
        self.modo.encerrar()
        self.modo = ModoApagar(self)

    def inicio(self, x, y):
        self.modo.inicio(x, y)

    def meio(self, x, y):
        self.modo.meio(x, y)

    def fim(self, x, y):
        self.modo.fim(x, y)

    def desenhar(self, canvas):
        for figura in self.figuras:
            figura.desenhar(canvas)
        self.modo.desenhar(canvas)

class AcaoMover:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def executar(self):
        self.modelo.modo_mover()

class AcaoRet:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def executar(self):
        self.modelo.modo_ret()

class AcaoApagar:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def executar(self):
        self.modelo.modo_apagar()

class ObservadorCanvas:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def desenhar(self, canvas):
        self.modelo.desenhar(canvas)

    def inicio(self, x, y):
        self.modelo.inicio(x, y)

    def meio(self, x, y):
        self.modelo.meio(x, y)

    def fim(self, x, y):
        self.modelo.fim(x, y)
    
class ModoMover:
    def __init__(self, modelo):
        self.modelo = modelo

    def desenhar(self, canvas):
        pass

    def encerrar(self):
        pass

    def inicio(self, x, y):
        pass

    def meio(self, x, y):
        pass

    def fim(self, x, y):
        pass
    
class ModoRet:
    def __init__(self, modelo):
        self.modelo = modelo

    def desenhar(self, canvas):
        pass

    def encerrar(self):
        pass

    def inicio(self, x, y):
        pass

    def meio(self, x, y):
        pass

    def fim(self, x, y):
        pass

class ModoApagar:
    def __init__(self, modelo):
        self.modelo = modelo

    def desenhar(self, canvas):
        pass

    def encerrar(self):
        pass

    def inicio(self, x, y):
        pass

    def meio(self, x, y):
        pass

    def fim(self, x, y):
        pass

editor = Editor()
gui.rodar(editor)
