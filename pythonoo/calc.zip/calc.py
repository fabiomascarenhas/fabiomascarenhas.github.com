import gui

# interface Componente:
#     x1, y1, x2, y2
#     def desenhar(self, tela)
#     def clicou(self, x, y)
#     def apertou(self, x, y)
#     def soltou(self, x, y)
#     def arrastou(self, x, y)

class AcaoVazia:
    def executar(self):
        print "CLICOU!"

class Calculadora:
    def __init__(self):
        self.LARGURA = 400
        self.ALTURA = 500
        self.TITULO = "Calculadora"
        self.modelo = ModeloCalc()
        # TODO: instanciar componentes
        self.componentes = []
        self.selecionados = []
    
    def tique(self, dt, teclas):
        pass

    def tecla(self, t):
        pass

    def desenhar(self, tela):
        for c in self.componentes:
            c.desenhar(tela)        

    def arrastou(self, x, y):
        for c in self.selecionados:
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                c.arrastou(x, y)

    def apertou(self, x, y):
        for c in self.componentes:
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                self.selecionados.append(c)
                c.apertou(x, y)
        
    def soltou(self, x, y):
        for c in self.selecionados:
            c.soltou(x, y)
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                c.clicou(x, y)
        self.selecionados = []
    
class Botao:
    def __init__(self, x, y, larg, alt, texto, acao):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos botoes
        self.texto = texto
        self.cor_texto = (1, 1, 1)
        self.cor_fundo = (0, 0, 0)
        self.acao = acao

    def apertou(self, x, y):
        self.cor_texto = (0, 0, 0)
        self.cor_fundo = (1, 1, 1)

    def arrastou(self, x, y):
        pass

    def soltou(self, x, y):
        self.cor_texto = (1, 1, 1)
        self.cor_fundo = (0, 0, 0)

    def clicou(self, x, y):
        self.acao.executar()

    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, self.cor_fundo)
        larg, alt = gui.tamanho_texto(self.texto)
        tela.texto(self.x1 + 50 - larg/2, self.y1 + 25 - alt/2, self.texto, self.cor_texto)

class ModeloCalc:
    def __init__(self):
        self.reset()

    def valor(self):
        return "%d" % self.display

    def digito(self, i):
        self.modo.digito(i)

    def soma(self):
        self.modo.soma()
    
    def sub(self):
        self.modo.sub()

    def mult(self):
        self.modo.mult()

    def div(self):
        self.modo.div()

    def igual(self):
        self.modo.igual()

    def reset(self):
        self.display = 0
        self.operando = 0
        self.modo = ModoNormal(self)
        self.ultima_op = self.modo
    
class ModoNormal:
    def __init__(self, modelo):
        self.modelo = modelo
        self.aumentando = False

    def faz(self, esq):
        return esq 
 
    def digito(self, i):
        if self.aumentando:
            self.modelo.display = self.modelo.display * 10 + i
        else:
            self.aumentando = True
            self.modelo.display = i

    def soma(self):
        self.modelo.operando = self.modelo.display
        self.modelo.modo = ModoOp(self.modelo, "+")

    def sub(self):
        self.modelo.operando = self.modelo.display
        self.modelo.modo = ModoOp(self.modelo, "-")

    def mult(self):
        self.modelo.operando = self.modelo.display
        self.modelo.modo = ModoOp(self.modelo, "*")

    def div(self):
        self.modelo.operando = self.modelo.display
        self.modelo.modo = ModoOp(self.modelo, "/")

    def igual(self):
        self.modelo.display = self.modelo.ultima_op.faz(self.modelo.display)
        self.aumentando = False

class ModoOp:
    def __init__(self, modelo, op):
        self.modelo = modelo
        self.op = op
        self.aumentando = False

    def faz(self, esq):
        if self.op == "+":
            return esq + self.dir
        elif self.op == "-":
            return esq - self.dir
        elif self.op == "*":
            return esq * self.dir
        elif self.op == "/":
            return esq / self.dir

    def faz_op(self, op):
        if self.aumentando:
            self.dir = self.modelo.display
            self.modelo.display = self.faz(self.modelo.operando)
            self.modelo.operando = self.modelo.display
            self.modelo.modo = ModoOp(self.modelo, op)
        else:
            self.modelo.modo = ModoOp(self.modelo, op)
            
    def digito(self, i):
        if self.aumentando:
            self.modelo.display = self.modelo.display * 10 + i
        else:
            self.aumentando = True
            self.modelo.display = i

    def soma(self):
        self.faz_op("+")

    def sub(self):
        self.faz_op("-")

    def mult(self):
        self.faz_op("*")

    def div(self):
        self.faz_op("/")

    def igual(self):
        if self.aumentando:
            self.dir = self.modelo.display
            self.modelo.ultima_op = self
            self.modelo.display = self.faz(self.modelo.operando)
            self.modelo.operando = self.modelo.display
            self.modelo.modo = ModoNormal(self.modelo)
        else:
            self.dir = self.modelo.display
            self.modelo.ultima_op = self
            self.modelo.display = self.faz(self.modelo.operando)
            self.modelo.modo = ModoNormal(self.modelo)
    
        
    
