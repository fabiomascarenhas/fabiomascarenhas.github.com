
# classe abstrata
class FiguraPt(object):
    def __init__(self, x, y, cor):
        self.x = x
        self.y = y
        self.cor = cor

    # metodo abstrato
    def dentro(self, x, y):
        raise NotImplementedError()

    def mover(self, dx, dy):
        self.x = self.x + dx
        self.y = self.y + dy

class Ponto(FiguraPt):
    def dentro(self, x, y):
        return abs(x - self.x) <= 2 and abs(y - self.y) <= 2

    def __str__(self):
        return "Ponto em (%f, %f) com cor %s" % (self.x, self.y, str(self.cor))

    def __repr__(self):
        return "Ponto(%s, %s, %s)" % (repr(self.x), repr(self.y), repr(self.cor))

    def __eq__(self, p):
        return self.x == p.x and self.y == p.y and self.cor == p.cor

    def __ne__(self, p):
        return not (self == p)

    def __hash__(self):
        return hash(self.x) + hash(self.y) + hash(self.cor)

    def __add__(self, p):
        return Ponto((self.x + p.x)/2.0, (self.y + p.y)/2.0,
                     ((self.cor[0] + p.cor[0])/2.0,
                      (self.cor[1] + p.cor[1])/2.0,
                      (self.cor[2] + p.cor[2])/2.0))

    def __call__(self, dx, dy):
        self.mover(dx, dy)
    
class Retangulo(FiguraPt):
    def __init__(self, x, y, larg, alt, cor):
        FiguraPt.__init__(self, x, y, cor)
        self.larg = larg
        self.alt = alt

    def dentro(self, x, y):
        return (x >= self.x and y >= self.y and x <= self.x + self.larg and
                y <= self.y + self.alt)

class Circulo(FiguraPt):
    def __init__(self, x, y, raio, cor):
        FiguraPt.__init__(self, x, y, cor)
        self.raio = raio

    def dentro(self, x, y):
        dx = x - self.x
        dy = y - self.y
        return (dx*dx + dy*dy) <= (self.raio*self.raio)        

