import Tkinter
import math
import numpy

def cor_tkinter(cor):
    return "#%02x%02x%02x" % (int(cor[0]*255),
                              int(cor[1]*255),
                              int(cor[2]*255))

class Janela(Tkinter.Tk):
    def __init__(self, titulo, larg, alt):
        Tkinter.Tk.__init__(self)
        self.title(titulo)
        x = (self.winfo_screenwidth()-larg)/2
        y = (self.winfo_screenheight()-alt)/2
        self.geometry("%dx%d+%d+%d" % (larg, alt, x, y))
        self.resizable(False, False)
        #self["bg"] = "#ffffff"
        self.componentes()

    def componentes(self):
        raise NotImplementedError()

class Botao(Tkinter.Button):
    def __init__(self, janela, x, y, larg, alt, texto, tamanho):
        Tkinter.Button.__init__(self, janela)
        self["text"] = texto
        self["font"] = "Arial %d" % tamanho
        self.place({ "x": x, "y": y, 
                     "width": larg, "height": alt })
        self["command"] = self.executar

    def executar(self):
        raise NotImplementedError()

class Canvas(Tkinter.Canvas):
    def __init__(self, janela, x, y, larg, alt):
        Tkinter.Canvas.__init__(self, janela)
        self["bg"] = "#ffffff"
        self.bind("<ButtonPress-1>", self.apertou)
        self.bind("<ButtonRelease-1>", self.soltou)
        self.bind("<B1-Motion>", self.arrastou)
        self.place({ "x": x, "y": y, "width": larg, "height": alt })

    def apertou(self, evt):
        pass

    def soltou(self, evt):
        pass

    def arrastou(self, evt):
        pass

    def limpar(self):
        self.delete(Tkinter.ALL)

    def retangulo(self, x, y, larg, alt, cor):
        self.create_rectangle(x, y, x+larg, y+alt, { "fill": cor_tkinter(cor),
                                                     "outline": cor_tkinter(cor) })

    def circulo(self, x, y, raio, cor):
        self.create_oval(x-raio, y-raio, x+raio, y+raio, { "fill": cor_tkinter(cor),
                                                               "outline": cor_tkinter(cor)})

    def triangulo(self, p1, p2, p3, cor):
        self.create_polygon([p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]],
                            { "fill": cor_tkinter(cor), "outline": cor_tkinter(cor) })

    def linha(self, p1, p2, cor):
        self.create_line(p1[0], p1[1], p2[0], p2[1],
                         { "fill": cor_tkinter(cor) })

class CanvasTartaruga(Canvas):
    def __init__(self, janela, x, y, larg, alt, tartaruga):
        Canvas.__init__(self, janela, x, y, larg, alt)
        self.tartaruga = tartaruga
        self.tartaruga.desenhar(self)

    def mudou(self, figuras):
        self.limpar()
        self.tartaruga.desenhar(self)

class CaixaTexto(Tkinter.Text):
    def __init__(self, janela, x, y, larg, alt, tamanho):
        Tkinter.Text.__init__(self, janela)
        self["font"] = "Arial %d" % tamanho
        self.place({ "x": x, "y": y, "width": larg, "height": alt })

    def texto(self):
        return self.get(1.0, Tkinter.END)

class BotaoExecutar(Botao):
    def __init__(self, janela, x, y, larg, alt, tartaruga, caixa):
        Botao.__init__(self, janela, x, y, larg, alt, "Executar", 16)
        self.tartaruga = tartaruga
        self.caixa = caixa

    def executar(self):
        texto = self.caixa.texto()
        for linha in texto.splitlines():
            espaco = linha.find(" ")
            if espaco != -1:
                comando = linha[:espaco].lower()
                arg = int(linha[espaco+1:])
                if comando == "frente":
                    self.tartaruga.frente(arg)
                elif comando == "tras":
                    self.tartaruga.tras(arg)
                elif comando == "esquerda":
                    self.tartaruga.esquerda(arg)
                elif comando == "direita":
                    self.tartaruga.direita(arg)
            elif linha == "levanta":
                self.tartaruga.levanta()
            elif linha == "abaixa":
                self.tartaruga.abaixa()

class BotaoLimpar(Botao):
    def __init__(self, janela, x, y, larg, alt, tartaruga):
        Botao.__init__(self, janela, x, y, larg, alt, "Limpar", 16)
        self.tartaruga = tartaruga

    def executar(self):
        self.tartaruga.reset()

class JanelaPrincipal(Janela):
    def componentes(self):
        self.tartaruga = Tartaruga()
        canvas = CanvasTartaruga(self, 0, 0, 600, 600, self.tartaruga)
        self.tartaruga.observar(canvas)
        caixa = CaixaTexto(self, 600, 0, 200, 500, 16)
        BotaoExecutar(self, 600, 500, 200, 50, self.tartaruga, caixa)        
        BotaoLimpar(self, 600, 550, 200, 50, self.tartaruga)        
    

####
#### MODELO
####

class Tartaruga:
    def __init__(self):
        self.obs = []
        self.reset()

    def reset(self):
        self.direcao = 0
        self.triangulo = numpy.array([[290, 290, 307, 300],
                                   [293, 307, 300, 300],
                                   [1, 1, 1, 1]])
        self.escreve = True
        self.pontos = []
        self.notificar()
        
    def ponto(self, i):
        return (self.triangulo[0,i], self.triangulo[1,i])

    def observar(self, o):
        self.obs.append(o)

    def notificar(self):
        for o in self.obs:
            o.mudou(self)

    def trans(self, dx, dy):
        T = numpy.array([[1, 0, dx], [0, 1, dy], [0, 0, 1]])
        self.triangulo = numpy.dot(T, self.triangulo)        

    def frente(self, dist):
        if self.escreve: self.pontos.append(self.ponto(3))
        dx = dist * math.cos(self.direcao)
        dy = dist * math.sin(self.direcao)
        self.trans(dx, dy)
        if self.escreve: self.pontos.append(self.ponto(3))
        self.notificar()

    def tras(self, dist):
        if self.escreve: self.pontos.append(self.ponto(3))
        dx = dist * math.cos(self.direcao)
        dy = dist * math.sin(self.direcao)
        self.trans(-dx, -dy)
        if self.escreve: self.pontos.append(self.ponto(3))
        self.notificar()

    def rot(self, dang):
        x, y = self.ponto(3)
        T2 = numpy.array([[1, 0, x],
                          [0, 1, y],
                          [0, 0, 1]])
        R = numpy.array([[math.cos(dang), math.sin(dang), 0],
                         [-math.sin(dang), math.cos(dang), 0],
                         [0, 0, 1]])
        T1 = numpy.array([[1, 0, -x],
                          [0, 1, -y],
                          [0, 0, 1]])
        T = numpy.dot(T2, numpy.dot(R, T1))
        self.triangulo = numpy.dot(T, self.triangulo)

    def esquerda(self, ang):
        self.direcao = self.direcao - ang * math.pi/180
        self.rot(ang * math.pi/180)
        self.notificar()

    def direita(self, ang):
        self.direcao = self.direcao + ang * math.pi/180
        self.rot(-ang * math.pi/180)
        self.notificar()

    def levanta(self):
        self.escreve = False

    def abaixa(self):
        self.escreve = True

    def desenhar(self, canvas):
        for i in range(0, len(self.pontos)-1, 2):
            canvas.linha(self.pontos[i], self.pontos[i+1], (0, 0, 0))
        canvas.triangulo(self.ponto(0), self.ponto(1), self.ponto(2), (0, 0, 0))

#### Rodando
        
raiz = JanelaPrincipal("Tartaruga", 800, 600)
raiz.mainloop()
