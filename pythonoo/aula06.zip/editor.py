import gui

# interface Componente:
#     x1, y1, x2, y2
#     def desenhar(self, tela)
#     def clicou(self, x, y)
#     def apertou(self, x, y)
#     def soltou(self, x, y)
#     def arrastou(self, x, y)

class AcaoVazia:
    def executar(self):
        print "CLICOU!"

class ObservadorVazio:
    def desenhar(self, canvas):
        canvas.retangulo(10, 10, 200, 75, (1, 0, 0))

    def inicio(self, x, y):
        print "APERTOU %d, %d" % (x, y)

    def meio(self, x, y):
        print "ARRASTOU %d, %d" % (x, y)

    def fim(self, x, y):
        print "SOLTOU %d, %d" % (x, y)

class ObservadorSlider:
    def __init__(self, modelo, i):
        self.modelo = modelo
        self.i = i

    def valor(self, valor):
        if self.i == 0:
            self.modelo.cor = (valor, self.modelo.cor[1], self.modelo.cor[2])
        if self.i == 1:
            self.modelo.cor = (self.modelo.cor[0], valor, self.modelo.cor[2])
        if self.i == 2:
            self.modelo.cor = (self.modelo.cor[0], self.modelo.cor[1], valor)
        
class CorPaleta:
    def __init__(self, modelo):
        self.modelo = modelo

    def cor(self):
        return self.modelo.cor

class Editor:
    def __init__(self):
        self.LARGURA = 800
        self.ALTURA = 600
        self.TITULO = "Editor"
        self.modelo = Modelo()
        self.componentes = [Botao(20, 20, 100, 50, "Mover",
                                  AcaoMover(self.modelo)),
                            Botao(20, 90, 100, 50, "Retangulo",
                                  AcaoRet(self.modelo)),
                            Botao(20, 160, 100, 50, "Apagar",
                                  AcaoApagar(self.modelo)),
                            Canvas(140, 0, self.LARGURA - 240, self.ALTURA,
                                   ObservadorCanvas(self.modelo)),
                            Slider(self.LARGURA - 70, 50, 40, 100, 20, 1.0, (1, 0, 0),
                                   ObservadorSlider(self.modelo, 0)),
                            Slider(self.LARGURA - 70, 200, 40, 100, 20, 1.0, (0, 1, 0),
                                   ObservadorSlider(self.modelo, 1)),
                            Slider(self.LARGURA - 70, 350, 40, 100, 20, 1.0, (0, 0, 1),
                                   ObservadorSlider(self.modelo, 2)),
                            Paleta(self.LARGURA - 85, 500, 70, 70, CorPaleta(self.modelo)),
                            Botao(20, 300, 100, 50, "Desfazer",
                                  AcaoVazia()),
                            Botao(20, 370, 100, 50, "Refazer",
                                  AcaoVazia())]
        self.selecionados = []
    
    def tique(self, dt, teclas):
        pass

    def tecla(self, t):
        pass

    def desenhar(self, tela):
        for c in self.componentes:
            c.desenhar(tela)        

    def arrastou(self, x, y):
        for c in self.selecionados:
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                c.arrastou(x, y)

    def apertou(self, x, y):
        for c in self.componentes:
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                self.selecionados.append(c)
                c.apertou(x, y)
        
    def soltou(self, x, y):
        for c in self.selecionados:
            c.soltou(x, y)
            if x >= c.x1 and x <= c.x2 and y >= c.y1 and y <= c.y2:
                c.clicou(x, y)
        self.selecionados = []
    
class Botao:
    def __init__(self, x, y, larg, alt, texto, acao):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos botoes
        self.texto = texto
        self.cor_texto = (1, 1, 1)
        self.cor_fundo = (0, 0, 0)
        self.acao = acao

    def apertou(self, x, y):
        self.cor_texto = (0, 0, 0)
        self.cor_fundo = (1, 1, 1)

    def arrastou(self, x, y):
        pass

    def soltou(self, x, y):
        self.cor_texto = (1, 1, 1)
        self.cor_fundo = (0, 0, 0)

    def clicou(self, x, y):
        self.acao.executar()

    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, self.cor_fundo)
        larg, alt = gui.tamanho_texto(self.texto)
        tela.texto(self.x1 + 50 - larg/2, self.y1 + 25 - alt/2, self.texto, self.cor_texto)

class Slider:
    def __init__(self, x, y, larg, alt, alt_int, valor, cor, obs):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos sliders
        self.cor = cor
        self.obs = obs
        self.valor = valor
        self.alt_int = alt_int
        self.arrastando = False

    def pos_de_valor(self):
        # valor == 0.0: self.y2 - 3 - 10
        # valor == 1.0: self.y1 + 3
        return self.y1 + 3 + (1.0 - self.valor) * (self.y2 - self.y1 - 6 - self.alt_int)

    def valor_de_pos(self, pos):
        return 1.0 - (pos - self.y1 - 3) / (self.y2 - self.y1 - 6 - self.alt_int)

    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, (0, 0, 0))
        tela.retangulo(self.x1 + 3, self.pos_de_valor(),
                       self.x2 - self.x1 - 6,
                       self.alt_int, self.cor)

    def clicou(self, x, y):
        pass

    def apertou(self, x, y):
        if (x >= self.x1 + 3 and y >= self.pos_de_valor() and
            x <= self.x2 - 3 and y <= self.pos_de_valor() + self.alt_int):
           self.y_arrasto = y
           self.arrastando = True

    def soltou(self, x, y):
        self.arrastando = False

    def arrastou(self, x, y):
        if self.arrastando:
            nova_pos = self.pos_de_valor() + (y - self.y_arrasto)
            if nova_pos < self.y1 + 3:
                nova_pos = self.y1 + 3
            if nova_pos > self.y2 - 3 - self.alt_int:
                nova_pos = self.y2 - 3 - self.alt_int
            self.valor = self.valor_de_pos(nova_pos)
            self.obs.valor(self.valor)
            self.y_arrasto = y

class Paleta:
    def __init__(self, x, y, alt, larg, cor):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos sliders
        self.cor = cor
        
    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, self.cor.cor())

    def clicou(self, x, y):
        pass

    def arrastou(self, x, y):
        pass

    def soltou(self, x, y):
        pass

    def apertou(self, x, y):
        pass

class Canvas:
    def __init__(self, x, y, larg, alt, obs):
        # campos comuns a todos os componentes
        self.x1 = x
        self.y1 = y
        self.x2 = x + larg
        self.y2 = y + alt
        # campos dos canvas
        self.obs = obs

    def desenhar(self, tela):
        tela.retangulo(self.x1, self.y1, self.x2 - self.x1,
                       self.y2 - self.y1, (1, 1, 1))
        tela.retangulo(self.x1 + 3, self.y1 + 3,
                       self.x2 - self.x1 - 6,
                       self.y2 - self.y1 - 6, (0, 0, 0))
        self.tela = tela
        self.obs.desenhar(self)

    def apertou(self, x, y):
        if (x > (self.x1 + 3) and y > (self.y1 + 3) and
            x < (self.x2 - 3) and y < (self.y2 - 3)):
            self.obs.inicio(x - self.x1 - 3, y - self.y1 - 3)

    def arrastou(self, x, y):
        if (x > (self.x1 + 3) and y > (self.y1 + 3) and
            x < (self.x2 - 3) and y < (self.y2 - 3)):
            self.obs.meio(x - self.x1 - 3, y - self.y1 - 3)

    def soltou(self, x, y):
        if (x > (self.x1 + 3) and y > (self.y1 + 3) and
            x < (self.x2 - 3) and y < (self.y2 - 3)):
            self.obs.fim(x - self.x1 - 3, y - self.y1 - 3)

    def clicou(self, x, y):
        pass

    def retangulo(self, x, y, larg, alt, cor):
        self.tela.retangulo(x + self.x1 + 3, y + self.y1 + 3, larg, alt, cor)

class Modelo:
    def __init__(self):
        self.figuras = []
        self.modo = ModoMover(self)
        self.cor = (1, 1, 1)

    def modo_mover(self):
        self.modo.encerrar()
        self.modo = ModoMover(self)

    def modo_ret(self):
        self.modo.encerrar()
        self.modo = ModoRet(self)

    def modo_apagar(self):
        self.modo.encerrar()
        self.modo = ModoApagar(self)

    def inicio(self, x, y):
        self.modo.inicio(x, y)

    def meio(self, x, y):
        self.modo.meio(x, y)

    def fim(self, x, y):
        self.modo.fim(x, y)

    def desenhar(self, canvas):
        for figura in self.figuras:
            figura.desenhar(canvas)
        self.modo.desenhar(canvas)

class AcaoMover:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def executar(self):
        self.modelo.modo_mover()

class AcaoRet:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def executar(self):
        self.modelo.modo_ret()

class AcaoApagar:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def executar(self):
        self.modelo.modo_apagar()

class ObservadorCanvas:
    def __init__(self, modelo):
        self.modelo = modelo
        
    def desenhar(self, canvas):
        self.modelo.desenhar(canvas)

    def inicio(self, x, y):
        self.modelo.inicio(x, y)

    def meio(self, x, y):
        self.modelo.meio(x, y)

    def fim(self, x, y):
        self.modelo.fim(x, y)
    
class ModoMover:
    def __init__(self, modelo):
        self.modelo = modelo
        self.movendo = False

    def desenhar(self, canvas):
        pass

    def encerrar(self):
        pass

    def inicio(self, x, y):
        for figura in self.modelo.figuras:
            if figura.dentro(x, y):
                self.movendo = True
                self.figura = figura
                self.x = x
                self.y = y

    def meio(self, x, y):
        if self.movendo:
            dx = x - self.x
            dy = y - self.y
            self.x = x
            self.y = y
            self.figura.mover(dx, dy)

    def fim(self, x, y):
        if self.movendo:
            dx = x - self.x
            dy = y - self.y
            x = self.x
            y = self.y
            self.figura.mover(dx, dy)
    
class ModoRet:
    def __init__(self, modelo):
        self.modelo = modelo
        self.desenhando = False

    def desenhar(self, canvas):
        if self.desenhando:
            canvas.retangulo(min(self.x1, self.x2),
                             min(self.y1, self.y2),
                             abs(self.x2 - self.x1),
                             abs(self.y2 - self.y1),
                             self.modelo.cor)

    def encerrar(self):
        pass

    def inicio(self, x, y):
        self.desenhando = True
        self.x1 = x
        self.y1 = y
        self.x2 = x
        self.y2 = y

    def meio(self, x, y):
        self.x2 = x
        self.y2 = y

    def fim(self, x, y):
        self.x2 = x
        self.y2 = y
        self.modelo.figuras.append(Retangulo(min(self.x1, self.x2),
                                             min(self.y1, self.y2),
                                             abs(self.x2 - self.x1),
                                             abs(self.y2 - self.y1),
                                             self.modelo.cor))

class ModoApagar:
    def __init__(self, modelo):
        self.modelo = modelo
        self.apagando = False

    def desenhar(self, canvas):
        pass

    def encerrar(self):
        pass

    def inicio(self, x, y):
        for figura in self.modelo.figuras:
            if figura.dentro(x, y):
                self.apagando = True
                self.figura = figura

    def meio(self, x, y):
        pass

    def fim(self, x, y):
        if self.apagando and self.figura.dentro(x, y):
            self.modelo.figuras.remove(self.figura)

class Retangulo:
    def __init__(self, x, y, larg, alt, cor):
        self.x = x
        self.y = y
        self.larg = larg
        self.alt = alt
        self.cor = cor

    def desenhar(self, canvas):
        canvas.retangulo(self.x, self.y, self.larg, self.alt, self.cor)

    def dentro(self, x, y):
        return (x >= self.x and y >= self.y and x <= self.x + self.larg and
                y <= self.y + self.alt)

    def mover(self, dx, dy):
        self.x = self.x + dx
        self.y = self.y + dy

editor = Editor()
gui.rodar(editor)
