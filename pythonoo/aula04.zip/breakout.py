import random
import motor

def cor_aleat():
    return (random.random(), random.random(), random.random())

class Bola:
    def __init__(self, x, y, vx, vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.raio = 5
        self.cor = (1, 1, 1) # branco
        self.hb = Hitbox(x - 4, y - 4, 8, 8)

    def desenhar(self, tela):
        tela.elipse(self.x - self.raio, self.y - self.raio,
                    self.raio * 2, self.raio * 2, self.cor)
        
    def para_cima(self):
        self.vy = -abs(self.vy)

    def para_baixo(self):
        self.vy = abs(self.vy)

    def para_esquerda(self):
        self.vx = -abs(self.vx)

    def para_direita(self):
        self.vx = abs(self.vx)

    def mover(self, dt):
        dx = self.vx * dt
        dy = self.vy * dt
        self.hb.mover(dx, dy)
        self.x = self.x + dx 
        self.y = self.y + dy 

class Raquete:
    larg = 100
    alt = 20
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.cor = (1, 1, 1)
        self.hb_e = Hitbox(x, y, 30, Raquete.alt)
        self.hb_c = Hitbox(x + 30, y, 40, Raquete.alt)
        self.hb_d = Hitbox(x + 70, y, 30, Raquete.alt)

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, Raquete.larg, Raquete.alt, self.cor)

    def mover(self, dx):
        self.hb_e.mover(dx, 0)
        self.hb_c.mover(dx, 0)
        self.hb_d.mover(dx, 0)
        self.x = self.x + dx

    def esquerda(self, dt):
        dx = -300 * dt
        self.mover(dx)

    def direita(self, dt):
        dx = 300 * dt
        self.mover(dx)

class TijoloSimples:
    larg = 50
    alt = 20

    def __init__(self, x, y, cor):
        self.x = x
        self.y = y
        self.cor = cor
        self.hb = Hitbox(x, y, TijoloSimples.larg, TijoloSimples.alt)
        self.pontos = 10

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, TijoloSimples.larg, TijoloSimples.alt, self.cor)

    def colisao(self, bola):
        onde = self.hb.intersecao(bola.hb)
        if onde == "acima":
            bola.para_cima()
        if onde == "abaixo":
            bola.para_baixo()
        if onde == "esquerda":
            bola.para_esquerda()
        if onde == "direita":
            bola.para_direita()
        return onde != ""

class TijoloHits:
    larg = 50
    alt = 20

    def __init__(self, x, y, hits):
        self.x = x
        self.y = y
        self.cor = (1.0, 1.0, 1.0)
        self.hits = hits
        self.hits_orig = hits
        self.hb = Hitbox(x, y, TijoloHits.larg, TijoloHits.alt)
        self.pontos = hits * 10

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, TijoloHits.larg, TijoloHits.alt, self.cor)

    def colisao(self, bola):
        onde = self.hb.intersecao(bola.hb)
        if onde == "acima":
            bola.para_cima()
        if onde == "abaixo":
            bola.para_baixo()
        if onde == "esquerda":
            bola.para_esquerda()
        if onde == "direita":
            bola.para_direita()
        if onde:
            self.hits = self.hits - 1
            cor = self.hits * 1.0 / self.hits_orig
            self.cor = (cor, cor, cor)
            return self.hits == 0

class TijoloPartes:
    larg = 50
    alt = 20

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.cor = (1, 0, 0)
        self.partes = [ Hitbox(x, y, 15, TijoloPartes.alt),
                        Hitbox(x + 15, y, 20, TijoloPartes.alt),
                        Hitbox(x + 35, y, 15, TijoloPartes.alt) ]
        self.pontos = 30

    def desenhar(self, tela):
        if self.partes[0]:
            tela.retangulo(self.x, self.y, 15, TijoloSimples.alt, self.cor)
        if self.partes[1]:
            tela.retangulo(self.x + 15, self.y, 20, TijoloSimples.alt, self.cor)
        if self.partes[2]:
            tela.retangulo(self.x + 35, self.y, 15, TijoloSimples.alt, self.cor)

    def colisao(self, bola):
        for i in range(3):
            if self.partes[i]:
                onde = self.partes[i].intersecao(bola.hb)
                if onde == "acima":
                    bola.para_cima()
                if onde == "abaixo":
                    bola.para_baixo()
                if onde == "esquerda":
                    bola.para_esquerda()
                if onde == "direita":
                    bola.para_direita()
                if onde:
                    self.partes[i] = None
        return not (self.partes[0] or self.partes[1] or self.partes[2])

class Segmento:
    def __init__(self, valor):
        self.valor = valor

    def zerado(self):
        return self.valor == 0

    def tique(self):
        self.valor = (self.valor - 1) % 60
        return self.valor == 59

    def texto(self):
        return "%02d" % (self.valor)

class Timer:
    def __init__(self, x, y, minutos, segundos):
        self.x = x
        self.y = y
        self.segundos = Segmento(segundos)
        self.minutos = Segmento(minutos)
        self.tempo = 0.0

    def tique(self, dt):
        self.tempo = self.tempo + dt
        if self.tempo >= 1.0:
            self.tempo = self.tempo - 1.0
            if self.segundos.tique():
                self.minutos.tique()
        return self.minutos.zerado() and self.segundos.zerado()

    def desenhar(self, tela):
        tela.texto(self.x, self.y,
                   "%s:%s" % (self.minutos.texto(), self.segundos.texto()))

class Breakout:
    def __init__(self):
        self.TITULO = "Breakout"
        self.LARGURA = 800
        self.ALTURA = 600
        self.fases = [PrimeiraFase(self), SegundaFase(self), TerceiraFase(self)]
        self.fase = 0

    def proxima_fase(self):
        self.fase = (self.fase + 1) % len(self.fases)
        self.fases[self.fase].reset()

    def tique(self, dt, teclas):
        self.fases[self.fase].tique(dt, teclas)

    def desenhar(self, tela):
        self.fases[self.fase].desenhar(tela)

    def tecla(self, tecla):
        self.fases[self.fase].tecla(tecla)

class PrimeiraFase:
    def __init__(self, jogo):
        self.jogo = jogo
        self.larg_parede = 50
        self.hb_par_e = Hitbox(0, 50, self.larg_parede, jogo.ALTURA - 50)
        self.hb_par_c = Hitbox(0, 50, jogo.LARGURA, self.larg_parede)
        self.hb_par_d = Hitbox(jogo.LARGURA - self.larg_parede, 50,
                               self.larg_parede, jogo.ALTURA - 50)
        self.hb_chao = Hitbox(self.larg_parede, jogo.ALTURA,
                              jogo.LARGURA - self.larg_parede * 2,
                              50)
        self.reset()

    def reset(self):
        self.score = 0
        self.pausa = False
        self.game_over = False
        self.bola = Bola(self.jogo.LARGURA/2, self.jogo.ALTURA/2, -200, 100)
        self.raquete = Raquete((self.jogo.LARGURA - Raquete.larg)/2,
                               self.jogo.ALTURA - Raquete.alt)
        self.tijolos = []
        self.timer = Timer(50, 10, 0, 15)
        for i in range(0, 14):
            for j in range(0, 5):
                t = TijoloSimples(i * TijoloSimples.larg + 50, j * TijoloSimples.alt + 150, cor_aleat())
                self.tijolos.append(t)
            if i % 2 == 0:
                t = TijoloHits(i * TijoloHits.larg + 50, 5 * TijoloHits.alt + 150, 4)
            else:
                t = TijoloPartes(i * TijoloPartes.larg + 50, 5 * TijoloPartes.alt + 150)
            self.tijolos.append(t)

    def desenhar(self, tela):
        self.desenhar_paredes(tela)
        self.desenhar_score(tela)
        self.bola.desenhar(tela)
        self.raquete.desenhar(tela)
        self.timer.desenhar(tela)
        for tijolo in self.tijolos:
            tijolo.desenhar(tela)
        if self.game_over:
            l, a = motor.tamanho_texto("GAME OVER")
            tela.texto((self.jogo.LARGURA - l)/2, (self.jogo.ALTURA - a)/2,
                        "GAME OVER", (1, 1, 1))

    def desenhar_paredes(self, tela):
        tela.retangulo(0, 50, self.larg_parede, self.jogo.ALTURA - 50)
        tela.retangulo(0, 50, self.jogo.LARGURA, self.larg_parede)
        tela.retangulo(self.jogo.LARGURA - self.larg_parede, 50,
                       self.larg_parede, self.jogo.ALTURA - 50)

    def desenhar_score(self, tela):
        l, a = motor.tamanho_texto(str(self.score))
        tela.texto(self.jogo.LARGURA - 50 - l, 10, str(self.score))

    def tique(self, dt, teclas):
        if self.pausa or self.game_over: return
        if ("left" in teclas and "right" not in teclas and
                self.raquete.x > self.larg_parede):
            self.raquete.esquerda(dt)
        if ("right" in teclas and "left" not in teclas and
                self.raquete.x + Raquete.larg < self.jogo.LARGURA - self.larg_parede):
            self.raquete.direita(dt)
        self.bola.mover(dt)
        self.colisao_paredes()
        if self.hb_chao.intersecao(self.bola.hb):
            self.game_over = True
        self.colisao_raquete()
        self.colisao_tijolos()
        if self.timer.tique(dt):
            self.jogo.proxima_fase()

    def colisao_paredes(self):
        if self.hb_par_e.intersecao(self.bola.hb):
            self.bola.para_direita()
        if self.hb_par_c.intersecao(self.bola.hb):
            self.bola.para_baixo()
        if self.hb_par_d.intersecao(self.bola.hb):
            self.bola.para_esquerda()

    def colisao_raquete(self):
        if self.raquete.hb_e.intersecao(self.bola.hb):
            self.bola.para_esquerda()
            self.bola.para_cima()
        if self.raquete.hb_c.intersecao(self.bola.hb):
            self.bola.para_cima()
        if self.raquete.hb_d.intersecao(self.bola.hb):
            self.bola.para_direita()
            self.bola.para_cima()

    def colisao_tijolos(self):
        remover = []
        for tijolo in self.tijolos:
            if tijolo.colisao(self.bola):
                self.score = self.score + tijolo.pontos
                remover.append(tijolo)
        for tijolo in remover:
            self.tijolos.remove(tijolo)

    def tecla(self, tecla):
        if tecla == "space":
            self.pausa = not self.pausa
        if tecla == "escape":
            self.reset()

class SegundaFase:
    def __init__(self, jogo):
        self.jogo = jogo

    def reset(self):
        self.x_texto = 50
        self.v_texto = 300
        self.texto = "Ola Mundo"
    
    def tique(self, dt, teclas):
        larg, alt = motor.tamanho_texto(self.texto)
        if self.x_texto < 0:
            self.v_texto = abs(self.v_texto)
        if self.x_texto + larg > self.jogo.LARGURA:
            self.v_texto = -abs(self.v_texto)
        self.x_texto = self.x_texto + self.v_texto * dt

    def tecla(self, t):
        if t == "space":
            self.jogo.proxima_fase()
        else:
            self.texto = t

    def desenhar(self, tela):
        tela.linha(10, 10, 300, 10, 3, (1.0, 0.0, 0.0))
        tela.retangulo(50, 50, 100, 200, (0.0, 1.0, 0.0))
        tela.elipse(0, 300, 50, 50, (0.0, 0.0, 1.0))
        tela.triangulo(400, 200, 300, 250, 500, 250, (1.0, 1.0, 0.0))
        tela.texto(self.x_texto, 500, self.texto, (0.0, 0.0, 1.0))

class Carro:
    def __init__(self, x, y, larg, vx):
        self.x = x
        self.y = y 
        self.vx = vx
        self.larg = larg
        self.alt = 50
        self.cor = (random.random(), random.random(),
                    random.random())

    def mover(self, dt):
        self.x = self.x + self.vx * dt
        if self.x >= 800:
            self.x = -self.larg

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, self.larg,
                       self.alt, self.cor)

class TerceiraFase:
    def __init__(self, jogo):
        self.jogo = jogo

    def reset(self):
        self.carro = Carro(200, 200, 50, 100)
        
    def tique(self, dt, teclas):
        self.carro.mover(dt)

    def desenhar(self, tela):
        self.carro.desenhar(tela)

    def tecla(self, tecla):
        if tecla == "space":
            self.jogo.proxima_fase()

class Hitbox:
    def __init__(self, x, y, larg, alt):
        self.x0 = x
        self.y0 = y
        self.x1 = x + larg
        self.y1 = y + alt

    def mover(self, dx, dy):
        self.x0 = self.x0 + dx
        self.x1 = self.x1 + dx
        self.y0 = self.y0 + dy
        self.y1 = self.y1 + dy

    def intersecao(self, hb):
        w = ((self.x1 - self.x0) + (hb.x1 - hb.x0)) / 2.0
        h = ((self.y1 - self.y0) + (hb.y1 - hb.y0)) / 2.0
        dx = ((self.x1 + self.x0) - (hb.x1 + hb.x0)) / 2.0
        dy = ((self.y1 + self.y0) - (hb.y1 + hb.y0)) / 2.0
        if abs(dx) <= w and abs(dy) <= h:
            wy = w * dy
            hx = h * dx
            if wy > hx:
                if wy > -hx:
                    return "acima"
                else:
                    return "direita"
            else:
                if wy > -hx:
                    return "esquerda"
                else:
                    return "abaixo"
        else:
            return ""
        
jogo = Breakout()
motor.rodar(jogo)

