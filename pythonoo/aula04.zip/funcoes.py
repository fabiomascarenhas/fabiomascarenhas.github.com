
# interface Funcao:
#              def valor(self, x)
#              self.formula

class Constante:
    def __init__(self, c):
        self.c = c
        self.formula = str(self.c)

    def valor(self, x):
        return self.c

class Potencia:
    def __init__(self, n):
        self.n = n
        self.formula = "x^" + str(self.n)

    def valor(self, x):
        return x ** self.n

class Exp:
    def __init__(self, n):
        self.n = n
        self.formula = str(self.n) + "^x"

    def valor(self, x):
        return self.n ** x

class Escala:
    def __init__(self, c, f):
        self.c = c
        self.f = f
        self.formula = str(self.c) + self.f.formula

    def valor(self, x):
        return self.c * self.f.valor(x)

class Soma:
    def __init__(self, fs):
        self.fs = fs
        formulas = []
        for f in self.fs:
            formulas.append(f.formula)
        self.formula = ("+").join(formulas)

    def valor(self, x):
        v = 0.0
        for f in self.fs:
            v = v + f.valor(x)
        return v
    
