import Tkinter

class Janela(Tkinter.Tk):
    def __init__(self, titulo, larg, alt):
        Tkinter.Tk.__init__(self)
        self.title(titulo)
        x = (self.winfo_screenwidth()-larg)/2
        y = (self.winfo_screenheight()-alt)/2
        self.geometry("%dx%d+%d+%d" % (larg, alt, x, y))
        self.resizable(False, False)
        self.componentes()

    def componentes(self):
        raise NotImplementedError()

class Botao(Tkinter.Button):
    def __init__(self, janela, x, y, larg, alt, texto):
        Tkinter.Button.__init__(self, janela)
        self["text"] = texto
        self.place({ "x": x, "y": y, 
                     "width": larg, "height": alt })
        self["command"] = self.executar

    def executar(self):
        raise NotImplementedError()

class BotaoPrint(Botao):
    def executar(self):
        print self["text"]

class BotaoRotulo(Botao):
    def __init__(self, janela, x, y, larg, alt, texto, rotulo):
        Botao.__init__(self, janela, x, y, larg, alt, texto)
        self.rotulo = rotulo
        
    def executar(self):
        self.rotulo["text"] = self["text"]

class BotaoIncrementa(Botao):
    def __init__(self, janela, x, y, larg, alt, texto, modelo):
        Botao.__init__(self, janela, x, y, larg, alt, texto)
        self.modelo = modelo
        
    def executar(self):
        self.modelo.inc()

class JanelaExemplo(Janela):
    def componentes(self):
        self.modelo = Modelo()
        self.rotulo1 = Rotulo(self, 200, 50, 100, 50, "0", "se")
        self.modelo.observar(self.rotulo1)
        self.rotulo2 = Rotulo(self, 350, 50, 100, 50, "0", "se")
        self.modelo.observar(self.rotulo2)
        self.botao = BotaoIncrementa(self, 50, 50, 100, 50, "Ok", self.modelo)

class Rotulo(Tkinter.Label):
    def __init__(self, janela, x, y, larg, alt, texto, ancora):
        Tkinter.Label.__init__(self, janela)
        self["text"] = texto
        self["anchor"] = ancora
        self.place({ "x": x, "y": y, "width": larg, "height": alt })
        
    def mudou(self, texto):
        self["text"] = str(texto)

class Modelo:
    def __init__(self):
        self.n = 0
        self.obs = []

    def observar(self, o):
        self.obs.append(o)

    def inc(self):
        self.n = self.n + 1
        for o in self.obs:
            o.mudou(self.n)
        
raiz = JanelaExemplo("Janela Tk", 800, 600)
raiz.mainloop()
