class Matriz(object):
    def __init__(self, m, n):
        self.m = m
        self.n = n
        self.elems = [0.0] * (m * n)

    def __getitem__(self, indice):
        lin, col = indice
        if lin < self.m and col < self.n:
            return self.elems[lin * self.n + col]

    def __setitem__(self, indice, valor):
        lin, col = indice
        if lin < self.m and col < self.n:
            self.elems[lin * self.n + col] = valor

    def __delitem__(self, indice):
        lin, col = indice
        if lin < self.m and col < self.n:
            self.elems[lin * self.n + col] = 0.0
                    
    def __str__(self):
        res = "["
        for i in range(self.m):
            for j in range(self.n):
                res = res + " " + str(self[i,j])
            if i < self.m-1:
                res = res + "\n "
        res = res + " ]"
        return res

    def __eq__(self, outra):
        return (type(outra) == Matriz and
                self.m == outra.m and
                self.n == outra.n and
                self.elems == outra.elems)
             
    def __ne__(self, outra):
        return not (self == outra)

    def __nonzero__(self):
        for elem in self.elems:
            if float(elem) != 0.0:
                return True
        return False

    def __add__(self, outra):
        if self.m == outra.m and self.n == outra.n:
            res = Matriz(self.m, self.n)
            for i in range(len(self.elems)):
                res.elems[i] = self.elems[i] + outra.elems[i]
            return res
        else:
            return None

    def __sub__(self, outra):
        if self.m == outra.m and self.n == outra.n:
            res = Matriz(self.m, self.n)
            for i in range(len(self.elems)):
                res.elems[i] = self.elems[i] - outra.elems[i]
            return res
        else:
            return None
        
    def __mul__(self, outra):
        if type(outra) == Matriz:
            if self.n == outra.m:
                res = Matriz(self.m, outra.n)
                # multiplicacao
                return res
            else:
                return None
        else:
            res = Matriz(self.m, self.n)
            for i in range(len(self.elems)):
                res.elems[i] = self.elems[i] * outra
            return res

    def __len__(self):
        return len(self.elems)

    def __contains__(self, valor):
        return valor in self.elems

    def __iter__(self):
        return IterMatriz(self)

class IterMatriz(object):
    def __init__(self, matriz):
        self.matriz = matriz
        self.m = 0
        self.n = 0

    def next(self):
        if self.n >= self.matriz.n:
            self.n = 0
            self.m = self.m + 1
        if self.m >= self.matriz.m:
            raise StopIteration()
        res = self.matriz[self.m,self.n]
        self.n = self.n + 1
        return res
        
class Intervalo(object):
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def __str__(self):
        return "[" + str(self.a) + "," + str(self.b) + "]"

    def __iter__(self):
        return IteradorIntervalo(self)

class IteradorIntervalo(object):
    def __init__(self, i):
        self.a = i.a
        self.b = i.b

    def next(self):
        if self.a > self.b:
            raise StopIteration()
        else:
            atual = self.a
            self.a = self.a + 1
            return atual
    
