import Tkinter

def cor_tkinter(cor):
    return "#%02x%02x%02x" % (int(cor[0]*255),
                              int(cor[1]*255),
                              int(cor[2]*255))

class Janela(Tkinter.Tk):
    def __init__(self, titulo, larg, alt):
        Tkinter.Tk.__init__(self)
        self.title(titulo)
        x = (self.winfo_screenwidth()-larg)/2
        y = (self.winfo_screenheight()-alt)/2
        self.geometry("%dx%d+%d+%d" % (larg, alt, x, y))
        self.resizable(False, False)
        #self["bg"] = "#ffffff"
        self.componentes()

    def componentes(self):
        raise NotImplementedError()

class Botao(Tkinter.Button):
    def __init__(self, janela, x, y, larg, alt, texto, tamanho):
        Tkinter.Button.__init__(self, janela)
        self["text"] = texto
        self["font"] = "Arial %d" % tamanho
        self.place({ "x": x, "y": y, 
                     "width": larg, "height": alt })
        self["command"] = self.executar

    def executar(self):
        raise NotImplementedError()

class BotaoPrint(Botao):
    def executar(self):
        print self["text"]

class BotaoRotulo(Botao):
    def __init__(self, janela, x, y, larg, alt, texto, rotulo):
        Botao.__init__(self, janela, x, y, larg, alt, texto, 20)
        self.rotulo = rotulo
        
    def executar(self):
        self.rotulo["text"] = self["text"]

class BotaoIncrementa(Botao):
    def __init__(self, janela, x, y, larg, alt, texto, modelo):
        Botao.__init__(self, janela, x, y, larg, alt, texto, 20)
        self.modelo = modelo
        
    def executar(self):
        self.modelo.inc()

class JanelaExemplo(Janela):
    def componentes(self):
        self.modelo = Modelo()
        self.rotulo1 = Rotulo(self, 200, 50, 100, 50, "0", "se", 20, (1, 1, 1), (0.3, 0.7, 0.4))
        self.modelo.observar_n(self.rotulo1)
        self.rotulo2 = Rotulo(self, 350, 50, 200, 50, "0", "center", 14, (1, 1, 1), (0, 0, 0))
        self.modelo.observar_cor(self.rotulo2)
        self.botao = BotaoIncrementa(self, 50, 50, 100, 50, "Ok", self.modelo)
        self.paleta = Paleta(self, 50, 150, 100, 100, (1.0, 1.0, 1.0))
        self.modelo.observar_cor(self.paleta)
        self.sliderR = SliderCor(self, 200, 150, self.modelo, 0)
        self.sliderG = SliderCor(self, 300, 150, self.modelo, 1)
        self.sliderB = SliderCor(self, 400, 150, self.modelo, 2)
        self.canvas = Canvas(self, 50, 300, 400, 200)
        self.canvas.retangulo(10, 10, 50, 90, (1, 0, 0))
        self.canvas.circulo(60, 100, 45, (0, 0, 1))
    
class Rotulo(Tkinter.Label):
    def __init__(self, janela, x, y, larg, alt, texto, ancora, tamanho, cor_texto, cor_fundo):
        Tkinter.Label.__init__(self, janela)
        self["text"] = texto
        self["anchor"] = ancora
        self["bg"] = cor_tkinter(cor_fundo)
        self["fg"] = cor_tkinter(cor_texto)
        self["font"] = "Arial " + str(tamanho)
        self.place({ "x": x, "y": y, "width": larg, "height": alt })
        
    def mudou(self, texto):
        self["text"] = str(texto)

class Paleta(Tkinter.Label):
    def __init__(self, janela, x, y, larg, alt, cor):
        Tkinter.Label.__init__(self, janela)
        self["text"] = ""
        self["bg"] = cor_tkinter(cor)
        self.place({ "x": x, "y": y, "width": larg, "height": alt })
    
    def mudou(self, cor):
        self["bg"] = cor_tkinter(cor)
 
class Slider(Tkinter.Scale):
    def __init__(self, janela, x, y, larg, alt, inicio, fim):
        Tkinter.Scale.__init__(self, janela)
        self["from"] = inicio
        self["to"] = fim
        self["resolution"] = -1
        self["showvalue"] = 0
        self["width"] = larg
        self.set(fim)
        self["command"] = self.mudou
        self.place({ "x": x, "y": y, "height": alt })

    def valor(self):
        return self.get()

    def mudou(self, valor):
        raise NotImplementedError()

class SliderCor(Slider):
    def __init__(self, janela, x, y, modelo, cor):
        Slider.__init__(self, janela, x, y, 50, 150, 0.0, 1.0)
        self.cor = cor
        self.modelo = modelo

    def mudou(self, valor):
        cor_modelo = [self.modelo.cor[0], self.modelo.cor[1], self.modelo.cor[2]]
        cor_modelo[self.cor] = float(valor)
        self.modelo.muda_cor((cor_modelo[0], cor_modelo[1], cor_modelo[2]))

class Canvas(Tkinter.Canvas):
    def __init__(self, janela, x, y, larg, alt):
        Tkinter.Canvas.__init__(self, janela)
        self["bg"] = "#ffffff"
        self.bind("<ButtonPress-1>", self.apertou)
        self.bind("<ButtonRelease-1>", self.soltou)
        self.bind("<B1-Motion>", self.arrastou)
        self.place({ "x": x, "y": y, "width": larg, "height": alt })

    def apertou(self, evt):
        pass

    def soltou(self, evt):
        pass

    def arrastou(self, evt):
        pass

    def limpar(self):
        self.delete(Tkinter.ALL)

    def retangulo(self, x, y, larg, alt, cor):
        self.create_rectangle(x, y, x+larg, y+alt, { "fill": cor_tkinter(cor),
                                                     "outline": cor_tkinter(cor) })

    def circulo(self, x, y, raio, cor):
        self.create_oval(x, y, x+raio*2, y+raio*2, { "fill": cor_tkinter(cor),
                                                     "outline": cor_tkinter(cor)})

class Modelo:
    def __init__(self):
        self.n = 0
        self.cor = (1, 1, 1)
        self.obs_n = []
        self.obs_cor = []

    def observar_n(self, o):
        self.obs_n.append(o)

    def observar_cor(self, o):
        self.obs_cor.append(o)

    def inc(self):
        self.n = self.n + 1
        for o in self.obs_n:
            o.mudou(self.n)

    def muda_cor(self, cor):
        self.cor = cor
        for o in self.obs_cor:
            o.mudou(self.cor)
        
raiz = JanelaExemplo("Janela Tk", 800, 600)
raiz.mainloop()
