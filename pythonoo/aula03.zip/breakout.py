import random
import motor

def cor_aleat():
    return (random.random(), random.random(), random.random())

class Bola:
    def __init__(self, x, y, vx, vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.raio = 5
        self.cor = (1, 1, 1) # branco
        self.hb = Hitbox(x - 4, y - 4, 8, 8)

    def desenhar(self, tela):
        tela.elipse(self.x - self.raio, self.y - self.raio,
                    self.raio * 2, self.raio * 2, self.cor)
        
    def para_cima(self):
        self.vy = -abs(self.vy)

    def para_baixo(self):
        self.vy = abs(self.vy)

    def para_esquerda(self):
        self.vx = -abs(self.vx)

    def para_direita(self):
        self.vx = abs(self.vx)

    def mover(self, dt):
        dx = self.vx * dt
        dy = self.vy * dt
        self.hb.mover(dx, dy)
        self.x = self.x + dx 
        self.y = self.y + dy 

class Raquete:
    larg = 100
    alt = 20
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.cor = (1, 1, 1)
        self.hb_e = Hitbox(x, y, 30, Raquete.alt)
        self.hb_c = Hitbox(x + 30, y, 40, Raquete.alt)
        self.hb_d = Hitbox(x + 70, y, 30, Raquete.alt)

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, Raquete.larg, Raquete.alt, self.cor)

    def mover(self, dx):
        self.hb_e.mover(dx, 0)
        self.hb_c.mover(dx, 0)
        self.hb_d.mover(dx, 0)
        self.x = self.x + dx

    def esquerda(self, dt):
        dx = -300 * dt
        self.mover(dx)

    def direita(self, dt):
        dx = 300 * dt
        self.mover(dx)

class Tijolo:
    larg = 50
    alt = 20

    def __init__(self, x, y, cor):
        self.x = x
        self.y = y
        self.cor = cor
        self.hb = Hitbox(x, y, Tijolo.larg, Tijolo.alt)

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, Tijolo.larg, Tijolo.alt, self.cor)

class Segmento:
    def __init__(self, valor):
        self.valor = valor

    def zerado(self):
        return self.valor == 0

    def tique(self):
        self.valor = (self.valor - 1) % 60
        return self.valor == 59

    def texto(self):
        return "%02d" % (self.valor)

class Timer:
    def __init__(self, x, y, minutos, segundos):
        self.x = x
        self.y = y
        self.segundos = Segmento(segundos)
        self.minutos = Segmento(minutos)
        self.tempo = 0.0

    def tique(self, dt):
        self.tempo = self.tempo + dt
        if self.tempo >= 1.0:
            self.tempo = self.tempo - 1.0
            if self.segundos.tique():
                self.minutos.tique()
        return self.minutos.zerado() and self.segundos.zerado()

    def desenhar(self, tela):
        tela.texto(self.x, self.y,
                   "%s:%s" % (self.minutos.texto(), self.segundos.texto()))

class Breakout:
    def __init__(self):
        self.TITULO = "Breakout"
        self.LARGURA = 800
        self.ALTURA = 600
        self.larg_parede = 50
        self.hb_par_e = Hitbox(0, 50, self.larg_parede, self.ALTURA - 50)
        self.hb_par_c = Hitbox(0, 50, self.LARGURA, self.larg_parede)
        self.hb_par_d = Hitbox(self.LARGURA - self.larg_parede, 50,
                               self.larg_parede, self.ALTURA - 50)
        self.hb_chao = Hitbox(self.larg_parede, self.ALTURA,
                              self.LARGURA - self.larg_parede * 2,
                              50)
        self.reset()

    def reset(self):
        self.score = 0
        self.pausa = False
        self.game_over = False
        self.bola = Bola(self.LARGURA/2, self.ALTURA/2, -200, 100)
        self.raquete = Raquete((self.LARGURA - Raquete.larg)/2,
                               self.ALTURA - Raquete.alt)
        self.tijolos = []
        self.timer = Timer(50, 10, 1, 15)
        for i in range(0, 14):
            for j in range(0, 6):
                t = Tijolo(i * Tijolo.larg + 50, j * Tijolo.alt + 150, cor_aleat())
                self.tijolos.append(t)
        
    def desenhar(self, tela):
        self.desenhar_paredes(tela)
        self.desenhar_score(tela)
        self.bola.desenhar(tela)
        self.raquete.desenhar(tela)
        self.timer.desenhar(tela)
        for tijolo in self.tijolos:
            tijolo.desenhar(tela)
        if self.game_over:
            l, a = motor.tamanho_texto("GAME OVER")
            tela.texto((self.LARGURA - l)/2, (self.ALTURA - a)/2,
                        "GAME OVER", (1, 1, 1))

    def desenhar_paredes(self, tela):
        tela.retangulo(0, 50, self.larg_parede, self.ALTURA - 50)
        tela.retangulo(0, 50, self.LARGURA, self.larg_parede)
        tela.retangulo(self.LARGURA - self.larg_parede, 50,
                       self.larg_parede, self.ALTURA - 50)

    def desenhar_score(self, tela):
        l, a = motor.tamanho_texto(str(self.score))
        tela.texto(self.LARGURA - 50 - l, 10, str(self.score))

    def tique(self, dt, teclas):
        if self.pausa or self.game_over: return
        if ("left" in teclas and "right" not in teclas and
                self.raquete.x > self.larg_parede):
            self.raquete.esquerda(dt)
        if ("right" in teclas and "left" not in teclas and
                self.raquete.x + Raquete.larg < self.LARGURA - self.larg_parede):
            self.raquete.direita(dt)
        self.bola.mover(dt)
        self.colisao_paredes()
        if self.hb_chao.intersecao(self.bola.hb):
            self.game_over = True
        self.colisao_raquete()
        self.colisao_tijolos()
        if self.timer.tique(dt):
            self.game_over = True

    def colisao_paredes(self):
        if self.hb_par_e.intersecao(self.bola.hb):
            self.bola.para_direita()
        if self.hb_par_c.intersecao(self.bola.hb):
            self.bola.para_baixo()
        if self.hb_par_d.intersecao(self.bola.hb):
            self.bola.para_esquerda()

    def colisao_raquete(self):
        if self.raquete.hb_e.intersecao(self.bola.hb):
            self.bola.para_esquerda()
            self.bola.para_cima()
        if self.raquete.hb_c.intersecao(self.bola.hb):
            self.bola.para_cima()
        if self.raquete.hb_d.intersecao(self.bola.hb):
            self.bola.para_direita()
            self.bola.para_cima()

    def colisao_tijolos(self):
        remover = []
        for tijolo in self.tijolos:
            onde = tijolo.hb.intersecao(self.bola.hb)
            if onde == "acima":
                self.bola.para_cima()
            if onde == "abaixo":
                self.bola.para_baixo()
            if onde == "esquerda":
                self.bola.para_esquerda()
            if onde == "direita":
                self.bola.para_direita()
            if onde:
                self.score = self.score + 10
                remover.append(tijolo)
        for tijolo in remover:
            self.tijolos.remove(tijolo)

    def tecla(self, tecla):
        if tecla == "space":
            self.pausa = not self.pausa
        if tecla == "escape":
            self.reset()

class Hitbox:
    def __init__(self, x, y, larg, alt):
        self.x0 = x
        self.y0 = y
        self.x1 = x + larg
        self.y1 = y + alt

    def mover(self, dx, dy):
        self.x0 = self.x0 + dx
        self.x1 = self.x1 + dx
        self.y0 = self.y0 + dy
        self.y1 = self.y1 + dy

    def intersecao(self, hb):
        w = ((self.x1 - self.x0) + (hb.x1 - hb.x0)) / 2.0
        h = ((self.y1 - self.y0) + (hb.y1 - hb.y0)) / 2.0
        dx = ((self.x1 + self.x0) - (hb.x1 + hb.x0)) / 2.0
        dy = ((self.y1 + self.y0) - (hb.y1 + hb.y0)) / 2.0
        if abs(dx) <= w and abs(dy) <= h:
            wy = w * dy
            hx = h * dx
            if wy > hx:
                if wy > -hx:
                    return "acima"
                else:
                    return "direita"
            else:
                if wy > -hx:
                    return "esquerda"
                else:
                    return "abaixo"
        else:
            return ""
        

jogo = Breakout()
motor.rodar(jogo)

