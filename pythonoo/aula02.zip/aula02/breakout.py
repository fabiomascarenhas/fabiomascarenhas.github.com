import random
import motor

def cor_aleat():
    return (random.random(), random.random(), random.random())

class Bola:
    def __init__(self, x, y, vx, vy):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.raio = 5
        self.cor = (1, 1, 1) # branco

    def desenhar(self, tela):
        tela.elipse(self.x - self.raio, self.y - self.raio,
                    self.raio * 2, self.raio * 2, self.cor)
        

    def mover(self, dt):
        self.x = self.x + self.vx * dt
        self.y = self.y + self.vy * dt

class Raquete:
    larg = 100
    alt = 20
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.cor = (1, 1, 1)

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, Raquete.larg, Raquete.alt, self.cor)

    def esquerda(self, dt):
        self.x = self.x - 100 * dt

    def direita(self, dt):
        self.x = self.x + 100 * dt

class Tijolo:
    larg = 50
    alt = 20

    def __init__(self, x, y, cor):
        self.x = x
        self.y = y
        self.cor = cor

    def desenhar(self, tela):
        tela.retangulo(self.x, self.y, Tijolo.larg, Tijolo.alt, self.cor)

class Breakout:
    def __init__(self):
        self.TITULO = "Breakout"
        self.LARGURA = 800
        self.ALTURA = 600
        self.larg_parede = 50
        self.reset()

    def desenhar(self, tela):
        tela.retangulo(0, 50, self.larg_parede, self.ALTURA - 50)
        tela.retangulo(0, 50, self.LARGURA, self.larg_parede)
        tela.retangulo(self.LARGURA - self.larg_parede, 50,
                       self.larg_parede, self.ALTURA - 50)
        tela.texto(self.LARGURA - 50, 10, str(self.score))
        self.bola.desenhar(tela)
        self.raquete.desenhar(tela)
        for tijolo in self.tijolos:
            tijolo.desenhar(tela)

    def tique(self, dt, teclas):
        if self.pausa: return
        if ("left" in teclas and "right" not in teclas and
                self.raquete.x > self.larg_parede):
            self.raquete.esquerda(dt)
        if ("right" in teclas and "left" not in teclas and
                self.raquete.x < self.LARGURA - self.larg_parede - Raquete.larg):
            self.raquete.direita(dt)
        self.bola.mover(dt)
        # verificar colisao da bola c/ raquete
        # verificar colisao da bola c/ tijolos

    def reset(self):
        self.score = 0
        self.pausa = False
        self.bola = Bola(self.LARGURA/2, self.ALTURA/2, 50, 50)
        self.raquete = Raquete((self.LARGURA - Raquete.larg)/2,
                               self.ALTURA - Raquete.alt)
        self.tijolos = []
        for i in range(0, 14):
            for j in range(0, 6):
                t = Tijolo(i * Tijolo.larg + 50, j * Tijolo.alt + 150, cor_aleat())
                self.tijolos.append(t)
        

    def tecla(self, tecla):
        if tecla == "space":
            self.pausa = not self.pausa
        if tecla == "escape":
            self.reset()

jogo = Breakout()
motor.rodar(jogo)

