#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gui.h>

struct Cor {
	double r;
	double g;
	double b;
};

struct Ponto {
	int x;
	int y;
};

struct Ret {
	struct Ponto canto;
	struct Cor cor;
};

static struct Cor AZUL = { 0.0, 0.0, 1.0 };
static struct Cor BRANCO;
 
static void init_vetdin(int *cap, int *uso, struct Ret **vet) {
	*cap = 1;
	*uso = 0;
	*vet = malloc(sizeof(struct Ret));
} 

static void adic_vetdin(int *cap, int *uso, struct Ret **vet, struct Ret *x) {
	if(*uso == *cap) { /* acabou o espa�o */
		struct Ret *nv;
		int i;
		*cap = *cap * 2;
		nv = malloc(*cap * sizeof(struct Ret));
		for(i = 0; i < *uso; i++) {
			nv[i] = (*vet)[i];
		}
		free(*vet);
		*vet = nv;
	}
	(*vet)[*uso] = *x;
	*uso = *uso + 1;
}

static int remove_vetdin(int *cap, int *uso, struct Ret **vet, int i) {
	int j;
	for(j = i + 1; j < *uso; j++) {
		(*vet)[j-1] = (*vet)[j];
	}
	*uso = *uso - 1;
}

static void cor_aleat(double *r, double *g, double *b) {
	*r = rand() * 1.0 / RAND_MAX;
	*g = rand() * 1.0 / RAND_MAX;
	*b = rand() * 1.0 / RAND_MAX;
}

static void retangulo(struct Ponto *p, int larg, int alt,
	                  struct Cor *c) {
    tela_ret(p->x, p->y, larg, alt, c->r, c->g, c->b);
}

/* vetor din�mico: ret�ngulos */
static int cap;
static int uso;
static struct Ret *vet;

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Hello World";
	*largura = 800;
	*altura = 600;
	init_vetdin(&cap, &uso, &vet);
	/*BRANCO.r = 1.0;
	BRANCO.g = 1.0;
	BRANCO.b = 1.0;*/
	cor_aleat(&BRANCO.r, &BRANCO.g, &BRANCO.b);
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
	if(botao == 0 && soltou == 1) {
		/* soltou bot�o esquerdo */
		struct Ret r;
		r.canto.x = x;
		r.canto.y = y;
		r.cor.r = rand() * 1.0 / RAND_MAX;
		r.cor.g = rand() * 1.0 / RAND_MAX;
		r.cor.b = rand() * 1.0 / RAND_MAX;
		adic_vetdin(&cap, &uso, &vet, &r);
	} else if(botao == 1 && soltou == 1) {
		/* soltou bot�o direito */
		int i;
		for(i = 0; i < cap; i++) {
			if(x >= vet[i].canto.x && y >= vet[i].canto.y &&
			   x < vet[i].canto.x + 50 && y < vet[i].canto.y + 30) {
			    remove_vetdin(&cap, &uso, &vet, i);
			    break;
			}
		}
	}
}

static void desenha_cadeias(int x, int y, char **vs) {
	/* �ltima cadeia de vs � a cadeia vazia */
	for(; **vs != 0; vs++, y += 50) {
		/* vs++ avan�a para a pr�xima cadeia */
		/* **vs l� o primeiro caractere da cadeia atual */
		/* *vs l� a cadeia atual */
		tela_texto(x, y, *vs, 1, 1, 1);
	}
}

void gui_desenhar() {
	int i;
	char s[10];
	/*desenha_cadeias(50, 50, cadeias);*/
	for(i = 0; i < uso; i++) {
		retangulo(&vet[i].canto, 50, 30, &vet[i].cor);
	}
	sprintf(s, "cap: %d", cap);
	tela_texto(10, 10, s, AZUL.r, AZUL.g, AZUL.b);
	sprintf(s, "uso: %d", uso);
	tela_texto(10, 50, s, BRANCO.r, BRANCO.g, BRANCO.b);
	/*tela_ret(X, 100, 200, 300, 0, 0, 1);
	tela_circ(X + 200, 300, 50, 1, 0, 0);
	tela_elipse(X + 400, 200, 50, 100, 0, 1, 0);
	tela_triang(X + 300, 100, X + 100, 150, X + 500, 150, 1, 1, 0);
	tela_texto(X, 500, "Hello World", 1, 1, 1);
	tela_letra(X + 300, 500, 'A', 1, 1, 1);*/
}

