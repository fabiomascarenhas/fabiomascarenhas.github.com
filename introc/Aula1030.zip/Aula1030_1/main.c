#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gui.h>

static double X = 100;

static int nums[] = { 10, 30, 50, 70, 90 };
static int x = 5;
static int y = 10;

static int *nn[] = { nums, &x, &y };

static char *cadeias[] = {
	"Foo",
	"Ola Mundo",
	"Outra cadeia",
	""
};

/* aloca um vetor de n vetores para n�meros
inteiros, onde o tamanho de cada vetor � dado
pelo vetor ts */
static int** aloca_vetores(int ts[], int n) {
    int **vv = malloc(n * sizeof(int*));
    int i;
    for(i = 0; i < n; i++) {
        vv[i] = malloc(ts[i] * sizeof(int));
    }
    return vv;
}

/* libera um vetor de n vetores para inteiros */
static void libera_vetores(int *vv[], int n) {
    int i;
    for(i = 0; i < n; i++) {
        free(vv[i]);
    }
    free(vv);
}

static void init_vetdin(int *cap, int *uso, int **vet) {
	*cap = 1;
	*uso = 0;
	*vet = malloc(sizeof(int));
} 

static void adic_vetdin(int *cap, int *uso, int **vet, int x) {
	if(*uso == *cap) { /* acabou o espa�o */
		int *nv;
		int i;
		*cap = *cap * 2;
		nv = malloc(*cap * sizeof(int));
		for(i = 0; i < *uso; i++) {
			nv[i] = (*vet)[i];
		}
		free(*vet);
		*vet = nv;
	}
	(*vet)[*uso] = x;
	*uso = *uso + 1;
}

static int remove_vetdin(int *cap, int *uso, int **vet, int i) {
	int j;
	for(j = i + 1; j < *uso; j++) {
		(*vet)[j-1] = (*vet)[j];
	}
	*uso = *uso - 1;
}

/* vetor din�mico: coordenadas x */
static int cap_xs;
static int uso_xs;
static int *vet_xs;
/* vetor din�mico: coordenadas y */
static int cap_ys;
static int uso_ys;
static int *vet_ys;
/* vetor din�mico: cores R  */
static int cap_rs;
static int uso_rs;
static int *vet_rs;
/* vetor din�mico: cores G  */
static int cap_gs;
static int uso_gs;
static int *vet_gs;
/* vetor din�mico: cores B */
static int cap_bs;
static int uso_bs;
static int *vet_bs;

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Hello World";
	*largura = 800;
	*altura = 600;
	int ts[] = { 3, 5, 2 };
	int **is = aloca_vetores(ts, 3);
	int x = 10;
	int i;

	/* vetor din�mico de inteiros */
	int cap; /* capacidade */
	int uso; /* quantos elementos est�o nele */
	int *vet; /* o vetor em si */

	init_vetdin(&cap, &uso, &vet);
	
	for(i = 0; i < 3; i ++) {
		int j;
		for(j = 0; j < ts[i]; j++) {
			is[i][j] = x;
			adic_vetdin(&cap, &uso, &vet, x);
			x = x + 10;
		}
	}
	for(i = 0; i < 3; i++) {
		int j;
		for(j = 0; j < ts[i]; j++) {
			printf("is[%d][%d] = %d\n", i, j, is[i][j]);
		}
	}
	remove_vetdin(&cap, &uso, &vet, 3);
	remove_vetdin(&cap, &uso, &vet, 7);
	printf("cap: %d, uso: %d\n", cap, uso);
	for(i = 0; i < uso; i++) {
		printf("vet[%d] = %d\n", i, vet[i]);
	}
	printf("terceiro numero e: %d\n", *(nums+2));
	printf("%d %d %d\n", *(nn[0]), *(nn[1]), *(nn[2]));
	printf("valor de x e: %d\n", **(nn+1));
	
	init_vetdin(&cap_xs, &uso_xs, &vet_xs);
	init_vetdin(&cap_ys, &uso_ys, &vet_ys);
	init_vetdin(&cap_rs, &uso_rs, &vet_rs);
	init_vetdin(&cap_gs, &uso_gs, &vet_gs);
	init_vetdin(&cap_bs, &uso_bs, &vet_bs);
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
	if(botao == 0 && soltou == 1) {
		/* soltou bot�o esquerdo */
		adic_vetdin(&cap_xs, &uso_xs, &vet_xs, x);
		adic_vetdin(&cap_ys, &uso_ys, &vet_ys, y);
		adic_vetdin(&cap_rs, &uso_rs, &vet_rs, rand());
		adic_vetdin(&cap_gs, &uso_gs, &vet_gs, rand());
		adic_vetdin(&cap_bs, &uso_bs, &vet_bs, rand());
	} else if(botao == 1 && soltou == 1) {
		/* soltou bot�o direito */
		int i;
		for(i = 0; i < cap_xs; i++) {
			if(x >= vet_xs[i] && y >= vet_ys[i] &&
			   x < vet_xs[i] + 30 && y < vet_ys[i] + 30) {
			    remove_vetdin(&cap_xs, &uso_xs, &vet_xs, i);
			    remove_vetdin(&cap_ys, &uso_ys, &vet_ys, i);
			    remove_vetdin(&cap_rs, &uso_rs, &vet_rs, i);
			    remove_vetdin(&cap_gs, &uso_gs, &vet_gs, i);
			    remove_vetdin(&cap_bs, &uso_bs, &vet_bs, i);
			    break;
			}
		}
	}
}

static void desenha_cadeias(int x, int y, char **vs) {
	/* �ltima cadeia de vs � a cadeia vazia */
	for(; **vs != 0; vs++, y += 50) {
		/* vs++ avan�a para a pr�xima cadeia */
		/* **vs l� o primeiro caractere da cadeia atual */
		/* *vs l� a cadeia atual */
		tela_texto(x, y, *vs, 1, 1, 1);
	}
}

void gui_desenhar() {
	int i;
	char s[10];
	/*desenha_cadeias(50, 50, cadeias);*/
	for(i = 0; i < uso_xs; i++) {
		tela_ret(vet_xs[i], vet_ys[i], 50, 30,
			  vet_rs[i] * 1.0 / RAND_MAX,
			  vet_gs[i] * 1.0 / RAND_MAX,
			  vet_bs[i] * 1.0 / RAND_MAX
			);
	}
	sprintf(s, "cap: %d", cap_xs);
	tela_texto(10, 10, s, 1, 1, 1);
	sprintf(s, "uso: %d", uso_xs);
	tela_texto(10, 50, s, 1, 1, 1);
	/*tela_ret(X, 100, 200, 300, 0, 0, 1);
	tela_circ(X + 200, 300, 50, 1, 0, 0);
	tela_elipse(X + 400, 200, 50, 100, 0, 1, 0);
	tela_triang(X + 300, 100, X + 100, 150, X + 500, 150, 1, 1, 0);
	tela_texto(X, 500, "Hello World", 1, 1, 1);
	tela_letra(X + 300, 500, 'A', 1, 1, 1);*/
}

