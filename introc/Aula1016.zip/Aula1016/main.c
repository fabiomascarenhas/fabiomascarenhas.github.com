#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gui.h>

static double X = 100;

void troca(int *p1, int *p2) {
	int i = *p1;
	*p1 = *p2;
	*p2 = i;	
}

/* retorna um vetor com os primeiros n
   n�meros naturais */
static int* naturais(int n) {
    int *v = malloc(n * sizeof(int));
    int i = 0;
    while(i < n) {
        v[i] = i + 1;
        i = i + 1;
    }
    return v;
}

void print_vetor(int v[], int n) {
	int i;
	for(i = 0; i < n; i++) {
		printf("%d ", v[i]);
	}
	printf("\n");
}

static int comprimento(char *s) {
	char *t; 
	for(t = s; *s; s++) {} 	/* t � o endere�o do primeiro caractere */
	/* s agora � o endere�o do 0 final */
	return s - t; /* n�mero de caracteres */
}

static char* busca(char *s, char c) {
    for(; *s && *s != c; s++) {}
    return s;
}

void gui_init(String *titulo, int *largura, int *altura) {
	int a = 5;
	int b = 10;
	int *pa = &a;
	int *pb = &b;
	printf("a = %d, b = %d\n", a, b);
	troca(&a, &b);
	printf("a = %d, b = %d\n", a, b);
	troca(pa, pb);
	printf("a = %d, b = %d\n", a, b);

	int *ns = naturais(10);
	print_vetor(ns+3, 7);
	free(ns); /* libera a mem�ria que foi reservada */
	/* o ponteiro ns agora � inv�lido!! */
	ns = &a;
	/* ns est� v�lido de novo */
	
	printf("'%s'\n", busca("batata", 't'));
	printf("'%s'\n", busca("batata", 'x'));
	
	*titulo = "Hello World";
	*largura = 800;
	*altura = 600;
}


void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
}

void gui_desenhar() {
	tela_ret(X, 100, 200, 300, 0, 0, 1);
	tela_circ(X + 200, 300, 50, 1, 0, 0);
	tela_elipse(X + 400, 200, 50, 100, 0, 1, 0);
	tela_triang(X + 300, 100, X + 100, 150, X + 500, 150, 1, 1, 0);
	tela_texto(X, 500, "Hello World", 1, 1, 1);
	tela_letra(X + 300, 500, 'A', 1, 1, 1);
}

