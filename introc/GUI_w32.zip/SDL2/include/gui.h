
#define String const char*

void tela_ret(int x, int y, int larg, int alt, double r, double g, double b);
void tela_circ(int x, int y, int raio, double r, double g, double b);
void tela_elipse(int x, int y, int rx, int ry, double r, double g, double b);
void tela_triang(int x1, int y1, int x2, int y2, int x3, int y3, double r, double g, double b);
void tela_letra(int x, int y, char c, double r, double g, double b);
void tela_texto(int x, int y, String txt, double r, double g, double b);

void som_tocar(String arqwav);

void gui_quit();

extern void gui_init(String *titulo, int *largura, int *altura);
extern void gui_tecla(String tecla, int soltou);
extern void gui_tique(double dt);
extern void gui_desenhar();
extern void gui_mouse(int x, int y, int botao, int cliques);

