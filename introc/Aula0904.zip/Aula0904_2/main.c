#include <stdio.h>
#include <string.h>
#include <gui.h>

/* Modelo */

char palavra[5];
static char acertos[] = "____";
static int erros = 0;
static int score = 100;

static int ganhou() {
	return acertos[0] != '_' && acertos[1] != '_' &&
	       acertos[2] != '_' && acertos[3] != '_';
}

static int perdeu() {
	return erros > 3;
}

/*
	Efeito: modificar o elemento pos de acertos
*/
static void testa_letra(char letra, int pos) {
	if(letra >= 'a' && letra <= 'z') {
		letra = letra - ' ';
	}
    if(letra == palavra[pos]) {
    	acertos[pos] = letra;
    }
}

static int e_letra(String s) {
	return (strlen(s) == 1) && 
		   ((strcmp(s, "A") >= 0) || (strcmp(s, "Z") <= 0));
}

/*
	Efeitos: modificar r1, r2, r3, r4 e erros
*/
static void rodada(char letra) {
	testa_letra(letra, 0);
	testa_letra(letra, 1);
	testa_letra(letra, 2);
	testa_letra(letra, 3);
    if(letra != palavra[0] && letra != palavra[1] && 
	   letra != palavra[2] && letra != palavra[3]) {
    	erros = erros + 1;
    	score = score - 25;
    }
}

/* Interface */

static char tentativas[9];
static char ultima_letra = ' ';

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Jogo da Forca";
	*largura = 1024;
	*altura = 768;
	strcpy(palavra, "FOGO");
	strcpy(tentativas, "");
}

void gui_tecla(String tecla, int soltou) {
	int nerr = erros;
	if(!ganhou() && !perdeu()) {
		if(e_letra(tecla) && soltou) {
			rodada(tecla[0]);
			ultima_letra = tecla[0];
			if(erros > nerr) {
				strcat(tentativas, tecla);
				strcat(tentativas, " ");
			}
		}
	}
	if(strcmp(tecla, "Space") == 0 && soltou) {
		acertos[0] = 0; acertos[1] = 0;
		acertos[2] = 0; acertos[3] = 0;
		ultima_letra = ' ';
		strcpy(tentativas, "");
		erros = 0;
		score = 100;
	}
}

void gui_tique(double dt) {}

void gui_mouse(int x, int y, int botao, int cliques) {}

void gui_desenhar() {
	char texto_ultima[] = "Ultima letra: A";
	char texto_score[] = "Score: 000";
	sprintf(texto_score, "Score: %3d", score);
	tela_texto(700, 10, texto_score, 1, 1, 1);
	tela_ret(100, 100, 200, 10, 1, 1, 1);
	tela_ret(200, 100, 2, 100, 1, 1, 1);
	if(erros > 0) {
		tela_circ(200, 220, 20, 1, 1, 1);
	}
	if(erros > 1) {
		tela_ret(200, 240, 2, 100, 1, 1, 1);		
	}
	if(erros > 2) {
		tela_ret(130, 280, 70, 2, 1, 1, 1);
		tela_ret(200, 280, 70, 2, 1, 1, 1);
	}
	if(erros > 3) {
		tela_triang(200, 340, 150, 420, 150, 420, 1, 1, 1);
		tela_triang(201, 341, 151, 421, 151, 421, 1, 1, 1);
		tela_triang(200, 340, 250, 420, 250, 420, 1, 1, 1);
		tela_triang(199, 341, 249, 421, 249, 421, 1, 1, 1);
	}
	sprintf(texto_ultima, "Ultima letra: %c", ultima_letra);
	tela_texto(400, 100, texto_ultima, 1, 1, 1);
	tela_texto(400, 300, acertos, 1, 1, 1);
	tela_texto(100, 500, tentativas, 1, 1, 1);
	if(ganhou()) {
		tela_texto(400, 500, "Voce ganhou!", 0, 0, 1);
	}
	if(perdeu()) {
		tela_texto(400, 500, "Voce perdeu!", 1, 0, 0);
	}
}


