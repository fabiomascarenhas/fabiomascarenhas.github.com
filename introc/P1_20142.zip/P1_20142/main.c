#include <stdio.h>
#include <string.h>
#include <gui.h>

/*

Primeira Prova de Introdu��o � Programa��o C BCMT

Responda as quest�es abaixo programando as fun��es pedidas.
Voc� � livre para criar fun��es auxiliares, e testar suas
fun��es usando o console ou a interface gr�fica.

A prova � individual, e com consulta livre. A dura��o da
prova � de duas horas.

*/

/* Quest�o 1 (2,0 pontos) */

/* Uma disciplina tem o seguinte crit�rio de c�lculo da
m�dia final: um aluno tem quatro notas: p1, p2, pf e tp,
correspondendo a duas provas, uma prova final e um trabalho
pr�tico. A m�dia parcial � dada por uma m�dia ponderada
entre as duas provas e o trabalho pr�tico, onde cada uma
das duas provas tem peso 4 e o trabalho pr�tico tem peso 2.

Se a m�dia parcial for maior ou igual a 7.0 essa � a m�dia
final do aluno. Se for menor ou igual a 3.0, essa tamb�m � a m�dia
final. Se for maior do que 3.0 e menor do que 7.0, � feita uma
nova m�dia ponderada entre a m�dia parcial e prova final em
que a m�dia parcial tem peso 6 e a prova final tem peso 4, e
essa m�dia ponderada � a m�dia final.

Implemente a fun��o media_final abaixo, que calcula a m�dia
final de um aluno, dadas as suas notas */

static double media_final(double p1, double p2, double tp, double pf) {
	double mp = (p1 * 4 + p2 * 4 + tp * 2) / 10;
	if(mp >= 7.0 || mp <= 3.0) {
		return mp;
	} else {
		return (mp * 6 + pf * 4) / 10;
	}
}

/* Quest�o 2 (3,0 pontos) */

/* Uma pal�ndromo � uma palavra que � a mesma se lida
de frente para tr�s ou de tr�s para frente, como ovo,
arara, rodador e sopapos.

Implemente a fun��o palindromo abaixo, que retorna 1 se
a palavra passada for um pal�ndromo ou 0 se n�o for um
pal�ndromo ou se n�o a cadeia passada n�o for uma
palavra (possuir um caractere que n�o seja uma letra
mai�scula ou min�scula). A fun��o n�o deve fazer distin��o
entre ma�sculas e min�sculas: "sOpaPos" � um pal�ndromo. */

static int letra(char c) {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}

static int letra_igual(char c1, char c2) {
	if(c1 >= 'a') {
		c1 = c1 - ' ';
	}
	if(c2 >= 'a') {
		c2 = c2 - ' ';
	}
	return c1 == c2;
}

static int palindromo(char s[]) {
	int i;
	int n = strlen(s);
	for(i = 0; i < n/2; i++) { /* pode-se tamb�m ir at� o final */
		if(!letra(s[i]) || !letra_igual(s[i], s[n-i-1])) {
			return 0;
		}
	}
	return 1;
}

/* Quest�o 3 (2,0 pontos) */

/* Um histograma � uma contagem de quantos elementos
de determinado conjunto est�o em cada uma de uma s�rie
de categorias. Se temos um conjunto de m�dias finais
de alunos, um histograma desse conjunto seria uma
contagem de quantos alunos se encaixam em um de quatro
grupos: o grupo 0 tem as m�dias menores ou iguais que 3.0,
o grupo 1 tem as m�dias maiores que 3.0 e menores que 5.0,
o grupo 2 tem as m�dias maiores ou iguais que 5.0 e menores
que 7.0, e o grupo 3 tem as m�dias maiores ou iguais que 7.0.

Implemente a fun��o hist_notas abaixo, que recebe um vetor
de m�dias finais, o n�mero de elementos desse vetor, e um
vetor de quatro inteiros que dever� ser preenchido com a contagem
de quantas nota est�o em cada grupo. */

static void hist_notas(double notas[], int n, int hist[]) {
	int i;
	for(i = 0; i < 4; i++) {
		hist[i] = 0;
	}
	for(i = 0; i < n; i ++) {
		double nota = notas[i];
		if(nota <= 3.0) {
			hist[0]++;
		} else if(nota > 3.0 && nota < 5.0) {
			hist[1]++;
		} else if(nota >= 5.0 && nota < 7.0) {
			hist[2]++;
		} else {
			hist[3]++;
		}
	}
}

/* Quest�o 4 (3,0 pontos) */

/* Um gr�fico de barras � uma maneira natural de
desenhar um histograma. Implemente a fun��o
desenha_hist abaixo, que recebe um histograma, quantos
grupos o histograma tem, o canto superior esquerdo do
gr�fico de barras, a largura do gr�fico, e a altura do
gr�fico. As barras devem preencher o gr�fico na horizontal,
e todas devem ter a mesma largura. Na vertical, o grupo
que tem o maior n�mero de elementos deve ter uma barra
com a mesma altura do gr�fico, e as outras barras devem
ter tamanhos proporcionais a quantos elementos o grupo
tem. 

Use a fun��o tela_ret(x, y, larg, alt, r, g, b) para
desenhar as barras. Alterne as cores das barras entre
vermelho, verde e azul. */

static int maior_valor(int v[], int n) {
	int m = v[0];
	int i;
	for(i = 1; i < n; i++) {
		if(v[i] > m) {
			m = v[i];
		}
	}
	return m;
}

static void desenha_hist(int hist[], int ngr, int x, int y, int larg, int alt) {
	int larg_barra = larg / ngr;
	int maior = maior_valor(hist, ngr);
	int i;
	double r = 1.0, g = 0.0, b = 0.0;
	for(i = 0; i < ngr; i++) {
		int x_barra = x + i * larg_barra;
		int alt_barra = (hist[i] * 1.0 / maior) * alt;
		int y_barra = y + alt - alt_barra;
		tela_ret(x_barra, y_barra, larg_barra, alt_barra, r, g, b);
		if(r == 1.0) {
			r = 0.0;
			g = 1.0;
		} else if(g == 1.0) {
			g = 0.0;
			b = 1.0;
		} else {
			b = 0.0;
			r = 1.0;
		}
	}
}

/* Fim das quest�es */

static int hist_exemplo[4];

void gui_init(String *titulo, int *largura, int *altura) {
	char s[81];
	double notas[] = {
		2.5, 5.5, 8.9, 4.0, 1.0, 0.0, 9.5, 6.0, 8.3, 1.5 
	}; /* 4 no grupo 0, 1 no grupo 1, 2 no grupo 2, 3 no grupo 3 */

	*titulo = "Primeira Prova de IntroC BCMT";
	*largura = 800;
	*altura = 600;
	/* Esse � um bom lugar para testar fun��es que
	podem ser testadas no console, usando scanf e printf */
	puts("Entre uma cadeia de caracteres:");
	scanf("%80[^\n]", s);
	if(palindromo(s)) {
		printf("%s e' um palindromo\n", s);
	} else {
		printf("%s nao e' um palindromo\n", s);
	}
	
	hist_notas(notas, 10, hist_exemplo);
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
}

void gui_desenhar() {
	tela_texto(10, 10, "Primeira Prova Introc", 1.0, 1.0, 1.0);
	desenha_hist(hist_exemplo, 4, 10, 100, 600, 300);
}

