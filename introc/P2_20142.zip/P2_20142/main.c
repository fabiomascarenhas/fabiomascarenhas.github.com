#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/*

Segunda Prova de Introdu��o � Programa��o C BCMT

Responda as quest�es abaixo programando as fun��es pedidas.
Voc� � livre para criar fun��es auxiliares, e testar suas
fun��es usando o console ou a interface gr�fica.

A prova � individual, e com consulta livre. A dura��o da
prova � de duas horas.

*/

/* Quest�o 1 (3,0 pontos) */

/* Uma pilha � uma cole��o onde podemos
acrescentar a remover elementos, sendo que
sempre removemos o �ltimo elemento que
foi acrescentado. Podemos representar uma
pilha de cadeias de caracteres que cresce
sob-demanda com a seguinte estrutura: */

struct Pilha {
	int topo;
	int capacidade;
	char **elementos; /* elementos � um vetor de strings */
};

static struct Pilha *pilha_cria() {
	struct Pilha *p = malloc(sizeof(struct Pilha));
	p->topo = -1;  /* �ndice do elemento do topo */
	p->capacidade = 1;
	p->elementos = malloc(p->capacidade * sizeof(char*));
	return p;
}

/* Implemente as fun��es abaixo que, respectivamente,
dizem se a pilha est� vazia ou n�o, inserem um novo
elemento na pilha e removem um elemento da pilha,
retornando o elemento removido. */

/* Pilha est� vazia? */
static int pilha_vazia(struct Pilha *p) {
	return p->topo == -1;
}

/* Insere elemento, crescendo a pilha se necess�rio. */
static void pilha_push(struct Pilha *p, char *s) {
	if(p->topo == p->capacidade - 1) {
		p->capacidade *= 2;
		char **nelems = malloc(p->capacidade * sizeof(char*));
		int i;
		for(i = 0; i <= p->topo; i++) {
			nelems[i] = p->elementos[i];
		}
		free(p->elementos);
		p->elementos = nelems;
	}
	p->topo = p->topo + 1;
	p->elementos[p->topo] = s;
}

/* Remove elemento do topo e retorna, ou retorna 0 se pilha for vazia. */
static char *pilha_pop(struct Pilha *p) {
	if(pilha_vazia(p)) {
		return 0;
	} else {
		char *s = p->elementos[p->topo];
		p->topo = p->topo - 1;
		return s;
	}
}

/* Quest�es 2, 3 e 4 - total de 7,0 pontos */

/* Uma �rvore bin�ria � uma estrutura recursiva em
que cada parte � composta de um "r�tulo" e dois ramos,
o ramo esquerdo e o ramo direito. Cada ramo pode ser
0 ou apontar para uma �rvore bin�ria.

Se ambos os ramos de uma �rvore s�o 0 dizemos que ela
� uma "folha". */

struct ArvBin {
	char *rot; /* string */
	struct ArvBin *esq;
	struct ArvBin *dir;
}; 

/* A fun��o abaixo imprime o conte�do de uma �rvore,
usando par�nteses: (rotulo ramo-esq ramo-dir). Use
para depura��o de suas fun��es. */

static void imprime_arvore(struct ArvBin *arv) {
	printf("(%s", arv->rot);
	if(arv->esq) {
		printf(" ");
		imprime_arvore(arv->esq);
	}
	if(arv->dir) {
		printf(" ");
		imprime_arvore(arv->dir);
	}
	printf(")");
}

/* Quest�o 2 (2,0 pontos) */

/* Implemente a fun��o abaixo, que cria uma nova �rvore
dado seu r�tulo e seus ramos esquerdo e direito. */

static struct ArvBin *cria_arvore(char *rot, struct ArvBin *esq, struct ArvBin *dir) {
	struct ArvBin *arv = malloc(sizeof(struct ArvBin));
	arv->rot = rot;
	arv->esq = esq;
	arv->dir = dir;
	return arv;
}

/* Quest�o 3 (2,0 pontos) */

/* Implemente a fun��o conta_rotulos, que recebe um ponteiro para
uma �rvore e retorna a soma do tamanho de todos os r�tulos dessa
�rvore. */

static int conta_rotulos(struct ArvBin *arv) {
	if(arv == 0) {
		return 0;
	} else {
		return strlen(arv->rot) + conta_rotulos(arv->esq) + conta_rotulos(arv->dir);
	}
}

/*static int conta_rotulos(struct ArvBin *arv) {
	int rots = strlen(arv->rot);
	if(arv->esq) {
		rots += conta_rotulos(arv->esq);
	}
	if(arv->dir) {
		rots += conta_rotulos(arv->dir);
	}
	return rots;
}*/

/* Quest�o 4 (3,0 pontos) */

/* Um caso particular das �rvores bin�rias acima s�o as �rvores de
express�es aritm�ticas. Em uma �rvore de express�o aritm�tica,
os r�tulos das folhas s�o cadeias de caracteres contendo n�meros,
como "3.14" ou "1000". Se uma �rvore de express�o n�o � uma folha
ent�o seu r�tulo � uma cadeia com o nome de uma das quatro opera��es
aritm�ticas ("SOMA", "SUB", "MUL" ou "DIV"), seus dois ramos
obrigatoriamente est�o presentes, e eles s�o �rvores de express�o.

Implemente a fun��o abaixo, que calcula o valor de uma �rvore
de express�o aritm�tica; o valor de uma folha � dado chamando
a fun��o "atod" no seu r�tulo. O valor de outras �rvores de
express�o � calculado aplicando a opera��o dada pelo seu r�tulo
aos valores de suas sub�rvores. */

static double atod(char *s) {
	double n;
	sscanf(s, "%lf", &n);
	return n;
}

static double valor_arvexp(struct ArvBin *exp) {
	if(exp->esq == 0 && exp->dir == 0) {
		/* folha */
		return atod(exp->rot);
	} else {
		/* express�o */
		double vesq = valor_arvexp(exp->esq);
		double vdir = valor_arvexp(exp->dir);
		if(strcmp(exp->rot, "SOMA") == 0) {
			return vesq + vdir;
		} else if(strcmp(exp->rot, "SUB") == 0) {
			return vesq - vdir;
		} else if(strcmp(exp->rot, "MUL") == 0) {
			return vesq * vdir;
		} else {
			return vesq / vdir;
		}
 	}
}

/* Fim das quest�es */

int main() {
	struct Pilha *p = pilha_cria();
	printf(pilha_vazia(p) ? "vazia\n" : "n�o vazia\n");
	pilha_push(p, "oi");
	printf(pilha_vazia(p) ? "vazia\n" : "n�o vazia\n");
	pilha_push(p, "tchau");
	pilha_push(p, "oi de novo");
	printf("%s\n", pilha_pop(p));
	printf("%s\n", pilha_pop(p));
	printf("%s\n", pilha_pop(p));
	printf(pilha_vazia(p) ? "vazia\n" : "n�o vazia\n");
	printf("%d\n", pilha_pop(p));
	struct ArvBin *arv = cria_arvore("raiz",
		cria_arvore("ramo1", cria_arvore("folha1", 0, 0), 0),
		cria_arvore("ramo2", cria_arvore("folha2", 0, 0), 
		                     cria_arvore("folha3", 0 , 0)));
	imprime_arvore(arv);
	printf("\nRotulos: %d\n", conta_rotulos(arv));
	struct ArvBin *exp = cria_arvore("DIV",
		cria_arvore("MUL", cria_arvore("2.0", 0, 0),
		                     cria_arvore("3.5", 0, 0)),
		cria_arvore("SOMA", cria_arvore("0.5", 0, 0), 
		                     cria_arvore("1.5", 0 , 0)));
	imprime_arvore(exp);
	printf("\n%lf\n", valor_arvexp(exp->esq->dir));
	printf("%lf\n", valor_arvexp(exp));
	char s1[10] = "_OLA";
	char *s2 = s1;
	s1[0]= 'B';
	printf("%d %d\n", sizeof(s1), sizeof(s2));
	printf("%d %d\n", strlen(s1), strlen(s2));
	printf("%s %s\n", s1, s2);
	printf("%d\n", "FOO" == "FOO");
	return 0;
}

