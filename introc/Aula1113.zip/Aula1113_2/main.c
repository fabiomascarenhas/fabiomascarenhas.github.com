#include <string.h>
#include <gui.h>

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Desenho Recursivo";
	*largura = 800;
	*altura = 600;
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
}

static void rec_H(double x, double y, double alt, double larg, int n) {
    tela_ret(x - larg/2, y-1, larg, 2, 1, 1, 1);
    tela_ret(x - larg/2 - 1, y - alt/2, 2, alt, 1, 1, 1);
    tela_ret(x + larg/2 - 1, y - alt/2, 2, alt, 1, 1, 1);
    if(n > 0) {
        rec_H(x - larg/2, y - alt/2, alt/2, larg/2, n-1);
        rec_H(x - larg/2, y + alt/2, alt/2, larg/2, n-1);
        rec_H(x + larg/2, y - alt/2, alt/2, larg/2, n-1);
        rec_H(x + larg/2, y + alt/2, alt/2, larg/2, n-1);
    }
}

void gui_desenhar() {
	rec_H(400, 300, 200, 400, 5);
}

