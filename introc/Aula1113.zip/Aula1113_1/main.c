#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAXNOME 256

struct Arq {
	char nome[MAXNOME];
	int tam; /* em kbytes */
};

struct Dir {
	char nome[MAXNOME];
	int uso_arqs;
	int cap_arqs;
	struct Arq *arqs;
	int uso_dirs;
	int cap_dirs;
	struct Dir *dirs;
};

static void init_dir(struct Dir *dir, char *nome) {
	strcpy(dir->nome, nome);
	dir->uso_arqs = 0;
	dir->cap_arqs = 1;
	dir->arqs = malloc(sizeof(struct Arq));
	dir->uso_dirs = 0;
	dir->cap_dirs = 1;
	dir->dirs = malloc(sizeof(struct Dir));
}

static void adic_arq(struct Dir *dir, char *nome, int tam) {
	if(dir->uso_arqs == dir->cap_arqs) {
		int i;
		struct Arq *nv;
		dir->cap_arqs = dir->cap_arqs * 2;
		nv = malloc(dir->cap_arqs * sizeof(struct Arq));
		for(i = 0; i < dir->uso_arqs; i++) {
			nv[i] = dir->arqs[i];
		}
		free(dir->arqs);
		dir->arqs = nv;
	}
	strcpy(dir->arqs[dir->uso_arqs].nome, nome);
	dir->arqs[dir->uso_arqs].tam = tam;
	dir->uso_arqs = dir->uso_arqs + 1;
}

static void adic_dir(struct Dir *dir, char *nome) {
	if(dir->uso_dirs == dir->cap_dirs) {
		int i;
		struct Dir *nv;
		dir->cap_dirs = dir->cap_dirs * 2;
		nv = malloc(dir->cap_dirs * sizeof(struct Dir));
		for(i = 0; i < dir->uso_dirs; i++) {
			nv[i] = dir->dirs[i];
		}
		free(dir->dirs);
		dir->dirs = nv;
	}
	init_dir(&(dir->dirs[dir->uso_dirs]), nome);
	dir->uso_dirs = dir->uso_dirs + 1;
}

static int kbytes_usados(struct Dir *dir) {
	int i;
	int total = 0;
	for(i = 0; i < dir->uso_arqs; i++) {
		total = total + dir->arqs[i].tam;
	}
	for(i = 0; i < dir->uso_dirs; i++) {
		struct Dir *subdir = &(dir->dirs[i]);
		total = total + kbytes_usados(subdir);
	}
	return total;
}

/* retorna um ponteiro para o diret�rio de nome "nome" em
   dir, ou 0 se n�o achar */
static struct Dir *busca_dir(struct Dir *dir, char *nome) {
	if(strcmp(dir->nome, nome) == 0) { /* caso base */
		return dir;
	} else {
		int i;
		for(i = 0; i < dir->uso_dirs; i++) {
			struct Dir *achado = busca_dir(&(dir->dirs[i]), nome);
			if(achado) {
				return achado;
			}
		}
		return 0;
	}
}

static struct Arq *busca_arq(struct Dir *dir, char *nome) {
	int i;
	for(i = 0; i < dir->uso_arqs; i++) {
		if(strcmp(dir->arqs[i].nome, nome) == 0) {
			return &(dir->arqs[i]);
		}
 	}
 	for(i = 0; i < dir->uso_dirs; i++) {
		struct Arq *achado = busca_arq(&(dir->dirs[i]), nome);
		if(achado) {
			return achado;
		}
 	}
 	return 0;
}

/* busca a n-�sima ocorr�ncia de "nome", retorna 0 e 
  quantos achou se n�o havia um n�mero suficiente */
static struct Arq *busca_arqn(struct Dir *dir, char *nome, 
                              int n, int *achados) {
	int i;
	*achados = 0;
	for(i = 0; i < dir->uso_arqs; i++) {
		if(strcmp(dir->arqs[i].nome, nome) == 0) {
			if(n - *achados == 1) {
				return &(dir->arqs[i]);
			} else {
				*achados = *achados + 1;
			}
		}
 	}
	for(i = 0; i < dir->uso_dirs; i++) {
		int a;
		struct Arq *achado = busca_arqn(&(dir->dirs[i]), 
		                                nome, n - *achados, &a);
		if(achado) {
			return achado;
		}
		*achados = *achados + a;
	}
	return 0;
}

static struct Arq *busca_arqnn(struct Dir *dir, char *nome, int n) {
	int a;
	return busca_arqn(dir, nome, n, &a);
}

int main(int argc, char *argv[]) {
	struct Dir raiz;
	struct Arq *arq;
	int achados;
	init_dir(&raiz, "C:");
	adic_dir(&raiz, "Programas");
	adic_dir(&raiz, "Usuarios");
	adic_arq(&raiz, "config.ini", 1);
	adic_dir(&raiz.dirs[0], "Dev-Cpp");
	adic_dir(&(raiz.dirs[0]), "Powerpoint");
	adic_arq(&(raiz.dirs[0].dirs[0]), "devcpp.exe", 300);
	adic_arq(&(raiz.dirs[0].dirs[0]), "config.ini", 5);
	adic_arq(&(raiz.dirs[0].dirs[1]), "ppt.exe", 1500);
	adic_dir(&(raiz.dirs[1]), "Fabio");
	adic_dir(&(raiz.dirs[1]), "Publico");
	adic_arq(&(raiz.dirs[1]), "chaves.ini", 2);
	adic_arq(&(raiz.dirs[1]), "config.ini", 4);
	adic_arq(&(raiz.dirs[1].dirs[0]), "aula1.txt", 10);
	adic_arq(&(raiz.dirs[1].dirs[0]), "prog.c", 5);
	adic_arq(&(raiz.dirs[1].dirs[1]), "aula1.txt", 15);
	adic_arq(&(raiz.dirs[1].dirs[1]), "prog.c", 3);
	adic_arq(&(raiz.dirs[1].dirs[1]), "recursao.c", 15);
	printf("%s\n%s\n%s\n%s\n", raiz.arqs[0].nome, raiz.dirs[0].dirs[1].nome,
		raiz.dirs[1].dirs[1].arqs[0].nome, raiz.dirs[0].dirs[0].arqs[1].nome);
	printf("Usados: %d\n", kbytes_usados(busca_dir(&raiz, "Fabio")));
	printf("Diretorio: %p\n", busca_dir(&raiz, "Fabio"));
	printf("Diretorio: %p\n", busca_dir(&raiz, "Joao"));
	printf("Arquivo: %p\n", busca_arq(&raiz, "config.ini"));
	printf("Arquivo: %p\n", busca_arq(&raiz, "xyz.txt"));
	arq = busca_arqn(&raiz, "config.ini", 1, &achados);
	if(arq) { printf("Arquivo %s de tamanho %d\n", arq->nome, arq->tam); }
	arq = busca_arqn(&raiz, "config.ini", 2, &achados);
	if(arq) { printf("Arquivo %s de tamanho %d\n", arq->nome, arq->tam); }
	arq = busca_arqn(&raiz, "config.ini", 3, &achados);
	if(arq) { printf("Arquivo %s de tamanho %d\n", arq->nome, arq->tam); }
	arq = busca_arqn(&raiz, "config.ini", 4, &achados);
	if(arq) { printf("Arquivo %s de tamanho %d\n", arq->nome, arq->tam); }
	arq = busca_arqn(&raiz, "config.ini", 5, &achados);
	if(arq) { printf("Arquivo %s de tamanho %d\n", arq->nome, arq->tam); }
	printf("Achados %d\n", achados);
	return 0;
}
