#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <gui.h>

/*

Terceira Prova de Introdu��o � Programa��o C BCMT

Responda as quest�es abaixo programando as fun��es pedidas.
Voc� � livre para criar fun��es auxiliares, e testar suas
fun��es usando o console ou a interface gr�fica.

A prova � individual, e com consulta livre. A dura��o da
prova � de duas horas.

*/

/* Quest�o 1 - 2,0 pontos */

/* Implemente a fun��o abaixo, que inverte a cadeia
de caracteres passada como par�metro sem precisar
criar uma nova cadeia, trocando o primeiro caractere
com o �ltimo, o segundo com o pen�ltimo etc. N�o
use a fun��o strrev. */

static void inverte(char *s) {
	/* implemente aqui */
}

/* Uma matriz de n�meros reais 
pode ser representada por uma estrutura
contendo o n�mero de linhas e colunas e um vetor com
os elementos da matriz (esse vetor tem sempre tamanho
lins * cols): */

struct Matriz {
	int lins;
	int cols;
	double *nums;
};

/* A fun��o abaixo cria uma matriz com o n�mero de linhas
e colunas pedido. */

static struct Matriz *matriz_cria(int lins, int cols) {
	struct Matriz *m = malloc(sizeof(struct Matriz));
	m->lins = lins;
	m->cols = cols;
	m->nums = malloc(lins * cols * sizeof(double));
	return m;
}

/* Quest�o 2 - 3,0 pontos */

/* Implemente a fun��o abaixo, que multiplica duas matrizes
e retorna uma terceira matriz. O n�mero de linhas de m2
deve ser igual ao n�mero de colunas de m1, e a matriz
resultante tem o n�mero de linhas de m1 e o n�mero de colunas
de m2. 

  m1m2(i,j) = m1(i,0) * m2(0, j) + 
              m1(i, 1) * m2(1, j) + 
			  ... +
			  m1(i, m1->cols) * m2(m2->lins, j)

 */

static struct Matriz *matriz_mult(struct Matriz *m1, struct Matriz *m2) {
	/* implemente aqui */
}


/* Uma �rvore bin�ria � uma estrutura recursiva em
que cada parte � composta de um "r�tulo" e dois ramos,
o ramo esquerdo e o ramo direito. Cada ramo pode ser
0 ou apontar para uma �rvore bin�ria.

Se ambos os ramos de uma �rvore s�o 0 dizemos que ela
� uma "folha". */

struct ArvBin {
	char *rot; /* string */
	struct ArvBin *esq;
	struct ArvBin *dir;
}; 

/* A fun��o abaixo imprime o conte�do de uma �rvore,
usando par�nteses: (rotulo ramo-esq ramo-dir). Use
para depura��o de suas fun��es. */

static void imprime_arvore(struct ArvBin *arv) {
	printf("(%s", arv->rot);
	if(arv->esq) {
		printf(" ");
		imprime_arvore(arv->esq);
	}
	if(arv->dir) {
		printf(" ");
		imprime_arvore(arv->dir);
	}
	printf(")");
}

/* A fun��o abaixo que cria uma nova �rvore
dado seu r�tulo e seus ramos esquerdo e direito. */

static struct ArvBin *cria_arvore(char *rot, struct ArvBin *esq, struct ArvBin *dir) {
	struct ArvBin *arv = malloc(sizeof(struct ArvBin));
	arv->rot = rot;
	arv->esq = esq;
	arv->dir = dir;
	return arv;
}

/* Quest�o 3 (3,0 pontos) */

/* Implemente a fun��o, que desenha *apenas a raiz* de uma �rvore
como um ret�ngulo preto com uma borda branca de dois pixels de largura.
O espa�o entre o texto do r�tulo e as bordas do ret�ngulo deve ser de cinco
pixels. As coordenadas x e y dadas s�o as do canto superior esquerdo
do ret�ngulo. O texto do r�tulo sempre tem 39 pixels de altura,
e a largura � de 24 pixels por caractere do texto. */

static void desenha_raiz(struct ArvBin *arv, int x, int y) {
	/* implemente aqui */
}

/* Quest�o 4 - 2,0 pontos */

/* Implemente a fun��o abaixo, que desenha a �rvore inteira.
A posi��o x dada � a do centro horizontal da raiz, 
e a posi��o y dada � a do lado superior:

               X
      Y +-------------+
        | Rotulo Raiz |
        +-------------+

Use a fun��o da quest�o 2 para desenhar a raiz.
O ramo esquerdo deve ser desenhado com centro horizontal 100 pixels
� esquerda do *lado esquerdo* da raiz e lado superior
100 pixels abaixo do *lado inferior* da raiz. O ramo direito
deve ser desenhado com centro horizontal 100 pixels � direita
do lado direito da raiz e lado superior 100 pixels abaixo do 
lado inferior da raiz. */

static void desenha_arvore(struct ArvBin *arv, int x, int y) {
	/* implemente aqui */
}

/* Fim das quest�es */

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Terceira Prova de IntroC BCMT";
	*largura = 1024;
	*altura = 768;
	/* Esse � um bom lugar para testar fun��es que
	podem ser testadas no console, usando scanf e printf */
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
}

void gui_desenhar() {
	tela_texto(10, 10, "Terceira Prova Introc", 1.0, 1.0, 1.0);
}

