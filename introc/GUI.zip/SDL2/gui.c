#include <stdio.h>
#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#include "gui.h"
#include "gfxprim.h"

#include "fonte.h"

static SDL_Renderer *ren;
static int quit = 0;

void tela_ret(int x, int y, int larg, int alt, double r, double g, double b) {
	boxRGBA(ren, x, y, x + larg, y + alt, r * 255, g * 255, b * 255, 255);
}

void tela_elipse(int x, int y, int rx, int ry, double r, double g, double b) {
	filledEllipseRGBA(ren, x, y, rx, ry, 255 * r, 255 * g, 255 * b, 255);
}

void tela_circ(int x, int y, int raio, double r, double g, double b) {
	tela_elipse(x, y, raio, raio, r, g, b);
}

void tela_triang(int x1, int y1, int x2, int y2, int x3, int y3, double r, double g, double b) {
	filledTrigonRGBA(ren, x1, y1, x2, y2, x3, y3, 255 * r, 255 * g, 255 * b, 255);
}

void tela_texto(int x, int y, String txt, double r, double g, double b) {
	stringRGBA(ren, x, y, txt, 255 * r, 255 * g, 255 * b, 255);
}

void tela_letra(int x, int y, char c, double r, double g, double b) {
	characterRGBA(ren, x, y, c, 255 * r, 255 * g, 255 * b, 255);
}

static String nome_tecla(int mod, SDL_Keycode code) {
	static char nome[255];
	strcpy(nome, "");
	if(mod & KMOD_CTRL) {
		strcat(nome, "Ctrl-");
	}
	if(mod & KMOD_ALT) {
		strcat(nome, "Alt-");
	}
	if(mod & KMOD_SHIFT) {
		strcat(nome, "Shift-");
	}
	strcat(nome, SDL_GetKeyName(code));
	return nome;
}

void gui_quit() {
	quit = 1;
}

static struct {
	const char *arq;
	Mix_Chunk *wav;
} wavs[20];

static int nwavs = 0;

void som_tocar(String arqwav) {
	int i;
	Mix_Chunk *wav = NULL;
	for(i = 0; i < nwavs; i++) {
		if(wavs[i].arq == arqwav) {
			wav = wavs[i].wav;
		}
	}
	if(wav == NULL) {
		if(nwavs == 20) {
			puts("Acabou o espa�o para samples de som!");
			return;
		}
		wav = Mix_LoadWAV(arqwav);
		if(wav == NULL) {
			printf("Failed to load scratch sound effect! SDL_mixer Error: %s\n", Mix_GetError());
			return;
		}
		nwavs++;
		wavs[nwavs].arq = arqwav;
		wavs[nwavs].wav = wav;		
	}
	Mix_PlayChannel(-1, wav, 0);
}

static void cleanup() {
	int i;
	for(i = 0; i < nwavs; i++) {
		Mix_FreeChunk(wavs[i].wav);
	}
   	Mix_Quit();
	SDL_Quit();
}

int main(int argc, char **argv) {
	String titulo;
	int largura, altura;
	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		printf("SDL_Init error: %d\n", SDL_GetError());
		return 1;
	}
	if(Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0) {
        printf("SDL_mixer Error: %s\n", Mix_GetError() );
		SDL_Quit();
    	return 1;
    }
	SDL_Rect r;
	if (SDL_GetDisplayBounds(0, &r) != 0) {
    	printf("SDL_GetDisplayBounds failed: %s", SDL_GetError());
    	cleanup();
    	return 1;
	}	
	gui_init(&titulo, &largura, &altura);
	SDL_Window *win = SDL_CreateWindow(titulo, (r.w - largura)/2,
		(r.h - altura)/2, largura, altura, SDL_WINDOW_SHOWN);
	if (win == NULL){
		printf("SDL_CreateWindow error: %d\n", SDL_GetError());
    	cleanup();
		return 1;
	}
	ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (ren == NULL){
		printf("SDL_CreateRenderer error: %d\n", SDL_GetError());
    	cleanup();
		return 1;
	}
	gfxPrimitivesSetFont(font24x39, 24, 39);
	SDL_Event e;
	int t1 = SDL_GetTicks();
	while (!quit){
		while (SDL_PollEvent(&e)){
			if (e.type == SDL_QUIT){
				gui_quit();
			}
			if (e.type == SDL_KEYDOWN){
				gui_tecla(nome_tecla(e.key.keysym.mod, e.key.keysym.sym), 0);
			}
			if (e.type == SDL_KEYUP){
				gui_tecla(nome_tecla(e.key.keysym.mod, e.key.keysym.sym), 1);
			}
			if (e.type == SDL_MOUSEBUTTONDOWN){
				switch(e.button.button) {
				case SDL_BUTTON_LEFT:
					gui_mouse(e.button.x, e.button.y, 0, 0);
					break;
				case SDL_BUTTON_RIGHT:
					gui_mouse(e.button.x, e.button.y, 1, 0);
					break;
				}
			}
			if (e.type == SDL_MOUSEBUTTONUP){
				switch(e.button.button) {
				case SDL_BUTTON_LEFT:
					gui_mouse(e.button.x, e.button.y, 0, e.button.clicks);
					break;
				case SDL_BUTTON_RIGHT:
					gui_mouse(e.button.x, e.button.y, 1, e.button.clicks);
					break;
				}
			}
			if (e.type == SDL_MOUSEMOTION){
				if(e.motion.state & SDL_BUTTON_LMASK) {
					gui_mouse(e.motion.x, e.motion.y, 0, 0);
				} else if(e.motion.state & SDL_BUTTON_RMASK) {
					gui_mouse(e.motion.x, e.motion.y, 1, 0);
				}
			}
		}
		int t2 = SDL_GetTicks();
		gui_tique((t2 - t1)/1000.0);
		t1 = t2;
		SDL_SetRenderDrawColor(ren, 0, 0, 0, 255);
		SDL_RenderClear(ren);
  		gui_desenhar();
        SDL_RenderPresent(ren);
        SDL_Delay(1);
	}
   	cleanup();
	return 0;
}
