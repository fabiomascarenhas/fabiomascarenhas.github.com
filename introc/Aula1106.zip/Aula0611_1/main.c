#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gui.h>

struct Cor {
	double r;
	double g;
	double b;
};

struct Ponto {
	int x;
	int y;
};

struct Ret {
	struct Ponto canto;
	struct Cor cor;
};

static struct Cor AZUL = { 0.0, 0.0, 1.0 };
static struct Cor BRANCO;

struct VetDin {
	int cap;
	int uso;
	struct Ret vet[1]; /* vetor dos ret�ngulos */
};
 
static struct VetDin *init_vetdin() {
	struct VetDin *vet = malloc(sizeof(struct VetDin));	
	vet->cap = 1;
	vet->uso = 0;
} 

static struct VetDin* adic_vetdin(struct VetDin *vet, struct Ret *x) {
	if(vet->uso == vet->cap) { /* acabou o espa�o */
		struct VetDin *nv;
		int i;
		int ncap = vet->cap * 2;
		nv = malloc(sizeof(struct VetDin) +
		            (ncap - 1) * sizeof(struct Ret));
		nv->cap = ncap;
		nv->uso = vet->uso;
		for(i = 0; i < nv->uso; i++) {
			nv->vet[i] = vet->vet[i];
		}
		free(vet);
		vet = nv;
	}
	vet->vet[vet->uso] = *x;
	vet->uso = vet->uso + 1;
}

static int remove_vetdin(struct VetDin *vet, int i) {
	int j;
	for(j = i + 1; j < vet->uso; j++) {
		vet->vet[j-1] = vet->vet[j];
	}
	vet->uso = vet->uso - 1;
}

static void cor_aleat(double *r, double *g, double *b) {
	*r = rand() * 1.0 / RAND_MAX;
	*g = rand() * 1.0 / RAND_MAX;
	*b = rand() * 1.0 / RAND_MAX;
}

static void retangulo(struct Ponto *p, int larg, int alt,
	                  struct Cor *c) {
    tela_ret(p->x, p->y, larg, alt, c->r, c->g, c->b);
}

static struct VetDin *retangulos[3];
static int atual = 0;

void gui_init(String *titulo, int *largura, int *altura) {
	int i;
	*titulo = "Hello World";
	*largura = 800;
	*altura = 600;
	for(i = 0; i < 3; i++) {
		retangulos[i] = init_vetdin();
	}
	/*BRANCO.r = 1.0;
	BRANCO.g = 1.0;
	BRANCO.b = 1.0;*/
	cor_aleat(&BRANCO.r, &BRANCO.g, &BRANCO.b);
}

void gui_tecla(String tecla, int soltou) {
	if(tecla[0] >= '1' && tecla[0] <= '3' && soltou) {
		atual = tecla[0] - '1';   	
	}
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
	if(botao == 0 && soltou == 1) {
		/* soltou bot�o esquerdo */
		struct Ret r;
		r.canto.x = x;
		r.canto.y = y;
		r.cor.r = rand() * 1.0 / RAND_MAX;
		r.cor.g = rand() * 1.0 / RAND_MAX;
		r.cor.b = rand() * 1.0 / RAND_MAX;
		retangulos[atual] = adic_vetdin(retangulos[atual], &r);
	} else if(botao == 1 && soltou == 1) {
		/* soltou bot�o direito */
		int i;
		for(i = 0; i < retangulos[atual]->cap; i++) {
			if(x >= retangulos[atual]->vet[i].canto.x &&
			   y >= retangulos[atual]->vet[i].canto.y &&
			   x < retangulos[atual]->vet[i].canto.x + 50 &&
			   y < retangulos[atual]->vet[i].canto.y + 30) {
			    remove_vetdin(retangulos[atual], i);
			    break;
			}
		}
	}
}

static void desenha_cadeias(int x, int y, char **vs) {
	/* �ltima cadeia de vs � a cadeia vazia */
	for(; **vs != 0; vs++, y += 50) {
		/* vs++ avan�a para a pr�xima cadeia */
		/* **vs l� o primeiro caractere da cadeia atual */
		/* *vs l� a cadeia atual */
		tela_texto(x, y, *vs, 1, 1, 1);
	}
}

void gui_desenhar() {
	int i;
	char s[10];
	/*desenha_cadeias(50, 50, cadeias);*/
	for(i = 0; i < retangulos[atual]->uso; i++) {
		retangulo(&retangulos[atual]->vet[i].canto, 50, 30,
		          &retangulos[atual]->vet[i].cor);
	}
	sprintf(s, "cap: %d", retangulos[atual]->cap);
	tela_texto(10, 10, s, AZUL.r, AZUL.g, AZUL.b);
	sprintf(s, "uso: %d", retangulos[atual]->uso);
	tela_texto(10, 50, s, BRANCO.r, BRANCO.g, BRANCO.b);
	sprintf(s, "atual: %d", atual);
	tela_texto(10, 100, s, BRANCO.r, BRANCO.g, BRANCO.b);
	/*tela_ret(X, 100, 200, 300, 0, 0, 1);
	tela_circ(X + 200, 300, 50, 1, 0, 0);
	tela_elipse(X + 400, 200, 50, 100, 0, 1, 0);
	tela_triang(X + 300, 100, X + 100, 150, X + 500, 150, 1, 1, 0);
	tela_texto(X, 500, "Hello World", 1, 1, 1);
	tela_letra(X + 300, 500, 'A', 1, 1, 1);*/
}

