#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gui.h>

#define PI 3.1415927

struct Ponto {
	double x;
	double y;
};

struct Cor {
	double r;
	double g;
	double b;
};

struct Caixa {
	struct Ponto cse;
	struct Ponto cid;
};

struct Ast {
	char tag;
	struct Ponto pos;
	struct Cor cor;
	double vx;
	double vy;
	struct Caixa bb;
	int tam;
};

struct Nave {
	char tag;
	struct Ponto pos;
	struct Cor cor;
	double vx;
	double vy;
	struct Caixa bb;
	double dir;
	int vidas;
};

struct Tiro {
	char tag;
	struct Ponto pos;
	struct Cor cor;
	double vx;
	double vy;
	struct Caixa bb;
	struct Nave *nave;
};

struct AstExtras {
	int tam;
};

struct NaveExtras {
	double dir;
	int vidas;
};

struct TiroExtras {
	struct Nave *nave;
};

union Extras {
	struct AstExtras a;
	struct NaveExtras n;
	struct TiroExtras t;
};

struct Obj {
	char tag;
	struct Ponto pos;
	struct Cor cor;
	double vx;
	double vy;
	struct Caixa bb;
	union Extras u;
};

struct VetDin {
	int cap;
	int uso;
	struct Obj *vet; /* vetor dos objetos */
};
 
static void init_vetdin(struct VetDin *vet) {
	vet->cap = 1;
	vet->uso = 0;
	vet->vet = malloc(sizeof(struct Obj));
} 

static void adic_vetdin(struct VetDin *vet, struct Obj *x) {
	if(vet->uso == vet->cap) { 
		struct Obj *nv;
		int i;
		vet->cap = vet->cap * 2;
		nv = malloc(vet->cap * sizeof(struct Obj));
		for(i = 0; i < vet->uso; i++) {
			nv[i] = vet->vet[i];
		}
		free(vet->vet);
		vet->vet = nv;
	}
	vet->vet[vet->uso] = *x;
	vet->uso = vet->uso + 1;
}

static int remove_vetdin(struct VetDin *vet, int i) {
	int j;
	for(j = i + 1; j < vet->uso; j++) {
		vet->vet[j-1] = vet->vet[j];
	}
	vet->uso = vet->uso - 1;
}

static struct VetDin objetos;

void gui_init(String *titulo, int *largura, int *altura) {
	struct Ast a;
	struct Nave n;
	struct Tiro t;
	*titulo = "Asteroids";
	*largura = 800;
	*altura = 600;
	init_vetdin(&objetos);
	a.tag = 'A';
	a.pos.x = 50;
	a.pos.y = 200;
	a.cor.r = 1.0;
	a.cor.g = 0.0;
	a.cor.b = 0.0;
	a.tam = 2;
	adic_vetdin(&objetos, (struct Obj*)&a);
	n.tag = 'N';
	n.pos.x = 200;
	n.pos.y = 50;
	n.cor.r = 0.0;
	n.cor.g = 0.0;
	n.cor.b = 1.0;
	n.dir = PI/2;
	adic_vetdin(&objetos, (struct Obj*)&n);
	t.tag = 'T';
	t.pos.x = 100;
	t.pos.y = 100;
	t.cor.r = 1.0;
	t.cor.g = 1.0;
	t.cor.b = 1.0;
	adic_vetdin(&objetos, (struct Obj*)&t);
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int soltou) {
}

static void desenha_ast(struct Ast *a) {
	tela_circ(a->pos.x, a->pos.y, a->tam*5,
	          a->cor.r, a->cor.g, a->cor.b);
}

static void desenha_nave(struct Nave *n) {
	int x1 = n->pos.x + 8*cos(n->dir);
	int y1 = n->pos.y - 8*sin(n->dir);
	int x2 = n->pos.x - 5*cos(n->dir) - 5*sin(n->dir);
	int y2 = n->pos.y + 5*sin(n->dir) - 5*cos(n->dir);
	int x3 = n->pos.x - 5*cos(n->dir) + 5*sin(n->dir);
	int y3 = n->pos.y + 5*sin(n->dir) + 5*cos(n->dir);
	tela_triang(x1, y1, x2, y2, x3, y3,
	            n->cor.r, n->cor.g, n->cor.b);
}

static void desenha_tiro(struct Tiro *t) {
	tela_circ(t->pos.x, t->pos.y, 2, t->cor.r,
	          t->cor.g, t->cor.b);
}

static void desenha_obj(struct Obj *o) {
	if(o->tag == 'A') {
		desenha_ast((struct Ast*)o);
	} else if(o->tag == 'N') {
		desenha_nave((struct Nave*)o);
	} else {
		desenha_tiro((struct Tiro*)o);
	}
}

void gui_desenhar() {
	int i;
	for(i = 0; i < objetos.uso; i++) {
		desenha_obj(&objetos.vet[i]);
	}
}

