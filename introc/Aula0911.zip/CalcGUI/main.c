#include <string.h>
#include <gui.h>
#include <stdio.h>

#define NBOT 20
#define COLS 4
#define LINS 5
#define TAMBOT 60

static String botoes[] = {
	"M+", "M-",	"MC", "C",
	"7", "8", "9", "/",
	"4", "5", "6", "*",
	"1", "2", "3", "-",
	"+-", "0", "ST", "+"
};
static int apertado = -1;
static int saiu = 0;

static void desenha_botao(int i) {
	int x = (i % COLS) * TAMBOT;
	int y = (i / COLS + 1) * TAMBOT;
	int x_texto = x + 8;
	if(strlen(botoes[i]) == 1) {
		x_texto = x_texto + 12;
	}
	tela_ret(x, y, TAMBOT, TAMBOT, 1, 1, 1);
	if(apertado == i && !saiu) {
		tela_texto(x_texto, y + 15, botoes[i], 0, 0, 0);
	} else {
		tela_ret(x + 3, y + 3, TAMBOT - 6, TAMBOT - 6, 0, 0, 0);
		tela_texto(x_texto, y + 12, botoes[i], 1, 1, 1);
	}
}

static int no_botao(int x, int y, int bot) {
	int xbot = (bot % COLS) * TAMBOT;
	int ybot = (bot / COLS + 1) * TAMBOT;
	return (x >= xbot) && (x < xbot + TAMBOT) &&
	       (y >= ybot) && (y < ybot + TAMBOT);
}

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Calculadora";
	*altura = LINS * TAMBOT + TAMBOT;
	*largura = COLS * TAMBOT;
}

void gui_tecla(String tecla, int soltou) {
}

void gui_tique(double dt) {
}

void gui_mouse(int x, int y, int botao, int cliques) {
	if(cliques == 0) { /* apertou */
		if(apertado == -1) {
  		    int i = 0;
		    while(i < NBOT) {
			    if(no_botao(x, y, i)) {
				    apertado = i;
				    return;
			    }
			    i = i + 1;
		    }
		} else if(!no_botao(x, y, apertado)) {
				saiu = 1;
		} else {
			saiu = 0;
		}
	} else { /* soltou */
		if(no_botao(x, y, apertado)) {
			printf("Botao %d\n", apertado);
		}
		apertado = -1;
		saiu = 0;
	}
}

void gui_desenhar() {
	int i = 0;
	while(i < NBOT) {
		desenha_botao(i);
		i = i + 1;
	}
}

