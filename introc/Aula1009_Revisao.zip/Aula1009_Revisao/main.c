#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/* O m�ximo divisor comum entre dois n�meros inteiros mdc(x,y)
pode ser dado pelo "algoritmo de euclides": assumindo que
x � maior que y,
 
se x � divis�vel por y ent�o y � o mdc(x,y).
Sen�o fa�a x ser igual a y, e y ser igual ao resto da divis�o
entre o x original e y, e tente de novo. OU

Enquanto x n�o for divis�vel por y, fa�a x ser igual a y, e 
y ser igual ao resto da divis�o entre o x original e y.
Ao final, o mdc � y.
*/
static int mdc(int x, int y) {
	int r = x % y; /* se x < y ent�o r ser� x */
	while(r != 0) {
		x = y;
		y = r;
		r = x % y;
	}
	return y;
}

/*
O m�ximo divisor comum de tres numeros inteiros positivos, MDC3(x,y,z),
� igual a MDC(MDC(x,y),z). Escreva uma fun��o que recebe tr�s
n�meros inteiros positivos e retorna o mdc deles, usando uma
fun��o mdc j� definida.
*/
static int mdc3(int x, int y, int z) {
	return mdc(mdc(x,y), z);
}

static double abs_real(double x) {
	if(x < 0) {
		return -x;
	} else {
		return x;
	}
}

static double erro_raiz(double palpite, double x) {
	return abs_real(x - palpite * palpite);
}

/* raiz quadrada de um n�mero real x */
static double raiz(double x) {
	double palpite = 1;
	while(erro_raiz(palpite, x) > 0.000001) {
		palpite = (palpite + x/palpite)/2;
	}
	return palpite;
}

/* Determina se o n�mero inteiro � primo ou n�o;
um n�mero N�O � primo se ele for divis�vel
por qualquer n�mero entre 2 e a sua raiz quadrada
(inclusive!) */
static int primo(int n) {
	int i;
	int r = raiz(n);
	for(i = 2; i <= r; i++) {
		if(n % i == 0) {
			return 0;
		}
	}
	return 1;
}

/* Retorna o n-�simo n�mero de fibonacci.
O primeiro n�mero de fibonacci � 1, o segundo
tamb�m � 1, o terceiro � o primeiro mais o segundo,
o quarto � o segundo mais o terceiro, o quinto
� o terceiro mais o quarto...

a = 0  1          1          2          3          5
b = 1  0 + 1 (1)  1 + 1 (2)  2 + 1 (3)  3 + 2 (5)  5 + 3 (8)

 */
static int fib(int n) {
	int a = 0;
	int b = 1;
	/* la�o de n voltas */
	for(; n > 0; n--) {
		int velho_a = a;
		a = b;
		b = velho_a + b;
	}
	return a;	
}

/*
  Calcula o histograma das letras de uma cadeia de caracteres
  s. O histograma d� a quantidade de vezes que cada letra
  aparece na cadeia. O vetor de inteiros que vai receber o
  histograma tamb�m � passado para a fun��o, e ela pode assumir
  que ele tem 26 elementos, mas n�o deve assumir que todos eles
  foram inicializados com 0
*/
static void histograma(char s[], int h[]) {
	int i;
	/* zera vetor h */
	for(i = 0; i < 26; i++) {
		h[i] = 0;
	}
	/* conta letras em s */
	for(i = 0; s[i] != 0; i++) {
		/* s[i] � uma letra de s */
		int l = s[i];
		if(l >= 'A' && l <= 'Z') {
			/* l � uma letra mai�scula */
			h[l - 'A']++;
		}
		if(l >= 'a' && l <= 'z') {
			h[l - 'a']++;
		}
	}
}

#define TEXTO "Calcula o histograma das letras de uma cadeia de caracteres \
s. O histograma da a quantidade de vezes que cada letra \
aparece na cadeia. O vetor de inteiros que vai receber o \
histograma tambem e passado para a funcao, e ela pode assumir \
que ele tem 26 elementos, mas nao deve assumir que todos eles \
foram inicializados com 0."

int main() {
	int a, b;
	puts("Entre dois numeros inteiros: ");
	scanf("%d %d", &a, &b);
	printf("mdc(%d,%d) = %d\n", a, b, mdc(a, b));
	printf("raiz(%d) = %lf, %lf\n", b, raiz(b), sqrt(b));
	if(primo(b)) {
		printf("%d e primo\n", b);
	} else {
		printf("%d nao e primo\n", b);
	}
	int i;
	for(i = 1; i <= 10; i++) {
		printf("fib(%d) = %d\n", i, fib(i));
	}
	int h[26];
	histograma(TEXTO, h);
	for(i = 0; i < 26; i++) {
		int j;
		printf("%c ", 'A' + i);
		for(j = 0; j < h[i]; j++) {
			printf("*");
		}
		printf("\n");
	}
	return 0;
}

