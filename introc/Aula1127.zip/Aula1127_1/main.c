#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Lista {
   int primeiro;
   struct Lista *resto;
};

static struct Lista *cria_lista(int primeiro, struct Lista *resto) {
	/* Alocar a nova lista */
	struct Lista *l = malloc(sizeof(struct Lista));
	l->primeiro = primeiro;
	l->resto = resto;
	return l;
}

static int tamanho(struct Lista *l) {
	if(l == 0) {
		return 0; /* lista vazia tem tamanho 0 */
	} else {
		return 1 + tamanho(l->resto);
	}
}

static int tamanho_loop(struct Lista *l) {
	int t = 0;
	while(l) {
		t = t + 1;
		l = l->resto;
	}
	return t;
}

static void lista_para_str(char *s, struct Lista *l) {
	if(l == 0) {
		sprintf(s, "");
	} else {
		sprintf(s, "%d ", l->primeiro);
		lista_para_str(s + strlen(s), l->resto);
	}
}

static void lista_para_str_loop(char *s, struct Lista *l) {
	sprintf(s, "");
	while(l) {
		sprintf(s, "%d ", l->primeiro);
		s = s + strlen(s);
		l = l->resto;
	}
}

static int soma(struct Lista *l) {
	if(l == 0) {
		return 0; /* lista vazia tem soma 0 */
	} else {
		return l->primeiro + soma(l->resto);
	}
}

static int soma_loop(struct Lista *l) {
	int s = 0;
	while(l) {
		s = s + l->primeiro;
		l = l->resto;
	}
	return s;
}

static int produto(struct Lista *l) {
	if(l == 0) {
		return 1; /* lista vazia tem produto 1 */
	} else {
		return l->primeiro * produto(l->resto);
	}
}

static int contem(struct Lista *l, int i) {
	if(l == 0) {
		return 0;
	} else if(i == l->primeiro) {
		return 1;
	} else {
		return contem(l->resto, i);
	}
}

static int elemento(struct Lista *l, int i) {
	if(l == 0) {
		return 0; /* erro! */
	} else if(i == 0) {
		return l->primeiro;
	} else {
		return elemento(l->resto, i-1);
	}
}

static int elemento_loop(struct Lista *l, int i) {
	int elem;
	do {
		elem = l->primeiro;
		i = i - 1;
		l = l->resto;
	} while(i);
	return elem;
}

static struct Lista *duplica(struct Lista *l) {
	if(l == 0) {
		return 0;
	} else {
		return cria_lista(l->primeiro, duplica(l->resto));
	}
}

static struct Lista *duplica_loop(struct Lista *l) {
	if(l == 0) {
		return 0;
	}
	struct Lista *nl = cria_lista(l->primeiro, 0);
	struct Lista *prox = nl;
	while(l->resto) {
		prox->resto = cria_lista(l->resto->primeiro, 0);
		prox = prox->resto;
		l = l->resto;
	}
	return nl;
}

static struct Lista *concatena(struct Lista *l1, struct Lista *l2) {
	if(l1 == 0) {
		return duplica(l2);
	} else if(l2 == 0) {
		return duplica(l1);
	} else {
		return cria_lista(l1->primeiro, concatena(l1->resto, l2));
	}
}

static struct Lista *concatena_loop(struct Lista *l1, struct Lista *l2) {
	if(l1 == 0) {
		return duplica_loop(l2);
	} else if(l2 == 0) {
		return duplica_loop(l1);
	} else {
		struct Lista *nl = cria_lista(l1->primeiro, 0);
		struct Lista *prox = nl;
		while(l1->resto) {
			prox->resto = cria_lista(l1->resto->primeiro, 0);
			prox = prox->resto;
			l1 = l1->resto;
		}
		while(l2) {
			prox->resto = cria_lista(l2->primeiro, 0);
			prox = prox->resto;
			l2 = l2->resto;
		}
		return nl;
	}
}

static struct Lista *insere_final(struct Lista *l, int i) {
	if(l == 0) {
		return cria_lista(i, 0);
	} else {
		l->resto = insere_final(l->resto, i);
		return l;
	}
}

static struct Lista *inverte(struct Lista *l) {
	if(l == 0) {
		return 0;
	} else {
		return insere_final(inverte(l->resto), l->primeiro);
	}
}

static struct Lista *merge(struct Lista *lord1, struct Lista *lord2) {
	if(lord1 == 0) {
		return duplica(lord2);
	} else if(lord2 == 0) {
		return duplica(lord1);
	} else {
		if(lord1->primeiro <= lord2->primeiro) {
			return cria_lista(lord1->primeiro, 
							  merge(lord1->resto, lord2));
		} else {
			return cria_lista(lord2->primeiro, 
							  merge(lord1, lord2->resto));
		}
	}
}

static struct Lista *zip(struct Lista *l1, struct Lista *l2) {
    if(l1 == 0 || l2 == 0) {
    	return 0;
	} else {
		return cria_lista(l1->primeiro, 
		       	          cria_lista(l2->primeiro,
									 zip(l1->resto, l2->resto)));

	}
}

static void free_lista(struct Lista *l) {
	if(l == 0) {
		return;
	} else {
		struct Lista *resto = l->resto;
		free(l); /* ponteiro "resto" continua v�lido! */
		free_lista(resto);
	}
}

int main(int argc, char *argv[]) {
	struct Lista *l1 = cria_lista(4, cria_lista(8, cria_lista(10, 
		cria_lista(14, 0))));
	printf("%d %d %d %d\n", l1->primeiro, l1->resto->primeiro,
		l1->resto->resto->primeiro, l1->resto->resto->resto->primeiro);
 	printf("tamanho: %d\n", tamanho(l1));
 	char s[100];
 	lista_para_str(s, l1->resto->resto);
 	printf("%s\n", s);
 	printf("soma: %d\n", soma(l1));
 	printf("produto: %d\n", produto(l1));
 	printf("%d %d %d\n", contem(l1, 4), contem(l1, 10), contem(l1, 5));
 	int i;
 	for(i = 0; i < tamanho(l1); i++) {
 		printf("i: %d, elemento: %d\n", i, elemento(l1, i));
 	}
	struct Lista *l2 = cria_lista(5, cria_lista(6, cria_lista(11, 
		cria_lista(15, 0))));
	struct Lista *l3 = concatena_loop(l1, l2);
	printf("%p %p\n", l2, l3->resto->resto->resto->resto);
	l2->primeiro = 3;
 	lista_para_str(s, l3);
 	printf("%s\n", s);
 	struct Lista *l4 = inverte(l3);
 	lista_para_str(s, l4);
 	printf("%s\n", s);
	l2->primeiro = 5;
	struct Lista *l5 = merge(l1, l2);
 	lista_para_str(s, l5);
 	printf("%s\n", s);
	struct Lista *l6 = zip(l1, l2);
 	lista_para_str(s, l6);
 	printf("%s\n", s);
	return 0;
}

