#include <stdio.h>
#include <stdlib.h>

static int ganhou(int r1, int r2, int r3, int r4) {
	return r1 && r2 && r3 && r4;
}

static int perdeu(int erros) {
	return erros > 3;
}

static void testa_letra(char letra, char pn, int *rn) {
    if(letra == pn) {
    	*rn = 1;
    }
}

static char letra_maiusc(char letra) {
	if(letra >= 'a' && letra <= 'z') {
		letra = letra - 32;
	}
	return letra;
}

static void rodada(char letra, char p1, char p2, char p3, char p4,
                   int *r1, int *r2, int *r3, int *r4, int *erros) {
	testa_letra(letra, p1, &*r1);
	testa_letra(letra, p2, &*r2);
	testa_letra(letra, p3, &*r3);
	testa_letra(letra, p4, &*r4);
    if(letra != p1 && letra != p2 && letra != p3 && letra != p4) {
    	*erros = *erros + 1;
    }
}

static void mostra_letra(char pn, int rn) {
	if(rn) {
		printf("%c", pn);
	} else {
		printf("_");
	}
}

static void tentativa(char p1, char p2, char p3, char p4,
                      int *r1, int *r2, int *r3, int *r4, int *erros) {
	char letra;
	printf("Advinhe uma letra: ");
	letra = letra_maiusc(getch());
	printf("%c\n", letra);
	rodada(letra, p1, p2, p3, p4, &*r1, &*r2, &*r3, &*r4, &*erros);
	mostra_letra(p1, *r1);
	mostra_letra(p2, *r2);
	mostra_letra(p3, *r3);
	mostra_letra(p4, *r4);
	printf("\nFaltam %d tentativas\n", 4 - *erros);
	if(ganhou(*r1, *r2, *r3, *r4)) {
		printf("Voce ganhou!");
		exit(0);
	}
	if(perdeu(*erros)) {
		printf("Voce perdeu!");
		exit(0);
	}
}

int main() {
	char p1 = 'A', p2 = 'B', p3 = 'R', p4 = 'A';
	int r1 = 0, r2 = 0, r3 = 0, r4 = 0;
	int erros = 0;
	
	puts("JOGO DA FORCA");
	puts("-------------");
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	tentativa(p1, p2, p3, p4, &r1, &r2, &r3, &r4, &erros);
	return 0;
}

