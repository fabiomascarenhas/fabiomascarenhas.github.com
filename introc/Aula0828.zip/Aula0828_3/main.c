#include <string.h>
#include <gui.h>

static char p1 = 'A', p2 = 'B', p3 = 'R', p4 = 'A';
static int r1 = 0, r2 = 0, r3 = 0, r4 = 0;
static int erros = 0;

static char ultima_letra = ' ';

static int ganhou() {
	return r1 && r2 && r3 && r4;
}

static int perdeu() {
	return erros > 3;
}

static void testa_letra(char letra, char pn, int *rn) {
	if(letra >= 'a' && letra <= 'z') {
		letra = letra - 32;
	}
    if(letra == pn) {
    	*rn = 1;
    }
}

static int e_letra(String s) {
	return (strlen(s) == 1) && 
		   ((strcmp(s, "A") >= 0) || (strcmp(s, "Z") <= 0));
}

/*
	Efeitos: modificar r1, r2, r3, r4 e erros
*/
static void rodada(char letra) {
	testa_letra(letra, p1, &r1);
	testa_letra(letra, p2, &r2);
	testa_letra(letra, p3, &r3);
	testa_letra(letra, p4, &r4);
    if(letra != p1 && letra != p2 && letra != p3 && letra != p4) {
    	erros = erros + 1;
    }
}

static void mostra_letra(char pn, int rn, int pos) {
	int x = 400 + pos * 50;
	int y = 300;
	if(rn) {
		tela_letra(x, y, pn, 1, 1, 1);
	} else {
		tela_letra(x, y, '_', 1, 1, 1);
	}
}

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Jogo da Forca";
	*largura = 1024;
	*altura = 768;
}

void gui_tecla(String tecla, int soltou) {
	if(!ganhou() && !perdeu()) {
		if(e_letra(tecla) && soltou) {
			rodada(tecla[0]);
			ultima_letra = tecla[0];
		}
	}
	if(strcmp(tecla, "Space") == 0 && soltou) {
		r1 = 0; r2 = 0; r3 = 0; r4 = 0;
		ultima_letra = ' ';
		erros = 0;
	}
}

void gui_tique(double dt) {}

void gui_mouse(int x, int y, int botao, int cliques) {}

void gui_desenhar() {
	tela_ret(100, 100, 200, 10, 1, 1, 1);
	tela_ret(200, 100, 2, 100, 1, 1, 1);
	if(erros > 0) {
		tela_circ(200, 220, 20, 1, 1, 1);
	}
	if(erros > 1) {
		tela_ret(200, 240, 2, 100, 1, 1, 1);		
	}
	if(erros > 2) {
		tela_ret(130, 280, 70, 2, 1, 1, 1);
		tela_ret(200, 280, 70, 2, 1, 1, 1);
	}
	if(erros > 3) {
		tela_triang(200, 340, 150, 420, 150, 420, 1, 1, 1);
		tela_triang(201, 341, 151, 421, 151, 421, 1, 1, 1);
		tela_triang(200, 340, 250, 420, 250, 420, 1, 1, 1);
		tela_triang(199, 341, 249, 421, 249, 421, 1, 1, 1);
	}
	tela_texto(400, 100, "Ultima letra: ", 1, 1, 1);
	tela_letra(730, 105, ultima_letra, 1, 1, 1);
	mostra_letra(p1, r1, 0);
	mostra_letra(p2, r2, 1);
	mostra_letra(p3, r3, 2);
	mostra_letra(p4, r4, 3);
	if(ganhou()) {
		tela_texto(400, 500, "Voce ganhou!", 0, 0, 1);
	}
	if(perdeu()) {
		tela_texto(400, 500, "Voce perdeu!", 1, 0, 0);
	}
}

