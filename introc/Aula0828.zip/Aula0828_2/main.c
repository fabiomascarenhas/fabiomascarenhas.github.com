#include <stdio.h>
#include <stdlib.h>

static char p1 = 'A', p2 = 'B', p3 = 'R', p4 = 'A';
static int r1 = 0, r2 = 0, r3 = 0, r4 = 0;
static int erros = 0;

static int ganhou() {
	return r1 && r2 && r3 && r4;
}

static int perdeu() {
	return erros > 3;
}

static void testa_letra(char letra, char pn, int *rn) {
    if(letra == pn) {
    	*rn = 1;
    }
}

static char letra_maiusc(char letra) {
	if(letra >= 'a' && letra <= 'z') {
		letra = letra - 32;
	}
	return letra;
}

/*
	Efeitos: modificar r1, r2, r3, r4 e erros
*/
static void rodada(char letra) {
	testa_letra(letra, p1, &r1);
	testa_letra(letra, p2, &r2);
	testa_letra(letra, p3, &r3);
	testa_letra(letra, p4, &r4);
    if(letra != p1 && letra != p2 && letra != p3 && letra != p4) {
    	erros = erros + 1;
    }
}

static void mostra_letra(char pn, int rn) {
	if(rn) {
		printf("%c", pn);
	} else {
		printf("_");
	}
}

/*
	Efeitos: modificar r1, r2, r3, r4 e erros
*/
static void tentativa() {
	char letra;
	printf("Advinhe uma letra: ");
	letra = letra_maiusc(getch());
	printf("%c\n", letra);
	rodada(letra); /* herdando efeitos de rodada */
	mostra_letra(p1, r1);
	mostra_letra(p2, r2);
	mostra_letra(p3, r3);
	mostra_letra(p4, r4);
	printf("\nFaltam %d tentativas\n", 4 - erros);
	if(ganhou()) {
		printf("Voce ganhou!");
		exit(0);
	}
	if(perdeu()) {
		printf("Voce perdeu!");
		exit(0);
	}
}

int main() {
	puts("JOGO DA FORCA");
	puts("-------------");
	tentativa();
	tentativa();
	tentativa();
	tentativa();
	tentativa();
	tentativa();
	tentativa();
	tentativa();
	return 0;
}

