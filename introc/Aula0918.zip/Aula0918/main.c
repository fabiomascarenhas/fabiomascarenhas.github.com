#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <gui.h>
#include <math.h>

#define HELI_VX 800
#define HELI_L 30
#define HELI_A 20

static double heli_x, heli_y;

#define BOMBA_VY 300
#define BOMBA_L 5
#define BOMBA_A 10

static double bomba_x, bomba_y;
static int tem_bomba;

static int score = 0;

static int game_over = 0;

#define BLOCO_L 30
#define BLOCO_A 30

#define NPREDIOS 20

static int predio_x[NPREDIOS];
static int predio_alt[NPREDIOS];
static double predio_r[NPREDIOS];
static double predio_g[NPREDIOS];
static double predio_b[NPREDIOS];
static int predio_telha[NPREDIOS];

/* n�mero aleat�rio no intervalo [0,max] */
static int rand_int(int max) {
	return round((rand() / (RAND_MAX * 1.0)) * 4);
}

void gui_init(String *titulo, int *largura, int *altura) {
	*titulo = "Chopper Drop";
	*largura = 800;
	*altura = 600;
	heli_x = 0;
	heli_y = 100;
	tem_bomba = 0;
	/* constr�i pr�dios */
	int i = 0;
	while(i < NPREDIOS) {
		predio_x[i] = (800 - NPREDIOS*30) / 2 + i * 30;
		predio_r[i] = rand() / (RAND_MAX * 1.0);
		predio_g[i] = rand() / (RAND_MAX * 1.0);
		predio_b[i] = rand() / (RAND_MAX * 1.0);
		predio_telha[i] = rand() % 2 == 0;
		predio_alt[i] = 2 + rand_int(4);
		i = i + 1;
	}
}

void gui_tecla(String tecla, int soltou) {
	if(game_over) {
		return;
	}
	/* soltar bomba */
	if(strcmp(tecla, "Space") == 0 && soltou && !tem_bomba) {
		tem_bomba = 1;
		bomba_x = heli_x + HELI_L / 2 - BOMBA_L / 2;
		bomba_y = heli_y + HELI_A - BOMBA_A;
	}
}

void gui_mouse(int x, int y, int botao, int soltou) {
}

static void move_heli(double dt) {
	/* dt est� em segundos */
	heli_x = heli_x + HELI_VX * dt;
	if(heli_x > 800) {
		heli_x = -HELI_L;
		heli_y = heli_y + HELI_A;
	}
}

/* testa se o ponto (x,y) est� dentro do ret�ngulo com canto
  (xr, yr) e largura l */
static int testa_colisao(double x, double y, double xr, double l, double yr) {
	return x >= xr && x < xr + l && y >= yr;
}

static void colisao_heli() {
	int i = 0;
	while(i < NPREDIOS) {
		double x = heli_x + HELI_L;
		double y = heli_y + HELI_A;
		int predio_y = 600 - predio_alt[i] * BLOCO_A;
		if(testa_colisao(x, y, predio_x[i], BLOCO_L, predio_y)) {
			game_over = 1;
		}
		i = i + 1;
	}
	if(heli_y > 600 - HELI_A) {
		game_over = 1;
	}
}

static void move_bomba(double dt) {
	bomba_y = bomba_y + BOMBA_VY * dt;
	if(bomba_y > 600 - BOMBA_A) {
		tem_bomba = 0;
	}
}


static void colisao_bomba() {
	int i = 0;
	while(i < NPREDIOS) {
		double x1 = bomba_x + BOMBA_L;
		double x2 = bomba_x;
		double y = bomba_y + BOMBA_A;
		int predio_y = 600 - predio_alt[i] * BLOCO_A;
		if(testa_colisao(x1, y, predio_x[i], BLOCO_L, predio_y) ||
				testa_colisao(x2, y, predio_x[i], BLOCO_L, predio_y)) {
			tem_bomba = 0;
			predio_alt[i] = predio_alt[i] - 3;
			predio_telha[i] = 0;
			score = score + 3;
		}
		i = i + 1;
	}
}

void gui_tique(double dt) {
	if(game_over) {
		return;
	}
	move_heli(dt);
	colisao_heli();
	if(tem_bomba) {
		move_bomba(dt);
		colisao_bomba();
	}
}

void gui_desenhar() {
	/* bomba */
	if(tem_bomba) {
		tela_ret(bomba_x, bomba_y, BOMBA_L, BOMBA_A, 1, 1, 1);
    }
	/* helic�ptero */
	tela_ret(heli_x, heli_y, HELI_L, HELI_A, 1, 0, 0);
	/* game over */
	if(game_over) {
		tela_texto(300, 250, "GAME OVER", 1, 1, 1);
	}
	/* score */
	if(score != 0) {
		char s[3];
		sprintf(s, "%d", score);
		tela_texto(750, 10, s, 1, 1, 1);
	}
	/* pr�dios */
	int i = 0;
	while(i < NPREDIOS) {
		int altura = predio_alt[i] * BLOCO_A;
		if(predio_telha[i]) {
			tela_triang(predio_x[i] + BLOCO_L / 2, 600 - altura, predio_x[i],
				600 - altura + BLOCO_A, predio_x[i] + BLOCO_L, 600 - altura + BLOCO_A,
				predio_r[i], predio_g[i], predio_b[i]);
			tela_ret(predio_x[i], 600 - altura + BLOCO_A, BLOCO_L, altura - BLOCO_A,
				predio_r[i], predio_g[i], predio_b[i]);
		} else {
			tela_ret(predio_x[i], 600 - altura, BLOCO_L, altura,
				predio_r[i], predio_g[i], predio_b[i]);
		}
		i = i + 1;
	}
	/*tela_ret(X, 100, 200, 300, 0, 0, 1);
	tela_circ(X + 200, 300, 50, 1, 0, 0);
	tela_elipse(X + 400, 200, 50, 100, 0, 1, 0);
	tela_triang(X + 300, 100, X + 100, 150, X + 500, 150, 1, 1, 0);
	tela_texto(X, 500, "Hello World", 1, 1, 1);
	tela_letra(X + 300, 500, 'A', 1, 1, 1);*/
}

