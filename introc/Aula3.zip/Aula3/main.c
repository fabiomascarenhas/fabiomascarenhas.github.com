#include <stdio.h>
#include <stdlib.h>

static int duplica(int x) {
	x = x * 2;
	return x;
}

static int hms_para_s(int h, int m, int s) {
	return h * 3600 + m * 60 + s;
}

static void divr(int a, int b, int* q, int* r) {
	*q = a / b;
	*r = a % b;
	printf("quociente: %d resto: %d\n", *q, *r);
}

/* 
  s � um par�metro de entrada
  th, tm, ts s�o par�metros de sa�da
*/
static void s_para_hms(int s, int *th, int *tm, int *ts) {
	divr(s, 3600, &*th, &s);
	divr(s, 60, &*tm, &*ts);
}

static int tempo_prova(int hp, int mp, int sp, int hc, int mc, int sc) {
	int tc = hms_para_s(hc, mc, sc);
	int tp = hms_para_s(hp, mp, sp);
	return tc - tp;
}

static int letra(char c) {
	int minusc = (c >= 'a') && (c <= 'z');
	int maiusc = (c >= 'A') && (c <= 'Z');
	return minusc || maiusc;
}

static double min(double a, double b) {
	if(a > b) {
		return b;
	} else {
		return a;
	}
}

static double media_final(double p1, double p2, double p3) {
	double menor = min(min(p1, p2), p3);
	double soma_maiores = p1 + p2 + p3 - menor;
	return soma_maiores / 2.0;
}

static int aprovado(double p1, double p2, double p3) {
	return media_final(p1, p2, p3) >= 5.0;
}

int main() {
	int hp, mp, sp, hc, mc, sc;
	int tprova;
	int h, m, s;
	char c;
	double p1, p2, p3;
	/*puts("De a hora, minuto e segundo de partida:");
	scanf("%d %d %d", &hp, &mp, &sp);
	puts("De a hora, minuto e segundo de chegada:");
	scanf("%d %d %d", &hc, &mc, &sc);
	tprova = tempo_prova(hp, mp, sp, hc, mc, sc);
	s_para_hms(tprova, &h, &m, &s);
	printf("Tempo de prova foi %d:%.2d:%.2d\n", h, m, s);*/
	/*puts("Entre uma letra");
	scanf("%c", &c);
	if(letra(c)) {
		puts("E' letra!");
	} else {
		puts("Nao e' letra!");
	}*/
	puts("Entre as notas:");
	scanf("%lf %lf %lf", &p1, &p2, &p3);
	if(aprovado(p1, p2, p3)){
		printf("Aprovado com media %.1lf\n", media_final(p1, p2, p3));
	} else {
		printf("Reprovado com media %.1lf\n", media_final(p1, p2, p3));
	}
	return 0;
}

