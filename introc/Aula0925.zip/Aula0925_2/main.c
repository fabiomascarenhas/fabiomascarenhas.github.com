#include <stdio.h>
#include <stdlib.h>

static int b = 3;

static double *pd;

static void errado(double x) {
	pd = &x; /* pondo endere�o local em ponteiro global! */
	printf("Voce passou: %lf\n", *pd);
}

/* Efeito: trocar os elementos i e j do vetor v */
static void troca(int v[], int i, int j) {
	int x = v[i];
	v[i] = v[j];
	v[j] = x;
}

static void divr(int a, int b, int* q, int* r) {
	*q = a / b;
	*r = a % b;
	printf("quociente: %d resto: %d\n", *q, *r);
}

static int* naturais(int n) {
	int *v = malloc(n * sizeof(int));
	int i;
	for(i = 0; i < n; i++) {
		v[i] = i + 1;
	}
	return v;
}

static void print_vetor(int v[], int n) {
	int i;
	for(i = 0; i < n; i++) {
		printf("%d ", v[i]);
    }
    printf("\n");
}

/* 
  s � um par�metro de entrada
  th, tm, ts s�o par�metros de sa�da
*/
static void s_para_hms(int s, int *th, int *tm, int *ts) {
	divr(s, 3600, th, &s);
	divr(s, 60, tm, ts);
}

int main() {
	int a = 5;
	int *p = &a; /* p � um endere�o para um int */
	printf("%p\n", p);
	printf("%d\n", *p);
	
	p = &b;
	printf("%p\n", p);
	printf("%d\n", *p);
	*p = *p * 2;
	printf("%d\n", b);
	
	int v[] = { 1, 2, 3, 4, 5 };
	p = v; /* p aponta para o primeiro elemento de v */
	printf("%d %d %d %d %d\n", *p, *(p+1), *(p+2), *(p+3), *(p+4));
    while(*p != 5) {
    	printf("%d\n", *p);
    	p = p + 1;
    }
  	printf("%d\n", *p);
  	/* p = p + 1;   inv�lido!! */
    while(*p != 1) {
    	printf("%d\n", *p);
    	p = p - 1;
    }
  	printf("%d\n", *p);

	s_para_hms(5000, &a, p, v); /* v � o mesmo que &v[0] */
	
	errado(5.3);
	printf("Oops!\n");
	printf("Voce passou: %lf\n", *pd); /* endere�o inv�lido!!! */
	int *v1 = naturais(10);
	printf("%d %d %d\n", v1[2], v1[4], v1[6]); /* v1[2] � o mesmo que *(v1+2) */
	print_vetor(v1, 10);
	/* v1 = 0; isso n�o libera a mem�ria reservada! */
	free(v1); /* v1 agora � um endere�o inv�lido */
	print_vetor(naturais(4), 4);
	return 0;
}
