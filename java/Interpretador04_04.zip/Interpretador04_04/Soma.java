public class Soma extends ExpressaoBinaria {
    public Soma(Expressao esq, Expressao dir) {
        super(esq, dir);
    }
    
    protected double op(double x, double y) {
        return x + y;
    }
    
    protected String opS() {
        return "+";
    }

    public double valor(java.util.HashMap<String,Double> vars) {
        return super.valor(vars) * 2;
    }
}
