public class Mult extends ExpressaoBinaria {
    public Mult(Expressao esq, Expressao dir) {
        super(esq, dir);
    }
    
    protected double op(double x, double y) {
        return x * y;
    }

    protected String opS() {
        return "*";
    }
}
