public class Num implements Expressao {
    double n;
    
    public Num(double n) {
        this.n = n;
    }
    
    public double valor(java.util.HashMap<String, Double> vars) {
        return n;
    }
    
    public String toString() {
        return "" + n;
    }

    public boolean equals(Object o) {
        if(o instanceof Num) {
            Num s = (Num)o;
            return n == s.n;
        } else return false;
    }
    
    public int hashCode() {
        return (int)n;
    }
}