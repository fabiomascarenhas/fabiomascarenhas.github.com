public abstract class ExpressaoBinaria implements Expressao {
    Expressao esq;
    Expressao dir;
    
    public ExpressaoBinaria(Expressao esq, Expressao dir) {
        this.esq = esq;
        this.dir = dir;
    }
    
    public double valor(java.util.HashMap<String, Double> vars) {
        // delegando para as subclasses
        return op(esq.valor(vars), dir.valor(vars));
    }

    public String toString() {
        return "(" + esq.toString() + opS() + dir.toString() + ")";
    }
    
    public boolean equals(Object o) {
        if(this.getClass().equals(o.getClass())) {
            ExpressaoBinaria s = (ExpressaoBinaria)o;
            return esq.equals(s.esq) && dir.equals(s.dir);
        } else return false;
    }
    
    public int hashCode() {
        return toString().hashCode();
    }
    
    protected abstract double op(double x, double y);
    protected abstract String opS();
}
