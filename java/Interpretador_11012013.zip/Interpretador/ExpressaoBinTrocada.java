
public abstract class ExpressaoBinTrocada extends ExpressaoBinaria
{
    public ExpressaoBinTrocada(Expressao esq, Expressao dir) {
        super(dir, esq);
    }

    public String toString() {
      return "(" + esq + "," + dir + ")";
    }

    // não preciso implementar o método op
    //public double valor() {
    //    return op(dir.valor(), esq.valor());
    //}
}
