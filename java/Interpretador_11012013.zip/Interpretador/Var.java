
public class Var implements Lvalue
{
    private String nome;
    private double val;

    public Var(String nome)
    {
        this.nome = nome;
    }

    public double valor() {
        return val;
    }
    
    public void atribui(double val) {
        this.val = val;
    }
    
    public String toString() {
        return "new Var(" + nome + ")";
    }
    
    public boolean equals(Object o) {
        if(o instanceof Var) {
            Var outro = (Var)o;
            return nome.equals(outro.nome);
        } else
            return false;
    }
}
