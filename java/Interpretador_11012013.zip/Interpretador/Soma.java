
public class Soma extends ExpressaoBinTrocada {
  public Soma(Expressao esq, Expressao dir) {
      super(esq, dir);
  }
  
  public double op(double a, double b) {
      return a + b;
  }
  
  public String toString() {
      return "Soma" + super.toString();
  }
}