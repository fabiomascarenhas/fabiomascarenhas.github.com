
public class Sub extends ExpressaoBinTrocada {
  public Sub(Expressao esq, Expressao dir) {
      super(esq, dir);
  }
  
  public double op(double a, double b) {
      return a - b;
  }
  
  public String toString() {
      return "Sub" + super.toString();
  }

}