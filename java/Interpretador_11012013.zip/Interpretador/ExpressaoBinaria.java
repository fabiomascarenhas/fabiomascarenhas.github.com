public abstract class ExpressaoBinaria implements Expressao {
  protected Expressao esq;
  protected Expressao dir;
  
  public ExpressaoBinaria(Expressao esq, Expressao dir) {
      this.esq = esq;
      this.dir = dir;
  }
  
  public double valor() {
      return op(esq.valor(), dir.valor());
  }
  
  public int hashCode() {
      return esq.hashCode() + dir.hashCode();
  }
    
  public boolean equals(Object o) {
      if(o instanceof ExpressaoBinaria) {
          ExpressaoBinaria outro = (ExpressaoBinaria)o;
          return this.getClass().equals(outro.getClass()) &&
            esq.equals(outro.esq) && dir.equals(outro.dir);
      } else
          return false;
  }  

  public abstract double op(double a, double b);
}