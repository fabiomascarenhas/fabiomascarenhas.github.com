
public class Num implements Expressao
{
    private double n;

    public Num(double n)
    {
        this.n = n;
    }

    public double valor() {
        return n;
    }
    
    public String toString() {
        return "new Num(" + n + ")";
    }
    
    public int hashCode() {
        return (int)n;
    }
    
    public boolean equals(Object o) {
        if(o instanceof Num) {
            Num outro = (Num)o;
            return n == outro.n;
        } else
            return false;
    }
}
