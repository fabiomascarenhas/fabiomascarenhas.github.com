public class Atrib
{
    private Lvalue lvalue;
    private Expressao rvalue;

    public Atrib(Lvalue lvalue, Expressao rvalue)
    {
        this.lvalue = lvalue;
        this.rvalue = rvalue;
    }

    public void executa() {
        lvalue.atribui(rvalue.valor());
    }

    public String toString() {
        return "new Atrib(" + lvalue + "," + rvalue + ")";
    }
    
    public boolean equals(Object o) {
        if(o instanceof Atrib) {
            Atrib outro = (Atrib)o;
            return lvalue.equals(outro.lvalue) &&
                rvalue.equals(outro.rvalue);
        } else
            return false;
    }}
