public interface Filtro {
    boolean aplica(int x);
}