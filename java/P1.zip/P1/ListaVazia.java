public class ListaVazia implements Lista {
    public ListaVazia() { }
    
    public int tamanho() {
        return 0;
    }
    
    public boolean contem(String s) {
        return false;
    }
    
    public Lista adiciona(String s) {
        return new ListaCons(s, this);
    }
}