import java.util.ArrayList;

public class IterUtils {
    public static ArrayList<Integer> listaDeEnum(Iterador e) {
        ArrayList<Integer> lista = new ArrayList<Integer>();
        while(!e.acabou()) {
            lista.add(e.proximo());
        }
        return lista;
    }
}