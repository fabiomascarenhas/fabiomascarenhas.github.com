import java.util.ArrayList;

public class ListaAL implements Lista {
    ArrayList<String> lista;
    
    public ListaAL(ArrayList<String> lista) {
        this.lista = lista;
    }
    
    public int tamanho() {
        return lista.size();
    }
    
    public boolean contem(String s) {
        return lista.contains(s);
    }
    
    public Lista adiciona(String s) {
        ArrayList<String> nova = new ArrayList<String>();
        nova.add(s);
        for(String sl: lista) {
            nova.add(sl);
        }
        return new ListaAL(nova);
    }
}