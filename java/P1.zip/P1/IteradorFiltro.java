public class IteradorFiltro implements Iterador {
    Iterador it;
    Filtro f;
    // próximo elemento filtrado
    int proximo;
    // sequência acabou?
    boolean acabou;
    
    public IteradorFiltro(Iterador it, Filtro f) {
        this.it = it;
        this.f = f;
        avanca();
    }

    void avanca() {
        acabou = true;
        while(!it.acabou()) {
            proximo = it.proximo();
            if(f.aplica(proximo)) {
                acabou = false;
                break;
            }
        }
    }
    
    public int proximo() {
        // Erro se não há mais elementos
        if(acabou) {
            it.proximo();
        }
        // Avança para o próximo e retorna o atual
        int r = proximo;
        avanca();
        return r;
    }
    
    public boolean acabou() {
        return acabou;
    }
}