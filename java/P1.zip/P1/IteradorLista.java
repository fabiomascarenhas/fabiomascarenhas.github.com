import java.util.ArrayList;
import java.util.Iterator;

public class IteradorLista implements Iterador {
    Iterator<Integer> it;
    
    public IteradorLista(ArrayList<Integer> lista) {
        it = lista.iterator();
    }
    
    public int proximo() {
        return it.next();
    }
    
    public boolean acabou() {
        return !it.hasNext();
    }
}