public interface Iterador {
    int proximo();
    boolean acabou(); // final
}