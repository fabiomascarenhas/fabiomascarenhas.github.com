public interface Toggle {
    void toggle();
}