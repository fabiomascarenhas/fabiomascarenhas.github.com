/*
typedef struct MinhaClasse {
    int x;
    double r;
    int vi[];
    char s[];
    OutraClasse* oc;
} MinhaClasse;
*/
public class MinhaClasse
{
    int x;
    double r;
    int[] vi;
    String s;
    OutraClasse oc;
    
    // Construtor
    MinhaClasse(int x, double r, int tvi, String s) {
        this.x = x;
        this.r = r;
        vi = new int[tvi];
        this.s = s;
        oc = new OutraClasse();
    }

    MinhaClasse(int x, double r, String s, OutraClasse oc) {
        this.x = x;
        this.r = r;
        vi = new int[x*2];
        this.s = s;
        this.oc = oc;
    }
}


