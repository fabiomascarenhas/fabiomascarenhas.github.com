public class OutraClasse
{
}
