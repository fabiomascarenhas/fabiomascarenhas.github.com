public class TarefaDownloadFoto extends AsyncTask<String, Void, Bitmap> {
    ImageView foto;

    public TarefaDownloadFoto(ImageView foto) {
        this.foto = foto;
    }

    @Override
    protected Bitmap doInBackground(String... urls) {
        if(urls.length > 0) {
            return new Bitmap();
        } else {
            throw new RuntimeException();
        }
    }

    @Override
    protected void onPostExecute(Bitmap bm) {
        System.out.println("ATUALIZOU: " + bm);
    }
}