public interface Callback<T> {
	void sucesso(T res);
	void falha(Exception e);
}
