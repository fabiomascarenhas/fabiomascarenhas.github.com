public abstract class AsyncTask<E,P,S>
{
    protected abstract S doInBackground(E... params);
    protected abstract void onPostExecute(S res);
}
