import java.util.List;
import java.util.ArrayList;

public class FiltroDivide extends FiltroRecupera {
    int dividendo = -1;
    
    protected List<String> processa(String linha) {
        ArrayList<String> saida = new ArrayList<String>();
        if(dividendo == -1) {
            dividendo = Integer.parseInt(linha);
        } else {
            int divisor = Integer.parseInt(linha);
            saida.add("" + dividendo/divisor);
            dividendo = -1;
        }
        return saida;
    }
    
    protected void erro(Exception e) {
        System.err.println("ERRO: " + e.toString());
    }
}