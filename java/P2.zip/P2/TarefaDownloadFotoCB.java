// Resposta questão 2
public class TarefaDownloadFotoCB extends TarefaDownloadFoto {
    // Guardar callback
    Callback<Bitmap> cb;
    // Guarda exceção para passar de doInBackground para onPostExecute
    Exception e;
    
    // Construtor
    public TarefaDownloadFotoCB(ImageView foto, Callback<Bitmap> cb) {
        // Chama superclasse
        super(foto);
        this.cb = cb;
    }

    // Redefinir para poder capturar exceção
    @Override
    protected Bitmap doInBackground(String... urls) {
        try {
            // Chama superclasse
            return super.doInBackground(urls);
        } catch(Exception e) {
            this.e = e;
            return null;
        }
    }
    
    // Redefine para chamar callback
    @Override
    protected void onPostExecute(Bitmap bm) {
        if(e == null) {
            // Não esquecer da superclasse
            super.onPostExecute(bm);
            // Callback sucesso
            cb.sucesso(bm);
        } else {
            // Callback falha
            cb.falha(e);
        }
    }
}
