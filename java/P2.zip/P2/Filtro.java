import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.io.IOException;

// Resposta questão 1a
public abstract class Filtro
{
    private BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    /*
     A exceção IOException é checada, logo o método
     não compila do jeito que está na prova, pois ele
     não trata IOException nem avisa que ela não é tratada
     através de uma cláusula throws na assinatura.
     */
    public void filtra() throws IOException { // Solução 1 - cláusula throws
    //public void filtra() {
        // Solução 2: converter de IOException para
        // uma exceção não-checada
        //try {
          String linha = br.readLine();
          while(linha != null) {
            for(String s: processa(linha)) {
                System.out.println(s);
            }
            linha = br.readLine();
          }
        //} catch(IOException ioe) {
        //    throw new RuntimeException(ioe);
        //}
    }

    protected abstract List<String> processa(String linha);
}
