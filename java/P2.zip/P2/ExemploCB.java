public class ExemploCB implements Callback<Bitmap> {
    public void sucesso(Bitmap res) {
        System.out.println("SUCESSO: " + res);
    }

    public void falha(Exception e) {
        System.out.println("FALHA: " + e);
    }
}