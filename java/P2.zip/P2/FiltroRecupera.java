import java.io.IOException;

// Resposta questão 1c
public abstract class FiltroRecupera extends Filtro {
    @Override
    public void filtra() throws IOException {
        while(true) {
            try {
                super.filtra();
                break;
            } catch(IOException ioe) {
                // Passa adiante
                throw ioe;
            } catch(Exception e) {
                // Passa para método
                erro(e);
                //filtra(); recursão para recomeçar
            }
            // Recomeça filtragem
        }
    }
    
    protected abstract void erro(Exception e);
}