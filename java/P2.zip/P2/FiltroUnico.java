import java.util.List;
import java.util.HashSet;
import java.util.ArrayList;

// Resposta questão 1b
public class FiltroUnico extends Filtro {
    // Linhas que já foram vistas
    HashSet<String> vistas = new HashSet<String>();

    @Override
    protected List<String> processa(String linha) {
        // Saída inicialmente vazia
        ArrayList<String> saida = new ArrayList<String>();
        if(!vistas.contains(linha)) {
            // marca como vista
            vistas.add(linha);
            // linha vai pra saída
            saida.add(linha);
        }
        return saida;
    }
}