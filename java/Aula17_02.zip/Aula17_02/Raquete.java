import java.util.HashSet;

public class Raquete {
    // Coordenadas do canto superior esquerdo
    double x;
    double y;
    Cor cor = new Cor(Math.random(), Math.random(), Math.random());
    int largura = 50;
    int altura = 10;

    // Campo da classe
    static double vx = 300;

    Raquete(double x_centro, double y_inferior) {
        x = x_centro - 25;
        y = y_inferior - 10;
    }
    
    void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
    
    void tique(HashSet<String> teclas, double dt) {
        if(teclas.contains("left") && x > 50) {
            x -= vx * dt;
        }
        if(teclas.contains("right") && x < 700) {
            x += vx * dt;
        }
    }
}