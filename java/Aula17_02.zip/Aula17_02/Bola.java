public class Bola {
    // Coordenadas do centro
    double x;
    double y;
    // Pixels por segundo
    double vx = -200;
    double vy = 150;
    Cor cor = new Cor("branco"); // o mesmo que (1)
    int raio = 5;
    
    Bola(double x, double y) {
        this.x = x;
        this.y = y;
        // cor = new Cor("branco"); (1)
    }
    
    Bola() {
        x = 800;
        y = 0;
    }
    
    void desenhar(Tela t) {
        t.circulo(x, y, raio, cor);
    }
    
    void tique(double dt) {
        x = x + vx * dt;
        y = y + vy * dt;
    }
    
    void refletirX() {
        vx = -vx;
    }
    
    void refletirY() {
        vy = -vy;
    }
}
