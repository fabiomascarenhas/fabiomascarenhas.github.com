public class Tijolo {
    int x;
    int y;
    Cor cor;
    boolean vivo;

    static int largura = 50;
    static int altura = 10;

    Tijolo(int x, int y, Cor cor) {
        this.x = x;
        this.y = y;
        this.cor = cor;
        vivo = true;
    }
    
    void desenhar(Tela t) {
        if(vivo) {
            t.retangulo(x, y, largura, altura, cor);
        }
    }
    
}