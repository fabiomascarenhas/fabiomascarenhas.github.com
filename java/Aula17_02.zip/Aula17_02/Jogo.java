import java.util.HashSet;

public class Jogo {
    String titulo = "Breakout";
    int altura = 600;
    int largura = 800;
    
    Bola bola = new Bola();
    Raquete raquete = new Raquete(400, 600);
    HashSet<Tijolo> tijolos = new HashSet<Tijolo>();
    int score = 0;
    int vidas = 3;
        
    public Jogo() {
        int y = 150;
        for(int i = 0; i < 6; i++) {
            Cor cor = new Cor(Math.random(), Math.random(), Math.random());
            int x = 50;
            for(int j = 0; j < 14; j++) {
                tijolos.add(new Tijolo(x, y, cor));
                x += Tijolo.largura;
            }
            y += Tijolo.altura;
        }
    }
    
    void desenhar(Tela t) {
        t.texto("" + score, 100, 30, 32, new Cor("branco"));
        t.texto("" + vidas, 300, 30, 32, new Cor("branco"));
        bola.desenhar(t);
        raquete.desenhar(t);
        for(Tijolo tijolo: tijolos) {
            tijolo.desenhar(t);
        }
        this.paredes(t);
    }
    
    void paredes(Tela t) {
        t.retangulo(0, 50, 50, 550, Cor.BRANCO);
        t.retangulo(50, 50, 700, 50, Cor.BRANCO);
        t.retangulo(750, 50, 50, 550, Cor.BRANCO);
    }
    
    void tique(HashSet<String> teclas, double dt) {
        bola.tique(dt);
        // Verificar colisão com a raquete
        // Verificar colisão com as paredes
        if((bola.x <= 50 && bola.vx < 0) ||
          (bola.x >= 750 && bola.vx > 0)) { // parede esquerda
            bola.refletirX();
        }
        if(bola.y <= 100 && bola.vy < 0) { // parede de cima
            bola.refletirY();
        }
        if(bola.y >= 600 && bola.vy > 0) {
            bola.refletirY();
        }
        // Verificar colisão com os tijolos
        // Verificar se saiu do jogo
        raquete.tique(teclas, dt);
    }
}