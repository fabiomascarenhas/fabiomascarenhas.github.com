public class Timer {
    int x, y;
    Segmento min, seg;
    int tamanho;
    Cor cor;
    double tempo;
    
    public Timer(int _x, int _y, int _min, int _seg,
                 int _tamanho, Cor _cor) {
        x = _x;
        y = _y;
        tamanho = _tamanho;
        cor = _cor;
        min = new Segmento(_min);
        seg = new Segmento(_seg);
    }
    
    public void tique(double dt) {
        tempo = tempo + dt;
        if(tempo >= 1.0) {
            tempo = tempo - 1.0;
            if(seg.tique()) min.tique();
        }
    }
    
    public boolean zerado() {
        return min.zerado() && seg.zerado();
    }
    
    public void desenhar(Tela t) {
        t.texto(min.getTexto() + ":" + seg.getTexto(),
                x, y, tamanho, cor);
    }
}