public class Tijolo {
    double x; 
    double y;
    Cor cor = new Cor(Math.random(), Math.random(), Math.random());
    static int larg = 64;
    static int alt = 20;
    Hitbox caixa;

    public Tijolo(double _x, double _y) {
        x = _x;
        y = _y;
        caixa = new Hitbox(x, y, x + larg, y + alt);
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, larg, alt, cor);
    }
    
    public void desligar() {
        caixa = new Hitbox(-larg, -alt, 0, 0);
        cor = new Cor(0, 0, 0);
    }
}