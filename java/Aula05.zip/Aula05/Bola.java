public class Bola {
    double x;
    double y;
    double vx;
    double vy;
    Cor cor;
    int raio = 8;
    
    public Bola(double _x, double _y, double _vx, double _vy, Cor _cor) {
        x = _x;
        y = _y;
        vx = _vx;
        vy = _vy;
        cor = _cor;
    }
    
    public void desenhar(Tela t) {
        t.circulo(x, y, raio, cor);
    }
    
    public void mover(double dt) {
        x = x + vx * dt;
        y = y + vy * dt;
    }
    
    public void sobe() {
        vy = -Math.abs(vy);
    }

    public void desce() {
        vy = Math.abs(vy);
    }

    public void esquerda() {
        vx = -Math.abs(vx);
    }

    public void direita() {
        vx = Math.abs(vx);
    }
    
    public Hitbox caixa() {
        return new Hitbox(x - raio + 3, y - raio + 3, x + raio - 3, y + raio - 3);
    }
}
