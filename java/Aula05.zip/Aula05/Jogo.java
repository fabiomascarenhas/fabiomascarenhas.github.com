import java.util.HashSet;

/*
 * Breakout
 */
public class Jogo {
    Bola b;
    Raquete r;
    Tijolo[] ts;
    int score;
    int vidas;
    boolean gameOver;
        
    public Jogo() {
        b = new Bola(getLargura()/2, getAltura()/2, 200, 200, Cor.AMARELO);
        r = new Raquete(getLargura()/2, getAltura(), Cor.BRANCO);
        int ts_por_lin = getLargura()/Tijolo.larg - 2;
        ts = new Tijolo[ts_por_lin * 6];
        for(int i = 0; i < ts.length; i++ ) {
            int lin = i / ts_por_lin;
            int col = i % ts_por_lin;
            ts[i] = new Tijolo(col * Tijolo.larg + Tijolo.larg,
                               lin * Tijolo.alt + 200);
        }
        vidas = 3;
    }
        
    public String getTitulo() {
        return "Breakout";
    }

    public int getLargura() {
        return 1024;
    }

    public int getAltura() {
        return 768;
    }

    public void tique(HashSet<String> teclas, double dt) {
        if(gameOver) return;
        b.mover(dt);
        if(b.x >= r.x && b.x <= r.x + r.larg &&
           b.y >= r.y && b.y <= r.y + r.alt) { // raquete
          b.sobe();
        }
        if(b.x <= Tijolo.larg) { // parede esquerda
          b.direita();
        }
        if(b.x >= getLargura() - Tijolo.larg) { // parede direita
          b.esquerda();
        }
        if(b.y <= 100) { // parede de cima
          b.desce();
        }
        for(Tijolo t: ts) {
            int lado = b.caixa().intersecao(t.caixa);
            if(lado == Hitbox.TOPO) {
                b.sobe();
            }
            if(lado == Hitbox.FUNDO) {
                b.desce();
            }
            if(lado == Hitbox.ESQUERDO) {
                b.direita();
            }
            if(lado == Hitbox.DIREITO) {
                b.esquerda();
            }
            if(lado > 0) {
                score = score + 1;
                break;
            }
        }
        if(b.y - b.raio >= getAltura()) {
            vidas = vidas - 1;
            if(vidas == 0) {
                gameOver = true;
            } else {
                b = new Bola(getLargura()/2, getAltura()/2, 200, 200, Cor.AMARELO);
            }
        }
    }

    public void desenhar(Tela t) {
        t.retangulo(0, 50, getLargura(), 50, Cor.CINZA);
        t.retangulo(0, 50, Tijolo.larg, getAltura(), Cor.CINZA);
        t.retangulo(getLargura() - Tijolo.larg, 50, Tijolo.larg, getAltura(), Cor.CINZA);
        b.desenhar(t);
        r.desenhar(t);
        for(Tijolo tij: ts) {
            tij.desenhar(t);
        }
        t.texto("" + score, 500, 40, 36, Cor.BRANCO); 
        t.texto("" + vidas, 950, 40, 36, Cor.BRANCO); 
        if(gameOver) t.texto("GAME OVER", 400, 370, 50, Cor.BRANCO);
    }

    public void tecla(String t) {
        if(t.equals("j")) { // esquerda
            r.esquerda();
        } else if(t.equals("k")) { // direita
            r.direita();
        }
    }

    public static void main(String[] args) {
        new Motor(new Jogo());
    }
}
