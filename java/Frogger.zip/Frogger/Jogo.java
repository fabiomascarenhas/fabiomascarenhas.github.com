import java.util.HashSet;

public class Jogo {
	int largura = 800;
	int altura = 600;
	String titulo = "Frogger";

	
    public static void main(String[] args) {
        new Motor(new Jogo());
    }
}
