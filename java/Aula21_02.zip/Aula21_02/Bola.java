public class Bola {
    // Coordenadas do centro
    double x;
    double y;
    // Pixels por segundo
    double vx = -200;
    double vy = 150;
    Cor cor = new Cor("branco"); // o mesmo que (1)
    int raio = 5;
    Hitbox caixa;
    
    Bola(double x, double y) {
        this.x = x;
        this.y = y;
        // cor = new Cor("branco"); (1)
        caixa = new Hitbox((int)x-3, (int)y-3, (int)x+3, (int)y+3);
    }
    
    Bola() {
        x = 800;
        y = 0;
        caixa = new Hitbox((int)x-3, (int)y-3, (int)x+3, (int)y+3);
    }
    
    void desenhar(Tela t) {
        t.circulo(x, y, raio, cor);
    }
    
    void tique(double dt) {
        x = x + vx * dt;
        y = y + vy * dt;
        caixa.mover((int)x-3, (int)y-3, (int)x+3, (int)y+3);
    }
    
    void refletirX() {
        vx = -vx;
    }
    
    void refletirY() {
        vy = -vy;
    }
    
    void esquerda() {
        vx = -Math.abs(vx);
    }

    void direita() {
        vx = Math.abs(vx);
    }
}
