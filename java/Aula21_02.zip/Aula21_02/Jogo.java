import java.util.ArrayList;
import java.util.HashSet;

public class Jogo {
    String titulo = "Breakout";
    int altura = 600;
    int largura = 800;
    
    Bola bola = new Bola(400, 300);
    Raquete raquete = new Raquete(400, 600);
    HashSet<Tijolo> tijolos = new HashSet<Tijolo>();
    int score = 0;
    int vidas = 3;
    Hitbox paredeE = new Hitbox(0, 50, 50, 600);
    Hitbox paredeC = new Hitbox(50, 50, 750, 100);
    Hitbox paredeD = new Hitbox(750, 50, 800, 600);
    Hitbox chao = new Hitbox(50, 600, 750, 700);
        
    public Jogo() {
        int y = 150;
        for(int i = 0; i < 6; i++) {
            Cor cor = new Cor(Math.random(), Math.random(), Math.random());
            int x = 50;
            for(int j = 0; j < 14; j++) {
                tijolos.add(new Tijolo(x, y, cor));
                x += Tijolo.largura;
            }
            y += Tijolo.altura;
        }
    }
    
    void desenhar(Tela t) {
        t.texto("" + score, 100, 30, 32, new Cor("branco"));
        t.texto("" + vidas, 300, 30, 32, new Cor("branco"));
        bola.desenhar(t);
        raquete.desenhar(t);
        for(Tijolo tijolo: tijolos) {
            tijolo.desenhar(t);
        }
        this.paredes(t);
        if(vidas == 0)
            t.texto("GAME OVER", 350, 250, 48, Cor.BRANCO); 
    }
    
    void paredes(Tela t) {
        t.retangulo(0, 50, 50, 550, Cor.BRANCO);
        t.retangulo(50, 50, 700, 50, Cor.BRANCO);
        t.retangulo(750, 50, 50, 550, Cor.BRANCO);
    }
    
    void tique(HashSet<String> teclas, double dt) {
        if(vidas == 0) return;
        bola.tique(dt);
        // Verificar colisão com a raquete
        if(bola.caixa.intersecao(raquete.caixaE) != 0) {
            bola.esquerda();
            bola.refletirY();
        } else if(bola.caixa.intersecao(raquete.caixaC) != 0) {
            bola.refletirY();
        } else if(bola.caixa.intersecao(raquete.caixaD) != 0) {
            bola.direita();
            bola.refletirY();
        }
        // Verificar colisão com as paredes
        if(bola.caixa.intersecao(paredeE) != 0) { // parede esquerda
            bola.refletirX();
        }
        if(bola.caixa.intersecao(paredeD) != 0) { // parede direita
            bola.refletirX();
        }
        if(bola.caixa.intersecao(paredeC) != 0) { // parede cima
            bola.refletirY();
        }
        // Verificar colisão com os tijolos
        ArrayList<Tijolo> remover = new ArrayList<Tijolo>();
        for(Tijolo tijolo: tijolos) {
            // Verificar colisão de bola com tijolo
            int lado = bola.caixa.intersecao(tijolo.caixa); 
            if(lado == 1 || lado == 3) { // acima ou abaixo
                bola.refletirY();
                remover.add(tijolo);
                score += 10;
            }
            if(lado == 2 || lado == 4) { // esquerda ou direita
                bola.refletirX();
                remover.add(tijolo);
                score += 10;
            }
        }
        tijolos.removeAll(remover);
        // Verificar se saiu do jogo
        if(bola.caixa.intersecao(chao) != 0) {
            vidas--;
            bola = new Bola(400, 300);
        }
        raquete.tique(teclas, dt);
    }
}