public class Tijolo {
    int x;
    int y;
    Cor cor;
    Hitbox caixa;

    static int largura = 50;
    static int altura = 10;

    Tijolo(int x, int y, Cor cor) {
        this.x = x;
        this.y = y;
        this.cor = cor;
        caixa = new Hitbox(x, y, x + largura, y + altura);
    }
    
    void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
    
}