import java.util.*;

public class IniVetor {
    public static Scanner entrada = new Scanner(System.in);
    
    // public static -> função global ou variável global
    public static void geraConjunto(double[] vetor, int tamanho, double inicial) {
      for(int i = 0; i < tamanho; i++) {
          vetor[i] = inicial;
          inicial *= 2;
      }
    }
    
    public static void main(String[] args) {
        double[] vetor = new double[5]; // criação do vetor
        double num;
        int i;
        System.out.println("Este programa gera um vetor de números inteiros.");
        System.out.println("Entre com o número inicial do conjunto.");
        num = entrada.nextInt(); // chamada de método (OO)
        geraConjunto(vetor, 5, num);
        for(i = 0; i < 5; i++)
            System.out.println("Elemento " + i + " = " + vetor[i]);
    }
}
