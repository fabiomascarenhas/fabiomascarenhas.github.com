/** Automatically generated file. DO NOT MODIFY */
package compii.buscatwitter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}