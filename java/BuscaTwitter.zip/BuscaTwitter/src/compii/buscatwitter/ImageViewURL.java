package compii.buscatwitter;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class ImageViewURL extends ImageView {
	public ImageViewURL(Context context) {
		super(context);
	}
	
	public ImageViewURL(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public ImageViewURL(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}
	
	public void setURL(String url) {
		new TarefaDownloadFoto(this).execute(url);
	}
}
