package compii.buscatwitter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

// Conexão do modelo com a lista
public class ListaTweet extends BaseAdapter {
	ArrayList<Tweet> tweets;
	View[] views;
	
	public ListaTweet(ArrayList<Tweet> tweets) {
		this.tweets = tweets;
		views = new View[tweets.size()];
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return tweets.size();
	}

	@Override
	public Object getItem(int i) {
		return tweets.get(i);
	}

	@Override
	public long getItemId(int i) {
		return i;
	}

	@Override
	public View getView(int i, View view, ViewGroup lista) {
		if(views[i] == null) {
			LayoutInflater inf = (LayoutInflater)lista.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			views[i] = inf.inflate(R.layout.tweet, null);
			Tweet t = tweets.get(i);
			ImageViewURL foto = (ImageViewURL)views[i].findViewById(R.id.foto);
			foto.setURL(t.figura);
			TextView nome = (TextView)views[i].findViewById(R.id.nome);
			nome.setText("@" + t.nome);
			TextView tweet = (TextView)views[i].findViewById(R.id.tweet);
			tweet.setText(t.tweet);
			TextView data = (TextView)views[i].findViewById(R.id.data);
			data.setText(t.hora);
		}
		return views[i];
	}

}
