package compii.buscatwitter;

import java.io.Serializable;

import android.graphics.Bitmap;
import twitter4j.Status;

public class Tweet implements Serializable {
	public String figura;
	public String nome;
	public String tweet;
	public String hora;
	
	public Tweet(Status tweet) {
		figura = tweet.getUser().getProfileImageURL();
		nome = tweet.getUser().getName();
		this.tweet = tweet.getText();
		hora = tweet.getCreatedAt().toLocaleString();
	}
}
