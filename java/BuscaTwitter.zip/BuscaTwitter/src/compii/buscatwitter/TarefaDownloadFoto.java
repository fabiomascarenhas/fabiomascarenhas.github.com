package compii.buscatwitter;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

public class TarefaDownloadFoto extends AsyncTask<String, Void, Bitmap> {
    ImageView foto;

    public TarefaDownloadFoto(ImageView foto) {
        this.foto = foto;
    }

    @Override
    protected Bitmap doInBackground(String... urls) {
        String url = urls[0];
        try {
            InputStream in = new URL(url).openStream();
            return BitmapFactory.decodeStream(in);
        } catch (IOException e) {
            Log.e("Error", e.getMessage());
        }
        return null;
    }

    protected void onPostExecute(Bitmap bm) {
        foto.setImageBitmap(bm);
    }
}