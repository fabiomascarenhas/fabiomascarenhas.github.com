package compii.buscatwitter;

import java.util.ArrayList;
import java.util.List;

import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class TarefaBusca extends AsyncTask<String,Void,ArrayList<Tweet>> {
	Twitter twitter;
	ListView lista;
	ProgressDialog pd;
	boolean erro;

	public TarefaBusca(ListView lista) {
		super();
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setDebugEnabled(true);
		cb.setOAuthConsumerKey("2tClxMM1EMMKUNpuPQQhjWdHM");
		cb.setOAuthConsumerSecret("KszFWfLBPFK9mI4VEfweOpeYDBb8FIxYETWkkEaUE9oU16LrmE");
		cb.setOAuthAccessToken("4894751-8dp5ZMFHjxtXYLvrOmVs0nmevbN8f6Pdreu1NfBjj5");
		cb.setOAuthAccessTokenSecret("QkIInzxDDutuCNqWnXjXSwP8g8uTkHL8gP5CxZPg76ifZ");
        TwitterFactory tf = new TwitterFactory(cb.build());
        twitter = tf.getInstance();
        this.lista = lista;
        pd = new ProgressDialog(lista.getContext());
        pd.setIndeterminate(true);
        pd.setTitle("Buscando...");
        pd.setMessage("Aguarde.");
        pd.setCancelable(false);
	}

	@Override
	protected void onPreExecute() {
		pd.show();
	}
	
	@Override
	protected ArrayList<Tweet> doInBackground(String... params) {
		erro = false;
		ArrayList<Tweet> tweets = new ArrayList<Tweet>();
		try {
			Query query = new Query(params[0]);
			QueryResult qr = twitter.search(query);
	        for(twitter4j.Status status: qr.getTweets()) {
	        	tweets.add(new Tweet(status));
	        }
		} catch (TwitterException e) {
			erro = true;
			e.printStackTrace();
		}
        return tweets;
	}

	@Override
	protected void onPostExecute(ArrayList<Tweet> tweets) {
		pd.dismiss();
		if(erro) {
			Toast.makeText(lista.getContext(), "Erro na busca, tente mais tarde", Toast.LENGTH_LONG).show();
		} else {
			lista.setAdapter(new ListaTweet(tweets));
		}
	}
	
}
