package compii.buscatwitter;

import java.util.ArrayList;

import twitter4j.Query;
import twitter4j.QueryResult;
import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.os.Build;

public class BuscaTweeter extends Activity {
	ListView tweets;
	EditText termo;
	ArrayList<String> termos;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.busca_tweeter);
        termos = new ArrayList<String>();
        tweets = (ListView)this.findViewById(R.id.tweets);
        termo = (EditText)this.findViewById(R.id.texto);
        this.findViewById(R.id.busca).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View botao) {
				String s = termo.getText().toString();
				termos.add(s);
		        busca(s);
			}
		});
        if(savedInstanceState != null && savedInstanceState.containsKey("termo")) {
        	termo.setText(savedInstanceState.getString("termo"));
        	tweets.setAdapter(new ListaTweet((ArrayList<Tweet>)savedInstanceState.getSerializable("tweets")));
        	termos = (ArrayList<String>)savedInstanceState.getSerializable("termos");
        }
    }
    
    @Override
    public void onSaveInstanceState(Bundle estado) {
    	estado.putString("termo", termo.getText().toString());
    	ListaTweet lt = (ListaTweet)tweets.getAdapter();
    	estado.putSerializable("tweets", lt.tweets);
    	estado.putSerializable("termos", termos);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	this.getMenuInflater().inflate(R.menu.busca_tweeter, menu);
    	return true;
    }
    
    @Override 
    public boolean onPrepareOptionsMenu(Menu menu) {
    	menu.clear();
    	this.getMenuInflater().inflate(R.menu.busca_tweeter, menu);
    	int primeiro = termos.size() - 5;
    	if(primeiro < 0) primeiro = 0;
    	for(int i = primeiro; i < termos.size(); i++) {
    		menu.add(0, 1000 + i, 200, termos.get(i));
    	}
    	return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch(item.getItemId()) {
    	case R.id.busca_android:
    		busca("android");	
    		break;
    	case R.id.busca_java:
    		busca("java");
    		break;
    	case R.id.busca_ufrj:
    		busca("UFRJ");
    		break;
    	default:
    		busca(termos.get(item.getItemId() - 1000));
    	}
    	return true;
    }

	private void busca(String s) {
		termo.setText(s);
		TarefaBusca tb = new TarefaBusca(tweets);
		tb.execute(s);
	}
}

