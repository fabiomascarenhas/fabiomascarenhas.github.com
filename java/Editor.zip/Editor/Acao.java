public interface Acao {
        void fazer();
        void desfazer();    
}