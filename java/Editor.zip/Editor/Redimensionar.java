
public class Redimensionar implements Acao {
    private Forma f;
    private double escala;
    
    public Redimensionar(Forma f, double escala) {
        this.f = f;
        this.escala = escala;
    }

    public void fazer() {
        f.redimensionar(escala);
    }
    
    public void desfazer() {
        f.redimensionar(1/escala);
    }
}