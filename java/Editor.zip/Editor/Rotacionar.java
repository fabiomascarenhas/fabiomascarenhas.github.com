public class Rotacionar implements Acao {
    private Forma f;
    private int graus;
    
    public Rotacionar(Forma f, int graus) {
        this.f = f;
        this.graus = graus;
    }
    
    public void fazer() {
        f.rotacionar(graus);
    }
    
    public void desfazer() {
        f.rotacionar(-graus);
    }
}