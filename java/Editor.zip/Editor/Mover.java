
public class Mover implements Acao {
    private Forma f;
    private int dx;
    private int dy;
    
    public Mover(Forma f, int dx, int dy) {
        this.f = f;
        this.dx = dx;
        this.dy = dy;
    }

    public void fazer() {
        f.mover(dx, dy);
    }
    
    public void desfazer() {
        f.mover(-dx, -dy);
    }
}