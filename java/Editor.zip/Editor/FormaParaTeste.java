public class FormaParaTeste implements Forma {
  public FormaParaTeste() { }

  public void mover(int dx, int dy) {
    System.out.println("MOVER: " + dx + ", " + dy);
  }

  public void redimensionar(double escala) {
    System.out.println("REDIMENSIONAR: " + escala);
  }
  
  public void rotacionar(int graus) {
    System.out.println("ROTACIONAR: " + graus);
  }
}