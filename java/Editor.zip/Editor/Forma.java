public interface Forma {
        // Mover a forma, dado o deslocamento
        void mover(int dx, int dy);
        // Redimensiona a forma por um fator de escala
        void redimensionar(double escala);
        // Rotaciona a forma em tantos graus
        void rotacionar(int graus);
}
      