import java.util.Stack;

public class Editor {
        // Ações feitas
        private Stack<Acao> feitas = new Stack<Acao>();
        // Ações desfeitas
        private Stack<Acao> desfeitas = new Stack<Acao>();

        public void fazer(Acao a) {
            a.fazer();
            feitas.push(a);
        }

        public void desfazer() {
            if(!feitas.empty()) {
                Acao a = feitas.pop();
                a.desfazer();
                desfeitas.push(a);
            }
        }

        public void refazer() {
            if(!desfeitas.empty()) {
                Acao a = desfeitas.pop();
                a.fazer();
                feitas.push(a);
            }
        }
        
        public static void main(String[] args) {
            FormaParaTeste f = new FormaParaTeste();
            Acao a1 = new Mover(f, 20, 30);
            Acao a2 = new Redimensionar(f, 1.4);
            Acao a3 = new Mover(f, -30, 50);
            Acao a4 = new Rotacionar(f, 30);
            Editor e = new Editor();
            e.fazer(a1);
            e.fazer(a2);
            e.fazer(a3);
            e.fazer(a4);
            e.desfazer();
            e.desfazer();
            e.refazer();
        }
}