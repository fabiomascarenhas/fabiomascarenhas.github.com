public interface OpBin {
    int op(int a, int b);  // faz a operação binária
}