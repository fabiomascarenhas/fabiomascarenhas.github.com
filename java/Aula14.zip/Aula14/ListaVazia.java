public class ListaVazia implements Lista, Enumerador
{
    public ListaVazia() { }

    public int quantos() {
        return 0;
    }
    
    public int soma() {
        return 0;
    }
    
    public Enumerador enumerador() {
        return this;
    }
    
    public int proximo() {
        throw new EnumeradorVazio("lista vazia");
    }
    
    public boolean fim() {
        return true;
    }
    
    public int foldr(OpBin op, int z) {
        return z;
    }
}
