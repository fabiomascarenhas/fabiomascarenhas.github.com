
public class ListaCons implements Lista
{
    private int primeiro;
    private Lista resto;
    
    public ListaCons(int primeiro, Lista resto)
    {
        this.primeiro = primeiro;
        this.resto = resto;
    }

    public int quantos() {
        return 1 + resto.quantos();
    }
    
    public int soma() {
        return primeiro + resto.soma();
    }
    
    public Enumerador enumerador() {
        return new Enumerador() {
            Enumerador enumResto;
            
            public int proximo() {
                if(enumResto == null) {
                    enumResto = resto.enumerador();
                    return primeiro;
                } else
                    return enumResto.proximo();
            }
            
            public boolean fim() {
                if(enumResto == null)
                    return false;
                else
                    return enumResto.fim();
            }
        };
    }
    
    public int foldr(OpBin op, int z) {
        return op.op(primeiro, resto.foldr(op, z));
    }
}
