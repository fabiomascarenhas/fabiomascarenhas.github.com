
public interface Enumerador {
  int proximo();  // próximo elemento
  boolean fim();  // acabaram os elementos?
}
