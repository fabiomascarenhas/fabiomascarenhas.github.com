package compii.editor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.os.Build;
import android.provider.MediaStore;

public class Editor extends Activity {
	final int ESCOLHE_COR = 0;
	
	Tela t;
	ModeloEditor modelo;
	ToggleModo tmover = new ToggleModo();
	ToggleModo tcirc = new ToggleModo();
	ToggleModo tret = new ToggleModo();
	
    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        if(estado != null && estado.containsKey("modelo")) {
        	modelo = (ModeloEditor)estado.getSerializable("modelo");
        	tmover = (ToggleModo)modelo.tmover;
        	tcirc = (ToggleModo)modelo.tcirc;
        	tret = (ToggleModo)modelo.tret;
        } else {
        	modelo = new ModeloEditor(tmover);
        	modelo.tcirc = tcirc;
        	modelo.tret = tret;
        }
        t = new Tela(this.getBaseContext());
        t.setObservadorCanvas(new ObservadorCanvas() {
			@Override
			public void desenhar(Tela c) {
				modelo.desenhar(c);
			}

			@Override
			public void aperto(int x, int y) {
				modelo.selecionar(x, y);
			}

			@Override
			public void solta(int x, int y) {
				modelo.terminar(x, y);
			}

			@Override
			public void arrasto(int x, int y) {
				modelo.parcial(x, y);
			}
        	
        });
        setContentView(t);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.editor, menu);
        return true;
    }

    @Override 
    public boolean onPrepareOptionsMenu(Menu menu) {
    	menu.getItem(0).setChecked(tmover.ligado);
    	menu.getItem(1).setChecked(tret.ligado);
    	menu.getItem(2).setChecked(tcirc.ligado);
    	return true;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
        case R.id.menu_circulo:
        	modelo.circulo();
        	break;
        case R.id.menu_desfazer:
        	modelo.desfazer();
        	t.invalidate();
        	break;
        case R.id.menu_refazer:
        	modelo.refazer();
        	t.invalidate();
        	break;
        case R.id.menu_mover:
        	modelo.mover();
        	break;
        case R.id.menu_retangulo:
        	modelo.retangulo();
        	break;
        case R.id.menu_escolhecor:
        	Intent icor = new Intent(this, EscolheCor.class);
        	icor.putExtra("corR", modelo.r);
        	icor.putExtra("corG", modelo.g);
        	icor.putExtra("corB", modelo.b);
        	this.startActivityForResult(icor, ESCOLHE_COR);
        case R.id.menu_enviar:
        	FileOutputStream arq;
			try {
				arq = this.openFileOutput("tela.jpg", 0);
				try {
					t.salvaTela(arq);
				} finally {
					arq.close();
				}
			} catch (IOException e) {
				Log.e("EDITOR", "erro de IO", e);
			}
        	Intent ienviar = new Intent(Intent.ACTION_SEND);
        	ienviar.setType("image/jpg");
        	Uri uri = Uri.parse("content://compii.editor/tela.jpg");
        	ienviar.putExtra(Intent.EXTRA_STREAM, uri);
        	this.startActivity(Intent.createChooser(ienviar, "Enviar com"));
        }
        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle estado) {
    	estado.putSerializable("modelo", modelo);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent msg) {
    	if(req == ESCOLHE_COR) {
    		if(res == RESULT_OK) {
    			modelo.r = msg.getIntExtra("corR", 0);
    			modelo.g = msg.getIntExtra("corG", 0);
    			modelo.b = msg.getIntExtra("corB", 0);
    			Toast.makeText(this, "Cor alterada", Toast.LENGTH_LONG).show();
    		}
    	}
    }
    
}
