package compii.editor;

import java.io.Serializable;

public interface Toggle extends Serializable {
    void toggle();
}