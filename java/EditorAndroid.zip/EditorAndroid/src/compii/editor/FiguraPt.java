package compii.editor;
public abstract class FiguraPt implements Figura {
    // ponto de controle
    int x;
    int y;
    
    // cor
    int r;
    int g;
    int b;
    
    public FiguraPt(int x, int y, int r, int g, int b) {
        this.x = x;
        this.y = y;
        this.r = r;
        this.g = g;
        this.b = b;
    }
    
    public void mover(int dx, int dy) {
        x += dx;
        y += dy;
    }
    
    //public abstract boolean dentro(int x, int y);
    //public abstract void desenhar(Canvas c);
    //public abstract void escala(double f);
}
