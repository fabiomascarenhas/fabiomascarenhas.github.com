package compii.editor;
public interface ObservadorCanvas
{
    void desenhar(Tela c);
    void aperto(int x, int y);
    void solta(int x, int y);
    void arrasto(int x, int y);
}
