package compii.editor;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

public class Cor extends View {
	int r = 0, g = 0, b = 0;
	
	 public Cor(Context context) {
		 super(context);
	 }
	 
	 public	Cor(Context context, AttributeSet attrs) {
		super(context, attrs); 
	 }
	 
	 public Cor(Context context, AttributeSet attrs, int defStyleAttr) {
		 super(context, attrs, defStyleAttr);
	 }
	 
	 public void setCor(int r, int g, int b) {
		 this.r = r;
		 this.g = g;
		 this.b = b;
		 this.invalidate();
	 }
	 
	 @Override
	 public void onDraw(Canvas c) {
		 c.drawRGB(r, g, b);
	 }
}
