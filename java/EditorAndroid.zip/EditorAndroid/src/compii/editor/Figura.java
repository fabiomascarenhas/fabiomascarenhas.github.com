package compii.editor;

import java.io.Serializable;

public interface Figura extends Serializable {
    boolean dentro(int x, int y);
    void mover(int dx, int dy);
    void escala(double f);
    void desenhar(Tela c);
}
