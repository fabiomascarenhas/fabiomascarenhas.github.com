package compii.editor;

import java.io.FileOutputStream;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

public class Tela extends View {
	Paint pen;
    ObservadorCanvas oc;
    Canvas c;

	public Tela(Context context) {
		super(context);
		pen = new Paint();
		pen.setARGB(255, 0, 0, 0);
		pen.setStyle(Style.FILL_AND_STROKE);
	}
	
	public void setObservadorCanvas(ObservadorCanvas oc) {
		this.oc = oc;
	}

	@Override
	public void onDraw(Canvas c) {
		this.c = c;
		c.drawRGB(255, 255, 255);
		if(oc != null) oc.desenhar(this);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent evt) {
		switch(evt.getAction()) {
		case MotionEvent.ACTION_DOWN:
			oc.aperto((int)evt.getX(), (int)evt.getY());
			break;
		case MotionEvent.ACTION_UP:
			oc.solta((int)evt.getX(), (int)evt.getY());
			break;
		case MotionEvent.ACTION_MOVE:
			oc.arrasto((int)evt.getX(), (int)evt.getY());
			break;
		}
		this.invalidate();
		return true;
	}
	
    public void retangulo(int x, int y, int largura, int altura, int r, int g, int b) {
    	pen.setARGB(255, r, g, b);
    	c.drawRect(x,  y, x + largura, y + altura, pen);
    }

    public void circulo(int cx, int cy, int raio, int r, int g, int b) {
    	pen.setARGB(255, r, g, b);
    	c.drawCircle(cx, cy, raio, pen);
    }

	public void salvaTela(FileOutputStream arq) {
		Bitmap bm = Bitmap.createBitmap(getWidth(), getHeight(), Config.ARGB_8888);
		Canvas c = new Canvas(bm);
		this.draw(c);
		bm.compress(CompressFormat.JPEG, 50, arq);
	}

}
