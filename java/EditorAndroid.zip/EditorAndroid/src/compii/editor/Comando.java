package compii.editor;

import java.io.Serializable;

public interface Comando extends Serializable {
    void desfazer(ModeloEditor modelo);
    void refazer(ModeloEditor modelo);
}