package compii.editor;

import java.io.Serializable;

public interface Estado extends Serializable {
    void selecionar(int x, int y);
    void parcial(int x, int y);
    void terminar(int x, int y);
    void desenhar(Tela c);
    void sair();
}