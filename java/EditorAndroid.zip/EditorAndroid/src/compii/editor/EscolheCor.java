package compii.editor;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.os.Build;

public class EscolheCor extends Activity {
	SeekBar corR, corG, corB;
	Cor cor;
		
	@Override
	protected void onCreate(Bundle estado) {
		int r, g, b;
		super.onCreate(estado);
		if(estado != null && estado.containsKey("corR")) {
			r = estado.getInt("corR");
			g = estado.getInt("corG");
			b = estado.getInt("corB");
		} else {
			Intent icor = this.getIntent();
			r = icor.getIntExtra("corR", 0);
			g = icor.getIntExtra("corG", 0);
			b = icor.getIntExtra("corB", 0);
		}
		setContentView(R.layout.escolhe_cor);
		cor = (Cor)this.findViewById(R.id.cor);
		corR = (SeekBar)this.findViewById(R.id.corR);
		corR.setMax(255);
		corR.setProgress(r);
		corG = (SeekBar)this.findViewById(R.id.corG);
		corG.setMax(255);
		corG.setProgress(g);
		corB = (SeekBar)this.findViewById(R.id.corB);
		corB.setMax(255);
		corB.setProgress(b);
		cor.setCor(corR.getProgress(), corG.getProgress(), corB.getProgress());
		OnSeekBarChangeListener mudaCor = new OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar sb, int valor, boolean user) {
				cor.setCor(corR.getProgress(), corG.getProgress(), corB.getProgress());
			}
			@Override
			public void onStartTrackingTouch(SeekBar arg0) {
			}
			@Override
			public void onStopTrackingTouch(SeekBar arg0) {
			}
		};
		corR.setOnSeekBarChangeListener(mudaCor);
		corG.setOnSeekBarChangeListener(mudaCor);
		corB.setOnSeekBarChangeListener(mudaCor);
	}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.escolhe_cor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()) {
        case R.id.menu_ok:
        	Intent icor = new Intent();
        	icor.putExtra("corR", corR.getProgress());
        	icor.putExtra("corG", corG.getProgress());
        	icor.putExtra("corB", corB.getProgress());
        	this.setResult(RESULT_OK, icor);
        	this.finish();
        	break;
        case R.id.menu_cancelar:
        	this.setResult(RESULT_CANCELED);
        	this.finish();
        	break;
        }
        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle estado) {
    	estado.putInt("corR", corR.getProgress());
    	estado.putInt("corG", corG.getProgress());
    	estado.putInt("corB", corB.getProgress());
    }

}
