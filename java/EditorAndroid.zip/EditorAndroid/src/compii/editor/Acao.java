package compii.editor;
public interface Acao {
	void executa();
}
