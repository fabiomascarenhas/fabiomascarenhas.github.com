package compii.editor;

public class ToggleModo implements Toggle {
	public boolean ligado = false;
	
	@Override
	public void toggle() {
		ligado = !ligado;
	}
}
