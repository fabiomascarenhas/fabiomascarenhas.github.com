public class Escala implements Funcao {
    double c;
    Funcao f;
    
    public Escala(double _c, Funcao _f) {
        c = _c;
        f = _f;
    }
    
    public double getValor(double x) {
        return f.getValor(x) * c;
    }
    
    public String getFormula() {
        return String.format("%f*%s", c, f.getFormula());
    }
}