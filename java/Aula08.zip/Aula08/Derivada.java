public class Derivada implements Funcao {
    double dx = 0.000001;
    Funcao f;
    
    public Derivada(Funcao _f) {
        f = _f;
    }
    
    public double getValor(double x) {
        return (f.getValor(x+dx) - f.getValor(x))/dx;
    }
    
    public String getFormula() {
        return String.format("(%s)'", f.getFormula());
    }
}