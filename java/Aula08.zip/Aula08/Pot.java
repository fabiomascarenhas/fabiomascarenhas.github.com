public class Pot implements Funcao {
    double n;
    
    public Pot(double _n) {
        n = _n;
    }
    
    public double getValor(double x) {
        return Math.pow(x, n);
    }
    
    public String getFormula() {
        return String.format("x^%f", n);
    }
}