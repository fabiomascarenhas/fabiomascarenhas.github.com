public interface Funcao {
    double getValor(double x);
    String getFormula();
}