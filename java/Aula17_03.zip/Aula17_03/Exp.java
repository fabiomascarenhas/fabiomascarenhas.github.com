// f(x) = n^x
public class Exp implements Funcao {
    int n;
    
    public Exp(int n) {
        this.n = n;
    }
    
    public double valor(double x) {
        return Math.pow(n, x);
    }
    
    public String formula() {
        return "" + n + "^x";
    }
}