public class TesteApp implements App {
    public String getTitulo() { return "TESTE"; }
    public int getAltura() { return 600; }
    public int getLargura() { return 800; }
    public void desenhar(Tela t) {}
    public void tique(java.util.HashSet<String> ts, double dt) {}
    public void tecla(String t) {}
    public void movimento(int x, int y) {
        System.out.println("MOV: " + x + "," + y);
    }
    public void arrasto(int x, int y) {
        System.out.println("DRG: " + x + "," + y);
    }
    public void clique(int x, int y) {
        System.out.println("CLK: " + x + "," + y);
    }
    public void apertou(int x, int y) {
        System.out.println("PRS: " + x + "," + y);
    }
    public void soltou(int x, int y) {
        System.out.println("RLS: " + x + "," + y);
    }
}