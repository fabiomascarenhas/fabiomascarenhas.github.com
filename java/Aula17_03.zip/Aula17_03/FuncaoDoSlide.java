public class FuncaoDoSlide implements Funcao {
    public double valor(double x) {
        if(x <= 2) {
            return x;
        } else if(x <= 3.5) {
            return 2;
        } else if(x <= 5) {
            return 3;
        } else {
            return x * x - 10 * x + 28;
        }
    }
    
    public String formula() {
        return "consulte o slide";
    }
}