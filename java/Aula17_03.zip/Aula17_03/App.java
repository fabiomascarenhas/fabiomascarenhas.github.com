// A interface App HERDA da interface Jogo
// Uma instância de App "é uma" instância Jogo
public interface App extends Jogo {
    void movimento(int x, int y);
    void arrasto(int x, int y);
    void clique(int x, int y);
    void apertou(int x, int y);
    void soltou(int x, int y);
}