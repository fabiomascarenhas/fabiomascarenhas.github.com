public class Calculo
{
    public static double dx = 0.000001;
    
    // Integral definida da função f no intervalo [a, b]
    public static double integral(Funcao f, double a, double b) {
        if(a > b) {
            double temp = b;
            b = a;
            a = temp;
        }
        double s = 0;
        while(a < b) {
            s = s + Math.abs(f.valor(a)) * dx;
            a = a + dx;
        }
        return s;
    }
    
    static Funcao DOSLIDE = new Funcao() {
      double v1 = 2;
      double v2 = 3;

      public double valor(double x) {
        if(x <= 2) {
            return x;
        } else if(x <= 3.5) {
            return v1;
        } else if(x <= 5) {
            return v2;
        } else {
            return ultima(x);
        }
      }

      double ultima(double x) {
          return x * x - 10 * x + 28;
      }
      
      public String formula() {
        return "consulte o slide";
      }
    };
}
