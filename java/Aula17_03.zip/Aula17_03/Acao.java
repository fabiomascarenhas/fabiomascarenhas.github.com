public interface Acao {
    void desfazer();
    void refazer();
}