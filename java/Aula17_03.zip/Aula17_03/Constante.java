public class Constante implements Funcao {
    double c;
    
    public Constante(double c) {
        this.c = c;
    }
    
    public double valor(double x) {
        return c;
    }
    
    public String formula() {
        return "" + c;
    }
}
