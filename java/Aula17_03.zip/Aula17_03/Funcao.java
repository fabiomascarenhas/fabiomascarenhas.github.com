// Funcoes reais de uma variávei
interface Funcao {
    double valor(double x);
    String formula();
}
