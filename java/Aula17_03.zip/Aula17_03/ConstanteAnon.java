public class ConstanteAnon implements Funcao {
    //double c;
    Funcao anon;
    
    public ConstanteAnon(double _c) {
        final double c = _c;
        anon = new Funcao() {
            public double valor(double x) {
                return c;
            }
            
            public String formula() {
                return "" + c;
            }
        };
    }
    
    public double valor(double x) {
        return anon.valor(x);
    }
    
    public String formula() {
        return anon.formula();
    }
}
