public interface Componente {
    void clique(int x, int y);
    void arrasto(int x, int y);
}