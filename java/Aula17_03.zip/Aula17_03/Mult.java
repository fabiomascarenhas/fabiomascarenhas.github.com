// f(x) = g0(x) * ... * gi(x)
public class Mult implements Funcao {
    Funcao[] gs;

    public Mult(Funcao... gs) {
        this.gs = gs;
    }
    
    public double valor(double x) {
        double p = 1;
        for(Funcao g: gs) {
            p *= g.valor(x);
        }
        return p;
    }
    
    public String formula() {
        String s = "(" + gs[0].formula();
        for(int i = 1; i < gs.length; i++) {
           s += "*" + gs[i].formula();
        }
        return s + ")";
    }
}