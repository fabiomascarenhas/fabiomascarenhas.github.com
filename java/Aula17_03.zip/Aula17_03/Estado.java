public interface Estado {
    void arrasto(int x, int y);
    void clique(int x, int y);
    void apertou(int x, int y);
    void soltou(int x, int y);
}