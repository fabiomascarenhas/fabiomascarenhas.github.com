// f(x) = g'(x)
public class Derivada implements Funcao {
    Funcao g;
    
    public Derivada(Funcao g) {
        this.g = g;
    }
    
    public double valor(double x) {
        return (g.valor(x+Calculo.dx) - g.valor(x)) / Calculo.dx;
    }
    
    public String formula() {
        return "Deriv[" + g.formula() + "]";
    }
}