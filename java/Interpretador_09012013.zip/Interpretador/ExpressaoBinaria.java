public abstract class ExpressaoBinaria implements Expressao {
  protected Expressao esq;
  protected Expressao dir;
  
  public ExpressaoBinaria(Expressao esq, Expressao dir) {
      this.esq = esq;
      this.dir = dir;
  }
  
  public double valor() {
      return op(esq.valor(), dir.valor());
  }
  
  abstract double op(double a, double b);
}