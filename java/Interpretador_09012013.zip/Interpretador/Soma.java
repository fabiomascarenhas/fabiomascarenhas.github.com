
public class Soma extends ExpressaoBinaria {
  public Soma(Expressao esq, Expressao dir) {
      super(esq, dir);
  }
  
  public double op(double a, double b) {
      return a + b;
  }
}