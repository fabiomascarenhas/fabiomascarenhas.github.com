
public class Sub extends ExpressaoBinaria {
  public Sub(Expressao esq, Expressao dir) {
      super(esq, dir);
  }
  
  public double op(double a, double b) {
      return a - b;
  }
}