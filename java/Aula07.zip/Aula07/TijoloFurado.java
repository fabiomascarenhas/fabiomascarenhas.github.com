public class TijoloFurado implements Tijolo {
    double x; 
    double y;
    Cor cor = new Cor(Math.random(), Math.random(), Math.random());
    Hitbox caixaEsq;
    Hitbox caixaDir;

    public TijoloFurado(double _x, double _y) {
        x = _x;
        y = _y;
        caixaEsq = new Hitbox(x, y, x + larg/4, y + alt);
        caixaDir = new Hitbox(x + larg - larg/4, y, x + larg, y + alt);
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, larg/4, alt, cor);
        t.retangulo(x + larg - larg/4, y, larg/4, alt, cor);
    }
    
    public void desligar() {
        caixaEsq = new Hitbox(-larg, -alt, 0, 0);
        caixaDir = new Hitbox(-larg, -alt, 0, 0);
        cor = new Cor(0, 0, 0);
    }
    
    public int getPontos() {
        return 5;
    }
    
    private boolean testaColisao(Hitbox caixa, Bola b) {
        int lado = b.getCaixa().intersecao(caixa);
        if(lado == Hitbox.TOPO) {
            b.sobe();
        }
        if(lado == Hitbox.FUNDO) {
            b.desce();
        }
        if(lado == Hitbox.ESQUERDO) {
            b.esquerda();
        }
        if(lado == Hitbox.DIREITO) {
            b.direita();
        }
        return lado > 0;
    }
    
    public boolean testaColisao(Bola b) {
        return testaColisao(caixaEsq, b) || testaColisao(caixaDir, b);
    }
}