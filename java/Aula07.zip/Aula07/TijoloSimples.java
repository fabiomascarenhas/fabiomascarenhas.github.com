public class TijoloSimples implements Tijolo {
    double x; 
    double y;
    Cor cor = new Cor(Math.random(), Math.random(), Math.random());
    Hitbox caixa;

    public TijoloSimples(double _x, double _y) {
        x = _x;
        y = _y;
        caixa = new Hitbox(x, y, x + larg, y + alt);
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, larg, alt, cor);
    }
    
    public void desligar() {
        caixa = new Hitbox(-larg, -alt, 0, 0);
        cor = new Cor(0, 0, 0);
    }
    
    public int getPontos() {
        return 1;
    }
    
    public boolean testaColisao(Bola b) {
        int lado = b.getCaixa().intersecao(caixa);
        if(lado == Hitbox.TOPO) {
            b.sobe();
        }
        if(lado == Hitbox.FUNDO) {
            b.desce();
        }
        if(lado == Hitbox.ESQUERDO) {
            b.esquerda();
        }
        if(lado == Hitbox.DIREITO) {
            b.direita();
        }
        return lado > 0;
    }
}