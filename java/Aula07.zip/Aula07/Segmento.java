public class Segmento {
    int valor;
    
    public Segmento(int _valor) {
        valor = _valor;
    }
    
    public boolean tique() {
        if(valor == 0) {
            valor = 59;
            return true;
        } else {
            valor = valor - 1;
            return false;
        }
    }
    
    public boolean zerado() {
        return valor == 0;
    }
    
    public String getTexto() {
        return String.format("%02d", valor);
    }
}