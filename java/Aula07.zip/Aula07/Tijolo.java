public interface Tijolo {
    boolean testaColisao(Bola bola);
    int getPontos();
    void desenhar(Tela tela);
    void desligar();

    static int larg = 64;
    static int alt = 20;
}