import java.util.Set;

public interface Fase {
    void tique(Set<String> teclas, double dt);
    void desenhar(Tela tela);
    void tecla(String tecla);
}