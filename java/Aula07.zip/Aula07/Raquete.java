public class Raquete {
    double x;
    double y;
    Cor cor;
    double vx = 300;
    int larg = 100;
    int alt = 20;
    
    public Raquete(double cx, double iy, Cor _cor) {
        x = cx - larg/2;
        y = iy - alt;
        cor = _cor;
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, larg, alt, cor);
    }
    
    public void esquerda(double dt) {
        x = x - vx * dt;
    }

    public void direita(double dt) {
        x = x + vx * dt;
    }
    
    public Hitbox getCaixaEsquerda() {
        return new Hitbox(x, y, x + 30, y + alt);
    }
    
    public Hitbox getCaixaCentro() {
        return new Hitbox(x + 30, y, x + 70, y + alt);
    }
    
    public Hitbox getCaixaDireita() {
        return new Hitbox(x + 70, y, x + larg, y + alt);
    }
}