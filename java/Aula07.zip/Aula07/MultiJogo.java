import java.util.Set;

public class MultiJogo implements Jogo {
    Fase[] fases;
    int i;
    
    public MultiJogo() {
        i = 0;
        fases = new Fase[2];
        fases[0] = new Bolinha();
        fases[1] = new Breakout();
    }
    
    public void proximaFase() {
        i = (i + 1) % fases.length;
    }
    
    public String getTitulo() {
        return "Multiplos Jogos";
    }
    
    public int getLargura() {
        return 1024;
    }
    
    public int getAltura() {
        return 768;
    }
    
    public void tique(Set<String> teclas, double dt) {
        fases[i].tique(teclas, dt);
    }
    
    public void desenhar(Tela t) {
        fases[i].desenhar(t);
    }
    
    public void tecla(String tecla) {
        if(tecla.equals("enter")) {
            proximaFase();
        } else {
            fases[i].tecla(tecla);
        }
    }
    
    public static void main(String[] args) {
        new Motor(new MultiJogo());
    }
}