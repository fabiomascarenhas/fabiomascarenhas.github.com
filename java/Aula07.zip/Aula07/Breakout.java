import java.util.Set;

/*
 * Breakout
 */
public class Breakout implements Jogo, Fase {
    Bola b;
    Raquete r;
    Tijolo[] ts;
    int score;
    int vidas;
    boolean gameOver;
    Timer timer;
        
    public Breakout() {
        reset();
    }

    public void reset() {
        b = new Bola(getLargura()/2, getAltura()/2, 200, 200, Cor.AMARELO);
        r = new Raquete(getLargura()/2, getAltura(), Cor.BRANCO);
        int ts_por_lin = getLargura()/Tijolo.larg - 2;
        ts = new Tijolo[ts_por_lin * 6];
        for(int i = 0; i < ts.length; i++ ) {
            int lin = i / ts_por_lin;
            int col = i % ts_por_lin;
            if(Math.random() > 0.5) {
                ts[i] = new TijoloSimples(col * Tijolo.larg + Tijolo.larg,
                                          lin * Tijolo.alt + 200);
            } else {
                ts[i] = new TijoloFurado(col * Tijolo.larg + Tijolo.larg,
                                          lin * Tijolo.alt + 200);
            }                      
        }
        gameOver = false;
        score = 0;
        vidas = 3;
        timer = new Timer(900, 40, 1, 15, 36, Cor.BRANCO);
    }

    public String getTitulo() {
        return "Breakout";
    }

    public int getLargura() {
        return 1024;
    }

    public int getAltura() {
        return 768;
    }

    public void tique(Set<String> teclas, double dt) {
        if(gameOver) return;
        if(teclas.contains("left")) r.esquerda(dt);
        if(teclas.contains("right")) r.direita(dt);
        b.mover(dt);
        testaTimer(dt);
        testaColisaoBolaRaquete();
        testaColisaoBolaParedes();
        testaColisaoBolaTijolos();
        testaColisaoBolaFundo();
    }
    
    private void testaTimer(double dt) {
        timer.tique(dt);
        if(timer.zerado()) gameOver = true;
    }
    
    private void testaColisaoBolaFundo() {
        if(b.y - b.raio >= getAltura()) {
            vidas = vidas - 1;
            if(vidas == 0) {
                gameOver = true;
            } else {
                b = new Bola(getLargura()/2, getAltura()/2, 200, 200, Cor.AMARELO);
            }
        }
    }
    
    private void testaColisaoBolaTijolos() {
        for(Tijolo t: ts) {
            if(t.testaColisao(b)) {
                score = score + t.getPontos();
                t.desligar();
                break;
            }
        }
    }
    
    private void testaColisaoBolaParedes() {
        if(b.x - b.raio <= Tijolo.larg) { // parede esquerda
          b.direita();
        }
        if(b.x + b.raio >= getLargura() - Tijolo.larg) { // parede direita
          b.esquerda();
        }
        if(b.y - b.raio <= 100) { // parede de cima
          b.desce();
        }
    }
    
    private void testaColisaoBolaRaquete() {
        if(b.getCaixa().intersecao(r.getCaixaEsquerda()) > 0) {
            b.esquerda();
            b.sobe();
        } else if(b.getCaixa().intersecao(r.getCaixaDireita()) > 0) {
            b.direita();
            b.sobe();
        } else if(b.getCaixa().intersecao(r.getCaixaCentro()) > 0) {
            b.sobe();
        }
    }

    public void desenhar(Tela t) {
        t.retangulo(0, 50, getLargura(), 50, Cor.CINZA);
        t.retangulo(0, 50, Tijolo.larg, getAltura(), Cor.CINZA);
        t.retangulo(getLargura() - Tijolo.larg, 50, Tijolo.larg, getAltura(), Cor.CINZA);
        r.desenhar(t);
        for(Tijolo tij: ts) {
            tij.desenhar(t);
        }
        b.desenhar(t);
        timer.desenhar(t);
        t.texto("" + score, 500, 40, 36, Cor.BRANCO); 
        t.texto("" + vidas, 800, 40, 36, Cor.BRANCO); 
        if(gameOver) t.texto("GAME OVER", 400, 370, 50, Cor.BRANCO);
    }

    public void tecla(String t) {
        if(t.equals("escape")) {
            reset();
        }
    }
    
    public static void main(String[] args) {
        new Motor(new Breakout());
    }
}
