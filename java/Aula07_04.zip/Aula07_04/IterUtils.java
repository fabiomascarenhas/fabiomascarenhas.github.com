import java.util.ArrayList;

public class IterUtils {
    public static ArrayList<Integer> listaDeEnum(Iterador e) {
        ArrayList<Integer> lista = new ArrayList<Integer>();
        while(!e.acabou()) {
            try {
                lista.add(e.proximo());
            } catch(IteradorVazio iv) {
                throw new RuntimeException("bug no iterador " + e);
            }
        }
        return lista;
    }
}