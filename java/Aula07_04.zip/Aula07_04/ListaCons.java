public class ListaCons implements Lista {
    String primeiro;
    Lista resto;
    
    public ListaCons(String primeiro, Lista resto) {
        this.primeiro = primeiro;
        this.resto = resto;
    }
    
    public int tamanho() {
        return resto.tamanho() + 1;
    }
    
    public Lista adiciona(String s) {
        return new ListaCons(s, this);
    }
    
    public boolean contem(String s) {
        return s.equals(primeiro) || resto.contem(s);
    }
}