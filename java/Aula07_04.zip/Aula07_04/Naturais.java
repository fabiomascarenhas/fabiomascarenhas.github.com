public class Naturais implements Iterador {
    int n;
    
    public Naturais(int n) {
        this.n = n;
    }
    
    public int proximo() {
        int r = n;
        n = n + 1;
        return r;
    }
    
    public boolean acabou() {
        return false; // infinita
    }
}