import java.util.ArrayList;
import java.util.Iterator;

public class IteradorLista implements Iterador {
    Iterator<Integer> it;
    
    public IteradorLista(ArrayList<Integer> lista) {
        it = lista.iterator();
    }
    
    public int proximo() throws IteradorVazio {
        if(it.hasNext()) {
            return it.next();
        } else {
            throw new IteradorVazio();
        }
    }
    
    public boolean acabou() {
        return !it.hasNext();
    }
}