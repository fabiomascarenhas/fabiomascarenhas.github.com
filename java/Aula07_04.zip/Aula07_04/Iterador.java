public interface Iterador {
    int proximo() throws IteradorVazio;
    boolean acabou(); // final
}