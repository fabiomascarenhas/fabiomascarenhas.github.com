public class TesteEx {
    IteradorLista il = new IteradorLista(new java.util.ArrayList<Integer>());
    //Iterador il = new Naturais(1);
    
    int foo() throws IteradorVazio {
        int r = 1 + bar();
        System.out.println("foo");
        return r;
    }    
   
    int baz() throws IteradorVazio {
        try {
            int r = 3 + il.proximo();
            System.out.println("baz");
            return r;
        } finally {
            System.out.println("acabando/abandonando baz");
        }
    }

        int bar() throws IteradorVazio {
        int r = 0;
        try {
            try {
                r = 2 + baz();
            } catch(IteradorVazio iv) {
                iv.printStackTrace();
                throw iv;
            }
            System.out.println("bar");
        } catch(IteradorVazio iv) {
            iv.printStackTrace();
            throw iv;
        }
        return r;
    }

    public static void main(String[] args) {
        System.out.println("Olá");
        try {
            System.out.println((new TesteEx()).foo());
        } catch(IteradorVazio iv) {
            iv.printStackTrace();
        }
        System.out.println("Tchau");
    }
}