public interface Lista {
    int tamanho();
    Lista adiciona(String s);
    boolean contem(String s);
}
