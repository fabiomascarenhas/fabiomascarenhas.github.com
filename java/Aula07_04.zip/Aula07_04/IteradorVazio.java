public class IteradorVazio extends Exception {
    public IteradorVazio() {
        super("iterador não tem mais elementos");
    }
}
