public class OutraClasse {
}