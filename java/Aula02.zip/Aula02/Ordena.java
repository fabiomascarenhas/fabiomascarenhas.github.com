
public class Ordena {
	static java.util.Scanner scan = new java.util.Scanner(System.in);
	
	public static void main(String[] args)
	{
	    int[] vetor = new int[5];
	    int i; 
	    boolean trocou = false;
	    int fim = vetor.length;
	    int temp;
	    System.out.println("Entre com um vetor de " + vetor.length + " elementos");
	    for (i = 0; i < vetor.length; i++) {
	    	System.out.println("Elemento " + i);
	    	vetor[i] = scan.nextInt();
	    }
	    for (i=0; i < vetor.length; i++) System.out.println(vetor[i]);
	    do {
	        trocou = false;
	        for (i=0; i < fim-1; i++) {
	            if (vetor[i] > vetor[i+1]) {
	                temp = vetor[i];
	                vetor[i] = vetor[i+1];
	                vetor[i+1] = temp;
	                trocou = true;
	            }
	        }
	        fim--;
	    } while (trocou);
	    for (i=0; i < vetor.length; i++) System.out.println(vetor[i]);
	}

}
