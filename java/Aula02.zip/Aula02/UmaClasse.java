public class UmaClasse {
    int i;
    double d;
    String s;
    boolean b;
    int[] v;
    OutraClasse oc;
    
    public UmaClasse(int i, double vd) {
        // this é uma referência para a instância de UmaClasse sendo inicializada
        this.i = i;
        d = vd / 2;
        s = "foo";
        b = true;
        oc = new OutraClasse();
    }
}
