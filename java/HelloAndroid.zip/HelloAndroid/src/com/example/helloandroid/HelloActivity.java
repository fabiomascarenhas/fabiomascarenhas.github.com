package com.example.helloandroid;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class HelloActivity extends Activity {

	// Pseudo-construtor
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Conecta layout � aplica��o
        setContentView(R.layout.fragment_hello);
        final TextView labelHello = (TextView)this.findViewById(R.id.textView1);
        labelHello.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				labelHello.setText(R.string.app_name);
			}
		});
    }
}
