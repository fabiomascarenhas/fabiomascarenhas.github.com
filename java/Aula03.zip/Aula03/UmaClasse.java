public class UmaClasse {
    int i;
    double d;
    String s;
    boolean b;
    int[] v;
    OutraClasse oc;
    
    public UmaClasse(int _i, double vd) {
        // this é uma referência para a instância de UmaClasse sendo inicializada
        i = _i;
        d = vd / 2;
        s = "foo";
        b = true;
        oc = new OutraClasse();
    }
    
    public UmaClasse(int _i, double _d, String _s, boolean _b, int tv) {
        i = _i;
        d = _d;
        s = _s;
        b = _b;
        v = new int[tv];
        oc = new OutraClasse();
    }
    
    public void dobraNumeros() {
        multNumeros(2);
    }
    
    public void multNumeros(int i) {
        this.i = this.i * i;
        d = d * i;
    }
    
    public OutraClasse getOc() {
        return oc;
    }
}
