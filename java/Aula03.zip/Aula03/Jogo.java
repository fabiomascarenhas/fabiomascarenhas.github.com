import java.util.Set;

/*
 * Exemplo simples que usa as classes do motor de jogo
 */
public class Jogo {
	public int tamanho;
	public double G;
	public double x;
	public double y;
	public double vx;
	public double vy;
	public Cor cor;
	
	public Jogo() {
	    tamanho = 30;
	    G = 500;
	    x = getLargura() / 2;
	    y = getAltura() / 2;
	    vx = 300;
	    vy = 0;
	    cor = new Cor(Math.random(), Math.random(), Math.random());
	}
	
	public void hit() {
		cor = new Cor(Math.random(), Math.random(), Math.random());
		Motor.tocar("ball.wav");
	}
	
	
	public String getTitulo() {
		return "Bola";
	}

	public int getLargura() {
		return 1024;
	}

	public int getAltura() {
		return 768;
	}

	public void tique(Set<String> keys, double dt) {
		x = x + vx * dt;
		if(x > getLargura() - tamanho * 2) {
			hit();
			vx = -vx;
			x = getLargura() - tamanho * 2;
		}
		if(x < 0) {
			hit();
			vx = -vx;
			x = 0;
		}
		vy = vy + G * dt;
		y = y + vy * dt;
		if(y > getAltura() - tamanho * 2) {
			hit();
			vy = -vy;
			y = getAltura() - tamanho * 2;
		}
		if(y < 0) {
			hit();
			vy = -vy;
			y = 0;
		}
	}

	public void desenhar(Tela c) {
		c.circulo(x + tamanho, y + tamanho, tamanho, cor);
	}

	public void tecla(String c) {
		if(c.equals(" ")) {
			x = getLargura() / 2 - tamanho;
			y = getAltura() / 2 - tamanho;
			vx = 300;
			vy = 0;
		}
	}

	public static void main(String[] args) {
		new Motor(new Jogo());
	}
}
