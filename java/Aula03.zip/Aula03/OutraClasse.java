public class OutraClasse {
    int i;
    
    public int soma(int j) {
        i = i + j;
        return i;
    }
}