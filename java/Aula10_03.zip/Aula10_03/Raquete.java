import java.util.HashSet;

public class Raquete {
    // Coordenadas do canto superior esquerdo
    double x;
    double y;
    Cor cor = Cor.rgbDouble(Math.random(), Math.random(), Math.random());
    int largura = 100;
    int altura = 10;
    Hitbox caixaE, caixaC, caixaD;

    // Campo da classe
    static double vx = 300;

    Raquete(double x_centro, double y_inferior) {
        x = x_centro - 25;
        y = y_inferior - 10;
        caixaE = new Hitbox((int)x, (int)y, (int)x+30, (int)y + altura);
        caixaC = new Hitbox((int)x+30, (int)y, (int)x+70, (int)y + altura);
        caixaD = new Hitbox((int)x+70, (int)y, (int)x+100, (int)y + altura);
    }
    
    void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
    
    void tique(HashSet<String> teclas, double dt) {
        if(teclas.contains("left") && x > 50) {
            x -= vx * dt;
        }
        if(teclas.contains("right") && x < 700) {
            x += vx * dt;
        }
        caixaE.mover((int)x, (int)y, (int)x+30, (int)y + altura);
        caixaC.mover((int)x+30, (int)y, (int)x+70, (int)y + altura);
        caixaD.mover((int)x+70, (int)y, (int)x+100, (int)y + altura);
    }
    
    void testaColisao(Bola bola) {
        if(bola.caixa.intersecao(caixaE) != 0 && bola.vy > 0) {
            bola.esquerda();
            bola.refletirY();
        } else if(bola.caixa.intersecao(caixaC) != 0  && bola.vy > 0) {
            bola.refletirY();
        } else if(bola.caixa.intersecao(caixaD) != 0 && bola.vy > 0) {
            bola.direita();
            bola.refletirY();
        }
    }
}