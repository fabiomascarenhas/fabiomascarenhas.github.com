public class Timer
{
    int x, y;
    Segmento minutos;
    Segmento segundos;
    
    double tempo = 0.0;
    
    Timer(int x, int y, int minutos, int segundos) {
        this.x = x;
        this.y = y;
        this.minutos = new Segmento(minutos);
        this.segundos = new Segmento(segundos);
    }
    
    boolean tique(double dt) {
        tempo += dt;
        if(tempo > 1) {
            tempo -= 1;
            if(segundos.desce()) {
                return minutos.desce();
            }
        }
        return false;
    }
    
    void desenhar(Tela t) {
        t.texto(minutos.texto() + ":" + segundos.texto(),
            x, y, 32, Cor.BRANCO);
    }
}
