public class TijoloSimples implements Tijolo {
    int x;
    int y;
    Cor cor;
    Hitbox caixa;
    int pontos;
    int vidas;
    int fatorV;

    static int largura = 50;
    static int altura = 10;

    TijoloSimples(int x, int y, int pontos, Cor cor) {
        this.x = x;
        this.y = y;
        this.cor = cor;
        this.pontos = pontos;
        caixa = new Hitbox(x, y, x + largura, y + altura);
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, largura, altura, cor);
    }
    
    public boolean testaColisao(Bola bola) {
        // Verificar colisão de bola com tijolo
        int lado = bola.caixa.intersecao(caixa); 
        if(lado == 1 || lado == 3) { // acima ou abaixo
            bola.refletirY();
            return true;
        }
        if(lado == 2 || lado == 4) { // esquerda ou direita
            bola.refletirX();
            return true;
        }
        return false;
    }
    
    public int pontos() {
        return pontos;
    }
}