public class Segmento
{
    int valor;
    
    Segmento(int valor) {
        this.valor = valor;
    }
    
    boolean desce() {
        if(valor == 0) {
            valor = 59;
            return true;
        } else {
            valor = valor - 1;
            return false;
        }
    }
    
    String texto() {
        if(valor < 10) {
            return "0" + valor;
        } else {
            return "" + valor;
        }
    }
}
