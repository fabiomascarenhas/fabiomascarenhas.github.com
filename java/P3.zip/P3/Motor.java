public interface Motor<T> {
    void adiciona(Regra<? super T> r, Acao<? super T> a);
    void remove(Regra<? super T> r);
    void executa(T obj);
}