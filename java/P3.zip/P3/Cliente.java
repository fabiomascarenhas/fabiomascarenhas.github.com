public class Cliente {
    public int idade;
    public boolean vip;
    public String aniv;
    
    public Cliente(int idade, boolean vip, String aniv) {
        this.idade = idade;
        this.vip = vip;
        this.aniv = aniv;
    }
}