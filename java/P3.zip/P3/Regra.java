// Questão 1
public abstract class Regra<T> {
    // Regra se aplica ao objeto passado ou não
    public abstract boolean seAplica(T obj);
    
    // Opção 1 (podemos combinar Regra<Cliente> e Regra<Object>, dando Regra<Cliente>):
    //public Regra<T> e(Regra<? super T> outra) {
    // Opção 2 (equivalente à 1):
    //public <S super T> Regra<T> e(Regra<S> outra) {
    // Opção 3 (podemos combinar Regra<Cliente> e Regra<Object>, dando Regra<Object>)):
    //public <S super T> Regra<S> e(Regra<S> outra) {
    // Opção 4 (podemos combinar Regra<Object> e Regra<Cliente>, dando Regra<Cliente>):
    //public <S extends T> Regra<S> e(Regra<S> outra) {
    public Regra<T> e(Regra<T> outra) {    
        return new RegraE<T>(this, outra);
    }
    
    // Mesmas opções para o método e
    public Regra<T> ou(Regra<T> outra) {
        return new RegraOu<T>(this, outra);
    }
    
    public Regra<T> nao() {
        return new RegraNao<T>(this);
    }
}