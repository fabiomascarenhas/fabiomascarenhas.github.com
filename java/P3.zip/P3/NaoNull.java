public class NaoNull extends Regra<Object> {
    public boolean seAplica(Object obj) {
        return obj != null;
    }
}