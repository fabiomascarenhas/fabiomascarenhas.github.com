public interface Acao<T> {
    public void executa(T obj);
}