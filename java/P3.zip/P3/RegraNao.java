// Questão 3
public class RegraNao<T> extends Regra<T> {
    private Regra<T> uma;
    
    public RegraNao(Regra<T> uma) {
        this.uma = uma;
    }
    
    public boolean seAplica(T obj) {
        return !uma.seAplica(obj);
    }
}
