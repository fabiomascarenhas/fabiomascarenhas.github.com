// Questão 4
// poderia ser mais genérico:
// public class Vip<T extends Cliente> extends Regra<T>
public class Vip extends Regra<Cliente> {
    public Vip() {}
    
    // Mais genérico:
    // public boolean seAplica(T c)
    public boolean seAplica(Cliente c) {
        return c.vip;
    }
}