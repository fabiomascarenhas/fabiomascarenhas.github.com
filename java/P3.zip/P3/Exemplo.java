public class Exemplo
{
    static Regra<Cliente> vip = new Vip();
    static Regra<Cliente> idoso = new Idoso();
    static Regra<Cliente> anivMaio = new Aniversariante("05");

    static Regra<Cliente> regra1 = anivMaio.e(vip).e(idoso.nao());
    static Regra<Cliente> regra2 = anivMaio.ou(vip).ou(idoso);
    
    static MotorRegras<Cliente> motor = new MotorRegras<Cliente>();
    
    static Cliente c1 = new Cliente(50, true, "06/05");
    static Cliente c2 = new Cliente(65, false, "06/06");
    static Cliente c3 = new Cliente(50, true, "06/06");
    static Cliente c4 = new Cliente(50, false, "06/05");
    
    static {
       motor.adiciona(regra1, new Acao<Cliente>() {
           public void executa(Cliente c) {
               System.out.println("vip, não idoso, nascido em maio");
           }
       });
       motor.adiciona(regra2, new Acao<Cliente>() {
           public void executa(Cliente c) {
               System.out.println("ou vip ou idoso ou nascido em maio");
           }
       });
    }
}
