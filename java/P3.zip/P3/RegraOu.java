// Questão 3
public class RegraOu<T> extends Regra<T> {
    private Regra<T> uma;
    private Regra<T> outra;
    
    public RegraOu(Regra<T> uma, Regra<T> outra) {
        this.uma = uma;
        this.outra = outra;
    }
    
    public boolean seAplica(T obj) {
        return uma.seAplica(obj) || outra.seAplica(obj);
    }
}
