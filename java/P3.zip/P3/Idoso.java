// Questão 4
// poderia ser mais genérico:
// public class Idoso<T extends Cliente> extends Regra<T>
public class Idoso extends Regra<Cliente> {
    public Idoso() {}
    
    // Mais genérico:
    // public boolean seAplica(T c)
    public boolean seAplica(Cliente c) {
        return c.idade >= 60;
    }
}