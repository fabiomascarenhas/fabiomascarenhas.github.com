import java.util.HashMap;

// Questão 2
public class MotorRegras<T> implements Motor<T> {
    private HashMap<Regra<? super T>, Acao<? super T>> mapa;
    
    public MotorRegras() {
        mapa = new HashMap<Regra<? super T>, Acao<? super T>>();
    }
    
    public void adiciona(Regra<? super T> r, Acao<? super T> a) {
        mapa.put(r, a);
    }
    
    public void remove(Regra<? super T> r) {
        mapa.remove(r);
    }
    
    // Executa a primeira regra que se aplica
    public void executa(T obj) {
        for(Regra<? super T> r: mapa.keySet()) {
            if(r.seAplica(obj)) {
                mapa.get(r).executa(obj);
                break;
            }
        }
    }
}