// Questão 4
// poderia ser mais genérico:
// public class Aniversariante<T extends Cliente> extends Regra<T>
public class Aniversariante extends Regra<Cliente> {
    String mes;
    
    public Aniversariante(String mes) {
        this.mes = mes;
    }
    
    // Mais genérico:
    // public boolean seAplica(T c)
    public boolean seAplica(Cliente c) {
        return c.aniv.endsWith(mes);
    }
}
