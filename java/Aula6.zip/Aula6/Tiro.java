
/**
 * Tiro do canhão
 */
public class Tiro
{
    // Coordenas de tela
    public double x;
    public double y;
    // De onde esse tiro saiu
    private Canhao origem;
    // Cor
    private Cor cor = new Cor("branco");
    // Vivo ou morto
    private boolean vivo = true;
    
    // Velocidade de *todos* os tiros
    private static double vy = -Jogo.ALTURA/3;
    public static int ALTURA = 5;
    public static int LARGURA = 2;
    
    public Tiro(Canhao origem, double x, double y) {
        this.x = x;
        this.y = y;
        this.origem = origem;
    }
    
    public void desenhar(Tela tela) {
        if(this.vivo) {
            tela.retangulo((int)(x + LARGURA/2), (int)y, 
                LARGURA, ALTURA, cor);
        }
    }
    
    public void mover(double dt, Alien[] aliens) {
        if(this.vivo) {
            this.y = this.y + vy * dt;
            for(Alien alien: aliens) {
                if(alien.colidiu(this)) {
                    this.vivo = false;
                    alien.morrer();
                    origem.pontue();
                }
            }
        }
    }
    
    public void morra() {
        this.vivo = false;
    }
}
