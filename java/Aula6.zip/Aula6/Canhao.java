
/**
 * Canhão do jogo
 */
public class Canhao
{
    // Posição em coordenadas de tela
    private double x;
    private double y = Jogo.ALTURA;
    // Pontos desse jogador
    private int score;
    private int scoreX;
    private int scoreY;
    // Cor
    private Cor cor;

    // Velocidade
    private static double vx = Jogo.LARGURA/4;
    private static int tamanho = 40;

    public Canhao(double x, int scoreX, int scoreY, Cor cor) {
        this.x = x;
        this.cor = cor;
        this.scoreX = scoreX;
        this.scoreY = scoreY;
    }
    
    public Canhao(double x, double y, int score, int scoreX, int scoreY, Cor cor) {
        this.x = x;
        this.y = y;
        this.score = score;
        this.cor = cor;
        this.scoreX = scoreX;
        this.scoreY = scoreY;
    }
    
    /*
     * direcao: -1 (esquerda), 0 (parado), 1 (direita)
     */
    public void mover(int direcao, double dt) {
        this.x = this.x + direcao * vx * dt;
        if(this.x + tamanho > Jogo.LARGURA)
            this.x = Jogo.LARGURA - tamanho;
        if(this.x < 0)
            this.x = 0;
    }
    
    public void desenhar(Tela tela) {
        tela.triangulo(
            (int)Math.round(x), (int)Math.round(y),
            (int)Math.round(x + tamanho), (int)Math.round(y),
            (int)Math.round(x + tamanho/2), 
              (int)Math.round(y - tamanho),
            cor);
        tela.texto(String.valueOf(score),
            scoreX, scoreY, new Cor("branco"));
    }
    
    public Tiro atirar() {
        return new Tiro(this, x + tamanho/2, y - tamanho);
    }
    
    public void pontue() {
        this.score += 50;
    }
}
