// java.util é o *pacote*
// ArrayList é a classe
import java.util.ArrayList;
import java.util.HashSet;
import java.awt.event.KeyEvent;

/**
 * Tabuleiro de Jogo
 */
public class Jogo
{
    // Jogadores
    private Canhao jogador1;
    private Canhao jogador2;
    
    // Alienígenas
    private Alien[] aliens;

    // Tiros
    private ArrayList<Tiro> tiros;
    
    // Acabou?
    private boolean gameOver = false;
    
    // Tamanho da tela
    public static int LARGURA = 800;
    public static int ALTURA = 600;
    public static String TITULO = "Space Invaders";
    
    public Jogo() {
        this.jogador1 = new Canhao(LARGURA/3, 20, 20, new Cor("vermelho"));
        this.jogador2 = new Canhao(2*LARGURA/3, 700, 20, new Cor("azul"));
        this.tiros = new ArrayList<Tiro>();
        this.aliens = new Alien[40];
        int x0 = 100; // Posição dos aliens da primeira coluna
        int y0 = 100; // Posição dos aliens da primeira linha
        int dx = 50;  // Distância entre colunas
        int dy = 50;  // Distância entre linhas
        for(int i = 0; i < 4; i++) {
            for(int j = 0; j < 10; j++) {
                aliens[i*10+j] = new Alien(
                    x0 + j * dx,
                    y0 + i * dy,
                    new Cor(
                        (int)(Math.random() * 255),
                        (int)(Math.random() * 255),
                        (int)(Math.random() * 255)
                   )
                );
            }
        }
    }

    public void desenhar(Tela tela) {
        jogador1.desenhar(tela);
        jogador2.desenhar(tela);
        for(Alien alien: aliens) {
            alien.desenhar(tela);
        }
        for(Tiro tiro: tiros) {
            tiro.desenhar(tela);
        }
        if(gameOver)
            tela.texto("GAME OVER", 350, 250, new Cor("branco"));
    }
    
    public void tecla(String tecla) {
        if(!gameOver) {
            Tiro t = null;
            if(tecla.equals("z"))
                t = jogador1.atirar();
            if(tecla.equals(","))
                t = jogador2.atirar();
            if(t != null) tiros.add(t);
        }
    }
        
    public void tique(HashSet<String> teclas, double dt) {
        if(!gameOver) {
            if(teclas.contains("q"))
                jogador1.mover(-1, dt);
            if(teclas.contains("e"))
                jogador1.mover(1, dt);
            if(teclas.contains("i"))
                jogador2.mover(-1, dt);
            if(teclas.contains("p"))
                jogador2.mover(1, dt);
            for(Tiro tiro: tiros) {
                tiro.mover(dt, aliens);
            }
            boolean bateu = false;
            for(Alien alien: aliens) {
                // Cuidado com o curto circuito!!!
                bateu = alien.mover(dt) || bateu;
                if(alien.pousou()) gameOver = true;
            }
            if(bateu) Alien.inverter();
        }
    }

    public static void main(String[] args) {
        Motor motor = new Motor(new Jogo());
    }
}

