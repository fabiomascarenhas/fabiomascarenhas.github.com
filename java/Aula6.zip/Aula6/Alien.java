
/**
 * Alienígena do "Space Invaders"
 */
public class Alien
{
    // Posição em "coordenadas de tela"
    private double x;
    private double y;
    // Cor
    private Cor cor;
    // Vivo ou morto
    private boolean vivo = true;
    
    // Velocidade inicial de *todos* os aliens
    private static double vx = Jogo.LARGURA/4;
    private static double vy = Jogo.ALTURA/60;
    private static int tamanho = 30;
    
    /*
     * Construtor
     */ 
    public Alien(double x, double y, Cor cor) {
        // this é o objeto Alien que acabou
        // de ser criado
        this.y = y;
        this.x = x;
        this.cor = cor;
    }

    /*
     * Faz o movimento do alienígena em um intervalo de tempo dt
     * em segundos
     */
    public boolean mover(double dt) {
        if(this.vivo) {
            // this é a instância na qual o método foi chamado
            this.x = this.x + vx * dt;
            this.y = this.y + vy * dt;
            if(vx > 0 && this.x + tamanho > Jogo.LARGURA) {
                return true;
            }
            if(vx < 0 && this.x < 0) {
                return true;
            }
        }
        return false;
    }
    
    public static void inverter() {
        vx = -vx;
    }
    
    public void desenhar(Tela tela) {
        if(this.vivo) {
            tela.quadrado((int)Math.round(x),
                          (int)Math.round(y),
                          tamanho,
                          cor);
        }
    }
    
    public void morrer() {
        this.vivo = false;
    }
    
    public boolean colidiu(Tiro t) {
        return this.vivo &&
               t.x + t.LARGURA > this.x &&
               t.x < this.x + this.tamanho &&
               t.y + t.ALTURA > this.y &&
               t.y < this.y + this.tamanho;
    }

    public boolean pousou() {
        return y + tamanho >= Jogo.ALTURA;
    }
}



