
public class EstadoSoma extends EstadoOp {

	public EstadoSoma(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public EstadoCalc estadoAumenta(ModeloCalc calc) {
		return new EstadoSomaAumenta(calc);
	}
	
	@Override
	public OpCalc criaOp(int dir) {
		return new OpSoma(dir);
	}
	
}
