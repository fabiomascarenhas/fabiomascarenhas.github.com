
public interface ObservadorDisplay {
	void mudouDisplay(int valor);
}
