
public class EstadoMultAumenta extends EstadoOpAumenta {
	
	public EstadoMultAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public OpCalc criaOp(int dir) {
		return new OpMult(dir);
	}
	
}
