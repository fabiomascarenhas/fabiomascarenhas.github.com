
public interface EstadoCalc {
	void digito(int n);
	void soma();
	void sub();
	void mult();
	void div();
	void igual();
}
