
public class Botao implements Componente {
	// canto superior esquerdo e inferior direito
	int x1, y1, x2, y2;
	// texto do bot�o e tamanho da fonte
	String texto;
	int fonte;
	// a��o a executar no clique
	Acao acao;
	
	public Botao(int x, int y, int largura, int altural, String texto, int fonte, Acao acao) {
		// TODO: construtor do bot�o
	}
	
	public int getX1() {
		return x1;
	}

	public int getY1() {
		return y1;
	}

	public int getX2() {
		return x2;
	}

	public int getY2() {
		return y2;
	}

	public void desenhar(Tela t) {
		// TODO: c�digo para desenhar o bot�o
	}

	public void clique(int x, int y) {
		// TODO: c�digo para executar a a��o do bot�o
	}

	public void aperto(int x, int y) {
		// TODO: c�digo para inverter a cor do bot�o
		// cor do texto vira cor do fundo, cor do fundo vira cor do texto
	}

	public void solta(int x, int y) {
		// TODO: c�digo para inverter a cor do bot�o
		// cor do texto vira cor do fundo, cor do fundo vira cor do texto
	}

	public void arrasto(int x, int y) {}

}
