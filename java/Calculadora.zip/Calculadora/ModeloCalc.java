
public class ModeloCalc {
	private EstadoCalc estado;
	
	private int display;
	private int operando;
	private OpCalc ultimaOp;
	
	public ModeloCalc() {
		reset();
	}
	
	public void digito(int i) {
		estado.digito(i);
	}
	
	public void soma() {
		estado.soma();
	}
	
	public void sub() {
		estado.sub();
	}
	
	public void mult() {
		estado.mult();
	}
	
	public void div() {
		estado.div();
	}

	public void igual() {
		estado.igual();
	}
	
	public void reset() {
		display = 0;
		operando = 0;
		ultimaOp = new OpSoma(0);
		estado = new EstadoNormal(this);
	}
	
	public void setEstado(EstadoCalc estado) {
		this.estado = estado;
	}
	
	public int getDisplay() {
		return display;
	}
	
	public void setDisplay(int display) {
		this.display = display;
	}
	
	public void setOperando(int operando) {
		this.operando = operando;
	}

	public OpCalc getUltimaOp() {
		return ultimaOp;
	}

	public void setUltimaOp(OpCalc ultimaOp) {
		this.ultimaOp = ultimaOp;
	}

	public int getOperando() {
		return operando;
	}
}
