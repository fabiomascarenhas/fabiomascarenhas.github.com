public class ModeloCalc {
	private EstadoCalc estado;
	
	private int display;
	private int operando;
	private OpCalc ultimaOp;

	private ObservadorDisplay obs;
	
	public ModeloCalc() {
		reset();
	}
	
	public void digito(int i) {
		estado.digito(i);
	}
	
	public void soma() {
		estado.soma();
	}
	
	public void sub() {
		estado.sub();
	}
	
	public void mult() {
		estado.mult();
	}
	
	public void div() {
		estado.div();
	}

	public void igual() {
		estado.igual();
	}
	
	public void reset() {
		setDisplay(0);
		setOperando(0);
		setUltimaOp(new OpSoma(0));
		setEstado(new EstadoNormal(this));
	}
	
	void setEstado(EstadoCalc estado) {
		this.estado = estado;
	}
	
	int getDisplay() {
		return display;
	}
	
	void setDisplay(int display) {
		this.display = display;
		notificar();
	}
	
	void setOperando(int operando) {
		this.operando = operando;
	}

	OpCalc getUltimaOp() {
		return ultimaOp;
	}

	void setUltimaOp(OpCalc ultimaOp) {
		this.ultimaOp = ultimaOp;
	}

	int getOperando() {
		return operando;
	}

	public void setObservador(ObservadorDisplay obs) {
		this.obs = obs;
	}

	private void notificar() {
		if(obs != null) obs.mudouDisplay(display);
	}
}
