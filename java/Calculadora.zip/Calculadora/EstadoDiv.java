
public class EstadoDiv extends EstadoOp {

	public EstadoDiv(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public EstadoCalc estadoAumenta(ModeloCalc calc) {
		return new EstadoDivAumenta(calc);
	}
	
	@Override
	public OpCalc criaOp(int dir) {
		return new OpDiv(dir);
	}
	
}
