
public abstract class OpCalc {
	protected int dir;
	
	public OpCalc(int dir) {
		this.dir = dir;
	}
	
	public abstract int faz(int esq);
}
