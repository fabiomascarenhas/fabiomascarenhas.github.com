import java.util.HashSet;

public class Jogo {
	public String getTitulo() {
	    return "Frogger";
	}
	
	public int getLargura() {
	    return 800;
	}
	
	public int getAltura() {
	    return 600;
	}
	
	public void tique(HashSet<String> teclas, double dt) {}
	
	public void desenhar(Tela tela) {}
	
	public void tecla(String tecla) {}
	
    public static void main(String[] args) {
        new Motor(new Jogo());
    }
}
