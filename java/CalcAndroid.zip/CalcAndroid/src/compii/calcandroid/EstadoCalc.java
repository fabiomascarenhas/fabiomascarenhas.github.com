package compii.calcandroid;

import java.io.Serializable;

public interface EstadoCalc extends Serializable {
	void digito(int n);
	void soma();
	void sub();
	void mult();
	void div();
	void igual();
}
