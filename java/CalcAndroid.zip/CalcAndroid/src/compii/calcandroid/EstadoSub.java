package compii.calcandroid;

public class EstadoSub extends EstadoOp {

	public EstadoSub(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public EstadoCalc estadoAumenta(ModeloCalc calc) {
		return new EstadoSubAumenta(calc);
	}
	
	@Override
	public OpCalc criaOp(int dir) {
		return new OpSub(dir);
	}
	
}
