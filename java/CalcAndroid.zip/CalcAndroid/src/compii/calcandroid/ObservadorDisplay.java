package compii.calcandroid;

public interface ObservadorDisplay {
	void mudouDisplay(int valor);
}
