package compii.calcandroid;

public class OpSub extends OpCalc {
	
	public OpSub(int dir) {
		super(dir);
	}

	public int faz(int esq) {
		return esq - dir;
	}
}
