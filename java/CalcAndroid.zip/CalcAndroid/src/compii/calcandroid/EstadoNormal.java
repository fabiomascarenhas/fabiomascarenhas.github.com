package compii.calcandroid;

public class EstadoNormal implements EstadoCalc {
	protected ModeloCalc calc;
	
	public EstadoNormal(ModeloCalc calc) {
		this.calc = calc;
	}
	
	@Override
	public void digito(int n) {
		calc.setDisplay(n);
		calc.setEstado(new EstadoNormalAumenta(calc));
	}

	@Override
	public void soma() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoSoma(calc));
	}

	@Override
	public void sub() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoSub(calc));
	}

	@Override
	public void mult() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoMult(calc));
	}

	@Override
	public void div() {
		calc.setOperando(calc.getDisplay());
		calc.setEstado(new EstadoDiv(calc));
	}

	@Override
	public void igual() {
		calc.setDisplay(
				calc.getUltimaOp().faz(calc.getDisplay()));
		calc.setEstado(new EstadoNormal(calc));
	}

}
