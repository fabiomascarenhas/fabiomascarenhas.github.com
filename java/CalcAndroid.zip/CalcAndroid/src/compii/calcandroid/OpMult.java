package compii.calcandroid;

public class OpMult extends OpCalc {
	
	public OpMult(int dir) {
		super(dir);
	}

	public int faz(int esq) {
		return esq * dir;
	}
}
