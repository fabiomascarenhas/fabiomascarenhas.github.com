package compii.calcandroid;

public class EstadoSubAumenta extends EstadoOpAumenta {
	
	public EstadoSubAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public OpCalc criaOp(int dir) {
		return new OpSub(dir);
	}
	
}
