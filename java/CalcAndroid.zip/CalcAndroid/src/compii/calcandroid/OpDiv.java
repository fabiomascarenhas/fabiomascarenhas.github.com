package compii.calcandroid;

public class OpDiv extends OpCalc {
	
	public OpDiv(int dir) {
		super(dir);
	}

	public int faz(int esq) {
		return esq / dir;
	}
}
