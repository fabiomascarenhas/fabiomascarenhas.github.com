package compii.calcandroid;

import java.io.Serializable;

public abstract class OpCalc implements Serializable {
	protected int dir;
	
	public OpCalc(int dir) {
		this.dir = dir;
	}
	
	public int getDir() {
		return dir;
	}
	
	public abstract int faz(int esq);
}
