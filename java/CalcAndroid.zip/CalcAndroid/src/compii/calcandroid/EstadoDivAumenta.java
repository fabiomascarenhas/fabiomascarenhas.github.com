package compii.calcandroid;

public class EstadoDivAumenta extends EstadoOpAumenta {
	
	public EstadoDivAumenta(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public OpCalc criaOp(int dir) {
		return new OpDiv(dir);
	}
	
}
