package compii.calcandroid;

import java.lang.reflect.InvocationTargetException;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.os.Build;

public class CalcActivity extends Activity {
    ModeloCalc calc = new ModeloCalc();
	
    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        if(estado != null && estado.containsKey("modelo")) {
        	calc = (ModeloCalc)estado.getSerializable("modelo");
        }
        setContentView(R.layout.layout_calc);
        View.OnClickListener listenerDig = new View.OnClickListener() {
			@Override
			public void onClick(View bot) {
				Button b = (Button)bot;
				calc.digito(Integer.parseInt(b.getText().toString()));
			}
		};
        this.findViewById(R.id.digito0).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito1).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito2).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito3).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito4).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito5).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito6).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito7).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito8).setOnClickListener(listenerDig);
        this.findViewById(R.id.digito9).setOnClickListener(listenerDig);
        this.findViewById(R.id.soma).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				calc.soma();
			}
		});
        this.findViewById(R.id.sub).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				calc.sub();
			}
		});
        this.findViewById(R.id.mult).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				calc.mult();
			}
		});
        this.findViewById(R.id.div).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				calc.div();
			}
		});
        this.findViewById(R.id.igual).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				calc.igual();;
			}
		});
        this.findViewById(R.id.reset).setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				calc.reset();
			}
		});
        final TextView display = (TextView)this.findViewById(R.id.display);
        calc.setObservador(new ObservadorDisplay() {
			@Override
			public void mudouDisplay(int valor) {
				display.setText(String.valueOf(valor));
			}
        });
        calc.notificar();
        /*if(estado != null && estado.containsKey("display")) {
        	calc.setDisplay(estado.getInt("display"));
        	calc.setOperando(estado.getInt("operando"));
        	try {
				calc.setUltimaOp((OpCalc)(Class.forName(estado.getString("opcalc")).getConstructor(int.class).newInstance(estado.getInt("opcalc_dir"))));
				calc.setEstado((EstadoCalc)(Class.forName(estado.getString("estado")).getConstructor(ModeloCalc.class).newInstance(calc)));
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
        }*/
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.calc, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSaveInstanceState(Bundle estado) {
    	/*estado.putInt("display", calc.getDisplay());
    	estado.putInt("operando", calc.getOperando());
    	estado.putInt("opcalc_dir", calc.getUltimaOp().getDir());
    	estado.putString("opcalc", calc.getUltimaOp().getClass().getName());
    	estado.putString("estado", calc.getEstado().getClass().getName());*/
    	estado.putSerializable("modelo", calc);
    }
}
