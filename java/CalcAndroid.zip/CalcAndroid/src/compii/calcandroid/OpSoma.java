package compii.calcandroid;

public class OpSoma extends OpCalc {
	
	public OpSoma(int dir) {
		super(dir);
	}

	public int faz(int esq) {
		return esq + dir;
	}
}
