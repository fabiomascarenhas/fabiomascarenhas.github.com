package compii.calcandroid;

public class EstadoMult extends EstadoOp {

	public EstadoMult(ModeloCalc calc) {
		super(calc);
	}

	@Override
	public EstadoCalc estadoAumenta(ModeloCalc calc) {
		return new EstadoMultAumenta(calc);
	}
	
	@Override
	public OpCalc criaOp(int dir) {
		return new OpMult(dir);
	}
	
}
