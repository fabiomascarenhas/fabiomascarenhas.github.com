package compii.recebeimagem;

import android.app.Activity;
import android.app.ActionBar;
import android.app.Fragment;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.os.Build;

public class RecebeImagem extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_recebe_imagem);
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();
        ImageView img = (ImageView)this.findViewById(R.id.img);
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if (type.startsWith("image/")) {
                Uri imageUri = (Uri)intent.getParcelableExtra(Intent.EXTRA_STREAM);
                if (imageUri != null) {
                    img.setImageURI(imageUri);
                }
            }    
        }
    }


}
