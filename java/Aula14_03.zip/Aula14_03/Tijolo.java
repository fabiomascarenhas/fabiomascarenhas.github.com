public interface Tijolo
{
    boolean testaColisao(Bola b);
    void desenhar(Tela t);
    int pontos();
}
