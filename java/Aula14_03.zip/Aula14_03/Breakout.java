import java.util.ArrayList;
import java.util.HashSet;

public class Breakout implements Jogo, Fase {
    public Bola bola = new Bola(400, 300);
    public Raquete raquete = new Raquete(400, 600);
    public HashSet<Tijolo> tijolos = new HashSet<Tijolo>();
    public int score = 0;
    public int vidas = 3;
    public boolean pausa = false;
    public Timer relogio = new Timer(500, 30, 1, 15);
    
    private Hitbox paredeE = new Hitbox(0, 50, 50, 600);
    private Hitbox paredeC = new Hitbox(50, 50, 750, 100);
    private Hitbox paredeD = new Hitbox(750, 50, 800, 600);
    private Hitbox chao = new Hitbox(50, 600, 750, 700);
    
    public Breakout() {
        int y = 150;
        int pontos = 60;
        for(int i = 0; i < 6; i++) {
            Cor cor = Cor.rgbDouble(Math.random(), Math.random(), Math.random());
            int x = 50;
            for(int j = 0; j < 14; j++) {
                tijolos.add(j % 3 == 0 ?
                    new TijoloFurado(x, y)
                    : new TijoloSimples(x, y, pontos, cor));
                x += TijoloSimples.largura;
            }
            y += TijoloSimples.altura;
            pontos -= 10;
        }
    }
    
    public String getTitulo() {
        return "Breakout";
    }
    
    public int getLargura() {
        return 800;
    }
    
    public int getAltura() {
        return 600;
    }
    
    public void desenhar(Tela t) {
        t.texto("" + score, 100, 30, 32, Cor.BRANCO);
        t.texto("" + vidas, 300, 30, 32, Cor.BRANCO);
        bola.desenhar(t);
        raquete.desenhar(t);
        for(Tijolo tijolo: tijolos) {
            tijolo.desenhar(t);
        }
        this.paredes(t);
        relogio.desenhar(t);
        if(vidas == 0)
            t.texto("GAME OVER", 350, 250, 48, Cor.BRANCO); 
    }
    
    private void paredes(Tela t) {
        t.retangulo(0, 50, 50, 550, Cor.BRANCO);
        t.retangulo(50, 50, 700, 50, Cor.BRANCO);
        t.retangulo(750, 50, 50, 550, Cor.BRANCO);
    }
    
    private void testaColisaoParedes() {
        if(bola.caixa.intersecao(paredeE) != 0 && bola.vx < 0) { // parede esquerda
            bola.refletirX();
        }
        if(bola.caixa.intersecao(paredeD) != 0 && bola.vx > 0) { // parede direita
            bola.refletirX();
        }
        if(bola.caixa.intersecao(paredeC) != 0 && bola.vy < 0) { // parede cima
            bola.refletirY();
        }
    }

    private void testaColisaoTijolos() {
        ArrayList<Tijolo> remover = new ArrayList<Tijolo>();
        for(Tijolo tijolo: tijolos) {
            if(tijolo.testaColisao(bola)) {
                remover.add(tijolo);
                score += tijolo.pontos();
            }
        }
        tijolos.removeAll(remover);
    }

    private void testaColisaoChao() {
        if(bola.caixa.intersecao(chao) != 0) {
            vidas--;
            bola = new Bola(400, 300);
        }
    }

    private void testaTimer(double dt) {
        if(relogio.tique(dt)) {
            vidas = 0;
        }
    }
    
    public void tique(HashSet<String> teclas, double dt) {
        if(vidas == 0 || pausa) return;
        bola.tique(dt);
        raquete.tique(teclas, dt);
        raquete.testaColisao(bola);
        testaColisaoParedes();
        testaColisaoTijolos();
        testaColisaoChao();
        testaTimer(dt);
    }
    
    public boolean toque(HashSet<String> teclas, double dt) {
        tique(teclas, dt);
        return tijolos.isEmpty();
    }
    
    public void tecla(String tecla) {
        if(tecla.equals(" ")) {
            pausa = !pausa;
        }
    }
}

