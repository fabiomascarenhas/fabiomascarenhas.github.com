
public class Sapo {
	private double x1;
	private double y1;
	private double x2;
	private double y2;
	private int vidas;
	private Cor cor;
	
	private static int raio = 30;
	private static int v = 300;
	
	public Sapo(double x, double y, int vidas, Cor cor) {
		this.x1 = this.x2 = x;
		this.y1 = this.y2 = y;
		this.vidas = vidas;
		this.cor = cor;
	}
	
	public void desenhar(Tela tela) {
		tela.circulo(x1, y1, raio, cor);
		tela.texto(String.valueOf(vidas), 750, 550, 40, Cor.AZUL);
	}
	
	public void mover(double dt) {
		if(x1 < x2) {
			x1 = x1 + dt * v;
			if(x1 - raio >= Frogger.LARGURA) {
				x1 -= Frogger.LARGURA;
				x2 -= Frogger.LARGURA;
			}
			if(x1 > x2) x1 = x2;
		} else if(x1 > x2) {
			x1 = x1 - dt * v;
			if(x1 + raio <= 0) {
				x1 += Frogger.LARGURA;
				x2 += Frogger.LARGURA;
			}
			if(x1 < x2) x1 = x2;
		}
		if(y1 < y2) {
			y1 = y1 + dt * v;
			if(y1 > y2) y1 = y2;
		} else if(y1 > y2) {
			y1 = y1 - dt * v;
			if(y1 < y2) y1 = y2;
		}
	}
	
	public void pular(String dir) {
		if(dir.equals("up"))
			y2 -= 100;
		if(dir.equals("down"))
			y2 += 100;
		if(dir.equals("left"))
			x2 -= 100;
		if(dir.equals("right"))
			x2 += 100;
	}
	
	public boolean chegou() {
	    return y1 > 0 && y1 < 100;
	}
}
