import java.util.HashSet;

public class Frogger implements Jogo, Fase {
	private Carro[] carros;
	private Sapo sapo;
	
	public static int LARGURA = 800;
	public static int ALTURA = 600;
	public static String TITULO = "Frogger";
	
	public Frogger() {
		sapo = new Sapo(400, 535, 3, Cor.VERDE);
		carros = new Carro[2+1+3+3];
		// Linha 1
		carros[0] = new Carro(191, 100, 100, LARGURA/5, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		carros[1] = new Carro(457, 100, 100, LARGURA/5, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		// Linha 2
		carros[2] = new Carro(350, 200, 150, LARGURA/2, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		// Linha 3
		carros[3] = new Carro(160, 300, 60, LARGURA/8, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		carros[4] = new Carro(360, 300, 60, LARGURA/8, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		carros[5] = new Carro(560, 300, 60, LARGURA/8, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		// Linha 4
		carros[6] = new Carro(160, 400, 60, LARGURA/6, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		carros[7] = new Carro(360, 400, 60, LARGURA/6, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
		carros[8] = new Carro(560, 400, 60, LARGURA/6, Cor.rgbInt(
                (int)(Math.random() * 255),
                (int)(Math.random() * 255),
                (int)(Math.random() * 255)
        ));
	}

	public String getTitulo() {
	    return TITULO;
	}
	
	public int getLargura() {
	    return LARGURA;
	}
	
	public int getAltura() {
	    return ALTURA;
	}
	
	public void desenhar(Tela tela) {
		tela.retangulo(0, 0, LARGURA, 75, Cor.BRANCO);
		tela.retangulo(0, 500, LARGURA, 75, Cor.BRANCO);
		for(Carro carro: carros)
			carro.desenhar(tela);
		sapo.desenhar(tela);
	}
	
	public void tique(HashSet<String> teclas, double dt) {
		for(Carro carro: carros) {
			carro.mover(dt);
		}
		sapo.mover(dt);
	}

	public boolean toque(HashSet<String> teclas, double dt) {
	    tique(teclas, dt);
	    return sapo.chegou();
	}
	   
	public void tecla(String tecla) {
		sapo.pular(tecla);
	}
	
    public static void main(String[] args) {
        Motor motor = new Motor(new Frogger());
    }

}
