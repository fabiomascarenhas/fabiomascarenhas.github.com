import java.util.HashSet;

public class MultiJogo implements Jogo
{
    String titulo;
    Fase[] fases;
    int atual;
    
    public MultiJogo(String titulo, Fase[] fases) {
        this.titulo = titulo;
        this.fases = fases;
        atual = 0;
    }
    
    public String getTitulo() {
        return titulo;
    }
    
    public int getAltura() {
        return 600;
    }
    
    public int getLargura() {
        return 800;
    }
    
    public void desenhar(Tela t) {
        fases[atual].desenhar(t);
    }
    
    public void tecla(String t) {
        if(t.equals("/"))
            proximaFase();
        else
            fases[atual].tecla(t);
    }
    
    public void tique(HashSet<String> teclas, double dt) {
        if(fases[atual].toque(teclas, dt))
            proximaFase();
    }
    
    void proximaFase() {
        atual = atual + 1;
        if(atual == fases.length)
            atual = 0;
    }
}
