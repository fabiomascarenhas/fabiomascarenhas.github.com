import java.util.HashSet;

// O Estado do padrão "Estado"
interface Fase {
  void tecla(String t);
  void desenhar(Tela t);
  // true indica que a fase terminou
  boolean toque(HashSet<String> teclas, double dt);
}