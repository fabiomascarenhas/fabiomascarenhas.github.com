
public class Carro {
	private double x;
	private double y;
	private int largura;
	private double vx;
	private Cor cor;
	
	private static int altura = 75;
	
	public Carro(double x, double y, int largura, double vx, Cor cor) {
		this.x = x;
		this.y = y;
		this.largura = largura;
		this.vx = vx;
		this.cor = cor;
	}
	
	public void desenhar(Tela tela) {
		tela.retangulo(x, y, largura, altura, cor);
	}
	
	public void mover(double dt) {
		x = x + dt * vx;
		if(vx > 0 && x >= Frogger.LARGURA)
			x = -largura;
		if(vx < 0 && x + largura <= 0)
			x = Frogger.LARGURA;
	}
}
