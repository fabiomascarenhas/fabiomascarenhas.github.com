public class ListaVetorObjeto implements ListaObjeto {
    Object[] v = new Object[1];
    int proximo = 0;
    
    public int tamanho() {
        return proximo;
    }

    private void checaInd(int i) {
        if(i < 0 || i >= proximo) {
            throw new IndexOutOfBoundsException();
        }
    }
    
    public Object le(int i) {
        checaInd(i);
        return v[i];
    }
    
    public void escreve(int i, Object s) {
        checaInd(i);
        v[i] = s;
    }
    
    public void adiciona(Object s) {
        if(proximo >= v.length) {
            Object[] nv = new Object[v.length*2];
            for(int i = 0; i < proximo; i++) {
                nv[i] = v[i];
            }
            v = nv;
        }
        v[proximo] = s;
        proximo = proximo + 1;
    }
}