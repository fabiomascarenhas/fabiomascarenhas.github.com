public interface Funcao<E,S> {
    S aplica(E x);
}
