public class Composta<E,I,S> implements Funcao<E,S> {
    private Funcao<E,I> f;
    private Funcao<I,S> g;
    
    public Composta(Funcao<E,I> f, Funcao<I,S> g) {
        this.f = f;
        this.g = g;
    }
    
    public S aplica(E x) {
        return g.aplica(f.aplica(x));
    }
}