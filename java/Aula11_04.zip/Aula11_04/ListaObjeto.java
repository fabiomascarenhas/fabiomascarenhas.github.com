
public interface ListaObjeto
{
    int tamanho();
    Object le(int i);
    void escreve(int i, Object s);
    void adiciona(Object s);
}
