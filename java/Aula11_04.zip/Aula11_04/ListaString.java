
public interface ListaString
{
    int tamanho();
    String le(int i);
    void escreve(int i, String s);
    void adiciona(String s);
}
