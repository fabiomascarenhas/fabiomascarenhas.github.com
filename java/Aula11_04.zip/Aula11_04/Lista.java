public interface Lista<E> {
    int tamanho();
    E le(int i);
    void escreve(int i, E e);
    void adiciona(E e);
    boolean contem(E e);
    void copiaDe(Lista<? extends E> l);
    void copiaPara(Lista<? super E> l);
    <S> Lista<S> coleta(Funcao<? super E,? extends S> f);
}