public class Revista extends ItemBibSuper implements ItemBib {
    private int volume;
    private int numero;

    public Revista(int categoria, String titulo,
               int volume, int numero, int dataEntrega) {
        super(categoria, titulo, dataEntrega);
        this.volume = volume;
        this.numero = numero;
    }
}