public class B extends A {
    public int fat(int n) {
        System.out.println("B: " + n);
        return super.fat(n);
    }
}