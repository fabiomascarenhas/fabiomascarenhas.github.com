public class CD extends ItemBibSuper implements ItemBib {
    private String artista;
    
    public CD(int categoria, String titulo,
                String artista, int dataEntrega) {
        super(categoria, titulo, dataEntrega);
        this.artista = artista;
    }
    
    public double multa(int hoje) {
        return super.multa(hoje) * 2;
    }
}