public class ItemBibSimples extends ItemBibSuper {
    public ItemBibSimples(String titulo) {
        super(100, titulo, 12500);
    }
}
