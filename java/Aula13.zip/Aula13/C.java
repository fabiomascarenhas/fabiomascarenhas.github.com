public class C extends B {
    java.util.HashMap<Integer, Integer> memo = new
        java.util.HashMap<Integer, Integer>();

    public int fat(int n) {
        System.out.println("C: " + n);
        if(n < 2)
            return 1;
        else
            return super.fat(n);    
    }
    
    public int fibo(int n) {
        if(memo.containsKey(n))
            return memo.get(n);
        int res = super.fibo(n);
        memo.put(n, res);
        return res;
    }
    
    public boolean equals(Object outro) {
        return (outro instanceof C);
    }
}