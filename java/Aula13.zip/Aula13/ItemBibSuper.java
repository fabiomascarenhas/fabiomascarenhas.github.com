public class ItemBibSuper {
    protected int categoria;
    protected String titulo;
    protected int dataEntrega;
    
    public ItemBibSuper(int categoria, String titulo,
            int dataEntrega) {
        this.categoria = categoria;
        this.titulo = titulo;
        this.dataEntrega = dataEntrega;
    }
    
    public boolean entregaAntes(ItemBibSuper outro) {
        return this.dataEntrega < outro.dataEntrega;
    }

    public int diasAtraso(int hoje) {
        return Math.max(hoje - dataEntrega, 0);
    }

    public double multa(int hoje) {
        return diasAtraso(hoje) * 1.5;
    }
}
