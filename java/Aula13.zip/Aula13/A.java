public class A {
    public int fat(int n) {
        System.out.println("A: " + n);
        return n * this.fat(n - 1);
    }
    
    public int fibo(int n) {
        if(n == 1 || n == 2) {
            return 1;
        } else {
            return fibo(n-1) + fibo(n-2);
        }
    }
    
    public String toString() {
        return "Objeto: " + super.toString();
    }
}
