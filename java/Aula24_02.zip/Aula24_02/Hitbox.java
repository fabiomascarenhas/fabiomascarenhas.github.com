// Retângulos para verificar colisões
public class Hitbox
{
    // Canto superior esquerdo e inferior direito
    int x0, y0, x1, y1;
    
    Hitbox(int x0, int y0, int x1, int y1) {
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
    }
    
    void mover(int x0, int y0, int x1, int y1) {
        this.x0 = x0;
        this.y0 = y0;
        this.x1 = x1;
        this.y1 = y1;
    }
    
    boolean dentro(int x, int y) {
        return x >= x0 && x <= x1 &&
               y >= y0 && y <= y1;
    }
    
    int intersecao(Hitbox hb) {
        double w = ((x1-x0) + (hb.x1 - hb.x0)) / 2;
        double h = ((y1-y0) + (hb.y1 - hb.y0)) / 2;
        double dx = ((x1 + x0) - (hb.x1 + hb.x0)) / 2;
        double dy = ((y1 + y0) - (hb.y1 + hb.y0)) / 2;

        if (Math.abs(dx) <= w && Math.abs(dy) <= h) {
            // colisão
            double wy = w * dy;
            double hx = h * dx;
            if (wy > hx) {
                if (wy > -hx) {
                    return 1;
                } else {
                    return 4;
                }
            } else {
                if (wy > -hx) {
                    return 2;
                } else {
                    return 3;
                }
            }
        }
        return 0;
    }
}
