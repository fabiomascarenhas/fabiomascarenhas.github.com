public class TijoloFurado implements Tijolo {
    int x;
    int y;
    Hitbox caixaE;
    Hitbox caixaD;

    TijoloFurado(int x, int y) {
        this.x = x;
        this.y = y;
        caixaE = new Hitbox(x, y, x + 10, y + TijoloSimples.altura);
        caixaD = new Hitbox(x + 40, y, x + 50, y + TijoloSimples.altura);
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, 10, TijoloSimples.altura, Cor.BRANCO);
        t.retangulo(x + 40, y, 10, TijoloSimples.altura, Cor.BRANCO);
    }
    
    public boolean testaColisao(Bola bola) {
        // Verificar colisão de bola com tijolo
        int lado = bola.caixa.intersecao(caixaE);
        if(lado == 0) {
            lado = bola.caixa.intersecao(caixaD);
        }
        if(lado == 1 || lado == 3) { // acima ou abaixo
            bola.refletirY();
            return true;
        }
        if(lado == 2 || lado == 4) { // esquerda ou direita
            bola.refletirX();
            return true;
        }
        return false;
    }
    
    public int pontos() {
        return 100;
    }
}