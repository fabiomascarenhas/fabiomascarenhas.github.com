import java.util.List;
import java.util.ArrayList;

public class Calculadora implements GuiApp {
    List<Componente> componentes;
    String texto = "";
    
    public Calculadora() {
        componentes = new ArrayList<Componente>();
        componentes.add(new Botao(0, 100, 100, 100, "7", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 7)));
        componentes.add(new Botao(100, 100, 100, 100, "8", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 8)));
        componentes.add(new Botao(200, 100, 100, 100, "9", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 9)));
        componentes.add(new Botao(300, 100, 100, 100, "+", Cor.BRANCO, Cor.PRETO, this::botaoMais));
        componentes.add(new Botao(0, 200, 100, 100, "4", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 4)));
        componentes.add(new Botao(100, 200, 100, 100, "5", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 5)));
        componentes.add(new Botao(200, 200, 100, 100, "6", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 6)));
        componentes.add(new Botao(300, 200, 100, 100, "-", Cor.BRANCO, Cor.PRETO, this::botaoMenos));
        componentes.add(new Botao(0, 300, 100, 100, "1", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 1)));
        componentes.add(new Botao(100, 300, 100, 100, "2", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 2)));
        componentes.add(new Botao(200, 300, 100, 100, "3", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 3)));
        componentes.add(new Botao(300, 300, 100, 100, "*", Cor.BRANCO, Cor.PRETO, this::botaoVezes));
        componentes.add(new Botao(0, 400, 100, 100, "C", Cor.BRANCO, Cor.PRETO, this::botaoReset));
        componentes.add(new Botao(100, 400, 100, 100, "0", Cor.BRANCO, Cor.PRETO, new AcaoDigito(this, 0)));
        componentes.add(new Botao(200, 400, 100, 100, "=", Cor.BRANCO, Cor.PRETO, this::botaoIgual));
        componentes.add(new Botao(300, 400, 100, 100, "/", Cor.BRANCO, Cor.PRETO, this::botaoDiv));
        componentes.add(new CaixaTexto(0, 0, 400, 100, Tela.CENTROY | Tela.DIREITA, this::getTextoDisplay, Cor.BRANCO, Cor.BRANCO, Cor.PRETO));
    }
    
    public String getTextoDisplay() {
        return texto;
    }

    public void botaoDigito(int digito) {
        texto = "" + digito;
    }
    
    public void botaoMais() {
        texto = "+";
    }

    public void botaoMenos() {
        texto = "-";
    }

    public void botaoVezes() {
        texto = "*";
    }

    public void botaoDiv() {
        texto = "/";
    }

    public void botaoIgual() {
        texto = "=";
    }

    public void botaoReset() {
        texto = "C";
    }

    public List<Componente> getComponentes() {
        return componentes;
    }
    
    public String getTitulo() {
        return "Calculadora";
    }
    
    public int getLargura() {
        return 400;
    }
    
    public int getAltura() {
        return 500;
    }
    
    public static void main(String[] args) {
        new Motor(new Calculadora());
    }
}