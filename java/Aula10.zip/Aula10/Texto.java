public interface Texto {
    String getTexto();
}