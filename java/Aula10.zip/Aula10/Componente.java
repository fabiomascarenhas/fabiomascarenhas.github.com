public interface Componente {
    int getX1();
    int getY1();
    int getX2();
    int getY2();
    void desenhar(Tela t);
    default void arrasto(int x, int y) {}
    default void clique(int x, int y) {}
    default void aperto(int x, int y) {}
    default void solta(int x, int y) {}
}