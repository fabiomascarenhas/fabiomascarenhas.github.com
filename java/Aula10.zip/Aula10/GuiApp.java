import java.util.List;
import java.util.Set;

public interface GuiApp extends App {
    List<Componente> getComponentes();
    default void tique(Set<String> teclas, double dt) {}
    default void tecla(String tecla) {}
    default void desenhar(Tela t) {
        for(Componente c: getComponentes()) {
            c.desenhar(t);
        }
    }
    default void movimento(int x, int y) {}
    default void arrasto(int x, int y) {}
    default void clique(int x, int y) {
        for(Componente c: getComponentes()) {
            if(x >= c.getX1() && x <= c.getX2() &&
               y >= c.getY1() && y <= c.getY2())
               c.clique(x, y);
        }
    }
    default void aperto(int x, int y) {
        for(Componente c: getComponentes()) {
            if(x >= c.getX1() && x <= c.getX2() &&
               y >= c.getY1() && y <= c.getY2())
               c.aperto(x, y);
        }
    }
    default void solta(int x, int y) {
        for(Componente c: getComponentes()) {
            if(x >= c.getX1() && x <= c.getX2() &&
               y >= c.getY1() && y <= c.getY2())
               c.solta(x, y);
        }
    }
}