public class AcaoMais implements Acao {
    Calculadora calc;
    
    public AcaoMais(Calculadora _calc) {
        calc = _calc;
    }
    
    public void executa() {
        calc.botaoMais();
    }
}