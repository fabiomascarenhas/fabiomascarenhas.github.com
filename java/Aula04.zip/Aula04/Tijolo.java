public class Tijolo {
    double x; 
    double y;
    Cor cor = new Cor(Math.random(), Math.random(), Math.random());
    static int larg = 64;
    static int alt = 20;
    
    public Tijolo(double _x, double _y) {
        x = _x;
        y = _y;
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, larg, alt, cor);
    }
}