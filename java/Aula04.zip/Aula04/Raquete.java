public class Raquete {
    double x;
    double y;
    Cor cor;
    int larg = 100;
    int alt = 20;
    
    public Raquete(double cx, double iy, Cor _cor) {
        x = cx - larg/2;
        y = iy - alt;
        cor = _cor;
    }
    
    public void desenhar(Tela t) {
        t.retangulo(x, y, larg, alt, cor);
    }
}