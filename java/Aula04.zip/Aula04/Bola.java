public class Bola {
    double x;
    double y;
    double vx;
    double vy;
    Cor cor;
    int raio = 8;
    
    public Bola(double _x, double _y, double _vx, double _vy, Cor _cor) {
        x = _x;
        y = _y;
        vx = _vx;
        vy = _vy;
        cor = _cor;
    }
    
    public void desenhar(Tela t) {
        t.circulo(x, y, raio, cor);
    }
}
