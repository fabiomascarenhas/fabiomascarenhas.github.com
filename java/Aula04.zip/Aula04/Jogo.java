import java.util.HashSet;

/*
 * Breakout
 */
public class Jogo {
    Bola b;
    Raquete r;
    Tijolo[] ts;
    int score;
    int vidas;
    
    static Cor cinza = new Cor(0.7, 0.7, 0.7);
    
    public Jogo() {
        b = new Bola(getLargura()/2, getAltura()/2, 100, 100, new Cor(0.0, 1.0, 1.0));
        r = new Raquete(getLargura()/2, getAltura(), new Cor("branco"));
        int ts_por_lin = getLargura()/Tijolo.larg - 2;
        ts = new Tijolo[ts_por_lin * 6];
        for(int i = 0; i < ts.length; i++ ) {
            int lin = i / ts_por_lin;
            int col = i % ts_por_lin;
            ts[i] = new Tijolo(col * Tijolo.larg + Tijolo.larg,
                               lin * Tijolo.alt + 200);
        }
    }
        
    public String getTitulo() {
        return "Breakout";
    }

    public int getLargura() {
        return 1024;
    }

    public int getAltura() {
        return 768;
    }

    public void tique(HashSet<String> teclas, double dt) {
    }

    public void desenhar(Tela t) {
        t.retangulo(0, 0, getLargura(), 50, cinza);
        t.retangulo(0, 0, Tijolo.larg, getAltura(), cinza);
        t.retangulo(getLargura() - Tijolo.larg, 0, Tijolo.larg, getAltura(), cinza);
        b.desenhar(t);
        r.desenhar(t);
        for(int i = 0; i < ts.length; i++) {
            ts[i].desenhar(t);
        }
    }

    public void tecla(String t) {
    }

    public static void main(String[] args) {
        new Motor(new Jogo());
    }
}
