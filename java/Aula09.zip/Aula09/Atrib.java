public class Atrib implements Comando {
    String var;
    Expressao exp;
    
    public Atrib(String _var, Expressao _exp) {
        var = _var;
        exp = _exp;
    }
    
    public void executa(java.util.Map<String,Double> vars) {
        double ve = exp.valor(vars);
        vars.put(var, ve);
    }
}