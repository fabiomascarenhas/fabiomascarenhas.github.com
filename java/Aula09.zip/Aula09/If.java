public class If implements Comando {
    Expressao cond;
    Comando cthen, celse;
    
    public If(Expressao _cond, Comando _cthen, Comando _celse) {
        cond = _cond;
        cthen = _cthen;
        celse = _celse;
    }
    
    public void executa(java.util.Map<String,Double> vars) {
        double vc = cond.valor(vars);
        if(vc != 0.0) {
            cthen.executa(vars);
        } else {
            celse.executa(vars);
        }
    }
}