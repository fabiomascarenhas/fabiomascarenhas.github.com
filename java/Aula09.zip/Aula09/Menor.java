public class Menor implements Expressao {
    Expressao esq, dir;
    
    public Menor(Expressao _esq, Expressao _dir) {
        esq = _esq;
        dir = _dir;
    }
    
    public double valor(java.util.Map<String,Double> vars) {
        if(esq.valor(vars) < dir.valor(vars)) {
            return 1.0;
        } else {
            return 0.0;
        }
    }
}