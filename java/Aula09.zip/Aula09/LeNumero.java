import java.util.Scanner;
import java.util.Map;

public class LeNumero implements Expressao {
    static Scanner STDIN = new Scanner(System.in);
    
    public LeNumero() {}
    
    public double valor(Map<String, Double> vars) {
        return STDIN.nextDouble();
    }
}