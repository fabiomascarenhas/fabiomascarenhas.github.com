public class Prog {
    static Comando c = new Bloco(
      new Atrib("x", new LeNumero()), // x = read()
      new Atrib("y", new Num(1.0)),   // y = 1
      new If(new Menor(new Var("x"), new Num(2.0)), // if(x < 2)
             new Imprime(new Num(1.0)),  // print(1)
             new Bloco( // else {
               new While(new Menor(new Num(1.0), new Var("x")), // while(1 < x) {
                         new Bloco(new Atrib("y", new Vezes(new Var("y"), new Var("x"))), // y = y * x
                                   new Atrib("x", new Menos(new Var("x"), new Num(1.0))))), // x = x - 1
               new Imprime(new Var("y"))))  // print(y) } }
    );
    
    public static void main(String[] args) {
        c.executa(new java.util.HashMap<String,Double>());
    }
}