public class Const implements Funcao {
    double c;
    
    public Const(double _c) {
        c = _c;
    }
    
    public double getValor(double ignorado) {
        return c;
    }
    
    public double getValor() {
        return c;
    }

    public String getFormula() {
        return String.format("%f", c);
    }
}