public interface Expressao {
    double valor(java.util.Map<String, Double> vars);
}