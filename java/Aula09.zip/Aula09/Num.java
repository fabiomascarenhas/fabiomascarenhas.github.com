public class Num implements Expressao {
    double n;
    
    public Num(double _n) {
        n = _n;
    }
    
    public double valor(java.util.Map<String,Double> vars) {
        return n;
    }
}