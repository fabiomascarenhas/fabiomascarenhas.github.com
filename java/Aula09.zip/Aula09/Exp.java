public class Exp implements Funcao {
    double b;
    
    public Exp(double _b) {
        b = _b;
    }
    
    public double getValor(double x) {
        return Math.pow(b, x);
    }
    
    public String getFormula() {
        return String.format("%f^x", b);
    }
}