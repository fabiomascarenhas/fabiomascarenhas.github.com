public class While implements Comando {
    Expressao cond;
    Comando corpo;
    
    public While(Expressao _cond, Comando _corpo) {
        cond = _cond;
        corpo = _corpo;
    }
    
    public void executa(java.util.Map<String,Double> vars) {
        while(cond.valor(vars) != 0.0) {
            corpo.executa(vars);
        }
    }
}