public class Bloco implements Comando {
    Comando[] cs;
    
    public Bloco(Comando... _cs) {
        cs = _cs;
    }
    
    public void executa(java.util.Map<String,Double> vars) {
        for(Comando c: cs) {
            c.executa(vars);
        }
    }
}