public class Div implements Expressao {
    Expressao esq, dir;
    
    public Div(Expressao _esq, Expressao _dir) {
        esq = _esq;
        dir = _dir;
    }
    
    public double valor(java.util.Map<String,Double> vars) {
        return esq.valor(vars) / dir.valor(vars);
    }
}