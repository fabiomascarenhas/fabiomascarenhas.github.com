import java.util.List;
import java.util.ArrayList;

public class Visualizador implements Jogo {
    List<Funcao> fs;
    int i;
    
    public Visualizador() {
        fs = new ArrayList<Funcao>();
        fs.add(new Const(5));
        fs.add(new Pot(2));
        fs.add(new Exp(2));
        fs.add(new Escala(0.5, fs.get(1)));
        fs.add(new Escala(0.5, fs.get(3)));
        fs.add(new Soma(new Escala(2, new Pot(1)), 
                        new Const(3)));
        fs.add(fs.get(5).derivada());
        fs.add(fs.get(1).derivada());
        for(int i = 0; i < 2; i++) {
          fs.add(new Funcao() {
              public String getFormula() {
                  return "<função por partes " + Visualizador.this.i + ">"; 
              }
              public double getValor(double x) {
                  if(x <= 2) return x;
                  else if(x > 2 && x <= 3) return 2;
                  else if(x > 3 && x <= 5) return 3;
                  else return resto(x);
              }
              public double resto(double x) { return x * x - 10 * x + 28; }
          });
        }
    }
    
    public String getTitulo() {
        return "Visualizador";
    }
    
    public int getLargura() {
        return 1024;
    }
    
    public int getAltura() {
        return 768;
    }
    
    public void tecla(String t) {
        if(t.equals("down")) {
            i = (i + 1) % fs.size();
        }
        if(t.equals("up")) {
            if(i == 0) i = fs.size()-1;
            else i = i - 1;
        }
    }
    
    public void desenhar(Tela t) {
        t.retangulo(getLargura()/2, 0, 1, getAltura(), Cor.BRANCO);
        t.retangulo(0, getAltura()/2, getLargura(), 1, Cor.BRANCO);
        for(int j = 0; j < getLargura(); j++) {
            double x = j/51.0 - 10.0;
            double y = fs.get(i).getValor(x);
            t.circulo(j, getAltura()/2 - y * 51, 2, Cor.BRANCO);
        }
        t.texto(fs.get(i).getFormula(), 10, 30, 24, Cor.BRANCO);
    }
    
    public void tique(java.util.Set<String> ts, double dt) {}
    
    public static void main(String[] args) {
        new Motor(new Visualizador());
    }
}
