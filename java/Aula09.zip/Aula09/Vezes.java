public class Vezes implements Expressao {
    Expressao esq, dir;
    
    public Vezes(Expressao _esq, Expressao _dir) {
        esq = _esq;
        dir = _dir;
    }
    
    public double valor(java.util.Map<String,Double> vars) {
        return esq.valor(vars) * dir.valor(vars);
    }
}