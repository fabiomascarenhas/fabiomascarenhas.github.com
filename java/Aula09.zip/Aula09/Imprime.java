public class Imprime implements Comando {
    Expressao exp;
    
    public Imprime(Expressao _exp) {
        exp = _exp;
    }
    
    public void executa(java.util.Map<String,Double> vars) {
        System.out.println(exp.valor(vars));
    }
}
