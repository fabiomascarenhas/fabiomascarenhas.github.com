public interface Comando {
    void executa(java.util.Map<String,Double> vars);
}