public class Soma implements Funcao {
    Funcao[] fs;
    
    public Soma(Funcao... _fs) {
        fs = _fs;
    }
    
    public double getValor(double x) {
        double s = 0.0;
        for(Funcao f: fs) {
            s = s + f.getValor(x);
        }
        return s;
    }
    
    public String getFormula() {
        String[] ffs = new String[fs.length];
        for(int i = 0; i < fs.length; i++) {
            ffs[i] = fs[i].getFormula();
        }
        return String.join("+", ffs);
    }
}