public class Var implements Expressao {
    String nome;
    
    public Var(String _nome) {
        nome = _nome;
    }
    
    public double valor(java.util.Map<String,Double> vars) {
        return vars.getOrDefault(nome, 0.0);
    }
}