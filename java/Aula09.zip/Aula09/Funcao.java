public interface Funcao {
    double getValor(double x);
    String getFormula();
    default Funcao derivada() {
        return new Derivada(this);
    }
}