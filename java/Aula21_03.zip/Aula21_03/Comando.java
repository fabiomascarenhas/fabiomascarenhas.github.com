public interface Comando {
    void desfazer();
    void refazer();
}