public class ListaVetorInteiro implements ListaInteiro {
    int[] v = new int[1];
    int proximo = 0;
    
    public int tamanho() {
        return proximo;
    }

    private void checaInd(int i) {
        if(i < 0 || i >= proximo) {
            throw new IndexOutOfBoundsException();
        }
    }
    
    public int le(int i) {
        checaInd(i);
        return v[i];
    }
    
    public void escreve(int i, int s) {
        checaInd(i);
        v[i] = s;
    }
    
    public void adiciona(int s) {
        if(proximo >= v.length) {
            int[] nv = new int[v.length*2];
            for(int i = 0; i < proximo; i++) {
                nv[i] = v[i];
            }
            v = nv;
        }
        v[proximo] = s;
        proximo = proximo + 1;
    }
}