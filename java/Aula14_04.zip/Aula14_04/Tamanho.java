public class Tamanho implements Funcao<String,Integer> {
    public Integer aplica(String s) {
        return s.length();
    }
}