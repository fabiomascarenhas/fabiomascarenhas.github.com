import java.util.Iterator;
import java.util.NoSuchElementException;

public class ListaVetor<E> implements Lista<E> {
    E[] v = (E[])new Object[1];
    int proximo = 0;
    
    public int tamanho() {
        return proximo;
    }

    private void checaInd(int i) {
        if(i < 0 || i >= proximo) {
            throw new IndexOutOfBoundsException();
        }
    }
    
    public E le(int i) {
        checaInd(i);
        return v[i];
    }
    
    public void escreve(int i, E s) {
        checaInd(i);
        v[i] = s;
    }
    
    public void adiciona(E s) {
        if(proximo >= v.length) {
            E[] nv = (E[])new Object[v.length*2];
            for(int i = 0; i < proximo; i++) {
                nv[i] = v[i];
            }
            v = nv;
        }
        v[proximo] = s;
        proximo = proximo + 1;
    }
    
    public boolean contem(E e) {
        for(int i = 0; i < proximo; i++) {
            if(v[i].equals(e))
                return true;
        }
        return false;
    }
    
    public void copiaDe(Lista<? extends E> l) {
        for(int i = 0; i < l.tamanho(); i++) {
            adiciona(l.le(i)); // retorna ?
        }
    }
    
    public void copiaPara(Lista<? super E> l) {
        for(int i = 0; i < tamanho(); i++) {
            l.adiciona(le(i)); // passando ?
        }
    }

    public <S> Lista<S> coleta(Funcao<? super E,? extends S> f) {
        Lista<S> nl = new ListaVetor<S>();
        for(int i = 0; i < tamanho(); i++) {
            nl.adiciona(f.aplica(le(i)));
        }
        return nl;
    }
    
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            int pos = 0;
            
            public boolean hasNext() {
                return pos < tamanho();
            }
            
            public E next() {
                if(pos < tamanho()) {
                    E elem = le(pos);
                    pos = pos + 1;
                    return elem;
                } else
                    throw new NoSuchElementException();
            }
            
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }
}