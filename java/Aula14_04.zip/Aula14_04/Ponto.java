public class Ponto extends FiguraPt {
    public Ponto(int x, int y) {
        // chamando construtor de FiguraPt
        super(x, y);
        System.out.println("construí um ponto!");
    }
    
    public boolean dentro(int x, int y) {
        return (x == this.x) && (y == this.y);
    }
    
    public void desenhar() {
        System.out.println("PONTO");
    }
    
    public void escala(double f) {}
}