public class Listas {
    public void imprime(Lista<String> ls) {
        for(String s: ls) System.out.println(s);
    }
    
    public void imprime(Lista<Integer> li) {
        for(int i: ls) System.out.println(i);
    }
}