public class ListaVetorString implements ListaString {
    String[] v = new String[1];
    int proximo = 0;
    
    public int tamanho() {
        return proximo;
    }

    private void checaInd(int i) {
        if(i < 0 || i >= proximo) {
            throw new IndexOutOfBoundsException();
        }
    }
    
    public String le(int i) {
        checaInd(i);
        return v[i];
    }
    
    public void escreve(int i, String s) {
        checaInd(i);
        v[i] = s;
    }
    
    public void adiciona(String s) {
        if(proximo >= v.length) {
            String[] nv = new String[v.length*2];
            for(int i = 0; i < proximo; i++) {
                nv[i] = v[i];
            }
            v = nv;
        }
        v[proximo] = s;
        proximo = proximo + 1;
    }
}