public class HashCode implements Funcao<Object,Integer> {
    public Integer aplica(Object o) {
        return o.hashCode();
    }
}