
public interface ListaInteiro
{
    int tamanho();
    int le(int i);
    void escreve(int i, int s);
    void adiciona(int s);
}
