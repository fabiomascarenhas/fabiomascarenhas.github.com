public class ListaFigura<E extends Figura> extends ListaVetor<E> {
    public void desenhar() {
        for(int i = 0; i < tamanho(); i++) {
            E fig = le(i);
            fig.desenhar();
        }
    }
}