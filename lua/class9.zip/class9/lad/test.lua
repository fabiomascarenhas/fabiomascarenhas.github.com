local a = 5
if a < 1 then
  a = a - 1
else
  a = a + 1
end
